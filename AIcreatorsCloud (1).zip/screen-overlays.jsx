/* ============================================================
   AIcreators.cloud · Overlays + Empty/Error states + Topic Detail
   ============================================================

   COMPONENTS in this file
     ToastHost           – global toast queue (mount once)
     NotificationsPanel  – right-drawer triggered from header bell
     SearchOverlay       – ⌘K spotlight search
     ConfirmDialog       – generic confirm modal
     TeamInviteModal     – invite team members
     VideoPreviewModal   – final video player + per-platform tabs
     TopicDetailScreen   – drop in from idea queue

     EmptyState / ErrorState — composable stubs

   BACKEND CONTRACTS
     Notifications:
       GET  /notifications?cursor=&unread_only=
       POST /notifications/mark-read    body: { ids[] }
       WS   /ws/notifications           – push new events
     Search:
       GET  /search?q=&types=videos,channels,topics&limit=
     Team:
       GET  /team
       POST /team/invite                body: { email, role }
       PATCH /team/{user_id}            body: { role }
       DELETE /team/{user_id}
   ============================================================ */

/* ------------------------------------------------------------
   TOAST SYSTEM
   Usage:
     window.toast({ kind:'success', title:'Saved', body?:'' })
   ------------------------------------------------------------ */
function ToastHost() {
  const [toasts, setToasts] = React.useState([]);

  React.useEffect(() => {
    window.toast = (t) => {
      const id = Math.random().toString(36).slice(2, 9);
      setToasts(prev => [...prev, { id, ...t }]);
      setTimeout(() => setToasts(prev => prev.filter(x => x.id !== id)), t.duration || 4500);
    };
    return () => { delete window.toast; };
  }, []);

  const palette = {
    success: { bg: 'var(--success-bg)', bd: 'var(--success-bd)', fg: 'var(--success)', icon: 'Check' },
    info:    { bg: 'var(--info-bg)',    bd: 'var(--info-bd)',    fg: 'var(--info-fg)', icon: 'Help' },
    warning: { bg: 'var(--warning-bg)', bd: 'var(--warning-bd)', fg: 'var(--warning-fg)', icon: 'Warn' },
    danger:  { bg: 'var(--danger-bg)',  bd: 'var(--danger-bd)',  fg: 'var(--danger-fg)', icon: 'Close' },
    magic:   { bg: 'var(--magic-tint)', bd: 'var(--accent-border-soft)', fg: 'var(--accent-fg)', icon: 'Sparkles' },
  };

  return (
    <div style={{
      position: 'fixed', bottom: 20, right: 20, zIndex: 2000,
      display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end',
      pointerEvents: 'none',
    }}>
      {toasts.map(t => {
        const p = palette[t.kind || 'info'];
        return (
          <div key={t.id} style={{
            minWidth: 280, maxWidth: 400, padding: 12,
            background: 'var(--bg-surface)', border: `1px solid ${p.bd}`,
            borderLeft: `3px solid ${p.fg}`,
            borderRadius: 12, boxShadow: 'var(--shadow-modal)',
            display: 'flex', gap: 10, alignItems: 'flex-start',
            pointerEvents: 'auto', animation: 'aiShimmer 0s',
          }}>
            <span style={{ width: 26, height: 26, borderRadius: 8, background: p.bg, color: p.fg, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              {React.createElement(I[p.icon], { size: 14 })}
            </span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{t.title}</div>
              {t.body && <div className="t-small" style={{ marginTop: 4 }}>{t.body}</div>}
            </div>
            <button className="btn btn--ghost btn--icon btn--sm" style={{ width: 24, height: 24 }} onClick={() => setToasts(prev => prev.filter(x => x.id !== t.id))}>
              <I.Close size={12}/>
            </button>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------
   NOTIFICATIONS PANEL — right drawer
   ------------------------------------------------------------ */
const MOCK_NOTIFS = [
  { id: 'n1', kind: 'review',     ago: '2 min',  title: 'Detective with no name needs your review', body: 'Keyframes stage paused — 8 frames ready', icon: 'Eye',    color: 'var(--warning)', unread: true,  link: 'project/p4/images' },
  { id: 'n2', kind: 'publish',    ago: '14 min', title: 'Published to YouTube',                       body: 'The Lost Library of Alexandria · @mythictales', icon: 'Youtube', color: '#FF0000', unread: true, link: 'library' },
  { id: 'n3', kind: 'publish',    ago: '15 min', title: 'Cross-posted to Instagram + TikTok',         body: 'Auto-reformatted to 9:16 · captioned for each platform', icon: 'Megaphone', color: 'var(--accent-fg)', unread: true },
  { id: 'n4', kind: 'job',        ago: '32 min', title: 'Motion stage finished',                       body: 'Volcanic lightning · 8/8 clips · ready for voice', icon: 'Film',   color: 'var(--accent-fg)', unread: false },
  { id: 'n5', kind: 'opportunity',ago: '1 h',    title: 'Trending topic for Mythic Tales',             body: '"Antikythera mechanism, decoded" · 95% fit', icon: 'TrendUp', color: 'var(--success)', unread: false, link: 'topics' },
  { id: 'n6', kind: 'system',     ago: '3 h',    title: 'GPU pool back to full capacity',              body: 'Renders are running ~30% faster again', icon: 'Lightning', color: 'var(--success)', unread: false },
  { id: 'n7', kind: 'billing',    ago: '1 day',  title: 'Studio Pro renews in 12 days',                body: '5,000 credits will refill on May 29', icon: 'Credit', color: 'var(--fg-default)', unread: false },
];

function NotificationsPanel({ open, onClose }) {
  const [tab, setTab] = React.useState('all');
  const items = tab === 'unread' ? MOCK_NOTIFS.filter(n => n.unread) : MOCK_NOTIFS;

  if (!open) return null;
  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, zIndex: 1100,
      background: 'rgba(0,0,0,0.30)', display: 'flex', justifyContent: 'flex-end',
      animation: 'aiShimmer 0s',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: 420, height: '100%', background: 'var(--bg-surface)',
        borderLeft: '1px solid var(--border-default)',
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ padding: '18px 22px 14px', borderBottom: '1px solid var(--border-hairline)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <I.Bell size={18}/>
            <span className="t-h4">Notifications</span>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', marginTop: 12, gap: 12 }}>
            <Tabs value={tab} onChange={setTab} items={[
              { id: 'all',    label: 'All' },
              { id: 'unread', label: 'Unread · 3' },
            ]}/>
            <div style={{ flex: 1 }}/>
            <Btn kind="ghost" size="sm">Mark all read</Btn>
          </div>
        </div>

        <div style={{ flex: 1, overflowY: 'auto' }}>
          {items.map((n, i) => (
            <div key={n.id} style={{
              padding: '14px 22px',
              borderBottom: '1px solid var(--border-hairline)',
              background: n.unread ? 'var(--surface-subtle)' : 'transparent',
              display: 'flex', alignItems: 'flex-start', gap: 12, cursor: 'pointer',
              transition: 'background 120ms var(--ease-out)',
            }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
              onMouseLeave={e => e.currentTarget.style.background = n.unread ? 'var(--surface-subtle)' : 'transparent'}>
              <span style={{
                width: 34, height: 34, borderRadius: 10,
                background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: n.color, flexShrink: 0,
              }}>{React.createElement(I[n.icon], { size: 16 })}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                  <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)', flex: 1 }}>{n.title}</div>
                  {n.unread && <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent-strong)', flexShrink: 0, marginTop: 4 }}/>}
                </div>
                <div className="t-small" style={{ marginTop: 4 }}>{n.body}</div>
                <div className="t-small" style={{ marginTop: 6, color: 'var(--fg-faint)' }}>{n.ago}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ padding: '14px 22px', borderTop: '1px solid var(--border-hairline)', display: 'flex', justifyContent: 'space-between' }}>
          <Btn kind="ghost" size="sm" icon={I.Settings}>Settings</Btn>
          <a href="#" className="t-small" style={{ color: 'var(--brand)' }}>Open all notifications</a>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------
   SEARCH OVERLAY — ⌘K
   ------------------------------------------------------------ */
function SearchOverlay({ open, onClose, onNavigate }) {
  const [q, setQ] = React.useState('');
  if (!open) return null;

  // Build results from MOCK data
  const lc = q.toLowerCase();
  const projects = MOCK.projects.filter(p => !q || p.title.toLowerCase().includes(lc)).slice(0, 5);
  const channels = MOCK.channels.filter(c => !q || c.name.toLowerCase().includes(lc)).slice(0, 3);
  const topics   = MOCK.topicIdeas.filter(t => !q || t.title.toLowerCase().includes(lc)).slice(0, 5);
  const pages    = [
    { label: 'Production Line', route: 'dashboard', icon: 'Pipeline' },
    { label: 'Channels',        route: 'channels',  icon: 'Youtube' },
    { label: 'Topics & Calendar', route: 'topics',  icon: 'Calendar' },
    { label: 'Voice Library',   route: 'voices',    icon: 'Mic' },
    { label: 'Avatars & Lip Sync', route: 'avatars', icon: 'User' },
    { label: 'Visual Styles',   route: 'styles',    icon: 'Image' },
    { label: 'Integrations',    route: 'integrations', icon: 'Globe' },
    { label: 'Analytics',       route: 'analytics', icon: 'BarChart' },
    { label: 'Billing & Plan',  route: 'billing',   icon: 'Credit' },
    { label: 'Help & Support',  route: 'help',      icon: 'Help' },
  ].filter(p => !q || p.label.toLowerCase().includes(lc));

  const navigate = (r) => {
    const parts = r.split('/');
    onNavigate(...parts);
    onClose();
  };

  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, zIndex: 1200,
      background: 'rgba(0,0,0,0.40)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
      paddingTop: 80,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', maxWidth: 640,
        background: 'var(--bg-surface)', border: '1px solid var(--border-default)',
        borderRadius: 16, boxShadow: 'var(--shadow-modal)',
        display: 'flex', flexDirection: 'column', maxHeight: '70vh',
      }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <I.Search size={18} stroke="var(--fg-muted)"/>
          <input value={q} onChange={e => setQ(e.target.value)} autoFocus placeholder="Search videos, channels, topics, settings…"
                 style={{ border: 0, padding: 0, height: 'auto', font: '500 17px/1 var(--font-sans)', background: 'transparent' }}/>
          <span style={{ padding: '4px 8px', borderRadius: 6, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', font: '600 11px/1 var(--font-mono)', color: 'var(--fg-muted)' }}>esc</span>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '4px 0' }}>
          {projects.length > 0 && (
            <SearchSection title="Projects" results={projects.map(p => ({ id: p.id, label: p.title, sub: STAGE_BY_ID[p.stage].label, icon: 'Film', onClick: () => navigate(`project/${p.id}`) }))}/>
          )}
          {channels.length > 0 && (
            <SearchSection title="Channels" results={channels.map(c => ({ id: c.id, label: c.name, sub: `${c.subs} subscribers`, icon: 'Youtube', onClick: () => navigate(`channel/${c.id}`) }))}/>
          )}
          {topics.length > 0 && (
            <SearchSection title="Topics" results={topics.map(t => ({ id: t.id, label: t.title, sub: `${t.score} score · ${t.est}`, icon: 'Spark', onClick: () => navigate('topics') }))}/>
          )}
          {pages.length > 0 && (
            <SearchSection title="Pages" results={pages.map(p => ({ id: p.route, label: p.label, sub: '', icon: p.icon, onClick: () => navigate(p.route) }))}/>
          )}
          {projects.length + channels.length + topics.length + pages.length === 0 && (
            <div style={{ padding: 60, textAlign: 'center' }} className="t-small">No results for "{q}"</div>
          )}
        </div>

        <div style={{ padding: '10px 18px', borderTop: '1px solid var(--border-hairline)', display: 'flex', gap: 16 }}>
          {[['↵','select'],['↑↓','navigate'],['esc','close']].map(([k, l]) => (
            <span key={k} className="t-small">
              <span style={{ padding: '2px 6px', borderRadius: 4, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', font: '600 11px/1 var(--font-mono)', color: 'var(--fg-default)' }}>{k}</span> {l}
            </span>
          ))}
          <div style={{ flex: 1 }}/>
          <span className="t-small">Powered by <span className="fg-grad">AI</span></span>
        </div>
      </div>
    </div>
  );
}

function SearchSection({ title, results }) {
  return (
    <div>
      <div style={{ padding: '10px 18px 4px', font: '700 10px/1 var(--font-sans)', letterSpacing: '0.10em', color: 'var(--fg-faint)', textTransform: 'uppercase' }}>{title}</div>
      {results.map(r => (
        <div key={r.id} onClick={r.onClick} style={{
          padding: '10px 18px',
          display: 'flex', alignItems: 'center', gap: 12,
          cursor: 'pointer',
        }}
          onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
          <span style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', color: 'var(--fg-default)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            {React.createElement(I[r.icon], { size: 14 })}
          </span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: '500 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{r.label}</div>
            {r.sub && <div className="t-small" style={{ marginTop: 2 }}>{r.sub}</div>}
          </div>
          <I.ChevRight size={14} stroke="var(--fg-faint)"/>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------
   CONFIRM DIALOG (generic)
   ------------------------------------------------------------ */
function ConfirmDialog({ open, title, body, confirmLabel = 'Confirm', danger, onConfirm, onClose }) {
  if (!open) return null;
  return (
    <Modal open={true} onClose={onClose} width={400}>
      <div style={{ padding: 24 }}>
        <div className="t-h4" style={{ marginBottom: 8 }}>{title}</div>
        <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>{body}</div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Btn kind="ghost" onClick={onClose}>Cancel</Btn>
          <Btn kind={danger ? 'danger' : 'primary'} onClick={onConfirm}>{confirmLabel}</Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------
   TEAM INVITE MODAL
   ------------------------------------------------------------ */
function TeamInviteModal({ open, onClose }) {
  const [role, setRole] = React.useState('editor');
  if (!open) return null;
  return (
    <Modal open={true} onClose={onClose} width={520}>
      <div style={{ padding: 26 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
          <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', color: 'var(--accent-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.Users size={18}/>
          </span>
          <span className="t-h4">Invite teammates</span>
          <div style={{ flex: 1 }}/>
          <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
        </div>

        <label className="label">Emails (comma-separated)</label>
        <textarea rows={2} placeholder="priya@studio.co, daniel@studio.co"/>

        <label className="label" style={{ marginTop: 14 }}>Role</label>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
          {[
            { id: 'editor',   label: 'Editor',    sub: 'Create, edit, publish' },
            { id: 'reviewer', label: 'Reviewer',  sub: 'Approve stages only' },
            { id: 'viewer',   label: 'Viewer',    sub: 'See analytics + library' },
          ].map(r => (
            <div key={r.id} onClick={() => setRole(r.id)} style={{
              padding: 12, borderRadius: 10, cursor: 'pointer',
              background: role === r.id ? 'var(--accent-tint-1)' : 'var(--surface-subtle)',
              border: `1px solid ${role === r.id ? 'var(--accent-border)' : 'var(--border-hairline)'}`,
            }}>
              <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{r.label}</div>
              <div className="t-small" style={{ marginTop: 4 }}>{r.sub}</div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 14, padding: 12, borderRadius: 10, background: 'var(--surface-subtle)', display: 'flex', alignItems: 'center', gap: 8 }}>
          <I.Help size={14} stroke="var(--fg-muted)"/>
          <span className="t-small">Studio Pro includes 5 seats. You're using 3.</span>
        </div>

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 22 }}>
          <Btn kind="ghost" onClick={onClose}>Cancel</Btn>
          <Btn kind="primary" icon={I.Send}>Send invites</Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------
   VIDEO PREVIEW MODAL — final cut player + per-platform variants
   ------------------------------------------------------------ */
function VideoPreviewModal({ open, project, onClose }) {
  const [variant, setVariant] = React.useState('long');
  if (!open || !project) return null;
  const variants = [
    { id: 'long',     label: 'YouTube · Long-form', aspect: '16:9', dur: '11:42', icon: 'Youtube', color: '#FF0000' },
    { id: 'shorts',   label: 'Shorts',              aspect: '9:16', dur: '0:58',  icon: 'Youtube', color: '#FF0000' },
    { id: 'reel',     label: 'Instagram Reel',      aspect: '9:16', dur: '0:58',  icon: 'Image',   color: '#E1306C' },
    { id: 'tiktok',   label: 'TikTok',              aspect: '9:16', dur: '0:58',  icon: 'Film',    color: '#000000' },
  ];
  const v = variants.find(x => x.id === variant);

  return (
    <Modal open={true} onClose={onClose} width={1080}>
      <div style={{ padding: 0 }}>
        {/* Top bar */}
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <I.Eye size={16} stroke="var(--fg-default)"/>
          <span className="t-h5">Preview · {project.title}</span>
          <div style={{ flex: 1 }}/>
          <Btn kind="ghost" size="sm" icon={I.Download}>Download</Btn>
          <Btn kind="primary" size="sm" icon={I.Check}>Approve & publish</Btn>
          <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
        </div>

        {/* Variant tabs */}
        <div style={{ padding: '10px 20px', borderBottom: '1px solid var(--border-hairline)', background: 'var(--surface-subtle)', display: 'flex', alignItems: 'center', gap: 6 }}>
          {variants.map(vt => (
            <button key={vt.id} onClick={() => setVariant(vt.id)} style={{
              border: 0, cursor: 'pointer',
              padding: '6px 12px', borderRadius: 8,
              background: variant === vt.id ? 'var(--bg-surface)' : 'transparent',
              border: variant === vt.id ? '1px solid var(--border-default)' : '1px solid transparent',
              color: variant === vt.id ? 'var(--fg-strong)' : 'var(--fg-muted)',
              font: '600 12px/1 var(--font-sans)',
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{ width: 16, height: 16, borderRadius: 4, background: vt.color, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                {React.createElement(I[vt.icon], { size: 9 })}
              </span>
              {vt.label}
              <span className="t-small" style={{ marginLeft: 4 }}>{vt.aspect}</span>
            </button>
          ))}
        </div>

        {/* Player */}
        <div style={{ padding: 22, background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{
            aspectRatio: v.aspect === '16:9' ? '16/9' : '9/16',
            width: v.aspect === '16:9' ? 920 : 360,
            background: project.thumb,
            borderRadius: 12, position: 'relative',
            overflow: 'hidden',
            boxShadow: '0 12px 48px rgba(0,0,0,0.6)',
          }}>
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
            <span style={{
              position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
              width: 80, height: 80, borderRadius: '50%',
              background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(6px)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              color: 'white', cursor: 'pointer',
              border: '2px solid rgba(255,255,255,0.30)',
            }}><I.Play size={36}/></span>

            {/* HUD */}
            <div style={{ position: 'absolute', top: 12, right: 12, display: 'flex', gap: 6 }}>
              <span className="chip" style={{ background: 'rgba(0,0,0,0.55)', color: 'white', border: 0 }}>{v.aspect}</span>
              <span className="chip" style={{ background: 'rgba(0,0,0,0.55)', color: 'white', border: 0 }}>{v.dur}</span>
            </div>

            {/* Bottom bar */}
            <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: 14, background: 'linear-gradient(to top, rgba(0,0,0,0.7), transparent)' }}>
              <div style={{ height: 4, background: 'rgba(255,255,255,0.20)', borderRadius: 999, overflow: 'hidden', marginBottom: 10 }}>
                <div style={{ width: '38%', height: '100%', background: 'white', borderRadius: 999 }}/>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'white' }}>
                <button className="btn btn--ghost btn--icon" style={{ color: 'white' }}><I.Play size={16}/></button>
                <span className="t-mono t-small" style={{ color: 'white' }}>04:24 / {v.dur}</span>
                <div style={{ flex: 1 }}/>
                <button className="btn btn--ghost btn--icon" style={{ color: 'white' }}><I.Languages size={16}/></button>
              </div>
            </div>
          </div>
        </div>

        {/* Per-variant copy preview */}
        <div style={{ padding: '14px 20px', borderTop: '1px solid var(--border-hairline)' }}>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Caption for {v.label}</div>
          <div style={{ font: '500 13px/1.6 var(--font-sans)', color: 'var(--fg-default)', textWrap: 'pretty' }}>
            {v.id === 'long' && 'The largest library of the ancient world didn\'t die in one night. We walk you through what was inside it — and the four other times it burned.'}
            {v.id === 'shorts' && 'They told you Alexandria burned in one night. That\'s not what happened 👀\n\n#historytok #didyouknow'}
            {v.id === 'reel' && 'They told you it burned in one night.\nThat\'s not what happened.\n\nFull story up — link in bio.\n\n#history #ancientegypt #alexandria #mystery'}
            {v.id === 'tiktok' && 'pov: they told u the library of alexandria burned in one night… that\'s not what happened 👀\n\n#historytok #mystery #fyp'}
          </div>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------
   TOPIC DETAIL — drops in from idea queue
   ------------------------------------------------------------ */
function TopicDetailScreen({ topic, onBack, onStart }) {
  if (!topic) return null;
  const ch = MOCK.channels.find(c => c.id === topic.channelId);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="t-small" style={{ cursor: 'pointer' }} onClick={onBack}>Topics</span>
            <I.ChevRight size={12} stroke="var(--fg-faint)"/>
            <span className="t-small" style={{ color: 'var(--fg-default)' }}>Idea</span>
          </div>
          <div style={{ flex: 1 }}/>
          <Btn kind="ghost" icon={I.Refresh}>Regenerate</Btn>
          <Btn kind="ghost" icon={I.Trash}>Discard</Btn>
          <Btn kind="magic" icon={I.Spark} onClick={onStart}>Generate video</Btn>
        </div>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16 }}>
          <span style={{
            width: 80, height: 80, borderRadius: 18,
            background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            font: '700 32px/1 var(--font-display)', color: 'var(--accent-fg)',
            flexShrink: 0,
          }}>{topic.score}</span>
          <div style={{ flex: 1 }}>
            <div className="t-h2">{topic.title}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
              <ChannelHeader ch={ch}/>
              <span className="t-small">{topic.est} estimated</span>
              <div style={{ display: 'flex', gap: 6 }}>
                {topic.tags.map(t => <span key={t} className="chip" style={{ height: 22, fontSize: 11 }}>{t}</span>)}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px 40px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20 }}>
          {/* Left: angle + research + planned structure */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 10 }}>Why this idea will land</div>
              <div className="t-body" style={{ color: 'var(--fg-default)', textWrap: 'pretty' }}>
                "{topic.title}" matches three of {ch.name}'s best-performing video patterns: ancient mystery + first-person walk-through + myth-busting reveal. Estimated CTR 11.4% based on similar videos.
              </div>
            </div>

            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 10 }}>Hook draft</div>
              <div style={{ font: '600 18px/1.4 var(--font-display)', color: 'var(--fg-strong)', textWrap: 'pretty' }}>
                "Five hundred Englishmen sailed to Roanoke Island in 1587. Three years later, every one of them was gone. They left exactly one word behind."
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                <Btn kind="secondary" size="sm" icon={I.Refresh}>Other hooks</Btn>
                <Btn kind="ghost" size="sm" icon={I.Edit}>Edit</Btn>
              </div>
            </div>

            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 10 }}>Planned structure</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { t: 'HOOK',    body: 'The vanishing — 1587 to 1590. One word: CROATOAN.', dur: '0:00–0:18' },
                  { t: 'BEAT 1',  body: 'Who they were — 117 settlers, 16 women, 11 children.', dur: '0:18–2:24' },
                  { t: 'BEAT 2',  body: 'What John White found when he came back.',           dur: '2:24–5:08' },
                  { t: 'TURN',    body: 'The DNA evidence that finally surfaced in 2020.',   dur: '5:08–7:42' },
                  { t: 'PAYOFF',  body: 'They didn\'t vanish. They walked.',                 dur: '7:42–10:30' },
                  { t: 'CTA',     body: 'If you want the full archaeological case…',         dur: '10:30–11:00' },
                ].map((b, i) => (
                  <div key={i} style={{ display: 'grid', gridTemplateColumns: '80px 1fr 100px', gap: 12, alignItems: 'baseline', padding: '8px 0', borderTop: i > 0 ? '1px solid var(--border-hairline)' : 0 }}>
                    <span style={{ font: '700 10px/1 var(--font-sans)', letterSpacing: '0.10em', color: 'var(--accent-fg)', textTransform: 'uppercase' }}>{b.t}</span>
                    <span style={{ font: '500 13px/1.4 var(--font-sans)', color: 'var(--fg-default)' }}>{b.body}</span>
                    <span className="t-small">{b.dur}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 10 }}>Research sources we'll cite</div>
              <ul style={{ margin: 0, padding: '0 0 0 18px', font: '500 13px/1.7 var(--font-sans)', color: 'var(--fg-secondary)' }}>
                <li>National Park Service · Roanoke historical record</li>
                <li>First Colony Foundation — 2020 archaeological dig</li>
                <li>NC State Archives — original colonist roster</li>
                <li>Smithsonian — "What happened to the Lost Colony" (2018)</li>
              </ul>
            </div>
          </div>

          {/* Right rail */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 12 }}>Predicted metrics</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { l: 'Confidence',     v: `${topic.score}/100`, c: 'var(--accent-fg)' },
                  { l: 'Trend velocity', v: '+24% w/w',          c: 'var(--success)' },
                  { l: 'Channel fit',    v: '92/100',            c: 'var(--accent-fg)' },
                  { l: 'Search competition', v: 'Low',           c: 'var(--success)' },
                  { l: 'Estimated CTR',  v: '11.4%',             c: 'var(--accent-fg)' },
                  { l: 'Estimated AVD',  v: '7:42',              c: 'var(--accent-fg)' },
                ].map((m, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span className="t-small">{m.l}</span>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: m.c }}>{m.v}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 12 }}>Where it'll publish</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  { p: 'YouTube · Long-form', col: '#FF0000', icon: 'Youtube' },
                  { p: 'YouTube · Shorts cut', col: '#FF0000', icon: 'Youtube' },
                  { p: 'Instagram · Reel',     col: '#E1306C', icon: 'Image' },
                  { p: 'TikTok',               col: '#000000', icon: 'Film' },
                ].map((p, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ width: 24, height: 24, borderRadius: 6, background: p.col, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{React.createElement(I[p.icon], { size: 12 })}</span>
                    <span style={{ flex: 1, font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{p.p}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 10 }}>Settings</div>
              <Switch on={true} label="Pause for review before publishing" size="sm"/>
              <div style={{ marginTop: 12 }}>
                <label className="label">Schedule</label>
                <input defaultValue="Fri · 6:00 PM"/>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------
   EMPTY STATES + ERROR STATES
   ------------------------------------------------------------ */
function EmptyState({ icon: Ico = I.Sparkles, title, body, action, secondary, magic }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: 60, textAlign: 'center', maxWidth: 520, margin: '0 auto',
      position: 'relative',
    }}>
      {magic && <SparkleField count={8} intensity={0.35}/>}
      <span style={{
        width: 64, height: 64, borderRadius: 18,
        background: magic ? 'var(--magic-tint)' : 'var(--surface-hover)',
        border: `1px solid ${magic ? 'var(--accent-border-soft)' : 'var(--border-hairline)'}`,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        color: magic ? 'var(--accent-fg)' : 'var(--fg-default)',
        marginBottom: 18, position: 'relative', zIndex: 1,
      }}><Ico size={28}/></span>
      <div className="t-h3" style={{ marginBottom: 8, position: 'relative', zIndex: 1 }}>{title}</div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 24, textWrap: 'pretty', position: 'relative', zIndex: 1 }}>{body}</div>
      <div style={{ display: 'flex', gap: 8, position: 'relative', zIndex: 1 }}>
        {action}
        {secondary}
      </div>
    </div>
  );
}

function ErrorState({ kind = 'not-found', onRetry, onHome }) {
  const m = {
    'not-found': { title: '404 · We can\'t find that page',  body: 'The link is broken, or the page has been moved.', icon: I.Search },
    'network':   { title: 'Lost connection',                  body: 'We can\'t reach the studio right now. Check your internet and try again.', icon: I.Globe },
    'forbidden': { title: '403 · You don\'t have access',      body: 'This view is restricted to members of a higher role.', icon: I.Lock },
    'crashed':   { title: 'Something broke',                  body: 'A page crashed unexpectedly. We\'ve logged it — try again or contact support.', icon: I.Warn },
  }[kind];
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <EmptyState
        icon={m.icon}
        title={m.title}
        body={m.body}
        action={<Btn kind="primary" icon={I.Home} onClick={onHome}>Back to studio</Btn>}
        secondary={onRetry && <Btn kind="ghost" icon={I.Refresh} onClick={onRetry}>Try again</Btn>}
      />
    </div>
  );
}

/* Export */
Object.assign(window, {
  ToastHost, NotificationsPanel, SearchOverlay, ConfirmDialog,
  TeamInviteModal, VideoPreviewModal, TopicDetailScreen,
  EmptyState, ErrorState,
});
