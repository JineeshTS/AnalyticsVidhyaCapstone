/* ============================================================
   AIcreators.cloud — Topics, Library, Analytics, Settings
   ============================================================ */

/* ---------- TOPICS & CALENDAR ---------- */
function TopicsScreen({ onOpenProject }) {
  const [view, setView] = React.useState('queue');
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto', position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Topics & Calendar</div>
            <div className="t-small" style={{ marginTop: 4 }}>The AI scouts for ideas continuously. Approve, schedule, or feed your own.</div>
          </div>
          <Tabs value={view} onChange={setView} items={[
            { id: 'queue',    label: 'Idea queue',  icon: I.Spark },
            { id: 'calendar', label: 'Calendar',    icon: I.Calendar },
            { id: 'trends',   label: 'Trends',      icon: I.TrendUp },
          ]}/>
          <Btn kind="magic" icon={I.Plus}>Add topic</Btn>
        </div>

        {view === 'queue' && <TopicsQueue/>}
        {view === 'calendar' && <CalendarView onOpenProject={onOpenProject}/>}
        {view === 'trends' && <TrendsView/>}
      </div>
    </div>
  );
}

function TopicsQueue() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>
      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <I.Filter size={16} stroke="var(--fg-muted)"/>
          <span className="t-small" style={{ color: 'var(--fg-default)' }}>{MOCK.topicIdeas.length} ideas · sorted by confidence</span>
          <div style={{ flex: 1 }}/>
          <button className="btn btn--ghost btn--sm"><I.Refresh size={12}/> Re-scout</button>
        </div>
        {MOCK.topicIdeas.map((t, i) => {
          const ch = MOCK.channels.find(c=>c.id===t.channelId);
          return (
            <div key={t.id} style={{
              display: 'grid', gridTemplateColumns: '60px 1fr auto', gap: 16, alignItems: 'center',
              padding: '14px 18px',
              borderBottom: i < MOCK.topicIdeas.length - 1 ? '1px solid var(--border-hairline)' : 0,
            }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ font: '700 22px/1 var(--font-display)', color: 'var(--accent-fg)', letterSpacing: '-0.02em' }}>{t.score}</div>
                <div className="t-tiny" style={{ marginTop: 4 }}>score</div>
              </div>
              <div>
                <div style={{ font: '500 14px/1.4 var(--font-sans)', color: 'var(--fg-strong)' }}>{t.title}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6, flexWrap: 'wrap' }}>
                  <ChannelHeader ch={ch}/>
                  <span style={{ color:'var(--fg-faint)' }}>•</span>
                  <span className="t-small">{t.est}</span>
                  {t.tags.map(tg => <span key={tg} className="chip" style={{ height: 22, fontSize: 11 }}>{tg}</span>)}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {t.status === 'in-progress' && <span className="chip chip--brand">In production</span>}
                {t.status === 'queued' && <span className="chip chip--info">Queued</span>}
                {t.status === 'idea' && <span className="chip">New</span>}
                <Btn kind="ghost" size="sm" icon={I.Spark}>Generate</Btn>
                <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="card" style={{ background: 'var(--magic-tint-soft)', border: '1px solid var(--brand-soft-bd)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            <I.Sparkles size={18} stroke="var(--accent-fg)"/>
            <span className="t-h5">Bring your own idea</span>
          </div>
          <div className="t-small" style={{ marginBottom: 12 }}>Paste a headline, a tweet, a wikipedia link — we'll handle the rest.</div>
          <textarea placeholder="e.g. The day the Sahara was a rainforest"/>
          <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
            <select style={{ flex: 1 }}>
              {MOCK.channels.map(c => <option key={c.id}>{c.name}</option>)}
            </select>
            <Btn kind="primary" icon={I.Send} size="sm">Send</Btn>
          </div>
        </div>
        <div className="card">
          <div className="t-tiny" style={{ marginBottom: 12 }}>This week</div>
          <div style={{ display: 'grid', gap: 12 }}>
            <Row k="Auto-queued" v="14"/>
            <Row k="Generated" v="9"/>
            <Row k="Published" v="6"/>
            <Row k="Watch time" v="128.4K hrs"/>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span className="t-small">{k}</span>
      <span style={{ font: '600 14px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}</span>
    </div>
  );
}

function CalendarView({ onOpenProject }) {
  // Build a 4-week month for a fictional May 2026
  const weeks = [
    [27, 28, 29, 30, 1, 2, 3],
    [4,  5,  6,  7,  8, 9, 10],
    [11,12, 13, 14, 15,16, 17],
    [18,19, 20, 21, 22,23, 24],
    [25,26, 27, 28, 29,30, 31],
  ];
  const events = {
    5:  [{ ch: 'c2', title: 'Why ice pops in water', color: '#22D3EE' }],
    7:  [{ ch: 'c1', title: 'Lost Library Alexandria', color: '#A78BFA' }],
    9:  [{ ch: 'c4', title: 'Detective with no name', color: '#F472B6' }],
    11: [{ ch: 'c2', title: 'Volcanic lightning', color: '#22D3EE' }],
    12: [{ ch: 'c3', title: 'Honey star bear', color: '#34D399' }],
    14: [{ ch: 'c1', title: 'Pompeii 72hrs',  color: '#A78BFA' }],
    17: [{ ch: 'c2', title: '12M nose sensors', color: '#22D3EE' }, { ch: 'c4', title: 'Hotel no door', color: '#F472B6' }],
    19: [{ ch: 'c1', title: 'Antikythera decoded', color: '#A78BFA' }],
    22: [{ ch: 'c3', title: 'Kite Cloud', color: '#34D399' }],
  };
  return (
    <div className="card" style={{ padding: 0 }}>
      <div style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', borderBottom: '1px solid var(--border-hairline)' }}>
        <div className="t-h5">May 2026</div>
        <div style={{ flex: 1 }}/>
        <button className="btn btn--ghost btn--icon btn--sm"><I.ChevLeft size={14}/></button>
        <button className="btn btn--ghost btn--icon btn--sm"><I.ChevRight size={14}/></button>
        <button className="btn btn--ghost btn--sm" style={{ marginLeft: 10 }}>Today</button>
      </div>
      {/* Week-day header */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', borderBottom: '1px solid var(--border-hairline)' }}>
        {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d => (
          <div key={d} style={{ padding: '10px 12px', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase' }}>{d}</div>
        ))}
      </div>
      {weeks.map((w, wi) => (
        <div key={wi} style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', borderBottom: wi < weeks.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
          {w.map((d, di) => {
            const inMonth = !(wi === 0 && d > 7) && !(wi >= 3 && d < 15);
            const evs = events[d] || [];
            const isToday = d === 17 && wi === 2;
            return (
              <div key={di} style={{
                minHeight: 96, padding: 8,
                borderRight: di < 6 ? '1px solid var(--border-hairline)' : 0,
                background: isToday ? 'rgba(124,58,237,0.06)' : 'transparent',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{
                    font: '700 12px/1 var(--font-sans)',
                    color: isToday ? 'var(--accent-fg)' : inMonth ? 'var(--fg-default)' : 'var(--fg-faint)',
                  }}>{d}</span>
                  {isToday && <span className="chip chip--brand" style={{ height: 18, fontSize: 10, padding: '0 6px' }}>today</span>}
                </div>
                <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {evs.map((e, i) => (
                    <div key={i} style={{
                      padding: '4px 6px', borderRadius: 6,
                      background: `${e.color}24`, borderLeft: `2px solid ${e.color}`,
                      font: '600 11px/1.2 var(--font-sans)', color: 'var(--fg-strong)',
                      overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      cursor: 'pointer',
                    }}>{e.title}</div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function TrendsView() {
  const trends = [
    { topic: 'ancient libraries', delta: '+38%', niche: 'Mythic Tales', spark: [3,5,4,7,9,12,14,18,17,22,28,30] },
    { topic: 'aurora science',    delta: '+72%', niche: 'Snackable Science', spark: [2,3,3,5,6,9,12,14,20,28,40,44] },
    { topic: 'noir thrillers',    delta: '+24%', niche: 'Noir Reels', spark: [12,14,13,17,16,19,22,21,23,25,28,30] },
    { topic: 'kids astronomy',    delta: '+14%', niche: 'Tiny Toon Theatre', spark: [4,5,5,6,7,8,8,10,11,12,13,14] },
    { topic: 'shipwreck reveals', delta: '+55%', niche: 'Mythic Tales', spark: [4,4,5,5,7,9,11,14,16,22,28,36] },
  ];
  return (
    <div className="card" style={{ padding: 0 }}>
      <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
        <span className="t-h5">What's gaining velocity</span>
        <span className="t-small" style={{ marginLeft: 12 }}>Across the YouTube graph, weighted by your channel fit</span>
      </div>
      {trends.map((t, i) => (
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: '1fr 220px auto', gap: 16, alignItems: 'center',
          padding: '14px 18px',
          borderBottom: i < trends.length - 1 ? '1px solid var(--border-hairline)' : 0,
        }}>
          <div>
            <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{t.topic}</div>
            <div className="t-small" style={{ marginTop: 4 }}>Best fit · {t.niche}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, height: 36 }}>
            {t.spark.map((v, j) => <span key={j} style={{ flex: 1, height: `${v * 2}%`, background: 'linear-gradient(180deg, var(--cyan-400), var(--violet-500))', borderRadius: 2, opacity: 0.7 }}/>)}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ font: '700 16px/1 var(--font-display)', color: 'var(--success)' }}>{t.delta}</span>
            <Btn kind="ghost" size="sm" icon={I.Plus}>Queue</Btn>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- LIBRARY ---------- */
function LibraryScreen({ onOpenProject: onOpenVideo }) {
  const tabs = [
    { id: 'all',       label: 'All' },
    { id: 'published', label: 'Published' },
    { id: 'drafts',    label: 'Drafts' },
    { id: 'archived',  label: 'Archived' },
  ];
  const [t, setT] = React.useState('published');
  const items = MOCK.publishedRecent.concat(MOCK.publishedRecent).slice(0, 8);
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Library</div>
            <div className="t-small" style={{ marginTop: 4 }}>Everything you've published, archived, or still working on.</div>
          </div>
          <div style={{ position: 'relative' }}>
            <I.Search size={16} stroke="var(--fg-muted)" style={{ position: 'absolute', top: 14, left: 14 }}/>
            <input placeholder="Search videos…" style={{ width: 280, paddingLeft: 40 }}/>
          </div>
          <Tabs value={t} onChange={setT} items={tabs}/>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          {items.map((v, i) => {
            const ch = MOCK.channels.find(c=>c.id===v.channelId);
            return (
              <div key={i} className="card card--hover" onClick={() => onOpenVideo && onOpenVideo(v)} style={{ padding: 0, overflow: 'hidden', cursor: 'pointer' }}>
                <div style={{ aspectRatio: '16/9', background: v.thumb, position: 'relative' }}>
                  <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
                  <span style={{ position:'absolute', bottom:8, right:8, font:'700 11px/1 var(--font-sans)', color:'white', padding:'4px 8px', background:'rgba(0,0,0,0.55)', borderRadius: 6 }}>{['11:42','0:52','3:08','2:14'][i % 4]}</span>
                  <span style={{ position:'absolute', top:8, left:8 }} className="chip chip--success" >LIVE</span>
                </div>
                <div style={{ padding: 14 }}>
                  <div style={{ font: '600 13px/1.4 var(--font-sans)', color: 'var(--fg-strong)', minHeight: 36, overflow: 'hidden' }}>{v.title}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 10, marginBottom: 10 }}>
                    <ChannelHeader ch={ch}/>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span className="t-small">{v.views} views</span>
                    <span className="t-small">{v.published}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ---------- ANALYTICS ---------- */
function AnalyticsScreen() {
  const a = MOCK.analytics;
  // Build a smooth area chart from the sparkline
  const spark = a.sparkline;
  const W = 920, H = 220, max = Math.max(...spark);
  const points = spark.map((v, i) => `${(i / (spark.length - 1)) * W},${H - (v / max) * (H - 20)}`);
  const path = `M${points.join(" L")}`;
  const areaPath = `${path} L${W},${H} L0,${H} Z`;

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Analytics</div>
            <div className="t-small" style={{ marginTop: 4 }}>Last 30 days across all your channels.</div>
          </div>
          <Btn kind="secondary" icon={I.Calendar}>Last 30 days</Btn>
          <Btn kind="ghost" icon={I.Download}>Export</Btn>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          <StatTile label="Views"          value={a.last30d.views}      sub="+18.2% vs prior 30d" icon={I.Eye}     gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-border-soft), transparent)"/>
          <StatTile label="New subscribers" value={a.last30d.subs}       sub="+24% vs prior"        icon={I.User}    gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-tint-3), transparent)"/>
          <StatTile label="Watch hours"     value={a.last30d.watchHours} sub="Strongest week ever"  icon={I.Clock}   gradient="radial-gradient(50% 100% at 50% 0%, var(--success-bd), transparent)"/>
          <StatTile label="Estimated revenue" value={a.last30d.revenue}  sub="$1.92 RPM"            icon={I.Credit}  gradient="radial-gradient(50% 100% at 50% 0%, rgba(236,72,153,0.30), transparent)"/>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 16 }}>
          {/* Big chart */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <span className="t-h5">Views</span>
              <span className="chip chip--success">+18.2%</span>
              <div style={{ flex: 1 }}/>
              <Tabs value="views" onChange={()=>{}} items={[
                { id: 'views', label: 'Views' },
                { id: 'subs',  label: 'Subscribers' },
                { id: 'avd',   label: 'AVD' },
              ]}/>
            </div>
            <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block' }}>
              <defs>
                <linearGradient id="vGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%"  stopColor="#A78BFA" stopOpacity="0.55"/>
                  <stop offset="100%" stopColor="#A78BFA" stopOpacity="0"/>
                </linearGradient>
              </defs>
              {/* gridlines */}
              {[0.25, 0.5, 0.75].map((y, i) => (
                <line key={i} x1="0" x2={W} y1={H * y} y2={H * y} stroke="rgba(255,255,255,0.04)" strokeWidth="1"/>
              ))}
              <path d={areaPath} fill="url(#vGrad)"/>
              <path d={path} fill="none" stroke="#A78BFA" strokeWidth="2"/>
            </svg>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
              {['Apr 18','Apr 25','May 2','May 9','May 16'].map(d => <span key={d} className="t-tiny">{d}</span>)}
            </div>
          </div>
          {/* Channel split donut */}
          <div className="card">
            <div className="t-h5" style={{ marginBottom: 16 }}>Per channel</div>
            <Donut data={a.perChannel}/>
            <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {a.perChannel.map(c => {
                const ch = MOCK.channels.find(x=>x.id===c.id);
                return (
                  <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ width: 10, height: 10, borderRadius: '50%', background: c.color }}/>
                    <span style={{ flex: 1, font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{ch.name}</span>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{c.views}</span>
                    <span className="t-small" style={{ width: 36, textAlign: 'right' }}>{c.pct}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Top videos */}
        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', borderBottom: '1px solid var(--border-hairline)' }}>
            <span className="t-h5">Top videos · 30 days</span>
          </div>
          {MOCK.publishedRecent.map((v, i) => {
            const ch = MOCK.channels.find(c=>c.id===v.channelId);
            return (
              <div key={v.id} style={{ display: 'grid', gridTemplateColumns: '40px 80px 1fr 100px 80px 80px', gap: 16, alignItems: 'center', padding: '14px 18px', borderBottom: i < MOCK.publishedRecent.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
                <span style={{ font: '700 18px/1 var(--font-display)', color: 'var(--fg-faint)' }}>{String(i + 1).padStart(2, '0')}</span>
                <div style={{ width: 80, height: 48, borderRadius: 6, background: v.thumb, border: '1px solid var(--border-hairline)' }}/>
                <div>
                  <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{v.title}</div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                    <ChannelHeader ch={ch}/>
                  </div>
                </div>
                <div><div className="t-tiny">Views</div><div style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)', marginTop: 4 }}>{v.views}</div></div>
                <div><div className="t-tiny">CTR</div><div style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--success)', marginTop: 4 }}>{v.ctr}</div></div>
                <div><div className="t-tiny">AVD</div><div style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)', marginTop: 4 }}>{v.avd}</div></div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Donut({ data, size = 140 }) {
  const total = data.reduce((s, d) => s + d.pct, 0);
  let acc = 0;
  const R = size / 2 - 12;
  const C = 2 * Math.PI * R;
  const slices = data.map((d, i) => {
    const len = (d.pct / total) * C;
    const dash = `${len} ${C - len}`;
    const offset = -acc;
    acc += len;
    return <circle key={i} r={R} cx={size/2} cy={size/2} fill="none" stroke={d.color} strokeWidth="16" strokeDasharray={dash} strokeDashoffset={offset} transform={`rotate(-90 ${size/2} ${size/2})`}/>;
  });
  return (
    <div style={{ display: 'flex', justifyContent: 'center' }}>
      <svg width={size} height={size}>
        <circle r={R} cx={size/2} cy={size/2} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="16"/>
        {slices}
        <text x="50%" y="48%" textAnchor="middle" fill="var(--fg-strong)" style={{ font: '700 22px/1 var(--font-display)', letterSpacing: '-0.02em' }}>2.4M</text>
        <text x="50%" y="62%" textAnchor="middle" fill="var(--fg-muted)" style={{ font: '500 11px/1 var(--font-sans)' }}>views</text>
      </svg>
    </div>
  );
}

/* ---------- SETTINGS ---------- */
function SettingsScreen({ section = 'settings' }) {
  const sections = [
    { id: 'profile',       label: 'Profile',       icon: I.User },
    { id: 'autopilot',     label: 'Autopilot',     icon: I.Robot },
    { id: 'models',        label: 'AI Models',     icon: I.Spark },
    { id: 'integrations',  label: 'Integrations',  icon: I.Globe },
    { id: 'billing',       label: 'Billing & Plan', icon: I.Credit },
        { id: 'notifications', label: 'Notifications', icon: I.Bell },
  ];
  const initial = section === 'billing' ? 'billing' :
                  section === 'integrations' ? 'integrations' :
                  section === 'voices' ? 'voices' :
                  section === 'styles' ? 'styles' :
                  'profile';
  const [active, setActive] = React.useState(initial);

  React.useEffect(() => setActive(initial), [section]);

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ marginBottom: 18 }}>
          <div className="t-h3">Settings</div>
          <div className="t-small" style={{ marginTop: 4 }}>Tune the autopilot, manage your subscription, plug Avyal into your stack.</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 18 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {sections.map(s => (
              <button key={s.id} onClick={() => setActive(s.id)} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 14px', border: 0, cursor: 'pointer',
                background: active === s.id ? 'var(--brand-soft-bg)' : 'transparent',
                color: active === s.id ? 'var(--accent-fg)' : 'var(--fg-default)',
                borderRadius: 10, textAlign: 'left',
                font: `${active === s.id ? 600 : 500} 13px/1 var(--font-sans)`,
              }}>
                <s.icon size={16}/>
                {s.label}
              </button>
            ))}
          </div>
          <div>
            {active === 'profile'      && <SetProfile/>}
            {active === 'autopilot'    && <SetAutopilot/>}
            {active === 'models'       && <SetModels/>}
            {active === 'integrations' && <SetIntegrations/>}
            {active === 'billing'      && <SetBilling/>}
            {active === 'notifications'&& <SetNotifications/>}
          </div>
        </div>
      </div>
    </div>
  );
}

function SetProfile({ onInviteTeam }) {
  return (
    <>
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div className="t-h4">Profile</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <Avatar name={MOCK.user.name} size={56} color="var(--magic-grad)"/>
        <Btn kind="secondary" icon={I.Upload}>Upload</Btn>
        <Btn kind="ghost">Remove</Btn>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div><label className="label">Full name</label><input defaultValue={MOCK.user.name}/></div>
        <div><label className="label">Email</label><input defaultValue={MOCK.user.email}/></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div><label className="label">Timezone</label><input defaultValue="America/New_York"/></div>
        <div><label className="label">Country</label><input defaultValue="United States"/></div>
      </div>
    </div>

    {/* Danger zone */}
    <div className="card" style={{ marginTop: 14, borderColor: 'var(--danger-bd)' }}>
      <div className="t-h4" style={{ color: 'var(--danger-fg)', marginBottom: 14 }}>Danger zone</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 0', borderTop: '1px solid var(--border-hairline)' }}>
        <I.Download size={18} stroke="var(--fg-default)"/>
        <div style={{ flex: 1 }}>
          <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>Export all my data</div>
          <div className="t-small" style={{ marginTop: 4 }}>One .zip with everything: account, projects, voice clones, generated videos. Emailed within 24 hours.</div>
        </div>
        <a href="AIcreators Cloud Legal.html#data-export" target="_blank"><Btn kind="secondary">Request export</Btn></a>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 0', borderTop: '1px solid var(--border-hairline)' }}>
        <I.Lock size={18} stroke="var(--fg-default)"/>
        <div style={{ flex: 1 }}>
          <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>Transfer account ownership</div>
          <div className="t-small" style={{ marginTop: 4 }}>Move ownership to a teammate without losing channels, voices, or videos.</div>
        </div>
        <Btn kind="secondary">Transfer</Btn>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 0', borderTop: '1px solid var(--border-hairline)' }}>
        <I.Trash size={18} stroke="var(--danger)"/>
        <div style={{ flex: 1 }}>
          <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>Delete my account</div>
          <div className="t-small" style={{ marginTop: 4, color: 'var(--danger-fg)' }}>Permanently deletes everything. 30-day grace period. Voice clones go immediately.</div>
        </div>
        <a href="AIcreators Cloud Legal.html#data-deletion" target="_blank"><Btn kind="danger" icon={I.Trash}>Delete account</Btn></a>
      </div>
    </div>
    </>
  );
}

function SetAutopilot() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div className="card" style={{ background: 'var(--magic-tint-soft)', border: '1px solid var(--brand-soft-bd)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <I.Robot size={20} stroke="var(--accent-fg)"/>
          <div style={{ flex: 1 }}>
            <div className="t-h5">Master autopilot</div>
            <div className="t-small" style={{ marginTop: 4 }}>When on, all channels with their own autopilot setting will run automatically.</div>
          </div>
          <Switch on={true} label="Active"/>
        </div>
      </div>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="t-h4">Default rules</div>
        <OptionRow icon={I.Spark} title="Pick best prompting technique automatically" sub="Avyal selects from 11 techniques (CoT, few-shot, persona, etc.) per stage." on={true}/>
        <OptionRow icon={I.Eye}   title="Stop for review when confidence is low"        sub="If a script or thumbnail scores under 70, hold for your approval." on={true}/>
        <OptionRow icon={I.Image} title="Lock keyframes after first re-roll"            sub="Saves credits — autopilot won't keep re-rolling forever." on={true}/>
        <OptionRow icon={I.Upload} title="Publish without final approval"               sub="Once the video is rendered, push to YouTube on schedule." on={false}/>
      </div>
    </div>
  );
}

function OptionRow({ icon: Ico, title, sub, on }) {
  const [v, setV] = React.useState(on);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', borderTop: '1px solid var(--border-hairline)' }}>
      <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-fg)' }}><Ico size={16}/></span>
      <div style={{ flex: 1 }}>
        <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{title}</div>
        <div className="t-small" style={{ marginTop: 4 }}>{sub}</div>
      </div>
      <Switch on={v} onChange={setV}/>
    </div>
  );
}

function SetModels() {
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div className="t-h4">AI models per stage</div>
      <div className="t-small">Avyal picks the best model automatically. Override if you want.</div>
      {[
        { stage: 'Script writing',  model: 'Avyal (Delta-2.0)', sub: 'Best-fit · 11¢ / 1k words' },
        { stage: 'Keyframes',       model: 'Avyal Imagine v4',  sub: 'Best-fit · 8¢ / image' },
        { stage: 'Image-to-video',  model: 'Avyal Motion v3',   sub: 'Best-fit for consistency · 4¢ / sec' },
        { stage: 'Voiceover',       model: 'Avyal Voice Pro',   sub: 'Studio quality · 2.4¢ / 1k chars' },
        { stage: 'Music bed',       model: 'Avyal Score',       sub: 'Cinematic loops · royalty-free' },
        { stage: 'Captions',        model: 'Avyal Whisper',     sub: '128 languages' },
      ].map((m, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', borderTop: '1px solid var(--border-hairline)' }}>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.stage}</div>
            <div className="t-small" style={{ marginTop: 4 }}>{m.sub}</div>
          </div>
          <div style={{
            padding: '8px 12px', borderRadius: 10,
            background: 'var(--accent-tint-1)', border: '1px solid var(--brand-soft-bd)',
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <I.Robot size={14} stroke="var(--accent-fg)"/>
            <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--accent-fg)' }}>{m.model}</span>
            <I.ChevDown size={12} stroke="var(--fg-muted)"/>
          </div>
        </div>
      ))}
    </div>
  );
}

function SetIntegrations() {
  const items = [
    { name: 'YouTube',     status: '4 channels connected', icon: I.Youtube, color: '#FF0000', on: true },
    { name: 'Google Drive', status: 'Sync drafts here',     icon: I.Folder,  color: '#4285F4', on: true },
    { name: 'Notion',      status: 'Send analytics digests', icon: I.Pin,    color: '#FFFFFF', on: false },
    { name: 'Slack',       status: 'Notify on publish',     icon: I.Bell,    color: '#4A154B', on: true },
    { name: 'Zapier',      status: 'Wire to anything',      icon: I.Lightning, color: '#FF4A00', on: false },
    { name: 'Webhooks',    status: 'POST to your endpoint', icon: I.Globe,   color: '#22D3EE', on: false },
  ];
  return (
    <div className="card" style={{ padding: 0 }}>
      <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div className="t-h4">Integrations</div>
      </div>
      {items.map((it, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 18px', borderBottom: i < items.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
          <span style={{ width: 40, height: 40, borderRadius: 10, background: `${it.color}22`, border: `1px solid ${it.color}44`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: it.color }}><it.icon size={18}/></span>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{it.name}</div>
            <div className="t-small" style={{ marginTop: 4 }}>{it.status}</div>
          </div>
          {it.on ? <span className="chip chip--success"><I.Check size={10}/> Connected</span> : <Btn kind="secondary" size="sm">Connect</Btn>}
        </div>
      ))}
    </div>
  );
}

function SetBilling() {
  const [openTopup, setOpenTopup] = React.useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div className="card" style={{ position: 'relative', overflow: 'hidden' }}>
        <SparkleField count={6} intensity={0.3}/>
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ flex: 1 }}>
            <span className="chip chip--magic"><I.Spark size={12}/> Pay-as-you-go</span>
            <div className="t-h2" style={{ marginTop: 10 }}>$0.20<span className="t-small" style={{ marginLeft: 6 }}>/ second of video</span></div>
            <div className="t-small" style={{ marginTop: 6 }}>Flat rate · no subscription · no tiers</div>
            <div style={{ marginTop: 18, padding: 14, borderRadius: 12, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <span className="t-small" style={{ color: 'var(--fg-default)' }}>Balance</span>
                <span style={{ font: '700 26px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em' }}>$148.24</span>
              </div>
              <div className="t-small">~ 12 min 21 sec of video</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <Btn kind="primary" icon={I.Plus} onClick={() => setOpenTopup(true)}>Top up balance</Btn>
            <Btn kind="ghost" icon={I.Refresh}>Auto-recharge</Btn>
          </div>
        </div>
      </div>

      {/* First-recharge bonus banner */}
      <div className="card" style={{ padding: 18, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{ width: 40, height: 40, borderRadius: 12, background: 'var(--magic-grad)', color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <I.Sparkles size={18}/>
        </span>
        <div style={{ flex: 1 }}>
          <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>Signup bonus — your first recharge is 100% doubled</div>
          <div className="t-small" style={{ marginTop: 4 }}>One-time. Min $10 · max $5,000. Add $100, get $200. Auto-applied at checkout.</div>
        </div>
        <Btn kind="magic" icon={I.Spark} onClick={() => setOpenTopup(true)}>Claim bonus</Btn>
      </div>

      <div className="card">
        <div className="t-h5" style={{ marginBottom: 16 }}>This month</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {[
            { l: 'Seconds generated', v: '2,148', s: '~ 35 min 48 sec' },
            { l: 'Spent',             v: '$429.60' },
            { l: 'Videos shipped',    v: '6' },
          ].map((m,i) => (
            <div key={i}>
              <div className="t-tiny" style={{ marginBottom: 8 }}>{m.l}</div>
              <div style={{ font: '700 22px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em' }}>{m.v}</div>
              {m.s && <div className="t-small" style={{ marginTop: 4 }}>{m.s}</div>}
            </div>
          ))}
        </div>
      </div>

      {openTopup && <TopupModal onClose={() => setOpenTopup(false)}/>}
    </div>
  );
}

function TopupModal({ onClose, firstTime = true }) {
  const [amount, setAmount] = React.useState(100);
  const bonus = firstTime ? amount : 0;
  const total = amount + bonus;
  const seconds = Math.floor(total / 0.20);
  const presets = [25, 50, 100, 250, 500, 1000, 2500, 5000];
  return (
    <Modal open={true} onClose={onClose} width={520}>
      <div style={{ padding: 26, position: 'relative', overflow: 'hidden' }}>
        <SparkleField count={6} intensity={0.30}/>
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
            <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', color: 'var(--accent-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
              <I.Credit size={18}/>
            </span>
            <span className="t-h4">Top up your balance</span>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
          </div>

          {firstTime && (
            <div style={{ padding: 12, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
              <I.Sparkles size={16} stroke="var(--accent-fg)"/>
              <div className="t-small" style={{ color: 'var(--fg-default)', flex: 1 }}>
                <strong style={{ color: 'var(--fg-strong)' }}>First-recharge bonus</strong> — we'll match your recharge 100%, one time. Whatever you add below is doubled.
              </div>
            </div>
          )}

          <label className="label">Amount to recharge</label>
          <div style={{ position: 'relative' }}>
            <span style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', font: '700 22px/1 var(--font-display)', color: 'var(--fg-muted)' }}>$</span>
            <input type="number" min="10" max="5000" step="5" value={amount} onChange={e => setAmount(Math.max(10, Math.min(5000, parseInt(e.target.value || '0', 10))))}
                   style={{ height: 64, paddingLeft: 36, font: '700 28px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em' }}/>
          </div>
          <div className="t-small" style={{ marginTop: 6 }}>Min $10 · max $5,000</div>

          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 12 }}>
            {presets.map(p => (
              <button key={p} onClick={() => setAmount(p)} className={amount === p ? 'chip chip--brand' : 'chip'} style={{ cursor: 'pointer', height: 32, padding: '0 12px', border: 0 }}>
                ${p}
              </button>
            ))}
          </div>

          <div className="card" style={{ marginTop: 18, padding: 16, background: 'var(--surface-subtle)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}>
              <span className="t-body">Recharge</span>
              <span style={{ font: '600 14px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>${amount.toFixed(2)}</span>
            </div>
            {firstTime && (
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}>
                <span className="t-body" style={{ color: 'var(--accent-fg)' }}>Signup bonus (100%)</span>
                <span style={{ font: '600 14px/1 var(--font-sans)', color: 'var(--accent-fg)' }}>+ ${bonus.toFixed(2)}</span>
              </div>
            )}
            <div className="divider" style={{ margin: '8px 0' }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}>
              <span className="t-body" style={{ fontWeight: 600 }}>Total credit added</span>
              <span style={{ font: '700 18px/1 var(--font-display)', color: 'var(--fg-strong)' }}>${total.toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}>
              <span className="t-small">Video you can make</span>
              <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>~ {Math.floor(seconds / 60)} min {seconds % 60} sec</span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 22 }}>
            <Btn kind="ghost" onClick={onClose}>Cancel</Btn>
            <Btn kind="magic" icon={I.Credit}>Pay ${amount.toFixed(2)} with card</Btn>
          </div>
        </div>
      </div>
    </Modal>
  );
}



function SetTeam() {
  return (
    <div className="card">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
        <div className="t-h4" style={{ flex: 1 }}>Team</div>
        <Btn kind="primary" icon={I.Plus}>Invite</Btn>
      </div>
      {[
        { name: 'Mihir Vaishnav', email: 'mihir@aicreators.cloud', role: 'Owner' },
        { name: 'Priya Shah',     email: 'priya@aicreators.cloud', role: 'Editor' },
        { name: 'Daniel Cho',     email: 'daniel@aicreators.cloud', role: 'Reviewer' },
      ].map((m, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 0', borderTop: i === 0 ? 0 : '1px solid var(--border-hairline)' }}>
          <Avatar name={m.name} size={36}/>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.name}</div>
            <div className="t-small" style={{ marginTop: 4 }}>{m.email}</div>
          </div>
          <span className="chip">{m.role}</span>
        </div>
      ))}
    </div>
  );
}

function SetNotifications() {
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div className="t-h4">Notifications</div>
      <OptionRow icon={I.Eye} title="Awaiting review" sub="Pause-stage notifications you must approve" on={true}/>
      <OptionRow icon={I.Upload} title="Publish events" sub="When a video goes live" on={true}/>
      <OptionRow icon={I.TrendUp} title="Weekly performance digest" sub="Sundays at 9am" on={true}/>
      <OptionRow icon={I.Credit} title="Low credit warning" sub="When you hit 90% of plan" on={true}/>
      <OptionRow icon={I.Spark} title="Idea opportunities" sub="Velocity spikes in your niche" on={false}/>
    </div>
  );
}

window.TopicsScreen = TopicsScreen;
window.LibraryScreen = LibraryScreen;
window.AnalyticsScreen = AnalyticsScreen;
window.SettingsScreen = SettingsScreen;
