/* ============================================================
   AIcreators.cloud — Visual Styles Library
   ============================================================

   PURPOSE
   -------
   Library of visual styles that drive every keyframe (T2I) +
   motion clip (I2V) for a channel. Users browse presets, fork
   them, or build their own from reference images.

   SCREENS in this file
     StylesLibraryScreen   — main grid
     StyleDetail           — drill-in to one style
     StyleBuilderModal     — create / edit a style

   BACKED BY
     GET    /styles                            – studio + user styles
     GET    /styles/{id}
     POST   /styles                            – create user style
     PATCH  /styles/{id}                       – tweak prompts / refs
     DELETE /styles/{id}
     POST   /styles/{id}/preview               – test render with this style
     POST   /styles/{id}/use-on-channel/{cid}

   DATA MODEL — Style
     id, user_id (null = studio), name, owner_name,
     swatch[], notes,
     prompt_lift (string),       // appended to every T2I prompt
     negative_prompt (string),
     model_id (string),          // default T2I model
     lora_url[],                 // optional fine-tuned LoRAs
     reference_image_urls[],     // user-uploaded refs we IP-Adapter from
     motion_model_id,            // default I2V model
     motion_lift (string),
     identity_lock (bool),
     channels_using_count,
     created_at
   ============================================================ */

const STUDIO_STYLES = [
  { id: 's1', name: 'Cinematic Noir',    swatch: ['#1A1024','#3B1F47','#85547E','#E0D2E6'], notes: '35mm grain · low key · teal-orange', tags: ['cinematic','dark'], owner: 'studio', uses: 412 },
  { id: 's2', name: 'Studio Ghibli',     swatch: ['#A8D8EA','#FCE38A','#F38181','#95E1D3'], notes: 'Soft cel · pastoral · gentle rim light', tags: ['anime','soft'], owner: 'studio', uses: 884 },
  { id: 's3', name: 'Cyber Pulse',       swatch: ['#FF006E','#8338EC','#3A86FF','#06D6A0'], notes: 'Neon · holo · synthwave grid', tags: ['neon','sci-fi'], owner: 'studio', uses: 320 },
  { id: 's4', name: 'Paper Cutout',      swatch: ['#FFE5B4','#FFB7B2','#B5DEFF','#E2BEF1'], notes: 'Flat layers · soft shadows · craft paper', tags: ['kids','flat'], owner: 'studio', uses: 142 },
  { id: 's5', name: 'Mythic Etching',    swatch: ['#2A1810','#7B4F2C','#D4A574','#F4E1B5'], notes: 'Engraved illustration · sepia · ornate', tags: ['historical','ornate'], owner: 'studio', uses: 264 },
  { id: 's6', name: 'Documentary Real',  swatch: ['#3D405B','#81B29A','#F2CC8F','#E07A5F'], notes: 'Realistic · earthy · grounded', tags: ['real','realistic'], owner: 'studio', uses: 612 },
  { id: 's7', name: 'Pixel Story',       swatch: ['#264653','#2A9D8F','#E9C46A','#F4A261'], notes: '16-bit pixel · CRT scanlines', tags: ['pixel','retro'], owner: 'studio', uses: 88 },
  { id: 's8', name: 'Editorial Photo',   swatch: ['#0F172A','#475569','#94A3B8','#F1F5F9'], notes: 'Magazine cover · negative space · serif overlay', tags: ['photo','editorial'], owner: 'studio', uses: 218 },
  { id: 's9', name: 'Vaporwave',         swatch: ['#FF71CE','#01CDFE','#05FFA1','#B967FF'], notes: '90s Greek bust · gradient haze · grid floor', tags: ['vaporwave','dreamy'], owner: 'studio', uses: 64 },
];

const MY_STYLES = [
  { id: 'my1', name: 'Mythic Tales · House Look', swatch: ['#1B0F08','#5A3A1F','#C39A5E','#F2DCB3'], notes: 'My channel\'s signature engraving + warm candlelight', tags: ['mine'], owner: 'me', uses: 38, channels_using: 1, basedOn: 's5' },
  { id: 'my2', name: 'Bedtime Soft',              swatch: ['#FFF4E6','#FFD3A5','#F8B595','#C06C84'], notes: 'For Tiny Toon Theatre kids content',     tags: ['mine','kids'], owner: 'me', uses: 12, channels_using: 1, basedOn: 's4' },
];

function StylesLibraryScreen() {
  const [tab, setTab]       = React.useState('all');
  const [openId, setOpenId] = React.useState(null);
  const [builderOpen, setBuilderOpen] = React.useState(false);
  const [builderBase, setBuilderBase] = React.useState(null);

  const styles = tab === 'mine'   ? MY_STYLES
               : tab === 'studio' ? STUDIO_STYLES
               :                    [...MY_STYLES, ...STUDIO_STYLES];

  const opened = [...MY_STYLES, ...STUDIO_STYLES].find(s => s.id === openId);

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Visual Styles</div>
            <div className="t-small" style={{ marginTop: 4 }}>Each style drives every keyframe + motion clip on a channel. Fork a preset or build your own from reference images.</div>
          </div>
          <Tabs value={tab} onChange={setTab} items={[
            { id: 'all',    label: 'All' },
            { id: 'mine',   label: 'Mine', icon: I.User },
            { id: 'studio', label: 'Studio', icon: I.Sparkles },
          ]}/>
          <Btn kind="magic" icon={I.Plus} onClick={() => { setBuilderBase(null); setBuilderOpen(true); }}>Build a style</Btn>
        </div>

        {/* Hero: "Build from reference images" prompt */}
        {tab !== 'studio' && (
          <div className="card" style={{ padding: 22, marginBottom: 16, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', position: 'relative', overflow: 'hidden' }}>
            <SparkleField count={8} intensity={0.35}/>
            <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 22 }}>
              <span style={{
                width: 64, height: 64, borderRadius: 18,
                background: 'var(--magic-grad)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: 'white', flexShrink: 0,
              }}><I.Image size={28}/></span>
              <div style={{ flex: 1 }}>
                <div className="t-h4" style={{ marginBottom: 6 }}>Train a style from reference images</div>
                <div className="t-small" style={{ maxWidth: 620 }}>
                  Upload 5-20 frames from a film, a photoshoot, a comic, or a previous video. We build a style that matches the look — usable across every keyframe and motion clip on your channels.
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <Btn kind="primary" icon={I.Upload} onClick={() => { setBuilderBase(null); setBuilderOpen(true); }}>Upload references</Btn>
                <Btn kind="ghost" size="sm" icon={I.Spark}>Or describe in words</Btn>
              </div>
            </div>
          </div>
        )}

        {tab !== 'studio' && MY_STYLES.length > 0 && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <span className="t-h5">Your styles</span>
              <span className="chip">{MY_STYLES.length}</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 28 }}>
              {MY_STYLES.map(s => <StyleCard key={s.id} s={s} onOpen={() => setOpenId(s.id)} mine/>)}
              <div onClick={() => { setBuilderBase(null); setBuilderOpen(true); }} className="card card--hover" style={{
                border: '1px dashed var(--border-default)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer', minHeight: 240,
              }}>
                <span style={{
                  width: 48, height: 48, borderRadius: 14,
                  background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)',
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  color: 'var(--accent-fg)', marginBottom: 12,
                }}><I.Plus size={20}/></span>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Build a style</div>
                <div className="t-small" style={{ marginTop: 6 }}>Refs or words</div>
              </div>
            </div>
          </>
        )}

        {tab !== 'mine' && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <span className="t-h5">Studio presets</span>
              <span className="chip">{STUDIO_STYLES.length}</span>
              <div style={{ flex: 1 }}/>
              <Btn kind="ghost" size="sm" icon={I.Filter}>Filter by tag</Btn>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
              {STUDIO_STYLES.map(s => <StyleCard key={s.id} s={s} onOpen={() => setOpenId(s.id)} onFork={() => { setBuilderBase(s); setBuilderOpen(true); }}/>)}
            </div>
          </>
        )}
      </div>

      {opened && <StyleDetailModal s={opened} onClose={() => setOpenId(null)} onFork={(s) => { setBuilderBase(s); setOpenId(null); setBuilderOpen(true); }}/>}
      {builderOpen && <StyleBuilderModal base={builderBase} onClose={() => setBuilderOpen(false)}/>}
    </div>
  );
}

function StyleCard({ s, mine, onOpen, onFork }) {
  return (
    <div className="card card--hover" onClick={onOpen} style={{ padding: 0, overflow: 'hidden', cursor: 'pointer' }}>
      {/* Sample tile - we render 3 mini "sample frames" using the swatch gradient */}
      <div style={{ position: 'relative' }}>
        <div style={{
          aspectRatio: '16/9',
          background: `linear-gradient(135deg, ${s.swatch.join(', ')})`,
          position: 'relative',
        }}>
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
          {mine && <span style={{ position: 'absolute', top: 8, left: 8 }} className="chip chip--brand"><I.User size={11}/> Mine</span>}
        </div>
        {/* Sample strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 1, background: 'var(--border-hairline)' }}>
          {[0, 1, 2].map(i => (
            <div key={i} style={{
              aspectRatio: '16/9',
              background: `linear-gradient(${135 + i * 25}deg, ${s.swatch[i % s.swatch.length]}, ${s.swatch[(i + 1) % s.swatch.length]})`,
              position: 'relative',
            }}>
              <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 40%, rgba(255,255,255,0.16), transparent 70%)' }}/>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding: 14 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 15px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{s.name}</div>
            <div className="t-small" style={{ marginTop: 4 }}>{s.notes}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 4, marginTop: 10 }}>
          {s.swatch.map((c, j) => <span key={j} style={{ width: 14, height: 14, borderRadius: 4, background: c, border: '1px solid var(--border-hairline)' }}/>)}
        </div>
        <div className="divider" style={{ margin: '12px 0' }}/>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="t-tiny" style={{ color: 'var(--fg-faint)' }}>{s.uses.toLocaleString()} uses</span>
          <div style={{ flex: 1 }}/>
          {!mine && onFork && <Btn kind="ghost" size="sm" icon={I.Copy} onClick={e => { e.stopPropagation(); onFork(); }}>Fork</Btn>}
          <Btn kind="secondary" size="sm" icon={I.Check} onClick={e => e.stopPropagation()}>Use</Btn>
        </div>
      </div>
    </div>
  );
}

function StyleDetailModal({ s, onClose, onFork }) {
  return (
    <Modal open={true} onClose={onClose} width={920}>
      <div style={{ position: 'relative' }}>
        {/* Hero */}
        <div style={{
          aspectRatio: '21/9',
          background: `linear-gradient(135deg, ${s.swatch.join(', ')})`,
          borderRadius: 'var(--r-xl) var(--r-xl) 0 0',
          position: 'relative',
        }}>
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
          <button className="btn btn--icon" onClick={onClose} style={{ position: 'absolute', top: 14, right: 14, background: 'rgba(0,0,0,0.45)', borderColor: 'rgba(255,255,255,0.20)', color: 'white' }}><I.Close size={14}/></button>
          <div style={{ position: 'absolute', bottom: 16, left: 22, right: 22 }}>
            <div style={{ font: '700 28px/1.1 var(--font-display)', color: 'white', textShadow: '0 2px 8px rgba(0,0,0,0.5)', letterSpacing: '-0.02em' }}>{s.name}</div>
            <div style={{ font: '500 13px/1.3 var(--font-sans)', color: 'rgba(255,255,255,0.85)', marginTop: 4, textShadow: '0 1px 4px rgba(0,0,0,0.5)' }}>{s.notes}</div>
          </div>
        </div>

        <div style={{ padding: 22 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 22 }}>
            <div>
              <div className="t-h5" style={{ marginBottom: 10 }}>Sample frames</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} style={{
                    aspectRatio: '16/9', borderRadius: 8,
                    background: `linear-gradient(${135 + i * 15}deg, ${s.swatch[i % 4]}, ${s.swatch[(i + 1) % 4]}, ${s.swatch[(i + 2) % 4]})`,
                    position: 'relative',
                    border: '1px solid var(--border-hairline)',
                  }}>
                    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 40%, rgba(255,255,255,0.20), transparent 70%)' }}/>
                  </div>
                ))}
              </div>

              <div className="t-h5" style={{ marginTop: 18, marginBottom: 10 }}>Prompt scaffolding</div>
              <div className="card" style={{ padding: 14, background: 'var(--surface-subtle)' }}>
                <div className="t-tiny" style={{ marginBottom: 6 }}>Lifted onto every T2I prompt</div>
                <div className="t-mono" style={{ font: '500 12px/1.5 var(--font-mono)', color: 'var(--fg-default)' }}>
                  cinematic still, {s.swatch[0]} dominant palette, low-key lighting, 35mm film grain, anamorphic flare, shallow depth of field, painterly atmosphere
                </div>
              </div>
              <div className="card" style={{ padding: 14, background: 'var(--surface-subtle)', marginTop: 8 }}>
                <div className="t-tiny" style={{ marginBottom: 6 }}>Negative prompt</div>
                <div className="t-mono" style={{ font: '500 12px/1.5 var(--font-mono)', color: 'var(--fg-default)' }}>
                  flat lighting, generic stock, oversaturated, watermark, text artifacts, blurry, lowres
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="card">
                <div className="t-tiny" style={{ marginBottom: 12 }}>Palette</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  {s.swatch.map((c, j) => (
                    <div key={j} style={{ flex: 1, aspectRatio: '1', borderRadius: 8, background: c, border: '1px solid var(--border-hairline)' }}/>
                  ))}
                </div>
                <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {s.swatch.map((c, j) => (
                    <div key={j} style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ width: 10, height: 10, borderRadius: 2, background: c, display: 'inline-block', marginRight: 6 }}/>
                      <span className="t-mono" style={{ font: '500 11px/1 var(--font-mono)', color: 'var(--fg-muted)', flex: 1 }}>{c}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card">
                <div className="t-tiny" style={{ marginBottom: 12 }}>Models</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span className="t-small">Keyframes</span>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>Avyal Imagine 4</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span className="t-small">Motion</span>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>Avyal Motion 3</span>
                  </div>
                </div>
              </div>

              <div className="card">
                <div className="t-tiny" style={{ marginBottom: 12 }}>Used by</div>
                <div className="t-small">{s.uses} videos · 12 channels</div>
              </div>
            </div>
          </div>

          <div className="divider" style={{ margin: '22px 0 18px' }}/>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Btn kind="ghost" onClick={onClose}>Close</Btn>
            {onFork && <Btn kind="secondary" icon={I.Copy} onClick={() => onFork(s)}>Fork & edit</Btn>}
            <Btn kind="primary" icon={I.Check}>Use on a channel</Btn>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function StyleBuilderModal({ base, onClose }) {
  const [step, setStep]   = React.useState(0);   // 0 inputs, 1 generating, 2 done
  const [name, setName]   = React.useState(base ? `${base.name} (mine)` : '');
  const [notes, setNotes] = React.useState(base?.notes || '');
  const [refs, setRefs]   = React.useState(0);

  return (
    <Modal open={true} onClose={onClose} width={680}>
      <div style={{ padding: 26, position: 'relative', overflow: 'hidden' }}>
        <SparkleField count={6} intensity={0.3}/>
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-fg)' }}>
              <I.Image size={18}/>
            </span>
            <span className="t-h4">{base ? `Fork "${base.name}"` : 'Build a visual style'}</span>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
          </div>

          <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
            {[0, 1, 2].map(i => <span key={i} style={{ flex: 1, height: 4, borderRadius: 999, background: i <= step ? 'var(--magic-grad)' : 'var(--surface-elev)' }}/>)}
          </div>

          {step === 0 && (
            <div>
              <label className="label">Name</label>
              <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Mythic Tales · House Look"/>

              <label className="label" style={{ marginTop: 14 }}>One-line description</label>
              <input value={notes} onChange={e => setNotes(e.target.value)} placeholder="e.g. Engraved illustration · sepia · ornate"/>

              <label className="label" style={{ marginTop: 14 }}>Reference images <span style={{ color: 'var(--fg-faint)', fontWeight: 500 }}>(5-20, optional)</span></label>
              <div style={{
                padding: 18, borderRadius: 14,
                border: '2px dashed var(--border-default)',
                background: 'var(--surface-subtle)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                gap: 10, cursor: 'pointer',
              }} onClick={() => setRefs(r => Math.min(20, r + 4))}>
                <I.Upload size={20} stroke="var(--fg-muted)"/>
                <div style={{ font: '600 14px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{refs > 0 ? `${refs} images uploaded` : 'Drop reference images here'}</div>
                <div className="t-small">JPG, PNG, HEIC · 20MB each</div>
              </div>

              {refs > 0 && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 6, marginTop: 10 }}>
                  {Array.from({ length: refs }).map((_, i) => (
                    <div key={i} style={{ aspectRatio: '1', borderRadius: 6, background: `hsl(${i * 40}, 35%, ${30 + (i % 4) * 10}%)` }}/>
                  ))}
                </div>
              )}

              <label className="label" style={{ marginTop: 18 }}>Or describe the look in your own words</label>
              <textarea placeholder="e.g. soft pastel watercolor, gentle rim light, paper grain, looks like a children's storybook from the 70s" rows={3}/>

              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 22 }}>
                <Btn kind="ghost" onClick={onClose}>Cancel</Btn>
                <Btn kind="magic" icon={I.Spark} onClick={() => { setStep(1); setTimeout(() => setStep(2), 2200); }}>Generate style</Btn>
              </div>
            </div>
          )}

          {step === 1 && (
            <div style={{ textAlign: 'center', padding: '40px 12px 24px' }}>
              <div style={{ position: 'relative', display: 'inline-block', marginBottom: 20 }}>
                <div style={{ position: 'absolute', inset: -30, borderRadius: '50%', background: 'radial-gradient(circle, var(--accent-tint-3) 0%, transparent 70%)', filter: 'blur(20px)' }}/>
                <div style={{ position: 'relative', width: 72, height: 72, borderRadius: '50%', border: '3px solid var(--accent-border-soft)', borderTopColor: 'var(--accent)', animation: 'slowSpin 1s linear infinite' }}/>
              </div>
              <div className="t-h4" style={{ marginBottom: 8 }}>Studying your references…</div>
              <div className="t-small" style={{ marginBottom: 24 }}>Extracting palette · prompt scaffolding · negative prompts</div>
            </div>
          )}

          {step === 2 && (
            <div style={{ textAlign: 'center', padding: '12px 0' }}>
              <div style={{ position: 'relative', display: 'inline-block', marginBottom: 18 }}>
                <span style={{ width: 64, height: 64, borderRadius: 18, background: 'var(--success-bg)', border: '1px solid var(--success-bd)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--success)' }}>
                  <I.Check size={28}/>
                </span>
              </div>
              <div className="t-h3" style={{ marginBottom: 8 }}>Your style is ready</div>
              <div className="t-small" style={{ marginBottom: 18 }}>Test it on a sample scene, or attach to a channel.</div>

              {/* preview */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginBottom: 18 }}>
                {['#2A1810','#7B4F2C','#D4A574','#F4E1B5'].map((c, i) => (
                  <div key={i} style={{ aspectRatio: '16/9', borderRadius: 6, background: `linear-gradient(${135 + i * 25}deg, ${c}, ${['#1B0F08','#5A3A1F','#C39A5E','#F2DCB3'][i]})` }}/>
                ))}
              </div>

              <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                <Btn kind="secondary" icon={I.Eye}>Test on sample</Btn>
                <Btn kind="primary" icon={I.Check} onClick={onClose}>Save</Btn>
              </div>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}

window.StylesLibraryScreen = StylesLibraryScreen;
