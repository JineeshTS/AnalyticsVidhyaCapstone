/* ============================================================
   AIcreators.cloud — Channels & Channel Identity
   ============================================================ */

function ChannelCard({ ch, onOpen }) {
  return (
    <div onClick={() => onOpen(ch)} className="card card--hover" style={{
      padding: 0, overflow: 'hidden', cursor: 'pointer',
    }}>
      <div style={{
        height: 96, background: ch.color, position: 'relative',
      }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 20% 30%, rgba(255,255,255,0.30), transparent 60%)' }}/>
        <span style={{
          position: 'absolute', left: 20, bottom: -22,
          width: 56, height: 56, borderRadius: '50%',
          background: ch.color, color: 'white',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 26, fontWeight: 700,
          border: '4px solid var(--bg-surface)',
          boxShadow: '0 4px 12px rgba(0,0,0,0.40)',
        }}>{ch.emoji || ch.name[0]}</span>
        <div style={{ position: 'absolute', top: 12, right: 12 }}>
          <Switch on={ch.autopilot} size="sm" onChange={()=>{}}/>
        </div>
      </div>
      <div style={{ padding: '32px 20px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <div className="t-h5">{ch.name}</div>
          <span className="t-small">{ch.handle}</span>
        </div>
        <div className="t-small" style={{ marginTop: 4 }}>{ch.niche}</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <span className="chip">{ch.format}</span>
          <span className="chip"><I.Languages size={12}/> {ch.language}</span>
        </div>
        <div className="divider" style={{ margin: '16px 0' }}/>
        <div style={{ display: 'flex', gap: 18 }}>
          <div>
            <div className="t-tiny">Subscribers</div>
            <div style={{ font:'700 18px/1 var(--font-display)', color:'var(--fg-strong)', marginTop: 6, letterSpacing: '-0.02em' }}>{ch.subs}</div>
          </div>
          <div>
            <div className="t-tiny">In queue</div>
            <div style={{ font:'700 18px/1 var(--font-display)', color:'var(--accent-fg)', marginTop: 6, letterSpacing: '-0.02em' }}>{ch.videosInQueue}</div>
          </div>
          <div style={{ flex: 1 }}/>
          <button className="btn btn--ghost btn--icon"><I.More size={16}/></button>
        </div>
      </div>
    </div>
  );
}

function ChannelsScreen({ onOpenChannel }) {
  return (
    <div style={{ flex: 1, overflowY: 'auto', position: 'relative' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto', position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Your channels</div>
            <div className="t-small" style={{ marginTop: 4 }}>Each channel has its own identity, format, and queue. Autopilot can run them independently.</div>
          </div>
          <Btn kind="secondary" icon={I.Youtube}>Connect YouTube</Btn>
          <Btn kind="primary" icon={I.Plus}>New channel</Btn>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {MOCK.channels.map(ch => <ChannelCard key={ch.id} ch={ch} onOpen={onOpenChannel}/>)}
          {/* Empty add card */}
          <div className="card card--hover" style={{
            border: '1px dashed var(--border-default)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            padding: 32, minHeight: 240, cursor: 'pointer',
          }}>
            <span style={{
              width: 56, height: 56, borderRadius: 16,
              background: 'var(--magic-tint)',
              border: '1px solid var(--brand-soft-bd)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--accent-fg)', marginBottom: 14,
            }}><I.Plus size={24}/></span>
            <div className="t-h5">Add another channel</div>
            <div className="t-small" style={{ marginTop: 6, textAlign: 'center' }}>Run unlimited channels in parallel, each with its own brand voice.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Channel Identity (a single channel's settings) ---------- */
function ChannelIdentityScreen({ channel, onBack }) {
  const ch = channel || MOCK.channels[0];
  const [tab, setTab] = React.useState('identity');

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="t-small" style={{ cursor: 'pointer' }} onClick={onBack}>Channels</span>
            <I.ChevRight size={12} stroke="var(--fg-faint)"/>
            <span className="t-small" style={{ color: 'var(--fg-default)' }}>{ch.name}</span>
          </div>
          <div style={{ flex: 1 }}/>
          <Switch on={ch.autopilot} label="Autopilot for this channel"/>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{
            width: 64, height: 64, borderRadius: '50%',
            background: ch.color, color: 'white',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 28, fontWeight: 700, flexShrink: 0,
            boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.20), 0 6px 18px rgba(0,0,0,0.40)',
          }}>{ch.emoji || ch.name[0]}</span>
          <div style={{ flex: 1 }}>
            <div className="t-h3">{ch.name}</div>
            <div className="t-small" style={{ marginTop: 4 }}>{ch.handle} · {ch.subs} subscribers · {ch.niche}</div>
          </div>
          <Btn kind="secondary" icon={I.Eye}>View on YouTube</Btn>
        </div>
        <div style={{ marginTop: 16 }}>
          <Tabs
            value={tab}
            onChange={setTab}
            items={[
              { id: 'identity', label: 'Identity',    icon: I.Spark },
              { id: 'format',   label: 'Format',      icon: I.Film },
              { id: 'voice',    label: 'Voice',       icon: I.Mic },
              { id: 'style',    label: 'Visual style', icon: I.Image },
              { id: 'schedule', label: 'Schedule',    icon: I.Calendar },
              { id: 'topics',   label: 'Topic rules', icon: I.Filter },
            ]}
          />
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px 40px' }}>
        <div style={{ maxWidth: 1080, margin: '0 auto' }}>
          {tab === 'identity' && <IdentityTab ch={ch}/>}
          {tab === 'format'   && <FormatTab ch={ch}/>}
          {tab === 'voice'    && <VoiceTab ch={ch}/>}
          {tab === 'style'    && <StyleTab ch={ch}/>}
          {tab === 'schedule' && <ScheduleTab ch={ch}/>}
          {tab === 'topics'   && <TopicRulesTab ch={ch}/>}
        </div>
      </div>
    </div>
  );
}

function IdentityTab({ ch }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 20 }}>
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div className="t-h4" style={{ marginBottom: 4 }}>Tell Avyal who this channel is</div>
        <div className="t-small">This is the brain we use for every script, every thumbnail, every title. Be specific — the more honest you are, the better the autopilot.</div>

        <div>
          <label className="label">Channel name</label>
          <input defaultValue={ch.name}/>
        </div>
        <div>
          <label className="label">One-line description (what does this channel do?)</label>
          <input defaultValue="Cinematic walk-throughs of the ancient world's strangest stories."/>
        </div>
        <div>
          <label className="label">Brand voice — describe the narrator</label>
          <textarea defaultValue="A patient, slightly conspiratorial historian. Drops the listener inside the scene before explaining what they're seeing. Never lectures. Reveals myths rather than repeating them. Always ends on a question."/>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <label className="label">Forbidden words / topics</label>
            <input defaultValue="never use: 'epic', 'mind-blowing', emoji in title"/>
          </div>
          <div>
            <label className="label">Always include</label>
            <input defaultValue="one cited source per video; one open question"/>
          </div>
        </div>
        <div>
          <label className="label">Reference channels (we'll study their pacing & retention)</label>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['@KingsAndGenerals','@hardcorehistory','@MetatronYT'].map(t => (
              <span key={t} className="chip">{t} <I.Close size={10}/></span>
            ))}
            <button className="btn btn--ghost btn--sm" style={{ height: 28 }}><I.Plus size={12}/> Add</button>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 }}>
          <Btn kind="ghost">Discard</Btn>
          <Btn kind="primary" icon={I.Check}>Save identity</Btn>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="card" style={{ position: 'relative', overflow: 'hidden' }}>
          <SparkleField count={8} intensity={0.4}/>
          <div style={{ position: 'relative' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <I.Spark size={20} stroke="var(--accent-fg)"/>
              <span className="t-h5">AI character preview</span>
            </div>
            <div style={{ font: '500 14px/1.6 var(--font-sans)', color: 'var(--fg-default)', fontStyle: 'italic', textWrap: 'pretty' }}>
              "You're standing in a hallway you've never been allowed to enter. The torches haven't been lit in a thousand years. But the dust on the floor — look down — the dust hasn't settled the way it should…"
            </div>
            <Btn kind="ghost" size="sm" icon={I.Refresh} style={{ marginTop: 14 }}>Regenerate sample</Btn>
          </div>
        </div>
        <div className="card">
          <div className="t-tiny" style={{ marginBottom: 12 }}>YouTube connection</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <I.Youtube size={20} stroke="var(--danger)"/>
            <div style={{ flex: 1 }}>
              <div style={{ font:'600 13px/1.2 var(--font-sans)', color:'var(--fg-strong)' }}>{ch.handle}</div>
              <div className="t-small" style={{ marginTop: 2 }}>Connected · upload + analytics</div>
            </div>
            <span className="chip chip--success"><I.Check size={10}/> Live</span>
          </div>
        </div>
        <div className="card">
          <div className="t-tiny" style={{ marginBottom: 12 }}>Channel art</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {[ch.color, 'linear-gradient(135deg,#0F172A,#7C3AED)', 'linear-gradient(135deg,#1E293B,#22D3EE)'].map((g, i) => (
              <div key={i} style={{
                aspectRatio: '16/9', borderRadius: 8, background: g,
                border: i === 0 ? '1px solid var(--accent)' : '1px solid var(--border-hairline)',
                boxShadow: i === 0 ? '0 0 0 3px rgba(139,92,246,0.20)' : 'none',
                cursor: 'pointer',
              }}/>
            ))}
            <div style={{
              aspectRatio: '16/9', borderRadius: 8,
              border: '1px dashed var(--border-default)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--fg-muted)', cursor: 'pointer',
            }}><I.Plus size={16}/></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FormatTab({ ch }) {
  return (
    <div className="card">
      <div className="t-h4" style={{ marginBottom: 18 }}>Format rules</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
        <div>
          <label className="label">Default format</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
            {[
              { id: 'shorts', label: 'Shorts', sub: '15–60s · 9:16', icon: I.Lightning },
              { id: 'longform', label: 'Long-form', sub: '6–14 min · 16:9', icon: I.Film, active: true },
              { id: 'cartoon', label: 'Cartoon', sub: '2–5 min · 16:9', icon: I.Image },
              { id: 'feature', label: 'Feature', sub: '1–3 min · cinematic', icon: I.Play },
            ].map(f => (
              <div key={f.id} style={{
                padding: 12, borderRadius: 12, cursor: 'pointer',
                background: f.active ? 'var(--accent-tint-1)' : 'var(--surface-subtle)',
                border: `1px solid ${f.active ? 'var(--accent)' : 'var(--border-hairline)'}`,
              }}>
                <f.icon size={18} stroke={f.active ? 'var(--accent-fg)' : 'var(--fg-muted)'}/>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', marginTop: 8 }}>{f.label}</div>
                <div className="t-small" style={{ marginTop: 2 }}>{f.sub}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div><label className="label">Target length</label><input defaultValue="10–12 minutes"/></div>
          <div><label className="label">Aspect ratio</label><input defaultValue="16:9 (horizontal)"/></div>
          <div><label className="label">Cadence</label><input defaultValue="3 videos per week · Mon/Wed/Fri"/></div>
          <div><label className="label">Languages</label><input defaultValue={ch.language}/></div>
        </div>
      </div>
    </div>
  );
}

function VoiceTab({ ch }) {
  const [picked, setPicked] = React.useState('v4');
  return (
    <div>
      <div className="t-h4" style={{ marginBottom: 4 }}>Voice library</div>
      <div className="t-small" style={{ marginBottom: 18 }}>Pick the narrator for this channel. We'll clone it for every video.</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
        {MOCK.voices.map(v => {
          const isPicked = picked === v.id;
          return (
            <div key={v.id} onClick={() => setPicked(v.id)} className="card card--hover" style={{
              cursor: 'pointer',
              border: `1px solid ${isPicked ? 'var(--accent)' : 'var(--border-hairline)'}`,
              boxShadow: isPicked ? '0 0 0 3px rgba(139,92,246,0.20)' : 'none',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{
                  width: 44, height: 44, borderRadius: '50%',
                  background: `linear-gradient(135deg, ${['#A78BFA','#22D3EE','#F472B6','#34D399','#FBBF24','#F87171'][MOCK.voices.indexOf(v) % 6]}, var(--violet-600))`,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  color: 'white', font: '700 18px/1 var(--font-display)', flexShrink: 0,
                }}>{v.name[0]}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{v.name}</div>
                  <div className="t-small" style={{ marginTop: 4 }}>{v.gender} · {v.accent} · {v.vibe}</div>
                </div>
                <button className="btn btn--ghost btn--icon" onClick={e=>e.stopPropagation()}><I.Play size={14}/></button>
              </div>
              <div style={{ marginTop: 14, height: 28, display: 'flex', alignItems: 'center', gap: 2 }}>
                {Array.from({ length: 40 }).map((_, i) => {
                  const h = 4 + Math.abs(Math.sin((i + MOCK.voices.indexOf(v) * 7) * 0.7) * 18);
                  return <span key={i} style={{ width: 2, height: h, background: isPicked ? 'var(--accent)' : 'var(--border-strong)', borderRadius: 1 }}/>;
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StyleTab({ ch }) {
  return (
    <div>
      <div className="t-h4" style={{ marginBottom: 4 }}>Visual style</div>
      <div className="t-small" style={{ marginBottom: 18 }}>Every keyframe and motion clip will inherit this look. Pick a preset or build your own.</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
        {MOCK.styles.map((s, i) => {
          const isPicked = i === 4;
          return (
            <div key={s.id} className="card card--hover" style={{
              padding: 0, overflow: 'hidden', cursor: 'pointer',
              border: `1px solid ${isPicked ? 'var(--accent)' : 'var(--border-hairline)'}`,
              boxShadow: isPicked ? '0 0 0 3px rgba(139,92,246,0.20)' : 'none',
            }}>
              <div style={{
                aspectRatio: '16/9',
                background: `linear-gradient(135deg, ${s.swatch.join(', ')})`,
                position: 'relative',
              }}>
                <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.18), transparent 60%)' }}/>
                {isPicked && <span style={{ position: 'absolute', top: 8, right: 8 }} className="chip chip--success"><I.Check size={10}/> active</span>}
              </div>
              <div style={{ padding: 14 }}>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{s.name}</div>
                <div className="t-small" style={{ marginTop: 4 }}>{s.notes}</div>
                <div style={{ display: 'flex', gap: 4, marginTop: 10 }}>
                  {s.swatch.map((sw, j) => <span key={j} style={{ width: 16, height: 16, borderRadius: 4, background: sw, border: '1px solid var(--border-hairline)' }}/>)}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ScheduleTab({ ch }) {
  const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const active = [1, 3, 5];
  return (
    <div className="card">
      <div className="t-h4" style={{ marginBottom: 18 }}>Publishing schedule</div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {days.map((d, i) => (
          <button key={d} style={{
            flex: 1, padding: '14px 0', borderRadius: 12,
            background: active.includes(i) ? 'var(--accent-tint-2)' : 'var(--surface-subtle)',
            border: `1px solid ${active.includes(i) ? 'var(--accent)' : 'var(--border-hairline)'}`,
            color: active.includes(i) ? 'var(--accent-fg)' : 'var(--fg-muted)',
            font: '600 13px/1 var(--font-sans)', cursor: 'pointer',
          }}>{d}</button>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        <div><label className="label">Time slot</label><input defaultValue="6:00 PM local"/></div>
        <div><label className="label">Audience timezone</label><input defaultValue="America/New_York"/></div>
        <div><label className="label">Buffer</label><input defaultValue="Keep 5 videos always ready"/></div>
      </div>
    </div>
  );
}

function TopicRulesTab({ ch }) {
  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div className="t-h4">Topic discovery rules</div>
      <div className="t-small">We continuously scan trends, the channel's history, and competing channels to surface 20–40 ideas per week. These rules tune what we suggest.</div>

      <div>
        <label className="label">Topics we love</label>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['ancient mystery','lost cities','underwater archaeology','etymology','first-person reconstruction'].map(t => (
            <span key={t} className="chip chip--brand">{t} <I.Close size={10}/></span>
          ))}
          <button className="btn btn--ghost btn--sm" style={{ height: 28 }}><I.Plus size={12}/> Add</button>
        </div>
      </div>
      <div>
        <label className="label">Topics we avoid</label>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['conspiracy','politics','clickbait listicles'].map(t => (
            <span key={t} className="chip chip--danger">{t} <I.Close size={10}/></span>
          ))}
          <button className="btn btn--ghost btn--sm" style={{ height: 28 }}><I.Plus size={12}/> Add</button>
        </div>
      </div>
      <div>
        <label className="label">Minimum confidence score to auto-queue</label>
        <input defaultValue="80"/>
        <div className="t-small" style={{ marginTop: 6 }}>Anything below 80 will appear in the idea queue but won't auto-start.</div>
      </div>
    </div>
  );
}

window.ChannelsScreen = ChannelsScreen;
window.ChannelIdentityScreen = ChannelIdentityScreen;
