/* ============================================================
   AIcreators.cloud · Legal & policy pages
   ============================================================
   PURPOSE
     All the legal surfaces a SaaS needs to ship to enterprise
     customers, comply with GDPR/CCPA, and pass security review:

       /terms                – Terms of Service
       /privacy              – Privacy Policy
       /cookies              – Cookie Policy
       /aup                  – Acceptable Use Policy
       /dpa                  – Data Processing Agreement
       /subprocessors        – Sub-processor list
       /security             – Security overview + cert badges
       /content-policy       – AI content guidelines
       /copyright            – DMCA + takedown form
       /data-export          – Self-serve GDPR/CCPA export request
       /data-deletion        – Self-serve account/data deletion request

   These pages render as standalone routes (no app shell), so
   they can be linked from emails, footers, and external blog
   posts without requiring auth.

   BACKEND
     GET  /legal/{slug}                 – the latest published version
     GET  /legal/{slug}/versions        – previous versions for audit
     POST /legal/dmca-takedown          – { url, original_owner, evidence }
     POST /me/data-export               – queues a GDPR export job
     POST /me/data-deletion             – schedules account deletion (30-day cool-off)

   IMPORTANT
     Every policy is markdown-rendered server-side. The text below
     is placeholder — replace before launch with copy reviewed by
     counsel. We've structured the headings to match common
     industry standards (Razorpay, Vercel, Linear) so legal review
     is straightforward.
   ============================================================ */

const LEGAL_PAGES = [
  { slug: 'terms',          title: 'Terms of Service',         updated: 'May 1, 2025',  icon: 'Edit' },
  { slug: 'privacy',        title: 'Privacy Policy',            updated: 'May 1, 2025',  icon: 'Lock' },
  { slug: 'cookies',        title: 'Cookie Policy',             updated: 'Apr 18, 2025', icon: 'Help' },
  { slug: 'aup',            title: 'Acceptable Use Policy',     updated: 'Apr 18, 2025', icon: 'Eye' },
  { slug: 'dpa',            title: 'Data Processing Agreement', updated: 'Mar 22, 2025', icon: 'Users' },
  { slug: 'subprocessors',  title: 'Sub-processors',            updated: 'May 10, 2025', icon: 'Cloud' },
  { slug: 'security',       title: 'Security & compliance',     updated: 'May 1, 2025',  icon: 'Lock' },
  { slug: 'content-policy', title: 'AI content policy',         updated: 'Apr 22, 2025', icon: 'Sparkles' },
  { slug: 'copyright',      title: 'Copyright & DMCA',          updated: 'Apr 18, 2025', icon: 'Help' },
  { slug: 'data-export',    title: 'Request your data',         updated: '—',            icon: 'Download', interactive: true },
  { slug: 'data-deletion',  title: 'Delete your account',       updated: '—',            icon: 'Trash',    interactive: true, danger: true },
];

function LegalShell({ slug, children }) {
  const page = LEGAL_PAGES.find(p => p.slug === slug);
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg-app)' }}>
      <header style={{ padding: '20px 32px', display: 'flex', alignItems: 'center', borderBottom: '1px solid var(--border-hairline)', position: 'relative', zIndex: 2 }}>
        <a href="AIcreators Cloud.html" style={{ textDecoration: 'none', display: 'inline-flex' }}>
          <LogoLockup markSize={32} wordSize={17}/>
        </a>
        <span style={{ marginLeft: 10, padding: '4px 10px', borderRadius: 999, background: 'var(--surface-hover)', font: '600 11px/1 var(--font-sans)', color: 'var(--fg-muted)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Legal</span>
        <div style={{ flex: 1 }}/>
        <a href="AIcreators Cloud.html" className="t-small" style={{ color: 'var(--brand)' }}>Back to studio</a>
      </header>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '280px 1fr', maxWidth: 1200, width: '100%', margin: '0 auto', padding: '40px 32px', gap: 40 }}>
        {/* Side nav */}
        <aside>
          <div className="t-tiny" style={{ marginBottom: 10 }}>Documents</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {LEGAL_PAGES.map(p => {
              const active = p.slug === slug;
              const Ico = I[p.icon] || I.Help;
              return (
                <a key={p.slug} href={`#${p.slug}`} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '10px 12px', borderRadius: 10,
                  textDecoration: 'none',
                  background: active ? 'var(--brand-soft-bg)' : 'transparent',
                  color: active ? 'var(--brand)' : p.danger ? 'var(--danger-fg)' : 'var(--fg-default)',
                  font: `${active ? 600 : 500} 13px/1.2 var(--font-sans)`,
                  transition: 'background 120ms var(--ease-out)',
                }}
                onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--surface-hover)'; }}
                onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}>
                  <Ico size={14}/>
                  <span style={{ flex: 1 }}>{p.title}</span>
                </a>
              );
            })}
          </div>
        </aside>

        {/* Article */}
        <article style={{ minWidth: 0 }}>
          {page && (
            <div style={{ marginBottom: 32 }}>
              <div className="t-tiny" style={{ marginBottom: 8 }}>Legal · {page.updated !== '—' && `Last updated ${page.updated}`}</div>
              <div className="t-h1" style={{ fontSize: 36, marginBottom: 14 }}>{page.title}</div>
            </div>
          )}
          {children}

          {!page?.interactive && (
            <div className="card" style={{ marginTop: 40, background: 'var(--surface-subtle)' }}>
              <div className="t-tiny" style={{ marginBottom: 8 }}>Questions about this policy?</div>
              <div className="t-body" style={{ color: 'var(--fg-default)' }}>
                Email <a href="mailto:legal@aicreators.cloud" style={{ color: 'var(--brand)' }}>legal@aicreators.cloud</a> or write to AIcreators Inc., 548 Market St #62189, San Francisco, CA 94104.
              </div>
            </div>
          )}
        </article>
      </div>

      <footer style={{ padding: '20px 32px', borderTop: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 16 }}>
        <span className="t-small">© 2026 AIcreators, Inc.</span>
        <div style={{ flex: 1 }}/>
        <a href="AIcreators Cloud Status.html" className="t-small">Status</a>
        <a href="#terms" className="t-small">Terms</a>
        <a href="#privacy" className="t-small">Privacy</a>
        <a href="#dpa" className="t-small">DPA</a>
      </footer>
    </div>
  );
}

/* ---------- Reusable article building blocks ---------- */
function LegalH2({ children })  { return <h2 style={{ font: '700 22px/1.3 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.01em', marginTop: 36, marginBottom: 12 }}>{children}</h2>; }
function LegalH3({ children })  { return <h3 style={{ font: '600 17px/1.3 var(--font-display)', color: 'var(--fg-strong)', marginTop: 22, marginBottom: 10 }}>{children}</h3>; }
function LegalP({ children })   { return <p style={{ font: '500 15px/1.7 var(--font-sans)', color: 'var(--fg-default)', margin: '0 0 14px', textWrap: 'pretty' }}>{children}</p>; }
function LegalUL({ items })     { return <ul style={{ font: '500 15px/1.7 var(--font-sans)', color: 'var(--fg-default)', margin: '0 0 14px', paddingLeft: 22 }}>{items.map((it, i) => <li key={i} style={{ marginBottom: 4 }}>{it}</li>)}</ul>; }

/* ============================================================
   TERMS OF SERVICE
   ============================================================ */
function TermsArticle() {
  return (
    <LegalShell slug="terms">
      <LegalP><em>Plain-English summary:</em> You can use AIcreators to make AI-assisted videos and publish them. We provide the tools; you're responsible for what you publish. Don't break the law, don't impersonate people, and pay your subscription.</LegalP>

      <LegalH2>1. Acceptance of terms</LegalH2>
      <LegalP>By accessing or using AIcreators.cloud ("Service"), you agree to these Terms of Service. If you're using the Service on behalf of a company, you confirm you have authority to bind that company.</LegalP>

      <LegalH2>2. Your account</LegalH2>
      <LegalUL items={[
        'You must be 16 or older.',
        'You're responsible for keeping your credentials safe.',
        'One person per personal account; teams use seats.',
        'We can suspend accounts that violate these Terms or the Acceptable Use Policy.',
      ]}/>

      <LegalH2>3. The Service</LegalH2>
      <LegalP>AIcreators is an AI-assisted video production platform. We script, render, voice, and publish videos to platforms you connect (YouTube, Instagram, TikTok, etc.). You can review, approve, or override any pipeline step.</LegalP>

      <LegalH2>4. Content & ownership</LegalH2>
      <LegalH3>4.1 Your content</LegalH3>
      <LegalP>You own all videos you create. We claim no ownership over your scripts, voice clones, avatars, or finished videos. You grant us a limited license to process, render, and deliver your content as needed to operate the Service.</LegalP>
      <LegalH3>4.2 AI-generated content</LegalH3>
      <LegalP>You're responsible for the AI-generated output your account produces. We embed C2PA provenance metadata in every render — required by many platforms.</LegalP>
      <LegalH3>4.3 Voice clones & avatars</LegalH3>
      <LegalP>You may only clone <strong>your own</strong> voice and face, or those you have explicit written consent to use. Impersonation of public figures or third parties is prohibited and will result in immediate account termination.</LegalP>

      <LegalH2>5. Payment</LegalH2>
      <LegalUL items={[
        'Subscriptions renew automatically until canceled.',
        'Credits do not carry over between billing periods unless explicitly stated.',
        'Refunds are at our discretion; see our refund policy.',
        'We reserve the right to change pricing with 30 days notice.',
      ]}/>

      <LegalH2>6. Third-party platforms</LegalH2>
      <LegalP>When you connect a YouTube, Instagram, or other social account, you authorize us to publish on your behalf per the scopes you grant. We follow each platform's developer terms; if they revoke our access, the Service may degrade.</LegalP>

      <LegalH2>7. Termination</LegalH2>
      <LegalP>You can cancel any time from <a href="AIcreators Cloud.html#billing" style={{ color: 'var(--brand)' }}>Billing & Plan</a>. We can terminate accounts for material breach. On termination, your data is retained 30 days then permanently deleted (see Privacy Policy).</LegalP>

      <LegalH2>8. Warranties & liability</LegalH2>
      <LegalP>The Service is provided "as is." We don't guarantee a video will rank, monetize, or pass platform review. Our liability is capped at the amount you paid us in the previous 12 months.</LegalP>

      <LegalH2>9. Governing law</LegalH2>
      <LegalP>These Terms are governed by the laws of the State of California, USA. Disputes go to the federal/state courts in San Francisco County.</LegalP>

      <LegalH2>10. Changes</LegalH2>
      <LegalP>We'll notify you of material changes by email at least 30 days before they take effect.</LegalP>
    </LegalShell>
  );
}

/* ============================================================
   PRIVACY POLICY
   ============================================================ */
function PrivacyArticle() {
  return (
    <LegalShell slug="privacy">
      <LegalP><em>Plain-English summary:</em> We collect what we need to run the Service (your account, your content, how you use it). We don't sell your data. We use it to deliver the Service, improve it, and meet our legal obligations.</LegalP>

      <LegalH2>1. What we collect</LegalH2>
      <LegalH3>1.1 You give us</LegalH3>
      <LegalUL items={[
        'Account: name, email, country, password hash (or OAuth provider id).',
        'Content: scripts, prompts, uploaded images, voice samples, channel identity, generated videos.',
        'Payment: billing details (held by Razorpay — tokenized, never on our servers).',
        'Support: messages you send, attachments you upload.',
      ]}/>
      <LegalH3>1.2 We collect automatically</LegalH3>
      <LegalUL items={[
        'Usage: pages visited, features used, pipeline stages run.',
        'Device: browser type, OS, screen size, language.',
        'Network: IP address, approximate location (city), session cookies.',
        'Cookies: see Cookie Policy.',
      ]}/>
      <LegalH3>1.3 From third parties</LegalH3>
      <LegalUL items={[
        'YouTube / Instagram / TikTok: channel metadata, analytics, OAuth scopes you grant.',
        'Razorpay: subscription status, invoice history.',
        'Sentry: error logs (no PII).',
      ]}/>

      <LegalH2>2. How we use it</LegalH2>
      <LegalUL items={[
        'Operate the Service (run your pipeline jobs, publish videos).',
        'Bill you and prevent fraud.',
        'Improve our models on aggregated, de-identified usage data.',
        'Send transactional email (publish confirmations, low-credit warnings) and, with consent, marketing.',
        'Respond to legal requests.',
      ]}/>
      <LegalP><strong>We do NOT</strong> sell your data, train foundation models on your private content, or share it with advertisers.</LegalP>

      <LegalH2>3. Legal bases (GDPR)</LegalH2>
      <LegalUL items={[
        'Contract — to deliver the Service you purchased.',
        'Legitimate interests — fraud prevention, product analytics.',
        'Consent — marketing email, optional integrations.',
        'Legal obligation — tax, anti-money-laundering.',
      ]}/>

      <LegalH2>4. Sharing</LegalH2>
      <LegalP>We share data only with sub-processors who help us run the Service. See the full <a href="#subprocessors" style={{ color: 'var(--brand)' }}>Sub-processors list</a> — they're contractually bound to the same protections.</LegalP>

      <LegalH2>5. Retention</LegalH2>
      <LegalUL items={[
        'Account data: while your account is active + 30 days after deletion.',
        'Pipeline artifacts (drafts, intermediate frames): 90 days.',
        'Published videos: indefinitely (they're on your YouTube/etc. anyway).',
        'Voice clones: until you delete them; immediate deletion on request.',
        'Logs: 30 days (security), 1 year (financial).',
      ]}/>

      <LegalH2>6. Your rights</LegalH2>
      <LegalUL items={[
        'Access — download a copy of everything we have (see Data Export).',
        'Rectification — edit your account anytime in Settings.',
        'Erasure — delete your account (Data Deletion).',
        'Portability — export your generated videos as MP4s.',
        'Objection — opt out of marketing and product analytics from Settings.',
        'Complaint — to your local data-protection authority.',
      ]}/>

      <LegalH2>7. International transfers</LegalH2>
      <LegalP>Data is stored in AWS us-east-1 by default. EU customers can opt for eu-west-1. Transfers between regions use Standard Contractual Clauses.</LegalP>

      <LegalH2>8. Children</LegalH2>
      <LegalP>The Service is not directed at children under 16. If you believe a child has signed up, contact <a href="mailto:privacy@aicreators.cloud" style={{ color: 'var(--brand)' }}>privacy@aicreators.cloud</a>.</LegalP>

      <LegalH2>9. Contact</LegalH2>
      <LegalP>Privacy questions: <a href="mailto:privacy@aicreators.cloud" style={{ color: 'var(--brand)' }}>privacy@aicreators.cloud</a>. EU representative: VeraSafe Ireland, Dublin.</LegalP>
    </LegalShell>
  );
}

/* ============================================================
   COOKIE POLICY
   ============================================================ */
function CookiesArticle() {
  const cookies = [
    { name: 'aic_session',       purpose: 'Sign-in session',                expires: '14 days',  type: 'essential' },
    { name: 'aic_admin_session', purpose: 'Admin sign-in session',          expires: '4 hours',  type: 'essential' },
    { name: 'aic_csrf',          purpose: 'CSRF protection',                expires: 'session',  type: 'essential' },
    { name: 'aic_consent',       purpose: 'Your cookie preferences',         expires: '1 year',   type: 'essential' },
    { name: '_ga',               purpose: 'Aggregate analytics (Plausible)', expires: '13 months',type: 'analytics' },
    { name: 'aic_route',         purpose: 'Remember last route on refresh', expires: '7 days',   type: 'preference' },
  ];
  return (
    <LegalShell slug="cookies">
      <LegalP>This page lists the cookies we set and why.</LegalP>

      <LegalH2>Cookie types</LegalH2>
      <LegalUL items={[
        <span><strong>Essential</strong> — sign-in and security. Cannot be disabled.</span>,
        <span><strong>Analytics</strong> — aggregated usage stats. Disabled by default for EU visitors.</span>,
        <span><strong>Preferences</strong> — remembering things like your theme or last route.</span>,
      ]}/>

      <LegalH2>The list</LegalH2>
      <div className="card" style={{ padding: 0, marginBottom: 18 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--surface-subtle)' }}>
              {['Name','Purpose','Expires','Type'].map(h => (
                <th key={h} style={{ padding: '10px 14px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {cookies.map((c, i) => (
              <tr key={c.name} style={{ borderBottom: i < cookies.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
                <td style={{ padding: '10px 14px', font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{c.name}</td>
                <td style={{ padding: '10px 14px', font: '500 13px/1.4 var(--font-sans)', color: 'var(--fg-default)' }}>{c.purpose}</td>
                <td style={{ padding: '10px 14px' }} className="t-small">{c.expires}</td>
                <td style={{ padding: '10px 14px' }}>
                  {c.type === 'essential' && <span className="chip">Essential</span>}
                  {c.type === 'analytics' && <span className="chip chip--info">Analytics</span>}
                  {c.type === 'preference' && <span className="chip chip--success">Preference</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <LegalH2>Your choices</LegalH2>
      <LegalP>Click the cookie icon in the footer of any page to update your preferences. You can also disable cookies in your browser; the Service may not work fully without essential cookies.</LegalP>
    </LegalShell>
  );
}

/* ============================================================
   ACCEPTABLE USE POLICY
   ============================================================ */
function AUPArticle() {
  return (
    <LegalShell slug="aup">
      <LegalP><em>Plain-English summary:</em> Don't make hateful, illegal, or impersonating content. Don't try to break our systems. Don't help others do either.</LegalP>

      <LegalH2>You may not use the Service to create or publish</LegalH2>
      <LegalUL items={[
        'Content that incites violence or hatred against protected groups',
        'Sexual content involving minors',
        'Non-consensual intimate imagery (NCII), real or deepfaked',
        'Content that impersonates real people without consent (politicians, celebrities, your boss)',
        'Misinformation likely to cause real-world harm (medical, election, financial)',
        'Spam, scams, phishing, or pyramid-scheme promotion',
        'Content that violates third-party intellectual property',
        'Content that violates a third-party platform's policies (which would get your channel banned anyway)',
      ]}/>

      <LegalH2>You may not</LegalH2>
      <LegalUL items={[
        'Attempt to bypass our content moderation classifiers',
        'Reverse-engineer, scrape, or stress-test the Service',
        'Use the API in ways that exceed published rate limits',
        'Share API keys with parties outside your organization',
        'Use voice clones to commit fraud or harassment',
      ]}/>

      <LegalH2>Enforcement</LegalH2>
      <LegalP>Violations result in (in escalating order) a warning, content removal, temporary suspension, and permanent ban with no refund. Severe violations (CSAM, NCII) are reported to law enforcement and the National Center for Missing & Exploited Children.</LegalP>

      <LegalH2>Report abuse</LegalH2>
      <LegalP>Email <a href="mailto:trust@aicreators.cloud" style={{ color: 'var(--brand)' }}>trust@aicreators.cloud</a>. We investigate every report within 24 hours.</LegalP>
    </LegalShell>
  );
}

/* ============================================================
   DPA (Data Processing Agreement)
   ============================================================ */
function DPAArticle() {
  return (
    <LegalShell slug="dpa">
      <LegalP>This Data Processing Agreement supplements our Terms of Service when you process personal data on behalf of others. Most teams on the Studio Pro and Studio plans need this.</LegalP>

      <LegalH2>1. Roles</LegalH2>
      <LegalUL items={[
        'You are the <strong>data controller</strong>.',
        'AIcreators is the <strong>data processor</strong> acting on your documented instructions.',
        'Our sub-processors are <strong>sub-processors</strong>; see the list.',
      ]}/>

      <LegalH2>2. Subject matter</LegalH2>
      <LegalUL items={[
        'Type of data: scripts, voice samples, channel analytics, end-viewer engagement signals.',
        'Categories of subjects: your end-users, your team, your channel's viewers.',
        'Processing operations: storage, generation, transcoding, publishing.',
        'Duration: as long as your account is active + 30 days.',
      ]}/>

      <LegalH2>3. Security</LegalH2>
      <LegalUL items={[
        'AES-256 at rest, TLS 1.3 in transit.',
        'Voice clone artifacts encrypted with per-user keys.',
        'SOC 2 Type II audited annually.',
        'Access logs retained 1 year; admin actions audited and immutable.',
      ]}/>

      <LegalH2>4. Sub-processors</LegalH2>
      <LegalP>See the live <a href="#subprocessors" style={{ color: 'var(--brand)' }}>Sub-processors list</a>. We give 30 days notice before adding a new sub-processor; you may object.</LegalP>

      <LegalH2>5. Data subject requests</LegalH2>
      <LegalP>If you receive an access/erasure request from one of your data subjects, contact <a href="mailto:dpa@aicreators.cloud" style={{ color: 'var(--brand)' }}>dpa@aicreators.cloud</a>; we'll help you respond within 30 days.</LegalP>

      <LegalH2>6. International transfers</LegalH2>
      <LegalP>Standard Contractual Clauses (SCCs) attached as Annex II. EU data can be pinned to eu-west-1 on the Studio plan.</LegalP>

      <LegalH2>7. Signing</LegalH2>
      <LegalP>This DPA is automatically in force when you sign up for Studio Pro or Studio. For a counter-signed copy, email <a href="mailto:legal@aicreators.cloud" style={{ color: 'var(--brand)' }}>legal@aicreators.cloud</a>.</LegalP>
    </LegalShell>
  );
}

/* ============================================================
   SUB-PROCESSORS
   ============================================================ */
function SubprocessorsArticle() {
  const sp = [
    { name: 'Amazon Web Services',     purpose: 'Cloud hosting + storage',        location: 'us-east-1 / eu-west-1', dpa: 'AWS DPA' },
    { name: 'Razorpay',                  purpose: 'Subscription billing',           location: 'United States',         dpa: 'Razorpay DPA' },
    { name: 'OpenAI',                  purpose: 'LLM (script generation)',        location: 'United States',         dpa: 'OpenAI DPA · zero retention' },
    { name: 'Anthropic',               purpose: 'LLM (script generation)',        location: 'United States',         dpa: 'Anthropic DPA · zero retention' },
    { name: 'Replicate',               purpose: 'Image / video model inference',  location: 'United States',         dpa: 'Replicate DPA' },
    { name: 'Runway ML',               purpose: 'Image-to-video (motion stage)',  location: 'United States',         dpa: 'Runway DPA' },
    { name: 'ElevenLabs',              purpose: 'Voice cloning + TTS',            location: 'United States / EU',    dpa: 'ElevenLabs DPA' },
    { name: 'Cloudflare',              purpose: 'CDN + edge cache',               location: 'Global',                dpa: 'Cloudflare DPA' },
    { name: 'Sentry',                  purpose: 'Error tracking (PII-scrubbed)',  location: 'United States',         dpa: 'Sentry DPA' },
    { name: 'Postmark',                purpose: 'Transactional email',            location: 'United States',         dpa: 'Postmark DPA' },
    { name: 'Plausible Analytics',     purpose: 'Privacy-friendly web analytics', location: 'EU (Frankfurt)',        dpa: 'Plausible DPA' },
    { name: 'Linear',                  purpose: 'Internal customer support',      location: 'United States',         dpa: 'Linear DPA' },
  ];
  return (
    <LegalShell slug="subprocessors">
      <LegalP>Companies that process personal data on our behalf. Last updated May 10, 2025. We give 30 days notice before adding a new one — <a href="#" style={{ color: 'var(--brand)' }}>subscribe to changes</a>.</LegalP>

      <div className="card" style={{ padding: 0, marginTop: 18 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--surface-subtle)' }}>
              {['Provider','Purpose','Region','DPA'].map(h => (
                <th key={h} style={{ padding: '10px 14px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sp.map((s, i) => (
              <tr key={s.name} style={{ borderBottom: i < sp.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
                <td style={{ padding: '10px 14px', font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{s.name}</td>
                <td style={{ padding: '10px 14px' }} className="t-small">{s.purpose}</td>
                <td style={{ padding: '10px 14px' }} className="t-small">{s.location}</td>
                <td style={{ padding: '10px 14px' }} className="t-small"><a href="#" style={{ color: 'var(--brand)' }}>{s.dpa}</a></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </LegalShell>
  );
}

/* ============================================================
   SECURITY OVERVIEW
   ============================================================ */
function SecurityOverviewArticle() {
  return (
    <LegalShell slug="security">
      <LegalP>How we keep your data and your channels safe.</LegalP>

      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 18, marginBottom: 28 }}>
        {[
          { l: 'SOC 2', s: 'Type II' },
          { l: 'GDPR', s: 'compliant' },
          { l: 'CCPA', s: 'compliant' },
          { l: 'HIPAA', s: 'on request' },
          { l: 'PCI DSS', s: 'via Razorpay' },
        ].map(b => (
          <span key={b.l} className="card" style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <I.Lock size={16} stroke="var(--brand)"/>
            <div>
              <div style={{ font: '700 14px/1 var(--font-display)', color: 'var(--fg-strong)' }}>{b.l}</div>
              <div className="t-small">{b.s}</div>
            </div>
          </span>
        ))}
      </div>

      <LegalH2>Encryption</LegalH2>
      <LegalUL items={[
        'AES-256 at rest for everything in our data stores.',
        'TLS 1.3 in transit on every endpoint.',
        'Voice-clone artifacts encrypted with per-user keys (so a database leak can't reconstruct voices).',
        'OAuth tokens encrypted with KMS-managed keys, rotated quarterly.',
      ]}/>

      <LegalH2>Access controls</LegalH2>
      <LegalUL items={[
        'SSO (SAML/OIDC) for enterprise teams.',
        'Mandatory 2FA on all internal admin accounts.',
        'Principle of least privilege across infrastructure.',
        'Production access is audit-logged and reviewed weekly.',
      ]}/>

      <LegalH2>Infrastructure</LegalH2>
      <LegalUL items={[
        'AWS us-east-1 primary, with optional eu-west-1 pinning on Studio.',
        'Postgres with automated daily backups, 30-day point-in-time recovery.',
        'Job queue redundancy across 3 availability zones.',
        'Daily restore drills.',
      ]}/>

      <LegalH2>Application security</LegalH2>
      <LegalUL items={[
        'OWASP Top 10 scans on every PR.',
        'Annual third-party penetration test (latest: March 2025).',
        'CSP, HSTS, and SRI on the web app.',
        'Public bug bounty program — see <a href="#" style={{ color: "var(--brand)" }}>security.aicreators.cloud</a>.',
      ]}/>

      <LegalH2>Incident response</LegalH2>
      <LegalP>We commit to a 72-hour breach notification under GDPR. Past incidents are public on our <a href="AIcreators Cloud Status.html" style={{ color: 'var(--brand)' }}>Status page</a>.</LegalP>

      <LegalH2>Contact</LegalH2>
      <LegalP>Report a vulnerability: <a href="mailto:security@aicreators.cloud" style={{ color: 'var(--brand)' }}>security@aicreators.cloud</a>. PGP key available on request.</LegalP>
    </LegalShell>
  );
}

/* ============================================================
   AI CONTENT POLICY
   ============================================================ */
function ContentPolicyArticle() {
  return (
    <LegalShell slug="content-policy">
      <LegalP>The rules that govern what AIcreators will and won't help you make. These are stricter than the Acceptable Use Policy — they're our editorial line.</LegalP>

      <LegalH2>What we automatically refuse to generate</LegalH2>
      <LegalUL items={[
        'Anything sexual involving minors',
        'Bioweapons / explosives / weapons-of-mass-destruction instructions',
        'Deepfakes of identifiable real people without verified consent',
        'Content that uses our voice clones / avatars to impersonate the cloned person without consent',
        'Step-by-step instructions for illegal activity (fraud, hacking, doxxing)',
      ]}/>

      <LegalH2>What we flag for review</LegalH2>
      <LegalUL items={[
        'Medical claims that could harm if wrong',
        'Election content (we don't ban it, but human-review before publish)',
        'Trademarks and copyrighted IP detected in keyframes or thumbnails',
        'Voice clones whose embedding is too close to a celebrity vector',
      ]}/>

      <LegalH2>Transparency / provenance</LegalH2>
      <LegalP>Every video we render embeds C2PA-compliant provenance metadata. Required by Meta, YouTube, and TikTok in many regions starting 2025. You cannot disable it.</LegalP>

      <LegalH2>Watermarks</LegalH2>
      <LegalP>Free and Starter plan videos include a small AIcreators watermark. Studio Pro / Studio remove the visible watermark; the C2PA metadata still ships.</LegalP>

      <LegalH2>Reporting harmful AI content</LegalH2>
      <LegalP>If you see a video made on our platform you believe violates this policy, report it to <a href="mailto:trust@aicreators.cloud" style={{ color: 'var(--brand)' }}>trust@aicreators.cloud</a>.</LegalP>
    </LegalShell>
  );
}

/* ============================================================
   COPYRIGHT / DMCA
   ============================================================ */
function DMCAArticle() {
  const [mode, setMode] = React.useState('takedown'); // takedown | counter
  return (
    <LegalShell slug="copyright">
      <LegalP>We respect intellectual property and expect our users to do the same.</LegalP>

      <div style={{ display: 'flex', gap: 6, marginBottom: 24 }}>
        <button onClick={() => setMode('takedown')} className={`btn btn--sm ${mode === 'takedown' ? 'btn--primary' : 'btn--ghost'}`}>File a takedown</button>
        <button onClick={() => setMode('counter')} className={`btn btn--sm ${mode === 'counter' ? 'btn--primary' : 'btn--ghost'}`}>File a counter-notice</button>
      </div>

      {mode === 'takedown' && <>
      <LegalH2>Filing a DMCA takedown</LegalH2>
      <LegalP>To report copyright infringement involving content on AIcreators, email <a href="mailto:dmca@aicreators.cloud" style={{ color: 'var(--brand)' }}>dmca@aicreators.cloud</a> with:</LegalP>
      <LegalUL items={[
        'Identification of the copyrighted work',
        'Identification of the infringing material (URL or video ID)',
        'Your contact info (name, address, phone, email)',
        'A good-faith statement that the use is unauthorized',
        'A statement made under penalty of perjury that you\'re authorized to act',
        'Your physical or electronic signature',
      ]}/>
      <LegalH2>Quick takedown form</LegalH2>
      <div className="card" style={{ padding: 18 }}>
        <label className="label">URL of the allegedly infringing content</label>
        <input placeholder="https://aicreators.cloud/v/..."/>
        <label className="label" style={{ marginTop: 14 }}>Original work you own</label>
        <input placeholder="Title or URL of your work"/>
        <label className="label" style={{ marginTop: 14 }}>Description / evidence</label>
        <textarea rows={4} placeholder="Why this is infringing..."/>
        <label className="label" style={{ marginTop: 14 }}>Your contact info</label>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <input placeholder="Full name"/>
          <input type="email" placeholder="Email"/>
        </div>
        <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginTop: 14 }}>
          <input type="checkbox" style={{ width: 16, height: 16, accentColor: 'var(--brand)', marginTop: 2 }}/>
          <span className="t-small">I declare, under penalty of perjury, that the above is accurate and that I'm authorized to act on behalf of the rights holder.</span>
        </label>
        <div style={{ marginTop: 14 }}>
          <Btn kind="primary" icon={I.Send}>Submit takedown</Btn>
        </div>
      </div>
      </>}

      {mode === 'counter' && <>
      <LegalH2>Filing a counter-notice</LegalH2>
      <LegalP>If your content was taken down and you believe it was a mistake — or the use is protected by fair use — you can file a counter-notice. We'll forward it to the original claimant, who has 10-14 business days to file suit. If they don't, we restore your content.</LegalP>
      <div className="card" style={{ padding: 18, background: 'var(--warning-bg)', border: '1px solid var(--warning-bd)', marginBottom: 18 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
          <I.Warn size={14} stroke="var(--warning-fg)" style={{ marginTop: 2 }}/>
          <span className="t-small" style={{ color: 'var(--fg-default)' }}>
            Filing a fraudulent counter-notice is a federal offense under 17 U.S.C. § 512(f). Don't file one unless you genuinely believe the takedown was a mistake.
          </span>
        </div>
      </div>

      <div className="card" style={{ padding: 18 }}>
        <label className="label">Take-down notice ID (in our email)</label>
        <input placeholder="DMCA-2025-…"/>

        <label className="label" style={{ marginTop: 14 }}>URL that was removed</label>
        <input placeholder="https://aicreators.cloud/v/..."/>

        <label className="label" style={{ marginTop: 14 }}>Why was the takedown a mistake?</label>
        <textarea rows={5} placeholder="Explain: original work, license, fair use, etc."/>

        <label className="label" style={{ marginTop: 14 }}>Your contact info</label>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <input placeholder="Full name"/>
          <input type="email" placeholder="Email"/>
        </div>
        <input placeholder="Physical mailing address" style={{ marginTop: 8 }}/>

        <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginTop: 14 }}>
          <input type="checkbox" style={{ width: 16, height: 16, accentColor: 'var(--brand)', marginTop: 2 }}/>
          <span className="t-small">I consent to the jurisdiction of the federal court in my district (or San Francisco if outside US), and I will accept service of process from the original claimant.</span>
        </label>

        <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginTop: 10 }}>
          <input type="checkbox" style={{ width: 16, height: 16, accentColor: 'var(--brand)', marginTop: 2 }}/>
          <span className="t-small">I declare, under penalty of perjury, that I have a good-faith belief the material was removed as a result of mistake or misidentification.</span>
        </label>

        <div style={{ marginTop: 14 }}>
          <Btn kind="primary" icon={I.Send}>Submit counter-notice</Btn>
        </div>
      </div>

      <LegalH2 style={{ marginTop: 28 }}>What happens next</LegalH2>
      <LegalUL items={[
        'We forward your counter-notice to the original claimant within 1 business day.',
        'They have 10-14 business days to file a lawsuit to keep the content offline.',
        'If they don\'t, we restore your content and notify you.',
        'If they do file suit, we keep the content offline until the court rules.',
      ]}/>
      </>}

      <LegalH2 style={{ marginTop: 28 }}>Repeat infringers</LegalH2>
      <LegalP>Accounts that receive 3 valid DMCA takedowns within 12 months are terminated. Counter-notices that succeed don't count.</LegalP>
    </LegalShell>
  );
}

function CopyrightArticle() { return <DMCAArticle/>; }

/* ============================================================
   DATA EXPORT (GDPR Article 20)
   ============================================================ */
function DataExportArticle() {
  const [requested, setRequested] = React.useState(false);
  return (
    <LegalShell slug="data-export">
      <LegalP>Download a copy of everything we have on file: account, projects, scripts, voice clones, avatars, generated videos, billing history, audit log. Delivered as a single .zip via email link, valid for 7 days.</LegalP>

      <LegalH2>What's included</LegalH2>
      <LegalUL items={[
        'Profile + account settings (JSON)',
        'Every channel + identity + voice + style (JSON)',
        'Every project incl. script, storyboard, prompts, keyframes (JSON + binaries)',
        'All generated videos (MP4)',
        'Voice clone embeddings (encrypted; instructions to use on request)',
        'Avatar mesh + reference photo',
        'Billing receipts (PDF)',
        'Audit log (your actions only)',
      ]}/>

      <div className="card" style={{ marginTop: 28, background: requested ? 'var(--success-bg)' : 'var(--magic-tint)', border: `1px solid ${requested ? 'var(--success-bd)' : 'var(--accent-border-soft)'}` }}>
        {!requested ? (
          <>
            <div className="t-h4" style={{ marginBottom: 8 }}>Request your data</div>
            <LegalP>We'll prepare your archive and email you a download link within 24 hours. There's no cost.</LegalP>
            <div style={{ display: 'flex', gap: 8 }}>
              <Btn kind="primary" icon={I.Download} onClick={() => setRequested(true)}>Request export</Btn>
              <Btn kind="ghost">Cancel</Btn>
            </div>
          </>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <I.Check size={28} stroke="var(--success)"/>
            <div>
              <div className="t-h5" style={{ marginBottom: 4 }}>Export queued</div>
              <LegalP>We'll email you a download link at <strong>mihir@aicreators.cloud</strong> within 24 hours. The link is valid for 7 days.</LegalP>
            </div>
          </div>
        )}
      </div>
    </LegalShell>
  );
}

/* ============================================================
   ACCOUNT DELETION (GDPR Article 17)
   ============================================================ */
function DataDeletionArticle() {
  const [step, setStep] = React.useState(0);
  const [confirm, setConfirm] = React.useState('');

  return (
    <LegalShell slug="data-deletion">
      <LegalP>This permanently deletes your AIcreators account and everything in it. <strong>This is final</strong> — there's a 30-day grace period to restore, then it's gone.</LegalP>

      <LegalH2>What gets deleted</LegalH2>
      <LegalUL items={[
        'Your profile, channels, and identity settings',
        'Every voice clone and avatar (immediately, even before the 30-day grace period)',
        'Every project, script, storyboard, and intermediate frame',
        'All API keys and webhook endpoints',
        'Your audit log (after legal retention requirements)',
      ]}/>

      <LegalH2>What does <em>not</em> get deleted</LegalH2>
      <LegalUL items={[
        'Published videos already on YouTube / Instagram / TikTok — those belong to you on those platforms. Delete them there.',
        'Financial records we're legally required to keep (invoices, tax) for 7 years.',
        'Aggregated, de-identified usage statistics.',
      ]}/>

      <LegalH2>How to delete</LegalH2>

      {step === 0 && (
        <div className="card" style={{ background: 'var(--danger-bg)', border: '1px solid var(--danger-bd)', marginTop: 14 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
            <I.Warn size={20} stroke="var(--danger-fg)" style={{ marginTop: 2, flexShrink: 0 }}/>
            <div style={{ flex: 1 }}>
              <div className="t-h4" style={{ marginBottom: 8 }}>Before you go — would any of these help?</div>
              <LegalUL items={[
                <>Running low on credits? <a href="AIcreators Cloud.html#billing" style={{ color: 'var(--danger-fg)', textDecoration: 'underline' }}>Add credits or upgrade</a></>,
                <>Need a break? <a href="AIcreators Cloud.html#settings" style={{ color: 'var(--danger-fg)', textDecoration: 'underline' }}>Pause autopilot</a> instead of deleting</>,
                <>Something broken? <a href="AIcreators Cloud.html#help" style={{ color: 'var(--danger-fg)', textDecoration: 'underline' }}>Tell us</a> — we want to fix it</>,
                <>Just don't need it for now? <a href="AIcreators Cloud.html#billing" style={{ color: 'var(--danger-fg)', textDecoration: 'underline' }}>Downgrade to Starter</a> ($29) and keep your data</>,
              ]}/>
              <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
                <Btn kind="secondary">Take me back</Btn>
                <Btn kind="danger" icon={I.Trash} onClick={() => setStep(1)}>Continue with deletion</Btn>
              </div>
            </div>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="card" style={{ marginTop: 14 }}>
          <div className="t-h4" style={{ marginBottom: 14 }}>Why are you leaving? <span style={{ font: '500 12px/1 var(--font-sans)', color: 'var(--fg-muted)' }}>optional</span></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              "It's too expensive",
              "Doesn't fit my workflow",
              "Found a better alternative",
              "Concerned about AI content policy",
              "Concerned about data privacy",
              "Switching to a different platform",
              "Just trying it out, not for me",
              "Other",
            ].map(r => (
              <label key={r} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 8, cursor: 'pointer', background: 'var(--surface-subtle)' }}>
                <input type="checkbox" style={{ accentColor: 'var(--brand)' }}/>
                <span className="t-body">{r}</span>
              </label>
            ))}
          </div>
          <label className="label" style={{ marginTop: 18 }}>Anything else you want us to know?</label>
          <textarea rows={3} placeholder="We read every one of these"/>
          <div style={{ display: 'flex', gap: 8, marginTop: 18, justifyContent: 'flex-end' }}>
            <Btn kind="ghost" onClick={() => setStep(0)}>Back</Btn>
            <Btn kind="danger" iconRight={I.ChevRight} onClick={() => setStep(2)}>Continue</Btn>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="card" style={{ background: 'var(--danger-bg)', border: '1px solid var(--danger-bd)', marginTop: 14 }}>
          <div className="t-h4" style={{ marginBottom: 14, color: 'var(--danger-fg)' }}>Confirm permanent deletion</div>
          <LegalP>We'll send a confirmation email to <strong>mihir@aicreators.cloud</strong>. Click the link in that email to start the 30-day countdown. During that 30 days you can <a href="#" style={{ color: 'var(--brand)' }}>sign back in to cancel</a>. After day 30, we wipe everything and it's unrecoverable.</LegalP>

          <label className="label" style={{ marginTop: 14, color: 'var(--fg-strong)' }}>Type <strong>delete my account</strong> below to confirm</label>
          <input value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="delete my account"/>

          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginTop: 16 }}>
            <input type="checkbox" style={{ width: 16, height: 16, accentColor: 'var(--brand)', marginTop: 2 }}/>
            <span className="t-small">I understand voice clones and avatars are deleted immediately, before the 30-day grace period.</span>
          </div>

          <div style={{ marginTop: 18, padding: 14, borderRadius: 10, background: 'var(--bg-surface)' }}>
            <div className="t-tiny" style={{ marginBottom: 8 }}>Before you delete, you might want to</div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <Btn kind="secondary" size="sm" icon={I.Download}>Export my data first</Btn>
              <Btn kind="ghost" size="sm" icon={I.Download}>Download published videos</Btn>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 18, justifyContent: 'flex-end' }}>
            <Btn kind="ghost" onClick={() => setStep(1)}>Back</Btn>
            <Btn kind="danger" icon={I.Trash} disabled={confirm.trim().toLowerCase() !== 'delete my account'} onClick={() => setStep(3)}>Send confirmation email</Btn>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="card" style={{ marginTop: 14, textAlign: 'center', padding: 32 }}>
          <span style={{ width: 64, height: 64, borderRadius: 18, background: 'var(--info-bg)', border: '1px solid var(--info-bd)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--info-fg)', marginBottom: 18 }}>
            <I.Mail size={28}/>
          </span>
          <div className="t-h3" style={{ marginBottom: 8 }}>Check your email</div>
          <LegalP>We've sent a confirmation link to <strong>mihir@aicreators.cloud</strong>. Click it within 24 hours to start the 30-day countdown. Your account is still active until you click the link.</LegalP>
          <Btn kind="primary" onClick={() => window.location.href = 'AIcreators Cloud.html'}>Back to studio</Btn>
        </div>
      )}
    </LegalShell>
  );
}

/* ============================================================
   ROUTER
   ============================================================ */
function LegalApp() {
  const [slug, setSlug] = React.useState(() => (window.location.hash || '#terms').replace(/^#/, ''));
  React.useEffect(() => {
    const onHash = () => setSlug((window.location.hash || '#terms').replace(/^#/, ''));
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const Article = {
    terms:          TermsArticle,
    privacy:        PrivacyArticle,
    cookies:        CookiesArticle,
    aup:            AUPArticle,
    dpa:            DPAArticle,
    subprocessors:  SubprocessorsArticle,
    security:       SecurityOverviewArticle,
    'content-policy': ContentPolicyArticle,
    copyright:      CopyrightArticle,
    'data-export':  DataExportArticle,
    'data-deletion':DataDeletionArticle,
  }[slug] || TermsArticle;

  return <Article/>;
}

ReactDOM.createRoot(document.getElementById('root')).render(<LegalApp/>);
