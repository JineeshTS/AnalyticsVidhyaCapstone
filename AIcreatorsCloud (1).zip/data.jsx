/* ============================================================
   AIcreators.cloud — Mock Data
   Channels, video projects, voices, styles, analytics.
   ============================================================ */

const MOCK = {
  user: {
    name: 'Mihir Vaishnav',
    email: 'mihir@aicreators.cloud',
    plan: 'Studio · Pro',
    credits: 2840,
    creditsCap: 5000,
  },

  channels: [
    { id: 'c1', name: 'Mythic Tales',     handle: '@mythictales',  subs: '127K', emoji: '🜲', color: 'linear-gradient(135deg,#7C3AED,#22D3EE)', niche: 'Mythology · Long-form',        format: 'Long-form (8-14 min)', autopilot: true,  videosInQueue: 5, language: 'English' },
    { id: 'c2', name: 'Snackable Science', handle: '@snackscience', subs: '38.2K', emoji: '⚛︎', color: 'linear-gradient(135deg,#EC4899,#F59E0B)', niche: 'Science explainers · Shorts',  format: 'Shorts (45-60s)',     autopilot: true,  videosInQueue: 12, language: 'English' },
    { id: 'c3', name: 'Tiny Toon Theatre', handle: '@tinytoon',     subs: '8.6K',  emoji: '✿', color: 'linear-gradient(135deg,#34D399,#22D3EE)', niche: 'Kids cartoons · Episodic',     format: 'Cartoon (3-5 min)',   autopilot: false, videosInQueue: 2,  language: 'English / Hindi' },
    { id: 'c4', name: 'Noir Reels',        handle: '@noirreels',    subs: '64.8K', emoji: '◑', color: 'linear-gradient(135deg,#475569,#A78BFA)', niche: 'Mini-features · Cinematic',    format: 'Feature (1-3 min)',   autopilot: true,  videosInQueue: 3,  language: 'English' },
  ],

  voices: [
    { id: 'v1', name: 'Atlas',       gender: 'M', accent: 'US',  vibe: 'Documentary · Warm',   wave: '◢◣◢◣◢◣' },
    { id: 'v2', name: 'Nova',        gender: 'F', accent: 'US',  vibe: 'Energetic · Bright',   wave: '◣◢◢◣◢◣' },
    { id: 'v3', name: 'Ember',       gender: 'F', accent: 'UK',  vibe: 'Whispered · Mystery',  wave: '◢◢◣◣◢◣' },
    { id: 'v4', name: 'Onyx',        gender: 'M', accent: 'UK',  vibe: 'Deep · Cinematic',     wave: '◣◢◣◢◢◣' },
    { id: 'v5', name: 'Marigold',    gender: 'F', accent: 'IN',  vibe: 'Bilingual · Friendly', wave: '◢◣◢◢◣◣' },
    { id: 'v6', name: 'Kai',         gender: 'M', accent: 'AU',  vibe: 'Casual · Upbeat',      wave: '◣◣◢◣◢◢' },
  ],

  styles: [
    { id: 's1', name: 'Cinematic Noir',  swatch: ['#1A1024','#3B1F47','#85547E','#E0D2E6'], notes: '35mm grain · low key · teal-orange' },
    { id: 's2', name: 'Studio Ghibli',   swatch: ['#A8D8EA','#FCE38A','#F38181','#95E1D3'], notes: 'Soft cel · pastoral · gentle rim light' },
    { id: 's3', name: 'Cyber Pulse',     swatch: ['#FF006E','#8338EC','#3A86FF','#06D6A0'], notes: 'Neon · holo · synthwave grid' },
    { id: 's4', name: 'Paper Cutout',    swatch: ['#FFE5B4','#FFB7B2','#B5DEFF','#E2BEF1'], notes: 'Flat layers · soft shadows · craft paper' },
    { id: 's5', name: 'Mythic Etching',  swatch: ['#2A1810','#7B4F2C','#D4A574','#F4E1B5'], notes: 'Engraved illustration · sepia · ornate' },
    { id: 's6', name: 'Documentary Real',swatch: ['#3D405B','#81B29A','#F2CC8F','#E07A5F'], notes: 'Realistic · earthy · grounded' },
  ],

  // Active production projects (the timeline data)
  projects: [
    {
      id: 'p1', title: 'The Lost Library of Alexandria',
      channelId: 'c1', style: 's5', voice: 'v4',
      thumb: 'linear-gradient(135deg, #2A1810 0%, #7B4F2C 100%)',
      duration: '11:42', stage: 'publish', stageState: 'running',
      progress: 92, eta: '4 min', autopilot: true,
      format: 'Long-form', publishAt: 'Today · 6:00 PM',
      stageStates: { idea: 'done', script: 'done', storyboard: 'done', images: 'done', motion: 'done', voice: 'done', edit: 'done', publish: 'running' },
    },
    {
      id: 'p2', title: 'Why your phone hates the cold ❄︎',
      channelId: 'c2', style: 's3', voice: 'v2',
      thumb: 'linear-gradient(135deg, #3A86FF 0%, #8338EC 100%)',
      duration: '0:52', stage: 'edit', stageState: 'running',
      progress: 64, eta: '7 min', autopilot: true,
      format: 'Shorts', publishAt: 'Tomorrow · 9:00 AM',
      stageStates: { idea: 'done', script: 'done', storyboard: 'done', images: 'done', motion: 'done', voice: 'done', edit: 'running', publish: 'todo' },
    },
    {
      id: 'p3', title: 'How Volcanoes Make Their Own Lightning',
      channelId: 'c2', style: 's6', voice: 'v1',
      thumb: 'linear-gradient(135deg, #E07A5F 0%, #3D405B 100%)',
      duration: '0:58', stage: 'motion', stageState: 'running',
      progress: 41, eta: '22 min', autopilot: true,
      format: 'Shorts', publishAt: 'Thu · 9:00 AM',
      stageStates: { idea: 'done', script: 'done', storyboard: 'done', images: 'done', motion: 'running', voice: 'todo', edit: 'todo', publish: 'todo' },
    },
    {
      id: 'p4', title: 'The Detective Who Forgot His Own Name',
      channelId: 'c4', style: 's1', voice: 'v4',
      thumb: 'linear-gradient(135deg, #1A1024 0%, #85547E 100%)',
      duration: '2:34', stage: 'images', stageState: 'review',
      progress: 30, eta: 'Needs review', autopilot: false,
      format: 'Feature', publishAt: 'Fri · 7:00 PM',
      stageStates: { idea: 'done', script: 'done', storyboard: 'done', images: 'review', motion: 'todo', voice: 'todo', edit: 'todo', publish: 'todo' },
    },
    {
      id: 'p5', title: 'Little Bear and the Honey Star',
      channelId: 'c3', style: 's2', voice: 'v5',
      thumb: 'linear-gradient(135deg, #A8D8EA 0%, #FCE38A 100%)',
      duration: '3:10', stage: 'script', stageState: 'running',
      progress: 18, eta: '12 min', autopilot: false,
      format: 'Cartoon', publishAt: 'Sat · 10:00 AM',
      stageStates: { idea: 'done', script: 'running', storyboard: 'todo', images: 'todo', motion: 'todo', voice: 'todo', edit: 'todo', publish: 'todo' },
    },
    {
      id: 'p6', title: 'Pompeii: 72 hours before the eruption',
      channelId: 'c1', style: 's5', voice: 'v4',
      thumb: 'linear-gradient(135deg, #7B4F2C 0%, #2A1810 100%)',
      duration: '—', stage: 'idea', stageState: 'queued',
      progress: 6, eta: 'Queued', autopilot: true,
      format: 'Long-form', publishAt: 'Next week',
      stageStates: { idea: 'queued', script: 'todo', storyboard: 'todo', images: 'todo', motion: 'todo', voice: 'todo', edit: 'todo', publish: 'todo' },
    },
  ],

  publishedRecent: [
    { id: 'pub1', title: 'Why the Pyramids Aren\'t Tombs (probably)', channelId: 'c1', views: '142K', ctr: '11.2%', avd: '7:28', published: '2 days ago', thumb: 'linear-gradient(135deg,#D4A574,#2A1810)' },
    { id: 'pub2', title: 'The 0.1s your brain hides from you', channelId: 'c2', views: '388K', ctr: '14.8%', avd: '0:48', published: '4 days ago', thumb: 'linear-gradient(135deg,#FF006E,#3A86FF)' },
    { id: 'pub3', title: 'Bunny finds a tiny moon 🌙', channelId: 'c3', views: '12K', ctr: '6.4%', avd: '2:55', published: '1 week ago', thumb: 'linear-gradient(135deg,#FCE38A,#F38181)' },
    { id: 'pub4', title: 'The phone-booth at the end of the world', channelId: 'c4', views: '71K', ctr: '13.1%', avd: '2:12', published: '1 week ago', thumb: 'linear-gradient(135deg,#475569,#1A1024)' },
  ],

  topicIdeas: [
    { id: 't1', channelId: 'c1', title: 'The vanishing of the Roanoke colony', score: 92, tags: ['mystery','history'], status: 'queued', est: '11 min' },
    { id: 't2', channelId: 'c1', title: 'How the Library of Nineveh was found in a desert', score: 88, tags: ['history','archaeology'], status: 'queued', est: '9 min' },
    { id: 't3', channelId: 'c2', title: 'Why ice makes a popping sound in water', score: 84, tags: ['physics','everyday'], status: 'in-progress', est: '50s' },
    { id: 't4', channelId: 'c2', title: 'Your nose has 12 million sensors. Here\'s why', score: 79, tags: ['biology'], status: 'idea', est: '55s' },
    { id: 't5', channelId: 'c4', title: 'The hotel room with no door', score: 90, tags: ['noir','thriller'], status: 'idea', est: '2:20' },
    { id: 't6', channelId: 'c3', title: 'The cloud that wanted to be a kite', score: 76, tags: ['friendship','imagination'], status: 'queued', est: '3 min' },
    { id: 't7', channelId: 'c1', title: 'The Antikythera mechanism, decoded', score: 95, tags: ['ancient tech'], status: 'idea', est: '12 min' },
  ],

  analytics: {
    last30d: { views: '2.4M', subs: '+14.2K', watchHours: '128.4K', revenue: '$2,184' },
    sparkline: [12, 18, 22, 19, 28, 34, 31, 40, 36, 44, 52, 49, 58, 64, 60, 72, 68, 80, 76, 88, 92, 87, 96, 104, 99, 112, 118, 114, 124, 132],
    perChannel: [
      { id: 'c1', views: '1.4M',  pct: 58, color: '#A78BFA' },
      { id: 'c2', views: '610K',  pct: 26, color: '#22D3EE' },
      { id: 'c4', views: '320K',  pct: 13, color: '#F472B6' },
      { id: 'c3', views: '70K',   pct:  3, color: '#34D399' },
    ],
  },
};

window.MOCK = MOCK;
