/* ============================================================
   AIcreators.cloud — Asset libraries
   Voice Library (with cloning) + Avatars (with lip sync)
   ============================================================ */

/* ====================================================
   VOICE LIBRARY
   ==================================================== */

const CLONED_VOICES = [
  { id: 'cv1', name: 'My Storyteller',  vibe: 'Cloned · 12 min sample · 96% match', status: 'ready',     created: 'Apr 28' },
  { id: 'cv2', name: 'Sleepy Bedtime',   vibe: 'Cloned · whisper register',          status: 'ready',     created: 'May 02' },
  { id: 'cv3', name: 'Hindi Narrator',   vibe: 'Cloned · हिंदी / English · 8 min',  status: 'training',  created: 'just now', progress: 64 },
];

function VoiceLibraryScreen() {
  const [openClone, setOpenClone] = React.useState(false);
  const [tab, setTab] = React.useState('mine');

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Voice Library</div>
            <div className="t-small" style={{ marginTop: 4 }}>Clone your voice, pick a studio voice, or build a brand voice from scratch.</div>
          </div>
          <Tabs value={tab} onChange={setTab} items={[
            { id: 'mine',     label: 'My voices', icon: I.Mic },
            { id: 'studio',   label: 'Studio voices', icon: I.Sparkles },
            { id: 'team',     label: 'Team', icon: I.Users },
          ]}/>
          <Btn kind="magic" icon={I.Plus} onClick={() => setOpenClone(true)}>Clone a voice</Btn>
        </div>

        {tab === 'mine' && (
          <>
            {/* Clone hero card */}
            <div className="card" style={{ padding: 24, marginBottom: 16, background: 'var(--magic-tint)', border: '1px solid var(--brand-soft-bd)', position: 'relative', overflow: 'hidden' }}>
              <SparkleField count={10} intensity={0.4}/>
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 22 }}>
                <span style={{
                  width: 72, height: 72, borderRadius: 20,
                  background: 'var(--magic-grad)',
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: '0 12px 32px rgba(124,58,237,0.45), inset 0 1px 0 rgba(255,255,255,0.20)',
                  color: 'white',
                }}>
                  <I.Mic size={32}/>
                </span>
                <div style={{ flex: 1 }}>
                  <div className="t-h4" style={{ marginBottom: 6 }}>Clone your voice — record 60 seconds</div>
                  <div className="t-small" style={{ maxWidth: 600 }}>
                    We capture your tone, cadence, and accent. The clone narrates every video in seconds, in any language — and only you can use it.
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end' }}>
                  <Btn kind="magic" icon={I.Mic} onClick={() => setOpenClone(true)}>Record now</Btn>
                  <Btn kind="ghost" size="sm" icon={I.Upload}>Upload sample</Btn>
                </div>
              </div>
            </div>

            {/* My cloned voices */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <span className="t-h5">Your voices</span>
              <span className="chip">{CLONED_VOICES.length}</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 24 }}>
              {CLONED_VOICES.map(v => <VoiceCard key={v.id} v={v} cloned/>)}
              <div onClick={() => setOpenClone(true)} className="card card--hover" style={{
                border: '1px dashed var(--border-default)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                padding: 24, cursor: 'pointer', minHeight: 158,
              }}>
                <span style={{
                  width: 48, height: 48, borderRadius: 14,
                  background: 'var(--magic-tint)',
                  border: '1px solid var(--brand-soft-bd)',
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  color: 'var(--accent-fg)', marginBottom: 12,
                }}><I.Plus size={20}/></span>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Clone another voice</div>
                <div className="t-small" style={{ marginTop: 4 }}>60s sample → ready in ~2 min</div>
              </div>
            </div>
          </>
        )}

        {/* Studio voices grid (always shown for now too) */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <span className="t-h5">Studio voices</span>
          <span className="chip">{MOCK.voices.length} included</span>
          <div style={{ flex: 1 }}/>
          <Btn kind="ghost" size="sm" icon={I.Filter}>Filter</Btn>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {MOCK.voices.map(v => <VoiceCard key={v.id} v={v}/>)}
        </div>
      </div>

      {openClone && <VoiceCloneModal onClose={() => setOpenClone(false)}/>}
    </div>
  );
}

function VoiceCard({ v, cloned }) {
  const isTraining = v.status === 'training';
  return (
    <div className="card card--hover" style={{
      position: 'relative',
      border: cloned ? '1px solid var(--accent-border-soft)' : '1px solid var(--border-hairline)',
    }}>
      {cloned && <span style={{ position: 'absolute', top: 12, right: 12 }} className="chip chip--magic"><I.Spark size={11}/> Cloned</span>}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
        <span style={{
          width: 48, height: 48, borderRadius: '50%',
          background: cloned
            ? 'var(--magic-grad)'
            : `linear-gradient(135deg, ${['#A78BFA','#22D3EE','#F472B6','#34D399','#FBBF24','#F87171'][(v.name.charCodeAt(0)) % 6]}, var(--violet-600))`,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: 'white', font: '700 19px/1 var(--font-display)', flexShrink: 0,
          boxShadow: cloned ? '0 6px 18px rgba(124,58,237,0.40)' : 'none',
        }}>{v.name[0]}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: '600 15px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{v.name}</div>
          <div className="t-small" style={{ marginTop: 4 }}>{v.vibe || `${v.gender} · ${v.accent}`}</div>
        </div>
        {!isTraining && (
          <button className="btn btn--ghost btn--icon" title="Preview"><I.Play size={16}/></button>
        )}
      </div>

      {isTraining ? (
        <div>
          <ProgressBar value={v.progress}/>
          <div className="t-small" style={{ marginTop: 6, color: 'var(--accent-fg)' }}>
            Training… learning your inflections ({v.progress}%)
          </div>
        </div>
      ) : (
        <>
          <div style={{ height: 28, display: 'flex', alignItems: 'center', gap: 2 }}>
            {Array.from({ length: 42 }).map((_, i) => {
              const h = 4 + Math.abs(Math.sin((i + v.name.charCodeAt(0)) * 0.7) * 18);
              return <span key={i} style={{ flex: 1, height: h, background: cloned ? 'linear-gradient(180deg,var(--accent),var(--cyan-400))' : 'var(--border-default)', borderRadius: 1 }}/>;
            })}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <Btn kind="secondary" size="sm" icon={I.Check}>Use as default</Btn>
            <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
          </div>
        </>
      )}
    </div>
  );
}

function VoiceCloneModal({ onClose }) {
  const [step, setStep] = React.useState(0);    // 0=intro, 1=recording, 2=processing, 3=done
  const [seconds, setSeconds] = React.useState(0);
  const [recording, setRecording] = React.useState(false);

  React.useEffect(() => {
    if (!recording) return;
    const t = setInterval(() => setSeconds(s => Math.min(60, s + 1)), 1000);
    return () => clearInterval(t);
  }, [recording]);

  const start = () => { setRecording(true); setSeconds(0); setStep(1); };
  const stop  = () => {
    setRecording(false);
    setStep(2);
    setTimeout(() => setStep(3), 2200);
  };

  return (
    <Modal open={true} onClose={onClose} width={560}>
      <div style={{ padding: 28, position: 'relative', overflow: 'hidden' }}>
        <SparkleField count={10} intensity={0.5}/>
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--brand-soft-bd)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-fg)' }}>
              <I.Mic size={18}/>
            </span>
            <span className="t-h4">Clone your voice</span>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
          </div>

          {step === 0 && <CloneIntro onStart={start}/>}
          {step === 1 && <CloneRecord seconds={seconds} onStop={stop}/>}
          {step === 2 && <CloneProcess/>}
          {step === 3 && <CloneDone onClose={onClose}/>}
        </div>
      </div>
    </Modal>
  );
}

function CloneIntro({ onStart }) {
  return (
    <div>
      <div className="t-small" style={{ marginBottom: 18, color: 'var(--fg-secondary)' }}>
        Read the passage below clearly, in your natural voice. 60 seconds is enough — more is better.
      </div>
      <div style={{
        padding: 18, borderRadius: 12,
        background: 'var(--surface-subtle)',
        border: '1px solid var(--border-hairline)',
        font: '500 15px/1.7 var(--font-display)', color: 'var(--fg-strong)',
        textWrap: 'pretty', marginBottom: 18,
      }}>
        "The first time I saw a video appear on my screen with my own voice narrating it,
        I didn't know whether to laugh or to feel a little betrayed by the future.
        But the future asked nicely, in my own cadence, and I let it in."
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 20 }}>
        {[
          { ic: I.Mic,   t: 'Quiet room' },
          { ic: I.Hourglass, t: '60 seconds' },
          { ic: I.Lock,  t: 'Private to you' },
        ].map((m, i) => (
          <div key={i} style={{ padding: 10, borderRadius: 10, background: 'var(--surface-subtle)', border: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <m.ic size={14} stroke="var(--accent-fg)"/>
            <span style={{ font: '500 12px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{m.t}</span>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
        <Btn kind="ghost" icon={I.Upload}>Upload existing sample</Btn>
        <Btn kind="magic" icon={I.Mic} onClick={onStart}>Start recording</Btn>
      </div>
    </div>
  );
}

function CloneRecord({ seconds, onStop }) {
  const pct = (seconds / 60) * 100;
  // Animated waveform bars
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => { const t = setInterval(() => setTick(x => x + 1), 90); return () => clearInterval(t); }, []);
  return (
    <div>
      <div style={{ textAlign: 'center', padding: '12px 0' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--danger)', boxShadow: '0 0 8px var(--danger)', animation: 'sparklePing 1s ease-out infinite' }}/>
          <span style={{ font: '700 11px/1 var(--font-sans)', letterSpacing: '0.10em', color: 'var(--danger)', textTransform: 'uppercase' }}>Recording</span>
        </div>
        <div style={{ font: '700 56px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums' }}>
          0:{String(seconds).padStart(2, '0')}
          <span style={{ color: 'var(--fg-faint)', fontSize: 22 }}> / 1:00</span>
        </div>
        {/* Live waveform */}
        <div style={{ height: 80, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 3, margin: '24px 0' }}>
          {Array.from({ length: 48 }).map((_, i) => {
            const h = 6 + Math.abs(Math.sin((i + tick * 0.5) * 0.4) * 32) + Math.abs(Math.sin((i + tick * 0.3) * 0.9) * 18);
            return <span key={i} style={{ width: 4, height: Math.min(74, h), background: 'linear-gradient(180deg, var(--accent), var(--cyan-400))', borderRadius: 2 }}/>;
          })}
        </div>
        <ProgressBar value={pct}/>
      </div>
      <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 20 }}>
        <Btn kind="danger" icon={I.Check} onClick={onStop}>Finish recording</Btn>
      </div>
    </div>
  );
}

function CloneProcess() {
  return (
    <div style={{ textAlign: 'center', padding: '36px 12px 24px' }}>
      <div style={{ position: 'relative', display: 'inline-block', marginBottom: 20 }}>
        <div style={{ position: 'absolute', inset: -30, borderRadius: '50%', background: 'radial-gradient(circle, var(--accent-tint-3) 0%, transparent 70%)', filter: 'blur(20px)' }}/>
        <div style={{ position: 'relative', width: 72, height: 72, borderRadius: '50%', border: '3px solid var(--accent-border-soft)', borderTopColor: 'var(--accent)', animation: 'slowSpin 1s linear infinite' }}/>
      </div>
      <div className="t-h4" style={{ marginBottom: 8 }}>Building your voice clone…</div>
      <div className="t-small" style={{ marginBottom: 24 }}>This usually takes about 2 minutes. We'll ping you when it's ready.</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 360, margin: '0 auto', textAlign: 'left' }}>
        {[
          { l: 'Cleaning your sample', done: true },
          { l: 'Extracting tone & cadence', done: true },
          { l: 'Training neural model', loading: true },
          { l: 'Verifying voice match', },
        ].map((s, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {s.done ? <I.Check size={14} stroke="var(--success)"/> :
             s.loading ? <span style={{ width: 14, height: 14, borderRadius: '50%', border: '2px solid var(--accent-border-soft)', borderTopColor: 'var(--accent)', animation: 'slowSpin 0.8s linear infinite' }}/> :
                          <span style={{ width: 10, height: 10, borderRadius: '50%', background: 'var(--border-default)' }}/>}
            <span className="t-small" style={{ color: s.done ? 'var(--fg-strong)' : 'var(--fg-default)' }}>{s.l}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CloneDone({ onClose }) {
  return (
    <div style={{ textAlign: 'center', padding: '12px 0' }}>
      <span style={{
        width: 72, height: 72, borderRadius: 20,
        background: 'linear-gradient(135deg, var(--success-bd), rgba(34,211,238,0.20))',
        border: '1px solid var(--success-bd)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        color: 'var(--success)', boxShadow: '0 12px 32px var(--success-bd)',
        marginBottom: 16,
      }}><I.Check size={32}/></span>
      <div className="t-h3" style={{ marginBottom: 8 }}>Your voice is live</div>
      <div className="t-small" style={{ marginBottom: 24 }}>96% match. Try a sample, or set it as your default narrator.</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 360, margin: '0 auto' }}>
        <Btn kind="magic" size="lg" icon={I.Play}>Hear it read your script</Btn>
        <Btn kind="secondary" icon={I.Check}>Set as default for Mythic Tales</Btn>
        <Btn kind="ghost" onClick={onClose}>Close</Btn>
      </div>
    </div>
  );
}

/* ====================================================
   AVATARS (face / lip sync)
   ==================================================== */

const MOCK_AVATARS = [
  { id: 'av1', name: 'Mihir · talking-head',  vibe: 'Real-face · realistic',     style: 'realistic',  status: 'ready', match: 98,
    portraitGrad: 'linear-gradient(135deg,#3D405B,#81B29A,#F2CC8F)' },
  { id: 'av2', name: 'Mihir · cartoon',       vibe: 'Stylized · cel-shaded',     style: 'cartoon',    status: 'ready', match: 91,
    portraitGrad: 'linear-gradient(135deg,#FCE38A,#F38181)' },
  { id: 'av3', name: 'Co-host · Priya',       vibe: 'Realistic · co-host',       style: 'realistic',  status: 'ready', match: 94,
    portraitGrad: 'linear-gradient(135deg,#F472B6,#A78BFA)' },
];

function AvatarsScreen() {
  const [openCreate, setOpenCreate] = React.useState(false);
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Avatars & Lip Sync</div>
            <div className="t-small" style={{ marginTop: 4 }}>Add your face. Avyal will lip-sync it to any voiceover, in any video.</div>
          </div>
          <Btn kind="magic" icon={I.Plus} onClick={() => setOpenCreate(true)}>New avatar</Btn>
        </div>

        {/* Hero */}
        <div className="card" style={{ padding: 24, marginBottom: 16, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', position: 'relative', overflow: 'hidden' }}>
          <SparkleField count={10} intensity={0.4}/>
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 22 }}>
            <span style={{
              width: 72, height: 72, borderRadius: 20,
              background: 'linear-gradient(135deg, var(--magenta-500), var(--brand))',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 12px 32px rgba(236,72,153,0.45), inset 0 1px 0 rgba(255,255,255,0.20)',
              color: 'white',
            }}>
              <I.User size={32}/>
            </span>
            <div style={{ flex: 1 }}>
              <div className="t-h4" style={{ marginBottom: 6 }}>Upload one photo. Get a talking head for every video.</div>
              <div className="t-small" style={{ maxWidth: 620 }}>
                A single front-facing portrait is enough. We extract a 3D mesh, lock identity across frames, and lip-sync your voice (or your clone) in real time.
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <Btn kind="magic" icon={I.Upload} onClick={() => setOpenCreate(true)}>Upload photo</Btn>
              <Btn kind="ghost" size="sm" icon={I.Film}>See a demo</Btn>
            </div>
          </div>
        </div>

        {/* My avatars grid */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <span className="t-h5">Your avatars</span>
          <span className="chip">{MOCK_AVATARS.length}</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {MOCK_AVATARS.map(a => <AvatarCard key={a.id} a={a}/>)}
          <div onClick={() => setOpenCreate(true)} className="card card--hover" style={{
            border: '1px dashed var(--border-default)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            padding: 24, cursor: 'pointer', minHeight: 320,
          }}>
            <span style={{
              width: 56, height: 56, borderRadius: 16,
              background: 'var(--magic-tint)',
              border: '1px solid var(--accent-border-soft)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--magenta-400)', marginBottom: 14,
            }}><I.Plus size={24}/></span>
            <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Add an avatar</div>
            <div className="t-small" style={{ marginTop: 6, textAlign: 'center' }}>One photo · lip-sync ready in ~3 min</div>
          </div>
        </div>

        {/* How it works */}
        <div className="card" style={{ marginTop: 24, padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-hairline)' }}>
            <span className="t-h5">How lip sync works in your pipeline</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 1, background: 'var(--border-hairline)' }}>
            {[
              { ic: I.Upload,  t: '1. Upload a photo', d: 'Front-facing, neutral expression, good light. We mesh it.' },
              { ic: I.Mic,     t: '2. Pick a voice',   d: 'Your cloned voice, a studio voice, or per-channel default.' },
              { ic: I.Film,    t: '3. Generate scenes', d: 'Image-to-video keeps your face consistent across cuts.' },
              { ic: I.Sparkles, t: '4. Lip-sync',      d: 'Phonemes align frame-perfect to the voiceover.' },
            ].map((s, i) => (
              <div key={i} style={{ padding: 20, background: 'var(--bg-surface)' }}>
                <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--accent-tint-1)', border: '1px solid var(--brand-soft-bd)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-fg)' }}>
                  <s.ic size={16}/>
                </span>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)', marginTop: 12 }}>{s.t}</div>
                <div className="t-small" style={{ marginTop: 6, textWrap: 'pretty' }}>{s.d}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {openCreate && <AvatarCreateModal onClose={() => setOpenCreate(false)}/>}
    </div>
  );
}

function AvatarCard({ a }) {
  return (
    <div className="card card--hover" style={{ padding: 0, overflow: 'hidden' }}>
      {/* Portrait */}
      <div style={{
        aspectRatio: '1 / 1',
        background: a.portraitGrad,
        position: 'relative',
      }}>
        {/* Mock face silhouette */}
        <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          <defs>
            <linearGradient id={`fa-${a.id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgba(255,255,255,0.30)"/>
              <stop offset="100%" stopColor="rgba(0,0,0,0.25)"/>
            </linearGradient>
          </defs>
          <ellipse cx="50" cy="38" rx="18" ry="22" fill={`url(#fa-${a.id})`}/>
          <path d="M22,98 C22,72 36,62 50,62 C64,62 78,72 78,98 Z" fill={`url(#fa-${a.id})`}/>
        </svg>
        {/* Tracking dots overlay */}
        <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.6 }}>
          {[
            [40,30],[60,30],[50,38],[42,46],[58,46],[50,50],[44,55],[56,55],[45,30],[55,30],[36,40],[64,40],[38,50],[62,50]
          ].map(([x,y], i) => <circle key={i} cx={x} cy={y} r="0.7" fill="var(--cyan-300)"/>)}
        </svg>
        {/* Stage chips */}
        <span style={{ position: 'absolute', top: 10, left: 10 }} className="chip chip--magic"><I.Sparkles size={11}/> Lip sync ready</span>
        <span style={{ position: 'absolute', top: 10, right: 10 }} className="chip">{a.match}% match</span>
        {/* Play talking-head preview */}
        <button className="btn btn--primary btn--icon-lg" style={{
          position: 'absolute', bottom: 12, right: 12,
          width: 44, height: 44, borderRadius: '50%',
        }}><I.Play size={16}/></button>
      </div>
      <div style={{ padding: 16 }}>
        <div style={{ font: '600 15px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{a.name}</div>
        <div className="t-small" style={{ marginTop: 4 }}>{a.vibe}</div>
        <div className="divider" style={{ margin: '14px 0' }}/>
        <div style={{ display: 'flex', gap: 6 }}>
          <Btn kind="secondary" size="sm" icon={I.Check}>Use in videos</Btn>
          <button className="btn btn--ghost btn--icon btn--sm"><I.Sliders size={14}/></button>
          <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
        </div>
      </div>
    </div>
  );
}

function AvatarCreateModal({ onClose }) {
  const [step, setStep] = React.useState(0); // 0 upload, 1 calibrate, 2 voice link, 3 done
  return (
    <Modal open={true} onClose={onClose} width={620}>
      <div style={{ padding: 28, position: 'relative', overflow: 'hidden' }}>
        <SparkleField count={8} intensity={0.4}/>
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
            <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--magenta-400)' }}>
              <I.User size={18}/>
            </span>
            <span className="t-h4">Create an avatar</span>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
          </div>

          {/* Progress dots */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 22 }}>
            {[0,1,2,3].map(i => (
              <span key={i} style={{
                flex: 1, height: 4, borderRadius: 999,
                background: i <= step ? 'linear-gradient(90deg, var(--violet-500), var(--cyan-400))' : 'var(--surface-active)',
              }}/>
            ))}
          </div>

          {step === 0 && <AvUpload onNext={() => setStep(1)}/>}
          {step === 1 && <AvCalibrate onNext={() => setStep(2)} onBack={() => setStep(0)}/>}
          {step === 2 && <AvVoice onNext={() => setStep(3)} onBack={() => setStep(1)}/>}
          {step === 3 && <AvDone onClose={onClose}/>}
        </div>
      </div>
    </Modal>
  );
}

function AvUpload({ onNext }) {
  return (
    <div>
      <div className="t-h5" style={{ marginBottom: 6 }}>Step 1 · Upload your photo</div>
      <div className="t-small" style={{ marginBottom: 18 }}>Front-facing, neutral expression, well-lit. A single shot is enough.</div>

      <div style={{
        aspectRatio: '4 / 3',
        borderRadius: 16,
        border: '2px dashed var(--border-default)',
        background: 'var(--surface-subtle)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 10, position: 'relative', overflow: 'hidden',
      }}>
        <SparkleField count={8} intensity={0.3}/>
        <span style={{
          width: 64, height: 64, borderRadius: 18,
          background: 'var(--magic-tint)',
          border: '1px solid var(--accent-border-soft)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--magenta-400)',
        }}><I.Upload size={26}/></span>
        <div style={{ font: '600 15px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Drop a photo or click to upload</div>
        <div className="t-small">JPG, PNG, or HEIC · up to 20MB</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
          <Btn kind="secondary" size="sm" icon={I.Image}>Choose file</Btn>
          <Btn kind="ghost" size="sm" icon={I.Eye}>Use webcam</Btn>
        </div>
      </div>

      <div style={{ marginTop: 18, padding: 14, borderRadius: 12, background: 'var(--info-bg)', border: '1px solid var(--info-bd)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <I.Help size={14} stroke="var(--info)"/>
          <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--info)' }}>For best results</span>
        </div>
        <div className="t-small" style={{ marginTop: 6, color: 'var(--fg-secondary)' }}>
          Looking straight at camera · soft front-lighting · no sunglasses · no hand on face · plain background works best.
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 22, justifyContent: 'flex-end' }}>
        <Btn kind="ghost">Cancel</Btn>
        <Btn kind="primary" iconRight={I.ChevRight} onClick={onNext}>Continue with demo photo</Btn>
      </div>
    </div>
  );
}

function AvCalibrate({ onNext, onBack }) {
  return (
    <div>
      <div className="t-h5" style={{ marginBottom: 6 }}>Step 2 · We're meshing your face</div>
      <div className="t-small" style={{ marginBottom: 18 }}>62 anchor points · skin, jaw, eyes, brow, lips. This is what we'll animate.</div>

      <div style={{
        aspectRatio: '4 / 3',
        borderRadius: 16,
        background: 'linear-gradient(135deg,#3D405B,#81B29A,#F2CC8F)',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Mock face */}
        <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          <ellipse cx="50" cy="42" rx="18" ry="22" fill="rgba(255,255,255,0.18)"/>
          <path d="M22,100 C22,72 36,62 50,62 C64,62 78,72 78,100 Z" fill="rgba(255,255,255,0.18)"/>
        </svg>
        {/* Mesh overlay */}
        <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          {/* mesh lines */}
          {Array.from({ length: 12 }).map((_, i) => (
            <line key={`h${i}`} x1="22" y1={28 + i * 6} x2="78" y2={28 + i * 6} stroke="var(--accent-tint-3)" strokeWidth="0.2"/>
          ))}
          {Array.from({ length: 12 }).map((_, i) => (
            <line key={`v${i}`} y1="22" x1={26 + i * 4.4} y2="98" x2={26 + i * 4.4} stroke="var(--accent-tint-3)" strokeWidth="0.2"/>
          ))}
          {/* anchor points */}
          {[
            [40,30],[60,30],[50,38],[42,46],[58,46],[50,50],[44,55],[56,55],[45,30],[55,30],[36,40],[64,40],[38,50],[62,50],
            [42,33],[58,33],[50,42],[40,58],[60,58],[46,60],[54,60],[50,60],[34,66],[66,66],[50,70],[42,72],[58,72],[50,76],
          ].map(([x,y], i) => <circle key={i} cx={x} cy={y} r="0.8" fill="var(--cyan-300)" stroke="white" strokeWidth="0.2"/>)}
        </svg>
        <span style={{ position: 'absolute', top: 12, left: 12 }} className="chip chip--brand"><I.Spark size={11}/> 62 anchor points</span>
        <span style={{ position: 'absolute', bottom: 12, left: 12 }} className="chip chip--success"><I.Check size={11}/> Mesh complete</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 18 }}>
        <div className="card" style={{ padding: 14 }}>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Render style</div>
          <div style={{ display: 'flex', gap: 6 }}>
            <span className="chip chip--brand"><I.Check size={11}/> Realistic</span>
            <span className="chip">Cartoon</span>
            <span className="chip">Painterly</span>
          </div>
        </div>
        <div className="card" style={{ padding: 14 }}>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Identity lock</div>
          <Switch on={true} label="Keep face consistent across scenes"/>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 22, justifyContent: 'space-between' }}>
        <Btn kind="ghost" onClick={onBack}>Back</Btn>
        <Btn kind="primary" iconRight={I.ChevRight} onClick={onNext}>Continue</Btn>
      </div>
    </div>
  );
}

function AvVoice({ onNext, onBack }) {
  const [picked, setPicked] = React.useState('cv1');
  const voices = [
    { id: 'cv1', name: 'My Storyteller', sub: 'Your cloned voice · 96%', mine: true },
    { id: 'cv2', name: 'Atlas',          sub: 'Studio · Documentary · Warm' },
    { id: 'cv3', name: 'Nova',           sub: 'Studio · Energetic · Bright' },
  ];
  return (
    <div>
      <div className="t-h5" style={{ marginBottom: 6 }}>Step 3 · Link a voice</div>
      <div className="t-small" style={{ marginBottom: 18 }}>This is what your avatar will lip-sync to.</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {voices.map(v => {
          const isP = picked === v.id;
          return (
            <button key={v.id} onClick={() => setPicked(v.id)} style={{
              padding: 14, borderRadius: 12, cursor: 'pointer', textAlign: 'left',
              border: '1px solid', borderColor: isP ? 'var(--accent)' : 'var(--border-hairline)',
              background: isP ? 'var(--accent-tint-1)' : 'var(--surface-subtle)',
              boxShadow: isP ? '0 0 0 3px rgba(139,92,246,0.16)' : 'none',
              display: 'flex', alignItems: 'center', gap: 14,
            }}>
              <span style={{
                width: 40, height: 40, borderRadius: '50%',
                background: v.mine ? 'var(--magic-grad)' : 'linear-gradient(135deg, var(--magenta-400), var(--brand))',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: 'white', font: '700 14px/1 var(--font-display)',
                boxShadow: v.mine ? '0 4px 12px rgba(124,58,237,0.35)' : 'none',
              }}>{v.name[0]}</span>
              <div style={{ flex: 1 }}>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {v.name}
                  {v.mine && <span className="chip chip--magic" style={{ height: 18, fontSize: 10, padding: '0 6px' }}>cloned</span>}
                </div>
                <div className="t-small" style={{ marginTop: 4 }}>{v.sub}</div>
              </div>
              <button onClick={e => e.stopPropagation()} className="btn btn--ghost btn--icon"><I.Play size={14}/></button>
            </button>
          );
        })}
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 22, justifyContent: 'space-between' }}>
        <Btn kind="ghost" onClick={onBack}>Back</Btn>
        <Btn kind="magic" iconRight={I.Spark} onClick={onNext}>Generate talking-head sample</Btn>
      </div>
    </div>
  );
}

function AvDone({ onClose }) {
  return (
    <div style={{ textAlign: 'center', padding: '8px 0' }}>
      <div style={{ position: 'relative', display: 'inline-block', marginBottom: 18 }}>
        <div style={{ position: 'absolute', inset: -30, borderRadius: '50%', background: 'radial-gradient(circle, var(--success-bd) 0%, transparent 70%)', filter: 'blur(20px)' }}/>
        <span style={{
          position: 'relative',
          width: 72, height: 72, borderRadius: 20,
          background: 'linear-gradient(135deg, var(--success-bd), rgba(34,211,238,0.20))',
          border: '1px solid var(--success-bd)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--success)',
        }}><I.Check size={32}/></span>
      </div>
      <div className="t-h3" style={{ marginBottom: 8 }}>Your avatar is ready</div>
      <div className="t-small" style={{ marginBottom: 18 }}>Lip sync is live. Try a sample, or attach this avatar to a channel.</div>

      {/* preview pill */}
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '12px 18px', borderRadius: 999, background: 'var(--accent-tint-1)', border: '1px solid var(--brand-soft-bd)', marginBottom: 20 }}>
        <span style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#3D405B,#81B29A)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg viewBox="0 0 24 24" width="20" height="20"><ellipse cx="12" cy="9" rx="4" ry="5" fill="rgba(255,255,255,0.40)"/><path d="M4,22 C4,16 8,14 12,14 C16,14 20,16 20,22 Z" fill="rgba(255,255,255,0.40)"/></svg>
        </span>
        <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>My talking-head · ready</span>
        <button className="btn btn--magic btn--icon btn--sm"><I.Play size={12}/></button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 360, margin: '0 auto' }}>
        <Btn kind="primary" icon={I.Check}>Use in Mythic Tales</Btn>
        <Btn kind="ghost" onClick={onClose}>Close</Btn>
      </div>
    </div>
  );
}

window.VoiceLibraryScreen = VoiceLibraryScreen;
window.AvatarsScreen = AvatarsScreen;
