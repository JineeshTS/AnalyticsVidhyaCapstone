/* ============================================================
   AIcreators V2 — Mobile (iOS + Android) screen mockups
   ============================================================
   Showcase of the new design system applied to native mobile.
   Two columns: iOS (left) and Android (right). Each shows 4
   key screens in a real device frame.
   For FlutterFlow handoff — these map 1:1 to Flutter widgets.
   ============================================================ */

const I = V2I;

const V2_STAGES_M = [
  { id: 'idea',       label: 'Idea',       icon: 'Spark' },
  { id: 'script',     label: 'Script',     icon: 'Edit' },
  { id: 'storyboard', label: 'Storyboard', icon: 'Layers' },
  { id: 'frames',     label: 'Keyframes',  icon: 'Image' },
  { id: 'motion',     label: 'Motion',     icon: 'Film' },
  { id: 'voice',      label: 'Voice',      icon: 'Mic' },
  { id: 'edit',       label: 'Edit',       icon: 'Bolt' },
  { id: 'publish',    label: 'Publish',    icon: 'Youtube' },
];

function V2MobileApp() {
  return (
    <div style={{ minHeight: '100vh', padding: '40px 20px' }}>
      {/* Top nav */}
      <header style={{ display: 'flex', alignItems: 'center', gap: 16, maxWidth: 1480, margin: '0 auto 40px' }}>
        <Logo markSize={28} wordSize={16}/>
        <span className="chip">v2 · mobile</span>
        <div style={{ flex: 1 }}/>
        <a href="AIcreators V2 Brand.html" className="btn btn--ghost btn--sm" style={{ textDecoration: 'none' }}>← Brand</a>
        <a href="AIcreators V2 Admin.html" className="btn btn--secondary btn--sm" style={{ textDecoration: 'none' }}>Admin →</a>
      </header>

      {/* Hero */}
      <div style={{ maxWidth: 1480, margin: '0 auto 56px', textAlign: 'center' }}>
        <span className="chip chip--accent">native iOS + Android · FlutterFlow</span>
        <h1 className="t-display" style={{ marginTop: 18, marginBottom: 14, fontSize: 56 }}>
          The studio<br/>in your pocket.
        </h1>
        <p className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 560, margin: '0 auto', fontSize: 17 }}>
          One Flutter codebase. Two platforms. The same brand, the same autopilot, the same lime accent.
        </p>
      </div>

      {/* Side-by-side iOS + Android — 4 screens each */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 40, marginBottom: 64, flexWrap: 'wrap' }}>
        <PlatformColumn platform="ios"/>
        <PlatformColumn platform="android"/>
      </div>

      <V2MobileFeatures/>
      <V2MobileNotifs/>
      <V2ThemeToggle/>
    </div>
  );
}

function PlatformColumn({ platform }) {
  return (
    <div style={{ flex: '0 0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 24, justifyContent: 'center' }}>
        <span className="chip" style={{ background: platform === 'ios' ? '#fff' : '#3DDC84', color: '#000', border: 0 }}>
          {platform === 'ios' ? 'iOS · iPhone' : 'Android · Material 3'}
        </span>
      </div>
      <div style={{ display: 'flex', gap: 28, alignItems: 'flex-start', overflowX: 'auto', paddingBottom: 12 }}>
        <ScreenFrame platform={platform} label="Studio · dashboard">
          {platform === 'ios' ? <IOSDevice><ScreenStudio platform="ios"/></IOSDevice>
                              : <AndroidDevice><ScreenStudio platform="android"/></AndroidDevice>}
        </ScreenFrame>
        <ScreenFrame platform={platform} label="Project · 8-stage pipeline">
          {platform === 'ios' ? <IOSDevice><ScreenProject platform="ios"/></IOSDevice>
                              : <AndroidDevice><ScreenProject platform="android"/></AndroidDevice>}
        </ScreenFrame>
        <ScreenFrame platform={platform} label="Voice clone · record">
          {platform === 'ios' ? <IOSDevice><ScreenRecord platform="ios"/></IOSDevice>
                              : <AndroidDevice><ScreenRecord platform="android"/></AndroidDevice>}
        </ScreenFrame>
        <ScreenFrame platform={platform} label="Top up · Razorpay">
          {platform === 'ios' ? <IOSDevice><ScreenTopup platform="ios"/></IOSDevice>
                              : <AndroidDevice><ScreenTopup platform="android"/></AndroidDevice>}
        </ScreenFrame>
      </div>
    </div>
  );
}

function ScreenFrame({ platform, label, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, flexShrink: 0 }}>
      {children}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
        <span className="t-tiny">{label}</span>
      </div>
    </div>
  );
}

/* ====================================================
   SHARED MOBILE LAYOUT — works inside iOS + Android frames
   ==================================================== */
function MobScaffold({ platform, title, children, fab, action, back }) {
  const isIOS = platform === 'ios';
  return (
    <div style={{ width: '100%', height: '100%', background: 'var(--bg-app)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Top app bar */}
      <div style={{ padding: isIOS ? '8px 16px 12px' : '14px 16px 12px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid var(--border-hairline)' }}>
        {back && (
          <button style={{ width: 36, height: 36, borderRadius: 12, background: 'transparent', border: 0, color: 'var(--fg-strong)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.ChevLeft size={20}/>
          </button>
        )}
        {!back && <LogoMark size={28}/>}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: isIOS ? '700 17px/1.2 var(--font-display)' : '600 20px/1.2 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.01em', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</div>
        </div>
        {action || (
          <button style={{ width: 36, height: 36, borderRadius: 12, background: 'transparent', border: 0, color: 'var(--fg-strong)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.Bell size={18}/>
          </button>
        )}
      </div>

      {/* Scroll body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 80px' }}>
        {children}
      </div>

      {/* Bottom tab bar */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: 'rgba(10,10,14,0.92)',
        backdropFilter: 'blur(20px)',
        borderTop: '1px solid var(--border-hairline)',
        padding: isIOS ? '6px 8px 26px' : '8px 8px 12px',
        display: 'flex', justifyContent: 'space-around',
      }}>
        {[
          { l: 'Studio', icon: 'Studio', active: title === 'Studio' || title?.startsWith('How') || title === 'Project' },
          { l: 'Topics', icon: 'Spark' },
          { l: 'Library', icon: 'Folder' },
          { l: 'Profile', icon: 'User', active: title === 'Top up' },
        ].map(t => {
          const Ico = I[t.icon];
          return (
            <button key={t.l} style={{
              border: 0, background: 'transparent', cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '6px 10px',
              color: t.active ? 'var(--accent)' : 'var(--fg-muted)',
            }}>
              <Ico size={20}/>
              <span style={{ font: '600 10px/1 var(--font-sans)' }}>{t.l}</span>
            </button>
          );
        })}
      </div>

      {/* FAB (Android only) */}
      {fab && !isIOS && (
        <button style={{
          position: 'absolute', bottom: 88, right: 16,
          width: 56, height: 56, borderRadius: 16,
          background: 'var(--accent)', color: 'var(--ink-950)',
          border: 0, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 24px rgba(204,255,0,0.30)', cursor: 'pointer',
        }}>
          <I.Plus size={24} strokeWidth={2.5}/>
        </button>
      )}
    </div>
  );
}

/* ====================================================
   SCREEN 1 · STUDIO DASHBOARD
   ==================================================== */
function ScreenStudio({ platform }) {
  return (
    <MobScaffold platform={platform} title="Studio" fab>
      {/* Greeting + balance card */}
      <div className="card card--accent" style={{ padding: 18, marginBottom: 14, background: 'var(--accent-tint)' }}>
        <div className="t-tiny" style={{ color: 'var(--accent)' }}>Balance</div>
        <div style={{ font: '700 36px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.03em', marginTop: 8 }}>
          $148<span style={{ color: 'var(--fg-muted)', fontSize: 22 }}>.24</span>
        </div>
        <div className="t-small" style={{ marginTop: 6, fontSize: 12 }}>~ 12 min 21 sec at $0.20/sec</div>
        <button className="btn btn--accent btn--sm" style={{ marginTop: 14, width: '100%' }}>
          <I.Plus size={14}/> Top up · 2× bonus
        </button>
      </div>

      {/* Status pill */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', borderRadius: 12, background: 'var(--bg-surface)', border: '1px solid var(--accent-border)', marginBottom: 18 }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)' }} className="ai-pulse"/>
        <div style={{ flex: 1 }}>
          <div style={{ font: '600 12px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Autopilot active</div>
          <div className="t-small" style={{ marginTop: 3, fontSize: 11 }}>3 videos in production</div>
        </div>
      </div>

      <div className="t-tiny" style={{ marginBottom: 12 }}>In production</div>

      {/* Project cards */}
      {[
        { t: 'Volcanoes & lightning', ch: 'Snackable Sci', dur: '0:58', stage: 6, format: 'short' },
        { t: 'Lost library of Alexandria', ch: 'Mythic Tales', dur: '11:42', stage: 7, format: 'long', state: 'review' },
        { t: 'Pufferfish facts', ch: 'Snackable Sci', dur: '1:24', stage: 4 },
      ].map((p, i) => <MobProjectCard key={i} p={p}/>)}
    </MobScaffold>
  );
}

function MobProjectCard({ p }) {
  return (
    <div className="card" style={{ padding: 14, marginBottom: 10 }}>
      <div style={{ display: 'flex', gap: 12 }}>
        <div style={{ width: 64, height: 40, borderRadius: 6, background: 'linear-gradient(135deg,#1F2030,#3E4259)', flexShrink: 0 }}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.t}</div>
          <div className="t-small" style={{ marginTop: 4, fontSize: 11 }}>{p.ch} · {p.dur}</div>
        </div>
        {p.state === 'review' && <span className="chip chip--warning" style={{ height: 22, fontSize: 10, padding: '0 8px' }}>review</span>}
      </div>
      {/* Mini pipeline */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 2, marginTop: 12 }}>
        {V2_STAGES_M.map((s, i) => {
          const done = i < p.stage;
          const running = i === p.stage && p.state !== 'review';
          const review = i === p.stage && p.state === 'review';
          return (
            <React.Fragment key={s.id}>
              <div className={running ? 'ai-pulse' : ''} style={{
                width: 18, height: 18, borderRadius: 5,
                background: done ? 'var(--accent-tint)' : running ? 'var(--accent)' : review ? 'var(--warning-tint)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${done ? 'var(--accent-border)' : running ? 'var(--accent)' : review ? 'var(--warning-border)' : 'var(--border-hairline)'}`,
                color: done ? 'var(--accent)' : running ? 'var(--ink-950)' : review ? 'var(--warning)' : 'var(--fg-faint)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              }}>{done ? <I.Check size={9}/> : React.createElement(I[s.icon], { size: 9 })}</div>
              {i < V2_STAGES_M.length - 1 && (
                <div style={{ flex: 1, height: 1.5, background: done ? 'var(--accent)' : 'rgba(255,255,255,0.08)', opacity: done ? 0.4 : 1 }}/>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

/* ====================================================
   SCREEN 2 · PROJECT DETAIL
   ==================================================== */
function ScreenProject({ platform }) {
  return (
    <MobScaffold platform={platform} title="Project" back action={<button style={{ width: 36, height: 36, borderRadius: 12, background: 'transparent', border: 0, color: 'var(--fg-strong)' }}><I.More size={20}/></button>}>
      {/* Hero */}
      <div style={{ aspectRatio: '16/9', borderRadius: 14, background: 'linear-gradient(135deg,#2A1810,#7B4F2C)', position: 'relative', marginBottom: 14, overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
        <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 48, height: 48, borderRadius: '50%', background: 'rgba(0,0,0,0.55)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
          <I.Play size={20} stroke="white"/>
        </span>
        <span style={{ position: 'absolute', bottom: 8, right: 10, font: '600 11px/1 var(--font-mono)', color: 'white', padding: '4px 7px', background: 'rgba(0,0,0,0.6)', borderRadius: 4 }}>11:42</span>
      </div>

      <div style={{ font: '600 17px/1.3 var(--font-display)', color: 'var(--fg-strong)', marginBottom: 4 }}>Lost library of Alexandria</div>
      <div className="t-small" style={{ marginBottom: 14, fontSize: 12 }}>Mythic Tales · long-form</div>

      {/* Cost so far */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        <div style={{ flex: 1, padding: 12, borderRadius: 12, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)' }}>
          <div className="t-tiny">Cost</div>
          <div style={{ font: '700 18px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 6 }}>$140.40</div>
        </div>
        <div style={{ flex: 1, padding: 12, borderRadius: 12, background: 'var(--warning-tint)', border: '1px solid var(--warning-border)' }}>
          <div className="t-tiny" style={{ color: 'var(--warning)' }}>Status</div>
          <div style={{ font: '700 14px/1.2 var(--font-display)', color: 'var(--fg-strong)', marginTop: 6 }}>Awaiting review</div>
        </div>
      </div>

      <div className="t-tiny" style={{ marginBottom: 10 }}>Pipeline</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 16 }}>
        {V2_STAGES_M.map((s, i) => {
          const done = i < 7;
          const review = i === 7;
          const Ico = I[s.icon];
          return (
            <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderRadius: 10, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)' }}>
              <span style={{
                width: 28, height: 28, borderRadius: 8,
                background: done ? 'var(--accent-tint)' : review ? 'var(--warning-tint)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${done ? 'var(--accent-border)' : review ? 'var(--warning-border)' : 'var(--border-hairline)'}`,
                color: done ? 'var(--accent)' : review ? 'var(--warning)' : 'var(--fg-muted)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              }}>{done ? <I.Check size={13}/> : <Ico size={13}/>}</span>
              <span style={{ flex: 1, font: '500 13px/1.2 var(--font-sans)', color: 'var(--fg-default)' }}>{s.label}</span>
              {review && <span className="chip chip--warning" style={{ height: 22, fontSize: 10, padding: '0 8px' }}>review →</span>}
            </div>
          );
        })}
      </div>

      <button className="btn btn--accent" style={{ width: '100%' }}>
        <I.Eye size={16}/> Preview latest cut
      </button>
    </MobScaffold>
  );
}

/* ====================================================
   SCREEN 3 · VOICE RECORD
   ==================================================== */
function ScreenRecord({ platform }) {
  return (
    <MobScaffold platform={platform} title="Clone voice" back>
      <div style={{ textAlign: 'center', padding: '20px 0' }}>
        <div className="t-tiny" style={{ marginBottom: 12 }}>Recording</div>
        <div style={{ font: '700 64px/1 var(--font-display)', color: 'var(--accent)', letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums' }}>0:24</div>
        <div className="t-small" style={{ marginTop: 6 }}>of 1:00</div>
      </div>

      {/* Live waveform */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 3, height: 100, padding: '0 4px' }}>
        {Array.from({ length: 56 }).map((_, i) => {
          const h = 6 + Math.abs(Math.sin(i * 0.4) * 36) + Math.abs(Math.sin(i * 0.91) * 22);
          return <span key={i} style={{ width: 3, height: Math.min(86, h), background: 'var(--accent)', borderRadius: 2 }}/>;
        })}
      </div>

      {/* Script prompt card */}
      <div className="card" style={{ marginTop: 24, marginBottom: 20, padding: 16, background: 'var(--bg-surface)' }}>
        <div className="t-tiny" style={{ marginBottom: 8 }}>Read this aloud</div>
        <div style={{ font: '500 14px/1.55 var(--font-sans)', color: 'var(--fg-strong)', textWrap: 'pretty' }}>
          "The first time I saw a video appear on my screen with my own voice narrating it, I didn't know whether to laugh or feel a little betrayed by the future."
        </div>
      </div>

      {/* Big stop button */}
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 24 }}>
        <button style={{
          width: 80, height: 80, borderRadius: '50%',
          background: 'var(--danger)', color: 'white', border: 0,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 0 6px rgba(255,71,71,0.2)', cursor: 'pointer',
        }}>
          <div style={{ width: 28, height: 28, borderRadius: 6, background: 'white' }}/>
        </button>
      </div>
      <div style={{ textAlign: 'center', marginTop: 12 }}>
        <span className="t-small">Tap to finish</span>
      </div>
    </MobScaffold>
  );
}

/* ====================================================
   SCREEN 4 · TOP UP / RAZORPAY
   ==================================================== */
function ScreenTopup({ platform }) {
  return (
    <MobScaffold platform={platform} title="Top up" back>
      {/* Bonus banner */}
      <div className="card card--accent" style={{ padding: 14, marginBottom: 18, background: 'var(--accent-tint)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--accent)', color: 'var(--ink-950)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.Spark size={16}/>
          </span>
          <div style={{ flex: 1 }}>
            <div style={{ font: '700 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>First recharge is 2×</div>
            <div className="t-small" style={{ marginTop: 3, fontSize: 11 }}>Whatever you add is doubled, one time.</div>
          </div>
        </div>
      </div>

      <label style={{ marginBottom: 8 }}>Amount</label>
      <div style={{ position: 'relative', marginBottom: 12 }}>
        <span style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', font: '700 24px/1 var(--font-display)', color: 'var(--fg-muted)' }}>$</span>
        <input defaultValue="100" style={{ height: 64, paddingLeft: 36, font: '700 28px/1 var(--font-display)', color: 'var(--fg-strong)' }}/>
      </div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 18 }}>
        {[25, 50, 100, 250, 500, 1000].map(p => (
          <button key={p} className={p === 100 ? 'chip chip--accent' : 'chip'} style={{ cursor: 'pointer', height: 32, border: 0 }}>${p}</button>
        ))}
      </div>

      {/* Receipt */}
      <div className="card" style={{ padding: 14, marginBottom: 18 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}>
          <span className="t-body" style={{ fontSize: 13 }}>Recharge</span>
          <span style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>$100.00</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}>
          <span className="t-body" style={{ fontSize: 13, color: 'var(--accent)' }}>Signup bonus</span>
          <span style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--accent)' }}>+ $100.00</span>
        </div>
        <div className="divider" style={{ margin: '8px 0' }}/>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}>
          <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>Total credit</span>
          <span style={{ font: '700 18px/1 var(--font-display)', color: 'var(--fg-strong)' }}>$200.00</span>
        </div>
        <div className="t-small" style={{ marginTop: 6, fontSize: 11 }}>~ 16 min 40 sec of video</div>
      </div>

      <button className="btn btn--accent btn--lg" style={{ width: '100%' }}>
        <I.Credit size={16}/> Pay with Razorpay
      </button>
      <div style={{ textAlign: 'center', marginTop: 12 }}>
        <span className="t-small" style={{ fontSize: 11 }}>UPI · Cards · Net banking · Wallets · EMI</span>
      </div>
    </MobScaffold>
  );
}

/* ====================================================
   FEATURE GRID + NOTIFICATION STATES
   ==================================================== */
function V2MobileFeatures() {
  return (
    <section style={{ maxWidth: 1280, margin: '0 auto 64px', padding: '0 20px' }}>
      <span className="chip">native features</span>
      <h2 className="t-h2" style={{ marginTop: 18, marginBottom: 28 }}>What mobile unlocks</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {[
          { ic: 'Bell',   t: 'Push notifications', d: 'When a video needs review or goes live — actionable from the lock screen' },
          { ic: 'Mic',    t: 'Tap-to-record clone', d: 'Use the phone\'s mic — better than uploading on web' },
          { ic: 'Image',  t: 'Camera for avatars', d: 'Snap a selfie, mesh in 3 minutes, lip sync ready' },
          { ic: 'Studio', t: 'Watch from anywhere', d: 'Approve a stage between meetings · review on the train' },
          { ic: 'Spark',  t: 'Voice-input topics', d: 'Speak an idea while walking · Whisper transcribes' },
          { ic: 'Layers', t: 'Widget on home screen', d: 'Today\'s production at a glance, no app open' },
          { ic: 'Folder', t: 'Share-sheet target',   d: 'Send a link / image into AIcreators from any app' },
          { ic: 'Credit', t: 'Razorpay UPI native',  d: 'One-tap UPI on Android · UPI in-app browser on iOS' },
        ].map(f => {
          const Ico = I[f.ic];
          return (
            <div key={f.t} className="card" style={{ padding: 16 }}>
              <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--accent-tint)', border: '1px solid var(--accent-border)', color: 'var(--accent)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
                <Ico size={16}/>
              </span>
              <div className="t-h5" style={{ marginBottom: 6 }}>{f.t}</div>
              <div className="t-small" style={{ textWrap: 'pretty' }}>{f.d}</div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function V2MobileNotifs() {
  return (
    <section style={{ maxWidth: 1280, margin: '0 auto 80px', padding: '0 20px' }}>
      <span className="chip">notifications</span>
      <h2 className="t-h2" style={{ marginTop: 18, marginBottom: 8 }}>Push states</h2>
      <p className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 28 }}>
        Same brand voice, dressed for the lock screen.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14, maxWidth: 800 }}>
        {[
          { ic: 'Eye',     title: '"Detective" needs your review', body: 'Mythic Tales · 8 keyframes ready', tone: 'warning', ago: 'now' },
          { ic: 'Youtube', title: 'Your video is live 🎉', body: 'Volcano lightning · published to YouTube + 4 platforms', tone: 'accent', ago: '2m' },
          { ic: 'Spark',   title: 'A trending topic just dropped', body: '"Antikythera mechanism, decoded" · 95% fit for Mythic Tales', tone: 'plain', ago: '14m' },
          { ic: 'Credit',  title: 'Running low on credits', body: '$8 left · ~ 40 seconds of video', tone: 'warning', ago: '1h' },
        ].map((n, i) => {
          const Ico = I[n.ic];
          const bg = n.tone === 'warning' ? 'var(--warning-tint)' : n.tone === 'accent' ? 'var(--accent-tint)' : 'var(--bg-surface)';
          const bd = n.tone === 'warning' ? 'var(--warning-border)' : n.tone === 'accent' ? 'var(--accent-border)' : 'var(--border-hairline)';
          return (
            <div key={i} className="card" style={{ padding: 14, background: bg, borderColor: bd, display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)', color: n.tone === 'warning' ? 'var(--warning)' : n.tone === 'accent' ? 'var(--accent)' : 'var(--fg-default)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Ico size={16}/>
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8 }}>
                  <span style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>aicreators</span>
                  <span className="t-tiny">{n.ago}</span>
                </div>
                <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)', marginTop: 2 }}>{n.title}</div>
                <div className="t-small" style={{ marginTop: 4 }}>{n.body}</div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<V2MobileApp/>);
