/* ============================================================
   AIcreators.cloud · Transactional email gallery
   ============================================================
   Visual preview of every transactional email the platform sends.
   Real email-safe HTML (table-based layout, inline styles, web-safe
   fonts with display-font fallback). Each preview shows the email
   exactly as it'd render in Gmail/Outlook/Apple Mail.

   This page is for design QA + dev handoff. The shipping templates
   live in /transactional/*.html on the backend and are rendered
   with Liquid variables at send time.

   Sender: AIcreators <noreply@aicreators.cloud>
   Reply-to: support@aicreators.cloud
   List-Unsubscribe-Post: List-Unsubscribe=One-Click
   ============================================================ */

const EMAIL_TEMPLATES = [
  { key: 'welcome',           name: 'Welcome',                       sub: 'Sent immediately after signup', category: 'lifecycle' },
  { key: 'verify_email',      name: 'Verify your email',             sub: 'Single-tap verify link',          category: 'lifecycle' },
  { key: 'magic_link',        name: 'Magic sign-in link',            sub: '10-min one-use token',            category: 'auth' },
  { key: 'reset_password',    name: 'Reset your password',           sub: '30-min one-use link',             category: 'auth' },
  { key: '2fa_enabled',       name: 'Two-factor enabled',            sub: 'Security confirmation',           category: 'auth' },
  { key: 'new_device',        name: 'New sign-in on Linux · Firefox',sub: 'Security alert',                  category: 'auth' },
  { key: 'review_needed',     name: 'A video needs your review',     sub: 'Pipeline paused for approval',    category: 'product' },
  { key: 'video_published',   name: 'Your video is live',            sub: 'Across all destinations',         category: 'product' },
  { key: 'oauth_disconnected',name: 'YouTube disconnected',          sub: 'Re-connect link',                 category: 'product' },
  { key: 'weekly_digest',     name: 'Your weekly digest',            sub: 'Sundays · 9 AM',                  category: 'lifecycle' },
  { key: 'low_credits',       name: 'Running low on credits',        sub: 'Top up or upgrade',               category: 'billing' },
  { key: 'plan_renewal',      name: 'Studio Pro renews in 7 days',   sub: 'Receipt preview',                 category: 'billing' },
  { key: 'invoice',           name: 'Receipt · May 2025',            sub: 'After successful charge',         category: 'billing' },
  { key: 'data_export_ready', name: 'Your data export is ready',     sub: '.zip download link',              category: 'compliance' },
  { key: 'deletion_confirm',  name: 'Confirm account deletion',      sub: 'Starts the 30-day grace',         category: 'compliance' },
];

function EmailsApp() {
  const [active, setActive] = React.useState('welcome');
  const [device, setDevice] = React.useState('desktop');
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-app)' }}>
      <header style={{ padding: '14px 32px', display: 'flex', alignItems: 'center', gap: 16, borderBottom: '1px solid var(--border-hairline)' }}>
        <a href="AIcreators Cloud Home.html" style={{ textDecoration: 'none', display: 'inline-flex' }}>
          <LogoLockup markSize={28} wordSize={15}/>
        </a>
        <span style={{ padding: '4px 10px', borderRadius: 999, background: 'var(--surface-hover)', font: '600 11px/1 var(--font-sans)', color: 'var(--fg-muted)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Email templates</span>
        <div style={{ flex: 1 }}/>
        <Tabs value={device} onChange={setDevice} items={[
          { id: 'desktop', label: 'Desktop' },
          { id: 'mobile',  label: 'Mobile' },
          { id: 'plain',   label: 'Plain text' },
        ]}/>
        <Btn kind="secondary" size="sm" icon={I.Send}>Send test to me</Btn>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', minHeight: 'calc(100vh - 65px)' }}>
        <aside style={{ padding: '24px 16px 24px 32px', borderRight: '1px solid var(--border-hairline)' }}>
          {['auth','lifecycle','product','billing','compliance'].map(cat => (
            <div key={cat} style={{ marginBottom: 18 }}>
              <div className="t-tiny" style={{ marginBottom: 8 }}>{cat}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {EMAIL_TEMPLATES.filter(t => t.category === cat).map(t => {
                  const isActive = active === t.key;
                  return (
                    <button key={t.key} onClick={() => setActive(t.key)} style={{
                      border: 0, cursor: 'pointer',
                      padding: '8px 10px', borderRadius: 8,
                      background: isActive ? 'var(--brand-soft-bg)' : 'transparent',
                      color: isActive ? 'var(--brand)' : 'var(--fg-default)',
                      textAlign: 'left',
                      font: `${isActive ? 600 : 500} 13px/1.3 var(--font-sans)`,
                    }}>
                      {t.name}
                      <div style={{ font: '500 11px/1.2 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 3 }}>{t.sub}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </aside>

        <main style={{ padding: '32px', background: 'var(--surface-subtle)' }}>
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <div style={{
              width: device === 'mobile' ? 380 : 720,
              background: 'white', borderRadius: 8, overflow: 'hidden',
              boxShadow: 'var(--shadow-soft)',
              border: '1px solid var(--border-default)',
            }}>
              {/* Email meta strip */}
              <div style={{ padding: '14px 20px', borderBottom: '1px solid #E5E7EB', background: '#F9FAFB' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ font: '600 13px/1 sans-serif', color: '#111827' }}>AIcreators</span>
                  <span style={{ font: '500 12px/1 sans-serif', color: '#6B7280' }}>noreply@aicreators.cloud</span>
                </div>
                <div style={{ font: '500 12px/1.4 sans-serif', color: '#6B7280' }}>to mihir@aicreators.cloud</div>
              </div>
              {/* Body */}
              {device === 'plain'
                ? <PlainTextEmail template={active}/>
                : <HTMLEmail template={active}/>}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

/* ============================================================
   HTML EMAILS — table-based, email-client safe markup
   ============================================================ */
function HTMLEmail({ template }) {
  return (
    <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ background: '#F4F4F7', fontFamily: 'Helvetica, Arial, sans-serif' }}>
      <tbody>
        <tr><td style={{ padding: '32px 24px 16px' }}>
          {/* Brand bar */}
          <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ marginBottom: 24 }}>
            <tbody><tr>
              <td>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                  <span style={{
                    width: 28, height: 28, borderRadius: 8, background: '#064E3B',
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                    border: '1px solid rgba(6,78,59,0.3)',
                  }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                      <defs>
                        <linearGradient id="emG" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
                          <stop offset="0%" stopColor="#A7F3D0"/>
                          <stop offset="100%" stopColor="#DEE7FF"/>
                        </linearGradient>
                      </defs>
                      <path d="M12 2 C 12.6 8 14.6 10 22 12 C 14.6 14 12.6 16 12 22 C 11.4 16 9.4 14 2 12 C 9.4 10 11.4 8 12 2 Z" fill="url(#emG)"/>
                    </svg>
                  </span>
                  <span style={{ font: '700 16px/1 Helvetica, Arial, sans-serif', color: '#111827', letterSpacing: '-0.02em' }}>AIcreators</span>
                </span>
              </td>
            </tr></tbody>
          </table>

          {/* Card */}
          <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ background: 'white', borderRadius: 12, border: '1px solid #E5E7EB' }}>
            <tbody>
              {EMAIL_BODIES[template] ? EMAIL_BODIES[template]() : <DefaultEmail template={template}/>}
            </tbody>
          </table>

          {/* Footer */}
          <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ marginTop: 24, textAlign: 'center' }}>
            <tbody>
              <tr><td style={{ padding: '16px 0', font: '500 12px/1.5 Helvetica, Arial, sans-serif', color: '#6B7280' }}>
                AIcreators, Inc. · 548 Market St #62189 · San Francisco, CA 94104<br/>
                <a href="https://aicreators.cloud" style={{ color: '#6B7280', textDecoration: 'underline' }}>aicreators.cloud</a>
                {' · '}
                <a href="https://aicreators.cloud/unsubscribe" style={{ color: '#6B7280', textDecoration: 'underline' }}>Unsubscribe</a>
                {' · '}
                <a href="https://aicreators.cloud/legal/privacy" style={{ color: '#6B7280', textDecoration: 'underline' }}>Privacy</a>
              </td></tr>
            </tbody>
          </table>
        </td></tr>
      </tbody>
    </table>
  );
}

/* All shared email styles */
const E = {
  td:  { padding: '32px 32px 16px' },
  tdBody: { padding: '0 32px 32px' },
  h1:  { font: '700 24px/1.3 Helvetica, Arial, sans-serif', color: '#111827', margin: '0 0 12px', letterSpacing: '-0.01em' },
  h2:  { font: '700 18px/1.3 Helvetica, Arial, sans-serif', color: '#111827', margin: '24px 0 10px' },
  p:   { font: '400 15px/1.65 Helvetica, Arial, sans-serif', color: '#374151', margin: '0 0 14px' },
  btn: { display: 'inline-block', padding: '12px 22px', borderRadius: 8, background: '#064E3B', color: 'white', textDecoration: 'none', font: '600 14px/1 Helvetica, Arial, sans-serif' },
  btnSecondary: { display: 'inline-block', padding: '10px 18px', borderRadius: 8, background: 'white', color: '#111827', border: '1px solid #E5E7EB', textDecoration: 'none', font: '600 13px/1 Helvetica, Arial, sans-serif' },
  divider: { borderTop: '1px solid #E5E7EB', margin: '24px 0' },
  callout: { background: '#ECFDF5', border: '1px solid #A7F3D0', borderRadius: 10, padding: 14, font: '500 13px/1.5 Helvetica, Arial, sans-serif', color: '#065F46', margin: '0 0 16px' },
  calloutWarn: { background: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 10, padding: 14, font: '500 13px/1.5 Helvetica, Arial, sans-serif', color: '#92400E', margin: '0 0 16px' },
  calloutDanger: { background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 10, padding: 14, font: '500 13px/1.5 Helvetica, Arial, sans-serif', color: '#991B1B', margin: '0 0 16px' },
  small: { font: '400 13px/1.5 Helvetica, Arial, sans-serif', color: '#6B7280' },
  mono: { font: '600 13px/1 ui-monospace, SFMono-Regular, Menlo, monospace', color: '#111827', background: '#F3F4F6', padding: '3px 6px', borderRadius: 4, border: '1px solid #E5E7EB' },
};

const EMAIL_BODIES = {
  welcome: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Welcome to AIcreators, Mihir 👋</p>
      <p style={E.p}>Your studio is live. In the next 30 minutes you can connect a YouTube channel, define its identity, and ship your first video on autopilot.</p>
      <p style={E.p}><a href="https://app.aicreators.cloud/onboarding" style={E.btn}>Set up my studio →</a></p>
    </td></tr>
    <tr><td style={{ ...E.tdBody, paddingTop: 8 }}>
      <p style={{ ...E.p, marginBottom: 18 }}><strong>3 things most creators do first:</strong></p>
      <table cellPadding={0} cellSpacing={0} border={0} width="100%">
        <tbody>
          {[
            ['1. Connect a YouTube channel', 'OAuth · we never see your password'],
            ['2. Clone your voice in 60 seconds', 'Or pick a studio voice'],
            ['3. Pick a topic and let autopilot run', 'Drop in any time to review'],
          ].map(([t, s]) => (
            <tr key={t}><td style={{ paddingBottom: 10 }}>
              <span style={{ font: '600 14px/1.2 Helvetica, Arial, sans-serif', color: '#111827' }}>{t}</span><br/>
              <span style={E.small}>{s}</span>
            </td></tr>
          ))}
        </tbody>
      </table>
      <div style={E.divider}/>
      <p style={E.small}>Stuck? Reply to this email and a human will help within a few hours.</p>
    </td></tr>
  </>),

  verify_email: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>One last step — verify your email</p>
      <p style={E.p}>Click the link below to confirm your email address. The link expires in 24 hours.</p>
      <p style={E.p}><a href="https://app.aicreators.cloud/auth/verify?token=…" style={E.btn}>Verify email →</a></p>
    </td></tr>
    <tr><td style={E.tdBody}>
      <p style={E.small}>If the button doesn't work, copy this link into your browser:</p>
      <p style={{ ...E.small, wordBreak: 'break-all' }}><a href="#" style={{ color: '#064E3B' }}>https://app.aicreators.cloud/auth/verify?token=8a4Bk2QzKx9R3jKxM2Pwn9</a></p>
      <div style={E.divider}/>
      <p style={E.small}>Didn't sign up? You can safely ignore this — your address won't be added to anything.</p>
    </td></tr>
  </>),

  magic_link: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Your sign-in link</p>
      <p style={E.p}>Click below to sign in. The link expires in 10 minutes and can only be used once.</p>
      <p style={E.p}><a href="#" style={E.btn}>Sign in →</a></p>
      <div style={E.calloutWarn}>
        ⚠ If you didn't ask to sign in, someone may be trying to access your account. <a href="#" style={{ color: '#92400E', textDecoration: 'underline' }}>Lock my account</a>.
      </div>
    </td></tr>
  </>),

  reset_password: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Reset your password</p>
      <p style={E.p}>Click the button below to choose a new password. This link expires in 30 minutes.</p>
      <p style={E.p}><a href="#" style={E.btn}>Choose a new password →</a></p>
      <p style={E.small}>If you didn't request a reset, you can safely ignore this email. Your password won't change.</p>
    </td></tr>
  </>),

  '2fa_enabled': () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Two-factor authentication is now active</p>
      <p style={E.p}>From now on we'll ask for a 6-digit code on every sign-in from a new device.</p>
      <div style={E.callout}>
        ✓ Method: <strong>Authenticator app</strong> (1Password)<br/>
        ✓ Backup codes: <strong>10 saved</strong>
      </div>
      <p style={E.p}><strong>Important:</strong> save your backup codes somewhere safe. If you lose your phone and your codes, account recovery takes 5-7 business days.</p>
      <p style={E.p}><a href="#" style={E.btnSecondary}>View backup codes →</a></p>
    </td></tr>
  </>),

  new_device: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>New sign-in to your AIcreators account</p>
      <p style={E.p}>We noticed a sign-in we haven't seen before. If this was you, you can ignore this email.</p>
      <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ background: '#F9FAFB', borderRadius: 10, border: '1px solid #E5E7EB', margin: '0 0 16px' }}>
        <tbody>
          <tr><td style={{ padding: 14 }}>
            <span style={{ font: '500 13px/1.6 Helvetica, Arial, sans-serif', color: '#374151' }}>
              <strong>Linux · Firefox 128</strong><br/>
              Frankfurt, Germany · 88.99.45.221<br/>
              Today at 14:32 UTC
            </span>
          </td></tr>
        </tbody>
      </table>
      <div style={E.calloutDanger}>
        Wasn't you? <a href="#" style={{ color: '#991B1B', textDecoration: 'underline' }}>Sign out of all sessions and change your password →</a>
      </div>
    </td></tr>
  </>),

  review_needed: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>The Lost Library is ready to review</p>
      <p style={E.p}>Your Mythic Tales video has paused at the <strong>Keyframes</strong> stage because confidence dropped below 80. Approve, re-roll, or override the prompt to continue.</p>
      <p style={E.p}><a href="#" style={E.btn}>Open project →</a></p>
    </td></tr>
    <tr><td style={E.tdBody}>
      <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ background: '#F9FAFB', borderRadius: 10, padding: 0 }}>
        <tbody><tr><td style={{ padding: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ width: 56, height: 36, borderRadius: 4, background: 'linear-gradient(135deg,#2A1810,#7B4F2C)', display: 'inline-block' }}/>
            <div>
              <span style={{ font: '600 14px/1.2 Helvetica, Arial, sans-serif', color: '#111827' }}>The Lost Library of Alexandria</span><br/>
              <span style={E.small}>Mythic Tales · 11:42 long-form · keyframe stage</span>
            </div>
          </div>
        </td></tr></tbody>
      </table>
      <p style={E.small}>Autopilot will hold this video until you act. To stop receiving these for low-confidence stages, adjust your <a href="#" style={{ color: '#064E3B' }}>autopilot rules</a>.</p>
    </td></tr>
  </>),

  video_published: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Your video is live 🎉</p>
      <p style={E.p}><strong>The Lost Library of Alexandria</strong> has been published to YouTube and is cross-posted to 4 other platforms.</p>
      <p style={E.p}><a href="#" style={E.btn}>Watch on YouTube →</a> &nbsp; <a href="#" style={E.btnSecondary}>Open analytics</a></p>
    </td></tr>
    <tr><td style={E.tdBody}>
      <p style={E.h2}>Where it's live</p>
      <table cellPadding={0} cellSpacing={0} border={0} width="100%">
        <tbody>
          {[
            ['YouTube — long-form (16:9)', '#FF0000'],
            ['YouTube — Shorts cut',       '#FF0000'],
            ['Instagram — Reel',           '#E1306C'],
            ['TikTok',                     '#000000'],
            ['X — thread',                 '#0F1419'],
          ].map(([n, c]) => (
            <tr key={n}><td style={{ padding: '6px 0' }}>
              <span style={{ display: 'inline-block', width: 16, height: 16, borderRadius: 3, background: c, marginRight: 8, verticalAlign: 'middle' }}/>
              <span style={{ font: '500 14px/1.4 Helvetica, Arial, sans-serif', color: '#374151', verticalAlign: 'middle' }}>{n}</span>
            </td></tr>
          ))}
        </tbody>
      </table>
    </td></tr>
  </>),

  oauth_disconnected: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>YouTube disconnected — action needed</p>
      <p style={E.p}>Your <strong>@aztecdaily</strong> YouTube connection has stopped working — likely because the OAuth token expired or you revoked our access.</p>
      <div style={E.calloutDanger}>
        ⚠ Until you reconnect, this channel can't publish. <strong>2 videos</strong> are queued and waiting.
      </div>
      <p style={E.p}><a href="#" style={E.btn}>Reconnect YouTube →</a></p>
    </td></tr>
  </>),

  weekly_digest: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Your studio · last week</p>
      <p style={E.p}>6 videos shipped · 384K total views · +1,240 subscribers · $284 estimated revenue. Here's the picture.</p>
    </td></tr>
    <tr><td style={E.tdBody}>
      <table cellPadding={0} cellSpacing={0} border={0} width="100%">
        <tbody><tr>
          {[
            { l: 'Views', v: '384K', d: '+22%' },
            { l: 'Subs',  v: '+1.2K', d: '+18%' },
            { l: 'AVD',   v: '6:48',  d: '+0:28' },
            { l: 'Revenue', v: '$284', d: '$1.84 RPM' },
          ].map(s => (
            <td key={s.l} style={{ width: '25%', padding: 10, textAlign: 'center', background: '#F9FAFB', border: '1px solid #E5E7EB', borderRadius: 8 }}>
              <span style={E.small}>{s.l}</span><br/>
              <span style={{ font: '700 22px/1 Helvetica, Arial, sans-serif', color: '#111827', letterSpacing: '-0.02em' }}>{s.v}</span><br/>
              <span style={{ font: '600 11px/1 Helvetica, Arial, sans-serif', color: '#10B981' }}>{s.d}</span>
            </td>
          ))}
        </tr></tbody>
      </table>
      <p style={E.h2}>Top performer</p>
      <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ background: '#F9FAFB', borderRadius: 10, padding: 0, border: '1px solid #E5E7EB' }}>
        <tbody><tr><td style={{ padding: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ width: 72, height: 44, borderRadius: 4, background: 'linear-gradient(135deg,#3A86FF,#8338EC)', display: 'inline-block' }}/>
            <div>
              <span style={{ font: '600 14px/1.2 Helvetica, Arial, sans-serif', color: '#111827' }}>Why your phone hates the cold</span><br/>
              <span style={E.small}>Snackable Science · 142K views · 14.8% CTR</span>
            </div>
          </div>
        </td></tr></tbody>
      </table>
      <p style={E.p} style={{ ...E.p, marginTop: 18 }}><a href="#" style={E.btnSecondary}>Open full analytics →</a></p>
    </td></tr>
  </>),

  low_credits: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>You're running low on credits</p>
      <p style={E.p}>You have <strong>240 of 5,000</strong> credits left and your plan resets in 8 days. At your current pace you'll run out in about 2 days.</p>
      <div style={E.calloutWarn}>
        At 0 credits, autopilot pauses. Already-rendered videos still publish on schedule.
      </div>
      <p style={E.p}><a href="#" style={E.btn}>Top up credits →</a> &nbsp; <a href="#" style={E.btnSecondary}>Upgrade plan</a></p>
    </td></tr>
  </>),

  plan_renewal: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Heads-up: Studio Pro renews in 7 days</p>
      <p style={E.p}>We'll charge <strong>$89.00</strong> to Visa •••• 4242 on May 24, 2025. No action needed if everything looks right.</p>
      <p style={E.p}>
        <a href="#" style={E.btnSecondary}>Manage subscription</a> &nbsp; <a href="#" style={E.btnSecondary}>Update card</a>
      </p>
    </td></tr>
  </>),

  invoice: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Receipt · May 2025</p>
      <p style={E.p}>Thanks for being on AIcreators. Here's your receipt — also attached as PDF.</p>
      <table cellPadding={0} cellSpacing={0} border={0} width="100%" style={{ background: '#F9FAFB', borderRadius: 10, border: '1px solid #E5E7EB', margin: '0 0 18px' }}>
        <tbody>
          {[['Plan','Studio Pro'],['Period','May 1 – May 31, 2025'],['Card','Visa •••• 4242'],['Subtotal','$89.00'],['Tax','$0.00'],['Total','$89.00']].map(([k, v]) => (
            <tr key={k}><td style={{ padding: '10px 14px', font: '500 14px/1.4 Helvetica, Arial, sans-serif', color: k === 'Total' ? '#111827' : '#6B7280', borderBottom: '1px solid #E5E7EB', fontWeight: k === 'Total' ? 700 : 500 }}>{k}</td><td style={{ padding: '10px 14px', font: '600 14px/1 Helvetica, Arial, sans-serif', color: '#111827', textAlign: 'right', borderBottom: '1px solid #E5E7EB' }}>{v}</td></tr>
          ))}
        </tbody>
      </table>
      <p style={E.p}><a href="#" style={E.btnSecondary}>Download PDF →</a></p>
    </td></tr>
  </>),

  data_export_ready: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Your data export is ready</p>
      <p style={E.p}>The archive includes your profile, every channel, every project (with script, storyboard, prompts, keyframes), all generated videos, your voice clones, your avatar mesh, billing receipts, and your audit log.</p>
      <p style={E.p}><a href="#" style={E.btn}>Download archive (842 MB) →</a></p>
      <div style={E.calloutWarn}>
        The link expires in 7 days. After that, you can request a new export.
      </div>
    </td></tr>
  </>),

  deletion_confirm: () => (<>
    <tr><td style={E.td}>
      <p style={E.h1}>Confirm account deletion</p>
      <p style={E.p}>You requested to delete your AIcreators account. Click below to confirm. Once you confirm, we'll start a 30-day grace period during which you can sign back in to cancel.</p>
      <p style={E.p}><a href="#" style={{ ...E.btn, background: '#B91C1C' }}>Confirm deletion →</a></p>
      <div style={E.calloutDanger}>
        Voice clones and avatars are deleted <strong>immediately</strong>, before the 30-day window. After day 30, everything else is permanently gone.
      </div>
      <p style={E.small}>Didn't request this? <a href="#" style={{ color: '#064E3B' }}>Cancel the request</a> — your account stays as-is.</p>
    </td></tr>
  </>),
};

function DefaultEmail({ template }) {
  return (
    <tr><td style={E.td}>
      <p style={E.h1}>{template}</p>
      <p style={E.p}>Placeholder body — see <a href="#" style={{ color: '#064E3B' }}>backend/transactional/{template}.html</a>.</p>
    </td></tr>
  );
}

/* PLAIN TEXT (for accessibility / spam-score) */
function PlainTextEmail({ template }) {
  const text = PLAIN_BODIES[template] || `=== ${template} ===\nThis is the plain-text fallback for clients without HTML support.`;
  return (
    <pre style={{ padding: 24, font: '500 13px/1.7 ui-monospace, monospace', color: '#111827', whiteSpace: 'pre-wrap', margin: 0 }}>{text}</pre>
  );
}

const PLAIN_BODIES = {
  welcome: `Welcome to AIcreators, Mihir.

Your studio is live. Connect a YouTube channel and ship your first video on autopilot:
https://app.aicreators.cloud/onboarding

3 things to do first:
  1. Connect a YouTube channel (OAuth, no password)
  2. Clone your voice in 60 seconds (or pick a studio voice)
  3. Pick a topic and let autopilot run

Stuck? Reply to this email; a human will help.

— AIcreators
https://aicreators.cloud · Unsubscribe`,

  magic_link: `Your AIcreators sign-in link:
https://app.aicreators.cloud/auth/magic?token=8a4Bk2QzKx9R3jKxM2Pwn9

The link expires in 10 minutes and can only be used once.

If you didn't ask to sign in, lock your account:
https://app.aicreators.cloud/auth/lock`,

  review_needed: `The Lost Library of Alexandria is ready to review.

Your Mythic Tales video paused at the Keyframes stage (confidence dropped below 80).

Open: https://app.aicreators.cloud/project/p1/images

— AIcreators · Mythic Tales`,
};

ReactDOM.createRoot(document.getElementById('root')).render(<EmailsApp/>);
