/* ============================================================
   AIcreators V2 — Brand showcase + redesigned web hero
   ============================================================
   Single document presenting the new design system, hero
   screens for the webapp, and FlutterFlow handoff notes.
   ============================================================ */

const V2_STAGES = [
  { id: 'idea',       label: 'Idea',       icon: 'Spark' },
  { id: 'script',     label: 'Script',     icon: 'Edit' },
  { id: 'storyboard', label: 'Storyboard', icon: 'Layers' },
  { id: 'frames',     label: 'Keyframes',  icon: 'Image' },
  { id: 'motion',     label: 'Motion',     icon: 'Film' },
  { id: 'voice',      label: 'Voice',      icon: 'Mic' },
  { id: 'edit',       label: 'Edit',       icon: 'Bolt' },
  { id: 'publish',    label: 'Publish',    icon: 'Youtube' },
];

const I = V2I;

function V2App() {
  return (
    <div style={{ minHeight: '100vh' }}>
      <V2Nav/>
      <V2Hero/>
      <V2BrandSystem/>
      <V2ProductionLineSection/>
      <V2ColorAndType/>
      <V2Components/>
      <V2KeyScreens/>
      <V2FlutterFlowSpec/>
      <V2Footer/>
      <V2ThemeToggle/>
    </div>
  );
}

/* ---------- NAV ---------- */
function V2Nav() {
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 50,
      padding: '16px 32px', display: 'flex', alignItems: 'center', gap: 16,
      background: 'rgba(5,5,7,0.75)', backdropFilter: 'blur(20px)',
      borderBottom: '1px solid var(--border-hairline)',
    }}>
      <Logo markSize={30} wordSize={18}/>
      <span className="chip">v2 · brand</span>
      <div style={{ flex: 1 }}/>
      <nav style={{ display: 'flex', gap: 4 }}>
        {[
          ['#brand', 'Brand'],
          ['#color', 'Color & Type'],
          ['#components', 'Components'],
          ['#screens', 'Screens'],
          ['AIcreators V2 Mobile.html', 'Mobile'],
          ['AIcreators V2 Admin.html', 'Admin'],
        ].map(([href, l]) => (
          <a key={l} href={href} style={{
            padding: '8px 12px', borderRadius: 8,
            font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)',
            textDecoration: 'none',
          }}>{l}</a>
        ))}
      </nav>
      <a href="AIcreators Cloud.html" className="btn btn--secondary btn--sm" style={{ textDecoration: 'none' }}>v1 archive</a>
      <a href="#" className="btn btn--accent btn--sm" style={{ textDecoration: 'none' }}>Open studio</a>
    </header>
  );
}

/* ---------- HERO ---------- */
function V2Hero() {
  return (
    <section style={{ position: 'relative', padding: '96px 32px 64px', overflow: 'hidden' }} className="scanlines">
      {/* lime glow */}
      <div style={{
        position: 'absolute', top: '20%', right: '5%',
        width: 600, height: 600, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(204,255,0,0.18) 0%, transparent 60%)',
        filter: 'blur(80px)', pointerEvents: 'none',
      }}/>
      <div style={{ position: 'relative', maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 64, alignItems: 'center' }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 12px', borderRadius: 999, background: 'rgba(204,255,0,0.08)', border: '1px solid var(--accent-border)', marginBottom: 28 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }} className="ai-pulse"/>
            <span style={{ font: '600 11px/1 var(--font-mono)', letterSpacing: '0.06em', color: 'var(--accent)', textTransform: 'uppercase' }}>Brand v2 · live</span>
          </div>
          <h1 className="t-mega" style={{ marginBottom: 24 }}>
            Lights.<br/>
            Camera.<br/>
            <span style={{ color: 'var(--accent)' }}>Autopilot.</span>
          </h1>
          <p className="t-body" style={{ color: 'var(--fg-secondary)', fontSize: 18, maxWidth: 540, marginBottom: 32 }}>
            AIcreators is the AI film studio for solo creators. Script, voice, animate, publish — on a schedule you set. <span className="t-mono fg-accent">$0.20</span> per second of finished video. Nothing else.
          </p>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn btn--accent btn--lg">
              <V2I.Spark size={18}/>
              Start free · 2× your first recharge
            </button>
            <button className="btn btn--secondary btn--lg">
              <V2I.Play size={18}/>
              90-second tour
            </button>
          </div>
          <div style={{ display: 'flex', gap: 24, marginTop: 40, flexWrap: 'wrap' }}>
            {[['12,400+', 'creators'], ['184M', 'views shipped'], ['10', 'destinations']].map(([v, l]) => (
              <div key={l}>
                <div style={{ font: '700 28px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.025em' }}>{v}</div>
                <div className="t-tiny" style={{ marginTop: 6 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: floating logo + production line card */}
        <div style={{ position: 'relative' }}>
          <LogoBig size={240}/>
          <div style={{ position: 'absolute', right: -20, bottom: -40 }}>
            <V2MiniProductionCard/>
          </div>
        </div>
      </div>
    </section>
  );
}

function V2MiniProductionCard() {
  return (
    <div className="card card--elev" style={{ width: 360, padding: 18, background: 'var(--ink-850)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        <div style={{ width: 56, height: 36, borderRadius: 6, background: 'linear-gradient(135deg,#1F2030,#3E4259)', flexShrink: 0 }}/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>How volcanoes make lightning</div>
          <div className="t-small">snackable science · 0:58</div>
        </div>
        <span className="chip chip--accent">live</span>
      </div>
      {/* mini timeline */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
        {V2_STAGES.map((s, i) => {
          const done = i < 6;
          const running = i === 6;
          return (
            <React.Fragment key={s.id}>
              <div className={running ? 'ai-pulse' : ''} style={{
                width: 28, height: 28, borderRadius: 8,
                background: done ? 'var(--accent-tint)' : running ? 'var(--accent)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${done ? 'var(--accent-border)' : running ? 'var(--accent)' : 'var(--border-hairline)'}`,
                color: done ? 'var(--accent)' : running ? 'var(--ink-950)' : 'var(--fg-faint)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {done ? <V2I.Check size={12}/> : React.createElement(V2I[s.icon], { size: 12 })}
              </div>
              {i < V2_STAGES.length - 1 && (
                <div style={{ flex: 1, height: 2, background: done ? 'var(--accent)' : 'rgba(255,255,255,0.06)', opacity: done ? 0.4 : 1 }}/>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- BRAND SYSTEM ---------- */
function V2BrandSystem() {
  return (
    <section id="brand" style={{ padding: '80px 32px', borderTop: '1px solid var(--border-hairline)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <span className="chip">01 · Brand</span>
        <h2 className="t-h1" style={{ marginTop: 16, marginBottom: 12 }}>The mark</h2>
        <p className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 720, marginBottom: 48 }}>
          A film aperture fused with a play triangle. Six iris blades — five lime, one amber — represent autopilot stages and the human-review moment. The center is a play button: the moment of release.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 32 }}>
          <div className="card" style={{ padding: 48, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-canvas)' }}>
            <LogoMark size={240}/>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
            {[
              { size: 80, l: 'XL · marketing' },
              { size: 56, l: 'L · app icon' },
              { size: 40, l: 'M · header' },
              { size: 24, l: 'S · favicon' },
            ].map((b, i) => (
              <div key={i} className="card" style={{ aspectRatio: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
                <LogoMark size={b.size}/>
                <span className="t-tiny">{b.l}</span>
              </div>
            ))}
          </div>
        </div>

        <h3 className="t-h3" style={{ marginTop: 48, marginBottom: 18 }}>Lockups</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          <div className="card" style={{ padding: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 14 }}>
            <Logo markSize={36} wordSize={22}/>
            <span className="t-tiny">Horizontal · default</span>
          </div>
          <div className="card" style={{ padding: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 14 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <LogoMark size={48}/>
              <Wordmark size={18}/>
            </div>
            <span className="t-tiny">Stacked · app icon</span>
          </div>
          <div className="card" style={{ padding: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 14 }}>
            <Wordmark size={28}/>
            <span className="t-tiny">Wordmark only</span>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- COLOR AND TYPE ---------- */
function V2ColorAndType() {
  return (
    <section id="color" style={{ padding: '80px 32px', borderTop: '1px solid var(--border-hairline)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <span className="chip">02 · Color & Type</span>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, marginTop: 28 }}>
          {/* Colors */}
          <div>
            <h2 className="t-h2" style={{ marginBottom: 18 }}>Palette</h2>
            <p className="t-small" style={{ marginBottom: 24, maxWidth: 480 }}>
              Inky black canvas. Electric lime as the AI / autopilot signal. Warm amber for the review state. Magenta as the spark.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
              <ColorSwatch name="Lime · primary"  hex="#CCFF00" desc="Autopilot · accent · live"/>
              <ColorSwatch name="Amber · review"  hex="#FF9F1C" desc="Paused · attention · warning"/>
              <ColorSwatch name="Magenta · spark" hex="#FF2D92" desc="Sparkle · AI moments"/>
              <ColorSwatch name="Ink 950 · canvas" hex="#050507" desc="Hero · marketing"/>
              <ColorSwatch name="Ink 900 · app"   hex="#0A0A0E" desc="Default surface"/>
              <ColorSwatch name="Ink 850 · card"  hex="#11121A" desc="Cards · panels"/>
              <ColorSwatch name="Ink 300 · muted" hex="#8D92A8" desc="Secondary text"/>
              <ColorSwatch name="White · strong"  hex="#FFFFFF" desc="Headlines"/>
            </div>
          </div>

          {/* Typography */}
          <div>
            <h2 className="t-h2" style={{ marginBottom: 18 }}>Typography</h2>
            <p className="t-small" style={{ marginBottom: 24, maxWidth: 480 }}>
              <strong className="fg-strong">Geist</strong> for everything visible. <strong className="fg-strong">Geist Mono</strong> for numbers, code, and micro-labels. Tight tracking on display sizes.
            </p>

            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <TypeRow l="Display · 64" v="Lights. Camera." cls="t-display"/>
              <TypeRow l="H1 · 44"      v="Headline goes here" cls="t-h1"/>
              <TypeRow l="H2 · 32"      v="Section heading" cls="t-h2"/>
              <TypeRow l="H3 · 24"      v="Subsection title" cls="t-h3"/>
              <TypeRow l="H4 · 18"      v="Card heading" cls="t-h4"/>
              <TypeRow l="Body · 15"    v="Body copy. Read me." cls="t-body"/>
              <TypeRow l="Small · 13"   v="Secondary metadata" cls="t-small"/>
              <TypeRow l="Tiny · 11"    v="LABEL · CHIP · TAG" cls="t-tiny"/>
              <TypeRow l="Mono · 13"    v="aic_live_8a4Bk2QzKx" cls="t-small t-mono"/>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ColorSwatch({ name, hex, desc }) {
  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
      <div style={{ height: 64, background: hex }}/>
      <div style={{ padding: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{name}</span>
          <span className="t-mono" style={{ font: '500 11px/1 var(--font-mono)', color: 'var(--fg-muted)' }}>{hex}</span>
        </div>
        <div className="t-small" style={{ marginTop: 6, fontSize: 11 }}>{desc}</div>
      </div>
    </div>
  );
}

function TypeRow({ l, v, cls }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '100px 1fr', padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', gap: 16, alignItems: 'baseline' }}>
      <span className="t-tiny">{l}</span>
      <span className={cls} style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v}</span>
    </div>
  );
}

/* ---------- PRODUCTION LINE SECTION ---------- */
function V2ProductionLineSection() {
  return (
    <section style={{ padding: '80px 32px', borderTop: '1px solid var(--border-hairline)', position: 'relative', overflow: 'hidden' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <span className="chip chip--accent">the centerpiece</span>
          <h2 className="t-display" style={{ marginTop: 18, marginBottom: 14, fontSize: 56 }}>
            The Production Line
          </h2>
          <p className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 560, margin: '0 auto', fontSize: 17 }}>
            Eight stages. Left to right. Drop in anywhere. Or let autopilot run it all.
          </p>
        </div>

        <V2BigPipeline/>
      </div>
    </section>
  );
}

function V2BigPipeline() {
  const states = ['done','done','done','done','running','queued','queued','queued'];
  return (
    <div className="card card--elev" style={{ padding: 28 }}>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${V2_STAGES.length}, 1fr)`, gap: 0 }}>
        {V2_STAGES.map((s, i) => {
          const Ico = V2I[s.icon];
          const state = states[i];
          const isDone = state === 'done';
          const isRunning = state === 'running';
          return (
            <div key={s.id} style={{ textAlign: 'center', padding: '0 8px', position: 'relative' }}>
              {i < V2_STAGES.length - 1 && (
                <div style={{ position: 'absolute', top: 28, left: '60%', right: '-40%', height: 2,
                  background: isDone ? 'var(--accent)' : 'var(--border-hairline)',
                  opacity: isDone ? 0.5 : 1, zIndex: 0 }}/>
              )}
              <div className={isRunning ? 'ai-pulse' : ''} style={{
                position: 'relative', zIndex: 1,
                width: 56, height: 56, borderRadius: 14,
                background: isDone ? 'var(--accent-tint)' : isRunning ? 'var(--accent)' : 'var(--ink-800)',
                border: `1px solid ${isDone ? 'var(--accent-border)' : isRunning ? 'var(--accent)' : 'var(--border-hairline)'}`,
                color: isDone ? 'var(--accent)' : isRunning ? 'var(--ink-950)' : 'var(--fg-muted)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                marginBottom: 14,
              }}>{isDone ? <V2I.Check size={22}/> : <Ico size={22}/>}</div>
              <div className="t-tiny" style={{ marginBottom: 4 }}>{String(i+1).padStart(2,'0')}</div>
              <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)', marginBottom: 6 }}>{s.label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- COMPONENTS ---------- */
function V2Components() {
  return (
    <section id="components" style={{ padding: '80px 32px', borderTop: '1px solid var(--border-hairline)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <span className="chip">03 · Components</span>
        <h2 className="t-h1" style={{ marginTop: 16, marginBottom: 32 }}>Building blocks</h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 18 }}>
          <ComponentCard title="Buttons">
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button className="btn btn--accent">Accent CTA</button>
              <button className="btn btn--primary">Primary</button>
              <button className="btn btn--secondary">Secondary</button>
              <button className="btn btn--ghost">Ghost</button>
              <button className="btn btn--danger">Danger</button>
            </div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 10 }}>
              <button className="btn btn--accent btn--lg"><V2I.Spark size={16}/> Lg accent</button>
              <button className="btn btn--secondary btn--sm">Sm</button>
              <button className="btn btn--ghost btn--icon"><V2I.Plus size={16}/></button>
            </div>
          </ComponentCard>

          <ComponentCard title="Chips & badges">
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              <span className="chip">default</span>
              <span className="chip chip--accent">autopilot</span>
              <span className="chip chip--warning">review</span>
              <span className="chip chip--danger">failed</span>
              <span className="chip"><V2I.Mic size={11}/> voice clone</span>
              <span className="chip chip--accent"><V2I.Check size={11}/> ready</span>
            </div>
          </ComponentCard>

          <ComponentCard title="Form inputs">
            <label>Channel name</label>
            <input defaultValue="Snackable Science"/>
            <label style={{ marginTop: 12 }}>Topic seed</label>
            <textarea defaultValue="Why volcanoes make their own lightning" rows={2}/>
          </ComponentCard>

          <ComponentCard title="Cards & elevation">
            <div className="card" style={{ background: 'var(--ink-800)' }}>
              <div className="t-tiny">Mini card</div>
              <div className="t-h4" style={{ marginTop: 6 }}>Default surface</div>
              <div className="t-small" style={{ marginTop: 6 }}>Hairline border, no shadow.</div>
            </div>
            <div className="card card--accent" style={{ background: 'var(--ink-800)', marginTop: 10 }}>
              <div className="t-tiny" style={{ color: 'var(--accent)' }}>Accented card</div>
              <div className="t-h4" style={{ marginTop: 6 }}>Lime border + glow</div>
            </div>
          </ComponentCard>
        </div>
      </div>
    </section>
  );
}

function ComponentCard({ title, children }) {
  return (
    <div className="card">
      <div className="t-tiny" style={{ marginBottom: 16 }}>{title}</div>
      {children}
    </div>
  );
}

/* ---------- KEY SCREENS ---------- */
function V2KeyScreens() {
  return (
    <section id="screens" style={{ padding: '80px 32px', borderTop: '1px solid var(--border-hairline)' }}>
      <div style={{ maxWidth: 1480, margin: '0 auto' }}>
        <span className="chip">04 · Web screens</span>
        <h2 className="t-h1" style={{ marginTop: 16, marginBottom: 12 }}>The redesigned studio</h2>
        <p className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 720, marginBottom: 40 }}>
          Same product, new skin. Dark by default. Lime is the autopilot. Numbers are mono. Everything earns its weight.
        </p>

        <V2DashboardMock/>
      </div>
    </section>
  );
}

function V2DashboardMock() {
  return (
    <div className="card card--elev" style={{ padding: 0, overflow: 'hidden', background: 'var(--bg-app)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '264px 1fr', minHeight: 700 }}>
        {/* sidebar */}
        <aside style={{ background: 'var(--bg-surface)', borderRight: '1px solid var(--border-hairline)', padding: '18px 14px', display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ padding: '4px 8px 16px' }}>
            <Logo markSize={28} wordSize={16}/>
          </div>
          {[
            { l: 'Studio',    icon: 'Studio', active: true },
            { l: 'Topics',    icon: 'Spark' },
            { l: 'Library',   icon: 'Folder' },
            { l: 'Channels',  icon: 'Youtube' },
            { l: 'Analytics', icon: 'BarChart' },
          ].map(n => {
            const Ico = V2I[n.icon];
            return (
              <div key={n.l} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 12px', borderRadius: 10,
                background: n.active ? 'var(--accent-tint)' : 'transparent',
                color: n.active ? 'var(--accent)' : 'var(--fg-default)',
                font: `${n.active ? 600 : 500} 14px/1 var(--font-sans)`,
              }}>
                <Ico size={16}/>
                <span style={{ flex: 1 }}>{n.l}</span>
                {n.active && <span style={{ width: 4, height: 4, borderRadius: '50%', background: 'var(--accent)' }}/>}
              </div>
            );
          })}
          <div style={{ flex: 1 }}/>
          <div className="card" style={{ background: 'var(--accent-tint)', borderColor: 'var(--accent-border)', padding: 12 }}>
            <div className="t-mono" style={{ font: '600 11px/1 var(--font-mono)', color: 'var(--accent)', letterSpacing: '0.06em' }}>BALANCE</div>
            <div style={{ font: '700 24px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 8, letterSpacing: '-0.02em' }}>$148.24</div>
            <div className="t-small" style={{ marginTop: 4, fontSize: 11 }}>~ 12 min 21 sec</div>
          </div>
        </aside>

        {/* main */}
        <div style={{ padding: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
            <div>
              <div className="t-h2">Studio</div>
              <div className="t-small">3 in production · 1 ready to review · publishing today at 6:00 PM</div>
            </div>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--secondary btn--sm">
              <V2I.Search size={14}/>
              <span style={{ marginLeft: 4, color: 'var(--fg-muted)' }}>Search · ⌘K</span>
            </button>
            <button className="btn btn--accent">
              <V2I.Plus size={16}/> New video
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 20 }}>
            {[
              { l: 'In production', v: '3', n: 'lime' },
              { l: 'Awaiting review', v: '1', n: 'amber' },
              { l: 'Published 30d',  v: '24', n: 'plain' },
              { l: 'Spent 30d',       v: '$429.60', n: 'plain' },
            ].map((s, i) => (
              <div key={i} className="card" style={{ padding: 16, background: s.n === 'lime' ? 'var(--accent-tint)' : s.n === 'amber' ? 'var(--warning-tint)' : 'var(--bg-surface)', borderColor: s.n === 'lime' ? 'var(--accent-border)' : s.n === 'amber' ? 'var(--warning-border)' : 'var(--border-hairline)' }}>
                <div className="t-tiny" style={{ color: s.n === 'lime' ? 'var(--accent)' : s.n === 'amber' ? 'var(--warning)' : 'var(--fg-faint)' }}>{s.l}</div>
                <div style={{ font: '700 28px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 10, letterSpacing: '-0.02em' }}>{s.v}</div>
              </div>
            ))}
          </div>

          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center' }}>
              <div className="t-h4">Production line</div>
              <div style={{ flex: 1 }}/>
              <span className="chip chip--accent"><V2I.Robot size={11}/> autopilot</span>
            </div>
            {[
              { title: 'How volcanoes make lightning',     ch: 'Snackable Science', dur: '0:58',  cost: '$11.60', stage: 6, format: 'short' },
              { title: 'The lost library of Alexandria',    ch: 'Mythic Tales',      dur: '11:42', cost: '$140.40', stage: 7, format: 'long', state: 'review' },
              { title: 'Why pufferfish are deadly',         ch: 'Snackable Science', dur: '1:24',  cost: '$16.80', stage: 4, format: 'short' },
              { title: 'The detective who forgot his name', ch: 'Noir Reels',        dur: '2:14',  cost: '$26.80', stage: 2, format: 'short' },
            ].map((p, idx) => (
              <V2ProjectRow key={idx} p={p}/>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function V2ProjectRow({ p }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr 90px 90px 110px', gap: 16, alignItems: 'center', padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
        <div style={{ width: 64, height: 40, borderRadius: 6, background: 'linear-gradient(135deg,#1F2030,#3E4259)', flexShrink: 0 }}/>
        <div style={{ minWidth: 0 }}>
          <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.title}</div>
          <div className="t-small" style={{ marginTop: 4 }}>{p.ch}</div>
        </div>
      </div>
      {/* pipeline strip */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 3, padding: '0 12px' }}>
        {V2_STAGES.map((s, i) => {
          const done = i < p.stage;
          const running = i === p.stage && p.state !== 'review';
          const review = i === p.stage && p.state === 'review';
          return (
            <React.Fragment key={s.id}>
              <div className={running ? 'ai-pulse' : ''} style={{
                width: 24, height: 24, borderRadius: 6,
                background: done ? 'var(--accent-tint)' : running ? 'var(--accent)' : review ? 'var(--warning-tint)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${done ? 'var(--accent-border)' : running ? 'var(--accent)' : review ? 'var(--warning-border)' : 'var(--border-hairline)'}`,
                color: done ? 'var(--accent)' : running ? 'var(--ink-950)' : review ? 'var(--warning)' : 'var(--fg-faint)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              }}>{done ? <V2I.Check size={11}/> : React.createElement(V2I[s.icon], { size: 11 })}</div>
              {i < V2_STAGES.length - 1 && (
                <div style={{ flex: 1, height: 2, background: done ? 'var(--accent)' : 'rgba(255,255,255,0.06)', opacity: done ? 0.4 : 1 }}/>
              )}
            </React.Fragment>
          );
        })}
      </div>
      <span className="chip">{p.format}</span>
      <span className="t-mono t-small">{p.dur}</span>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 6 }}>
        <span className="t-mono" style={{ font: '600 12px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{p.cost}</span>
        {p.state === 'review' && <span className="chip chip--warning">review</span>}
      </div>
    </div>
  );
}

/* ---------- FLUTTERFLOW SPEC ---------- */
function V2FlutterFlowSpec() {
  return (
    <section style={{ padding: '80px 32px', borderTop: '1px solid var(--border-hairline)', background: 'var(--bg-surface)' }}>
      <div style={{ maxWidth: 960, margin: '0 auto' }}>
        <span className="chip">05 · FlutterFlow</span>
        <h2 className="t-h1" style={{ marginTop: 16, marginBottom: 12 }}>For your dev team</h2>
        <p className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 36 }}>
          Token-for-token mapping from this design system to a Flutter <code className="t-mono" style={{ background: 'var(--ink-800)', padding: '2px 6px', borderRadius: 4 }}>ThemeData</code>. Drop straight into FlutterFlow.
        </p>

        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <pre style={{ margin: 0, padding: 24, font: '500 12px/1.7 var(--font-mono)', color: 'var(--fg-default)', background: 'var(--ink-950)', overflow: 'auto' }}>{`// pubspec.yaml — fonts
fonts:
  - family: Geist
    fonts:
      - asset: fonts/Geist-Regular.ttf
      - asset: fonts/Geist-Medium.ttf
        weight: 500
      - asset: fonts/Geist-SemiBold.ttf
        weight: 600
      - asset: fonts/Geist-Bold.ttf
        weight: 700
  - family: GeistMono
    fonts: [...]

// lib/theme.dart — ColorScheme
class AICColors {
  static const ink950   = Color(0xFF050507);
  static const ink900   = Color(0xFF0A0A0E);
  static const ink850   = Color(0xFF11121A);
  static const ink800   = Color(0xFF181924);
  static const ink300   = Color(0xFF8D92A8);
  static const ink100   = Color(0xFFDCDFEB);

  static const lime500  = Color(0xFFCCFF00);   // primary
  static const amber500 = Color(0xFFFF9F1C);   // review state
  static const magenta500 = Color(0xFFFF2D92);

  static const danger   = Color(0xFFFF4747);
}

// ThemeData
final aicTheme = ThemeData(
  brightness: Brightness.dark,
  scaffoldBackgroundColor: AICColors.ink900,
  colorScheme: const ColorScheme.dark(
    primary: AICColors.lime500,
    onPrimary: AICColors.ink950,
    secondary: AICColors.amber500,
    surface: AICColors.ink850,
    onSurface: AICColors.ink100,
  ),
  textTheme: TextTheme(
    displayLarge: TextStyle(
      fontFamily: 'Geist', fontWeight: FontWeight.w700,
      fontSize: 64, height: 1.0, letterSpacing: -2.2,
      color: Colors.white,
    ),
    headlineLarge: TextStyle(
      fontFamily: 'Geist', fontWeight: FontWeight.w700,
      fontSize: 44, height: 1.05, letterSpacing: -1.1,
      color: Colors.white,
    ),
    titleLarge: TextStyle(fontFamily: 'Geist', fontWeight: FontWeight.w600, fontSize: 18),
    bodyMedium: TextStyle(fontFamily: 'Geist', fontWeight: FontWeight.w500, fontSize: 15, height: 1.55),
    labelSmall:  TextStyle(fontFamily: 'GeistMono', fontWeight: FontWeight.w600, fontSize: 11, letterSpacing: 0.44),
  ),

  // Buttons
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: AICColors.lime500,
      foregroundColor: AICColors.ink950,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      minimumSize: const Size(0, 44),
      textStyle: const TextStyle(fontFamily: 'Geist', fontWeight: FontWeight.w700, fontSize: 14),
    ),
  ),
);`}</pre>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14, marginTop: 24 }}>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 10 }}>FlutterFlow project setup</div>
            <ol style={{ margin: 0, paddingLeft: 18, font: '500 14px/1.7 var(--font-sans)', color: 'var(--fg-default)' }}>
              <li>Create project · pick "Custom theme" not Material 3 defaults</li>
              <li>Upload Geist + Geist Mono fonts (Settings → Theme → Fonts)</li>
              <li>Paste the ColorScheme above into Theme → Colors</li>
              <li>Add Cupertino bindings for iOS feel</li>
              <li>Wire the Razorpay package: <code className="t-mono">razorpay_flutter</code></li>
            </ol>
          </div>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 10 }}>Component → Flutter widget</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                ['.card', 'Container + BoxDecoration radius 20'],
                ['.btn--accent', 'ElevatedButton w/ primaryStyle'],
                ['.chip', 'Chip widget · borderRadius 999'],
                ['.t-mono', 'Text style "GeistMono"'],
                ['pipeline dot', 'Stack + AnimatedContainer w/ pulse'],
                ['production-line row', 'ListView item · 96 h'],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
                  <code className="t-mono" style={{ font: '600 12px/1.4 var(--font-mono)', color: 'var(--accent)' }}>{k}</code>
                  <span className="t-small" style={{ textAlign: 'right' }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- FOOTER ---------- */
function V2Footer() {
  return (
    <footer style={{ padding: '60px 32px 40px', borderTop: '1px solid var(--border-hairline)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', alignItems: 'flex-start', gap: 40 }}>
        <div>
          <Logo markSize={32} wordSize={20}/>
          <div className="t-small" style={{ marginTop: 14, maxWidth: 300 }}>The AI film studio for solo creators.</div>
        </div>
        <div style={{ flex: 1 }}/>
        <div style={{ display: 'flex', gap: 40 }}>
          <FooterCol title="Design v2" links={[['#brand','Brand'],['#color','Color & Type'],['#components','Components'],['#screens','Screens']]}/>
          <FooterCol title="Apps" links={[['AIcreators Cloud.html','v1 archive · webapp'],['AIcreators V2 Mobile.html','Mobile · iOS + Android'],['AIcreators V2 Admin.html','Admin v2'],['AIcreators Cloud Status.html','Status']]}/>
          <FooterCol title="Handoff" links={[['#','FlutterFlow guide'],['#','Figma tokens'],['#','HANDOFF.md']]}/>
        </div>
      </div>
      <div style={{ maxWidth: 1280, margin: '32px auto 0', display: 'flex', gap: 16, paddingTop: 24, borderTop: '1px solid var(--border-hairline)' }}>
        <span className="t-tiny">© 2026 AICREATORS, INC.</span>
        <div style={{ flex: 1 }}/>
        <span className="t-mono t-small">aicreators.cloud</span>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }) {
  return (
    <div>
      <div className="t-tiny" style={{ marginBottom: 12 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {links.map(([href, l]) => (
          <a key={l} href={href} style={{ font: '500 13px/1.4 var(--font-sans)', color: 'var(--fg-default)', textDecoration: 'none' }}>{l}</a>
        ))}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<V2App/>);
