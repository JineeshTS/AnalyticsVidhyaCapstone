/* ============================================================
   AIcreators.cloud · Auth flow
   ============================================================
   Login · Sign-up · Forgot password · Reset password · Verify email

   ROUTING (via hash in the auth HTML)
     #login        (default)
     #signup
     #forgot
     #reset?token=
     #verify?token=
     #magic-sent

   BACKEND CONTRACT
     POST /auth/email/start            {email}        → 200, sends magic link
     POST /auth/email/verify           {token}        → 200 + session cookie
     POST /auth/password/signin        {email,pw}     → session cookie
     POST /auth/password/signup        {email,pw,name,country?,referrer?}
     POST /auth/password/forgot        {email}        → 200, sends reset link
     POST /auth/password/reset         {token,pw}     → 200 + session cookie
     POST /auth/oauth/google/start                    → redirect URL
     POST /auth/oauth/youtube/start                   → redirect URL  (skips email signup)
     GET  /auth/oauth/callback                         (server-side)
     POST /auth/logout

   SECURITY NOTES
     - Magic link tokens: short-lived (10 min), one-use, signed JWT
     - Reset token: 30 min, single-use
     - Email verify token: 24h, single-use
     - All form posts hit /api/v1; rate limit: 5/min per IP per endpoint
     - Lock account after 8 consecutive failed signins for 15 min
   ============================================================ */

const { useState: useAuthState } = React;

function AuthShell({ children }) {
  return (
    <div style={{
      flex: 1, position: 'relative', overflow: 'hidden',
      display: 'flex', alignItems: 'stretch', justifyContent: 'stretch',
      height: '100vh',
    }}>
      <SparkleField count={18} intensity={0.30}/>

      {/* Aurora wash */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(50% 50% at 80% 10%, var(--accent-tint-3) 0%, transparent 60%), radial-gradient(40% 30% at 10% 90%, var(--accent-tint-2) 0%, transparent 60%)',
        pointerEvents: 'none',
      }}/>

      {/* Header bar */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '22px 32px', display: 'flex', alignItems: 'center', zIndex: 3 }}>
        <a href="AIcreators Cloud.html" style={{ textDecoration: 'none' }}>
          <LogoLockup markSize={32} wordSize={17}/>
        </a>
        <div style={{ flex: 1 }}/>
      </div>

      {/* Two-column: form (left) + storytelling (right) */}
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 32 }}>
          <div style={{ width: '100%', maxWidth: 420 }}>{children}</div>
        </div>
        <AuthStory/>
      </div>
    </div>
  );
}

function AuthStory() {
  return (
    <div style={{
      background: 'var(--magic-tint)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: 48, position: 'relative', overflow: 'hidden',
      borderLeft: '1px solid var(--border-hairline)',
    }}>
      <SparkleField count={14} intensity={0.45}/>
      <div style={{ position: 'relative', width: '100%', maxWidth: 460, zIndex: 1 }}>
        {/* Floating production-line preview */}
        <div className="card card--lift" style={{ padding: 16, background: 'var(--bg-surface)', marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <span style={{ width: 36, height: 24, borderRadius: 4, background: 'linear-gradient(135deg, #2A1810, #7B4F2C)' }}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>The Lost Library of Alexandria</div>
              <div className="t-small">Mythic Tales · 11:42 · long-form</div>
            </div>
            <span className="chip chip--success" style={{ height: 22, fontSize: 11 }}>Live</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            {['Idea','Script','Storyboard','Keyframes','Motion','Voice','Edit','Publish'].map((s, i) => (
              <React.Fragment key={s}>
                <span style={{
                  width: 24, height: 24, borderRadius: 6,
                  background: i < 7 ? 'var(--success-bg)' : 'var(--magic-tint)',
                  border: `1px solid ${i < 7 ? 'var(--success-bd)' : 'var(--accent-border-soft)'}`,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  color: i < 7 ? 'var(--success)' : 'var(--accent-fg)',
                }}>
                  {i < 7 ? <I.Check size={11}/> : <I.Spark size={11}/>}
                </span>
                {i < 7 && <span style={{ flex: 1, height: 2, background: 'linear-gradient(90deg, var(--success), var(--accent))', opacity: 0.4 }}/>}
              </React.Fragment>
            ))}
          </div>
          <div className="divider" style={{ margin: '14px 0' }}/>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {[{c:'#FF0000'},{c:'#E1306C'},{c:'#000'},{c:'#0F1419'},{c:'#0A66C2'}].map((p, i) => (
              <span key={i} style={{ width: 20, height: 20, borderRadius: 6, background: p.c, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                {i === 0 && <I.Youtube size={10}/>}
                {i === 1 && <I.Image size={10}/>}
                {i === 2 && <I.Film size={10}/>}
                {i === 3 && <I.Send size={10}/>}
                {i === 4 && <I.Users size={10}/>}
              </span>
            ))}
            <span className="chip" style={{ height: 22, fontSize: 11 }}>5 destinations</span>
          </div>
        </div>

        <div className="t-h2" style={{ fontSize: 30, lineHeight: 1.2, marginBottom: 14, color: 'var(--fg-strong)' }}>
          One pipeline.<br/><span className="fg-grad">Every audience.</span>
        </div>
        <div className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 380 }}>
          Script, voice, animate, and publish to YouTube, Instagram, TikTok, X, and more — on autopilot. Or drop in to review any step.
        </div>
      </div>
    </div>
  );
}

function OAuthRow({ next }) {
  const buttons = [
    { id: 'google',  label: 'Continue with Google',   color: '#fff', fg: '#1F1F1F', icon: (<svg width="16" height="16" viewBox="0 0 24 24"><path fill="#EA4335" d="M12 5.04c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 1.7 14.97 0 12 0 7.7 0 3.99 2.48 2.18 6.09l3.66 2.84C6.71 6.31 9.14 5.04 12 5.04z"/><path fill="#34A853" d="M23.49 12.27c0-.79-.07-1.54-.2-2.27H12v4.51h6.47c-.28 1.4-1.05 2.6-2.24 3.43l3.57 2.77c2.08-1.92 3.69-4.74 3.69-8.44z"/><path fill="#4A90E2" d="M5.83 14.18a7.21 7.21 0 0 1 0-4.34L2.18 7C1.42 8.55 1 10.22 1 12s.42 3.45 1.18 5l3.65-2.82z"/><path fill="#FBBC05" d="M12 24c3.24 0 5.95-1.06 7.93-2.91l-3.57-2.77c-.99.66-2.24 1.05-4.36 1.05-2.86 0-5.29-1.27-6.16-3.89L2.18 18c1.81 3.61 5.52 6 9.82 6z"/></svg>) },
    { id: 'youtube', label: 'Continue with YouTube',  color: '#FF0000', fg: '#fff', icon: <I.Youtube size={16} stroke="white"/> },
    { id: 'apple',   label: 'Continue with Apple',    color: '#000', fg: '#fff', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M16.62 7.79c-1.59 0-2.6.69-3.46.69-.84 0-1.88-.66-3.31-.66-1.85 0-3.78.92-4.93 2.49-1.86 2.54-1.4 6.94.84 10.45.94 1.45 1.95 3.04 3.27 3 1.3-.05 1.79-.83 3.34-.83 1.55 0 1.98.83 3.33.81 1.39-.02 2.27-1.46 3.13-2.91.95-1.62 1.38-3.2 1.4-3.29-.03-.01-2.69-1.04-2.71-4.14-.02-2.59 2.12-3.83 2.22-3.89-1.21-1.78-3.09-1.98-3.74-2.02zM14.49 4.18C15.2 3.34 15.7 2.18 15.55 1c-1.04.04-2.3.7-3.04 1.55-.66.74-1.24 1.93-1.09 3.07 1.17.1 2.35-.61 3.07-1.44z"/></svg> },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {buttons.map(b => (
        <button key={b.id} style={{
          height: 48, padding: '0 16px', borderRadius: 12,
          border: '1px solid var(--border-default)',
          background: b.color, color: b.fg,
          display: 'flex', alignItems: 'center', gap: 10, justifyContent: 'center',
          font: '600 14px/1 var(--font-sans)', cursor: 'pointer',
          transition: 'transform 120ms var(--ease-out), border-color 120ms var(--ease-out)',
        }}
          onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--fg-strong)'}
          onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-default)'}>
          {b.icon}
          {b.label}
        </button>
      ))}
    </div>
  );
}

function LoginScreen({ go }) {
  return (
    <AuthShell>
      <div className="t-h1" style={{ fontSize: 32, marginBottom: 8 }}>Welcome back</div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>Pick up where your autopilot left off.</div>

      <OAuthRow/>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '20px 0' }}>
        <div style={{ flex: 1, height: 1, background: 'var(--border-hairline)' }}/>
        <span className="t-small">or with email</span>
        <div style={{ flex: 1, height: 1, background: 'var(--border-hairline)' }}/>
      </div>

      <label className="label">Email</label>
      <input defaultValue="mihir@aicreators.cloud" autoFocus/>

      <label className="label" style={{ marginTop: 14 }}>
        Password
        <a href="#forgot" onClick={(e)=>{e.preventDefault();go('forgot');}} style={{ float: 'right', font: '500 12px/1 var(--font-sans)', color: 'var(--brand)' }}>Forgot?</a>
      </label>
      <input type="password" defaultValue="••••••••••"/>

      <Btn kind="primary" size="lg" style={{ width: '100%', marginTop: 18 }} onClick={() => window.location.href = 'AIcreators Cloud.html'}>Sign in</Btn>

      <div style={{ marginTop: 18, textAlign: 'center' }} className="t-small">
        New here? <a href="#signup" onClick={(e)=>{e.preventDefault();go('signup');}} style={{ color: 'var(--brand)', fontWeight: 600 }}>Create an account</a>
      </div>
    </AuthShell>
  );
}

function SignupScreen({ go }) {
  return (
    <AuthShell>
      <div className="t-h1" style={{ fontSize: 32, marginBottom: 8 }}>Start your studio</div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>Free for 14 days. No credit card.</div>

      <OAuthRow/>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '20px 0' }}>
        <div style={{ flex: 1, height: 1, background: 'var(--border-hairline)' }}/>
        <span className="t-small">or with email</span>
        <div style={{ flex: 1, height: 1, background: 'var(--border-hairline)' }}/>
      </div>

      <label className="label">Full name</label>
      <input placeholder="Your name" autoFocus/>

      <label className="label" style={{ marginTop: 14 }}>Email</label>
      <input placeholder="you@studio.com"/>

      <label className="label" style={{ marginTop: 14 }}>Password</label>
      <input type="password" placeholder="At least 10 characters"/>
      <div style={{ display: 'flex', gap: 4, marginTop: 8 }}>
        {[1,1,1,0].map((on, i) => (
          <span key={i} style={{ flex: 1, height: 4, borderRadius: 999, background: on ? 'var(--success)' : 'var(--surface-elev)' }}/>
        ))}
      </div>
      <div className="t-small" style={{ marginTop: 6 }}>Strong password — nice.</div>

      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginTop: 18 }}>
        <input type="checkbox" defaultChecked style={{ width: 16, height: 16, accentColor: 'var(--brand)' }}/>
        <span className="t-small" style={{ color: 'var(--fg-default)' }}>
          I agree to the <a href="#" style={{ color: 'var(--brand)' }}>Terms</a> and <a href="#" style={{ color: 'var(--brand)' }}>Privacy Policy</a>.
        </span>
      </div>

      <Btn kind="magic" size="lg" icon={I.Spark} style={{ width: '100%', marginTop: 18 }} onClick={() => window.location.href = 'AIcreators Cloud.html'}>Create my studio</Btn>

      <div style={{ marginTop: 18, textAlign: 'center' }} className="t-small">
        Already have one? <a href="#login" onClick={(e)=>{e.preventDefault();go('login');}} style={{ color: 'var(--brand)', fontWeight: 600 }}>Sign in</a>
      </div>
    </AuthShell>
  );
}

function ForgotScreen({ go }) {
  return (
    <AuthShell>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <button className="btn btn--ghost btn--icon btn--sm" onClick={() => go('login')}><I.ChevLeft size={14}/></button>
        <span className="t-small">Back to sign in</span>
      </div>
      <div className="t-h1" style={{ fontSize: 32, marginBottom: 8 }}>Reset your password</div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>We'll email you a link. The link expires in 30 minutes.</div>

      <label className="label">Email</label>
      <input placeholder="you@studio.com" autoFocus/>

      <Btn kind="primary" size="lg" style={{ width: '100%', marginTop: 18 }} onClick={() => go('magic-sent')}>Send reset link</Btn>

      <div style={{ marginTop: 18, padding: 14, borderRadius: 12, background: 'var(--info-bg)', border: '1px solid var(--info-bd)', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        <I.Help size={14} stroke="var(--info-fg)" style={{ marginTop: 2 }}/>
        <div className="t-small" style={{ color: 'var(--fg-default)' }}>
          Used OAuth to sign up? Use the same Google / Apple button on <a href="#login" style={{ color: 'var(--brand)' }} onClick={(e)=>{e.preventDefault();go('login');}}>sign-in</a> — there's no password to reset.
        </div>
      </div>
    </AuthShell>
  );
}

function ResetScreen({ go }) {
  return (
    <AuthShell>
      <div className="t-h1" style={{ fontSize: 32, marginBottom: 8 }}>Choose a new password</div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>For mihir@aicreators.cloud</div>

      <label className="label">New password</label>
      <input type="password" placeholder="At least 10 characters" autoFocus/>

      <label className="label" style={{ marginTop: 14 }}>Confirm new password</label>
      <input type="password" placeholder="Repeat"/>

      <Btn kind="primary" size="lg" style={{ width: '100%', marginTop: 18 }} onClick={() => go('login')}>Update password</Btn>
    </AuthShell>
  );
}

function MagicSentScreen({ go }) {
  return (
    <AuthShell>
      <div style={{ textAlign: 'center', padding: '20px 0' }}>
        <span style={{
          width: 72, height: 72, borderRadius: 20,
          background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--accent-fg)', marginBottom: 18,
          boxShadow: 'var(--shadow-glow)',
        }}><I.Mail size={32}/></span>
        <div className="t-h2" style={{ fontSize: 28, marginBottom: 10 }}>Check your inbox</div>
        <div className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 360, margin: '0 auto' }}>
          We sent a magic link to <strong style={{ color: 'var(--fg-strong)' }}>mihir@aicreators.cloud</strong>. Click it to continue.
        </div>
        </div>
      )}

      {step === 1 && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <button className="btn btn--ghost btn--icon btn--sm" onClick={() => setStep(0)}><I.ChevLeft size={14}/></button>
            <span className="t-small">Back</span>
          </div>
          <div className="t-h1" style={{ fontSize: 28, marginBottom: 8 }}>Scan with your authenticator</div>
          <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>
            Open 1Password, Google Authenticator, or Authy. Scan this QR code, then enter the 6-digit code it gives you.
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 18 }}>
            <div style={{
              width: 192, height: 192, padding: 12, background: 'white', borderRadius: 14,
              border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-soft)',
            }}>
              {/* Fake QR: 12x12 grid */}
              <div style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 0 }}>
                {Array.from({ length: 144 }).map((_, i) => {
                  const r = Math.abs(Math.sin(i * 9.1));
                  const isCorner = (i % 12 < 3 && i / 12 < 3) || (i % 12 > 8 && i / 12 < 3) || (i % 12 < 3 && i / 12 > 8);
                  const on = isCorner ? (((i % 12) % 2 === 0) && ((Math.floor(i/12)) % 2 === 0)) : r > 0.5;
                  return <span key={i} style={{ background: on ? '#000' : 'white' }}/>;
                })}
              </div>
            </div>
          </div>

          <div style={{ marginBottom: 18, textAlign: 'center' }}>
            <span className="t-tiny">Or enter this key manually</span>
            <div className="t-mono" style={{ font: '600 14px/1 var(--font-mono)', color: 'var(--fg-strong)', marginTop: 6, padding: '8px 14px', background: 'var(--surface-subtle)', borderRadius: 8, display: 'inline-block', letterSpacing: '0.06em' }}>
              JBSW Y3DP EHPK 3PXP
            </div>
          </div>

          <Btn kind="primary" size="lg" iconRight={I.ChevRight} style={{ width: '100%' }} onClick={() => setStep(2)}>I've scanned it</Btn>
        </div>
      )}

      {step === 2 && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <button className="btn btn--ghost btn--icon btn--sm" onClick={() => setStep(1)}><I.ChevLeft size={14}/></button>
            <span className="t-small">Back</span>
          </div>
          <div className="t-h1" style={{ fontSize: 28, marginBottom: 8 }}>Enter the 6-digit code</div>
          <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>
            From your authenticator app. The code rotates every 30 seconds.
          </div>

          {/* 6-digit segmented input */}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginBottom: 18 }}>
            {Array.from({ length: 6 }).map((_, i) => (
              <input key={i} maxLength={1}
                     value={code[i] || ''}
                     onChange={e => setCode((code.slice(0, i) + e.target.value + code.slice(i + 1)).slice(0, 6))}
                     style={{
                       width: 52, height: 60, textAlign: 'center',
                       font: '700 24px/1 var(--font-display)', color: 'var(--fg-strong)',
                       letterSpacing: '0',
                     }}/>
            ))}
          </div>

          <div className="t-small" style={{ textAlign: 'center', marginBottom: 18 }}>
            Lost access to your authenticator? <a href="#" style={{ color: 'var(--brand)' }}>Use a backup code</a>
          </div>

          <Btn kind="primary" size="lg" style={{ width: '100%' }} onClick={() => setStep(3)} disabled={code.length < 6}>Verify & continue</Btn>
        </div>
      )}

      {step === 3 && (
        <div>
          <div className="t-h1" style={{ fontSize: 28, marginBottom: 8 }}>Save your backup codes</div>
          <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>
            If you lose your phone, you can sign in with one of these. <strong style={{ color: 'var(--fg-strong)' }}>Save them somewhere safe</strong> — each works once.
          </div>

          <div className="card" style={{ background: 'var(--surface-subtle)', marginBottom: 18 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
              {codes.map((c, i) => (
                <div key={i} className="t-mono" style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)', padding: '6px 10px', background: 'var(--bg-surface)', borderRadius: 6, border: '1px solid var(--border-hairline)' }}>
                  {String(i+1).padStart(2,'0')}. {c}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 14 }}>
              <Btn kind="secondary" size="sm" icon={I.Copy}>Copy all</Btn>
              <Btn kind="secondary" size="sm" icon={I.Download}>Download .txt</Btn>
              <Btn kind="ghost" size="sm" icon={I.Refresh}>Regenerate</Btn>
            </div>
          </div>

          <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 18 }}>
            <input type="checkbox" defaultChecked style={{ width: 16, height: 16, accentColor: 'var(--brand)', marginTop: 2 }}/>
            <span className="t-small" style={{ color: 'var(--fg-default)' }}>I've saved my backup codes somewhere safe.</span>
          </label>

          <Btn kind="primary" size="lg" style={{ width: '100%' }} onClick={() => setStep(4)}>Done</Btn>
        </div>
      )}

      {step === 4 && (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <span style={{
            width: 72, height: 72, borderRadius: 20,
            background: 'var(--success-bg)', border: '1px solid var(--success-bd)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            color: 'var(--success)', marginBottom: 18,
          }}><I.Check size={32}/></span>
          <div className="t-h2" style={{ fontSize: 28, marginBottom: 10 }}>Two-factor is on</div>
          <div className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 360, margin: '0 auto' }}>
            We'll ask for a code on every new device.
          </div>
          <Btn kind="magic" size="lg" icon={I.ArrowRight} style={{ marginTop: 24 }} onClick={() => window.location.href = 'AIcreators Cloud.html'}>Enter the studio</Btn>
        </div>
      )}
    </AuthShell>
  );
}

function FactorChoice({ icon: Ico, title, sub, recommended, onClick }) {
  return (
    <button onClick={onClick} style={{
      padding: 18, borderRadius: 14,
      border: '1px solid var(--border-default)',
      background: 'var(--bg-surface)',
      display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer', textAlign: 'left',
      transition: 'border-color 120ms var(--ease-out), background 120ms var(--ease-out)',
    }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--brand)'; e.currentTarget.style.background = 'var(--surface-hover)'; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-default)'; e.currentTarget.style.background = 'var(--bg-surface)'; }}>
      <span style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', color: 'var(--accent-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Ico size={22}/>
      </span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{title}</span>
          {recommended && <span className="chip chip--success" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>Recommended</span>}
        </div>
        <div className="t-small" style={{ marginTop: 4 }}>{sub}</div>
      </div>
      <I.ChevRight size={16} stroke="var(--fg-muted)"/>
    </button>
  );
}

function SSOScreen({ go }) {
  return (
    <AuthShell>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <button className="btn btn--ghost btn--icon btn--sm" onClick={() => go('login')}><I.ChevLeft size={14}/></button>
        <span className="t-small">Back to sign in</span>
      </div>
      <div className="t-h1" style={{ fontSize: 32, marginBottom: 8 }}>Sign in with SSO</div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 22 }}>Enter your work email and we'll redirect to your identity provider.</div>

      <label className="label">Work email</label>
      <input placeholder="you@company.com" autoFocus/>

      <Btn kind="primary" size="lg" iconRight={I.ChevRight} style={{ width: '100%', marginTop: 18 }}>Continue</Btn>

      <div style={{ marginTop: 24, padding: 16, borderRadius: 12, background: 'var(--surface-subtle)', border: '1px solid var(--border-hairline)' }}>
        <div className="t-tiny" style={{ marginBottom: 10 }}>Supported providers</div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['Okta','Google Workspace','Azure AD','OneLogin','JumpCloud','Auth0','Ping','Custom SAML','Custom OIDC'].map(p => (
            <span key={p} className="chip">{p}</span>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 18, textAlign: 'center' }}>
        <a href="#" onClick={(e)=>{e.preventDefault();go('login');}} className="t-small" style={{ color: 'var(--brand)' }}>Don't use SSO? Sign in with email instead</a>
      </div>
    </AuthShell>
  );
}

function AuthApp() {
  const [route, setRoute] = useAuthState(() => {
    const hash = (window.location.hash || '').replace(/^#/, '').split('?')[0];
    return hash || 'login';
  });
  const go = (name) => { setRoute(name); window.location.hash = name; };

  const Screen = {
    login:       LoginScreen,
    signup:      SignupScreen,
    forgot:      ForgotScreen,
    reset:       ResetScreen,
    'magic-sent': MagicSentScreen,
    verify:      VerifyScreen,
    '2fa-setup': TwoFASetupScreen,
  }[route] || LoginScreen;

  return <Screen go={go}/>;
}

ReactDOM.createRoot(document.getElementById('root')).render(<AuthApp/>);
