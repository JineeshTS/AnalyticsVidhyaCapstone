/* ============================================================
   AIcreators.cloud · Customer extras — full coverage
   ============================================================

   SCREENS in this file
     VideoDetailScreen     – drill into a single published video
     ChannelAnalyticsScreen – per-channel analytics deep-dive
     ABResultsScreen        – A/B thumbnail test results
     TicketThreadScreen     – single ticket conversation
     NotificationPrefsScreen – full prefs page with delivery channels
     ReferEarnScreen        – referral program
     SecurityScreen         – password, 2FA, passkeys, sessions
     UserAPIKeysScreen      – customer-facing API keys (settings tab)
     InvoicesScreen         – billing history / receipts

   BACKEND CONTRACTS
     GET    /videos/{id}                              – full video record
     POST   /videos/{id}/unlist                       – update YouTube visibility
     DELETE /videos/{id}                              – takedown
     GET    /videos/{id}/analytics?window=
     GET    /channels/{id}/analytics?window=
     GET    /videos/{id}/ab-tests                     – thumbnail variants + impressions
     POST   /videos/{id}/ab-tests/{vid}/promote       – set primary

     GET    /help/tickets/{id}
     POST   /help/tickets/{id}/reply                  – multipart {body, attachments[]}
     PATCH  /help/tickets/{id}                        – {status}

     GET    /me/notification-prefs
     PATCH  /me/notification-prefs                    – per-channel per-event

     GET    /me/referrals                              – stats + invites
     POST   /me/referrals/invite                       – {emails[]}

     POST   /me/2fa/totp/start                         – returns QR + secret
     POST   /me/2fa/totp/verify                        – {code}
     DELETE /me/2fa
     POST   /me/passkeys                               – WebAuthn register
     DELETE /me/passkeys/{id}
     GET    /me/sessions                               – browser sessions
     DELETE /me/sessions/{id}
     DELETE /me/sessions                               – sign out everywhere

     GET    /me/api-keys
     POST   /me/api-keys                               – {label, scopes[]}
     DELETE /me/api-keys/{id}

     GET    /me/invoices                               – Razorpay receipts
     GET    /me/invoices/{id}.pdf
   ============================================================ */

/* ============================================================
   1.  VIDEO DETAIL
   ============================================================ */
function VideoDetailScreen({ video, onBack }) {
  // Default to a representative mock video if none passed
  const v = video || MOCK.publishedRecent[0];
  const ch = MOCK.channels.find(c => c.id === v.channelId);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="t-small" style={{ cursor: 'pointer' }} onClick={onBack}>Library</span>
            <I.ChevRight size={12} stroke="var(--fg-faint)"/>
            <span className="t-small" style={{ color: 'var(--fg-default)' }}>Video</span>
          </div>
          <div style={{ flex: 1 }}/>
          <Btn kind="secondary" icon={I.Edit}>Edit on YouTube</Btn>
          <Btn kind="ghost" icon={I.Download}>Download mp4</Btn>
          <button className="btn btn--ghost btn--icon"><I.More size={16}/></button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>
          {/* Player + meta */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20, marginBottom: 20 }}>
            <div>
              <div style={{
                aspectRatio: '16/9', borderRadius: 14,
                background: v.thumb, position: 'relative', overflow: 'hidden',
                boxShadow: 'var(--shadow-soft)',
              }}>
                <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
                <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 80, height: 80, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(6px)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'white', border: '2px solid rgba(255,255,255,0.30)', cursor: 'pointer' }}><I.Play size={36}/></span>
              </div>
              <div style={{ marginTop: 18 }}>
                <div className="t-h2" style={{ fontSize: 26, marginBottom: 8 }}>{v.title}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14 }}>
                  <ChannelHeader ch={ch}/>
                  <span className="t-small">Published {v.published}</span>
                  <span style={{ color: 'var(--fg-faint)' }}>·</span>
                  <span className="t-small">11:42</span>
                </div>

                <div className="card" style={{ background: 'var(--surface-subtle)' }}>
                  <div className="t-tiny" style={{ marginBottom: 8 }}>Description</div>
                  <div style={{ font: '500 14px/1.6 var(--font-sans)', color: 'var(--fg-default)', textWrap: 'pretty' }}>
                    The largest library of the ancient world didn't die in one night. We walk you through what was inside it — and the four other times it burned.
                    {'\n\n'}Chapters:{'\n'}0:00 The night · 0:38 Building it · 3:00 The fire · 7:20 The myth
                  </div>
                </div>
              </div>
            </div>

            {/* Right rail: stats + actions */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="card">
                <div className="t-tiny" style={{ marginBottom: 14 }}>Performance · 7 days</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <Stat l="Views"     v={v.views}  d="+18%" up/>
                  <Stat l="CTR"       v={v.ctr}    d="+1.2pp" up/>
                  <Stat l="AVD"       v={v.avd}    d="+0:14"  up/>
                  <Stat l="Subscribers gained" v="+1,240" d="" />
                  <Stat l="Watch hours" v="3.8K" d="" />
                  <Stat l="Estimated revenue" v="$184" d="" />
                </div>
              </div>

              <div className="card">
                <div className="t-tiny" style={{ marginBottom: 10 }}>Distribution</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {[
                    { p: 'YouTube · Long-form',  st: 'live', col: '#FF0000', ic: 'Youtube', metric: '142K' },
                    { p: 'YouTube · Shorts cut', st: 'live', col: '#FF0000', ic: 'Youtube', metric: '384K' },
                    { p: 'Instagram · Reel',     st: 'live', col: '#E1306C', ic: 'Image',   metric: '88K' },
                    { p: 'TikTok',               st: 'live', col: '#000000', ic: 'Film',    metric: '210K' },
                  ].map((d, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ width: 22, height: 22, borderRadius: 5, background: d.col, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                        {React.createElement(I[d.ic], { size: 11 })}
                      </span>
                      <span style={{ flex: 1, font: '500 12px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{d.p}</span>
                      <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{d.metric}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card">
                <div className="t-tiny" style={{ marginBottom: 12 }}>Actions</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <Btn kind="secondary" size="sm" icon={I.Eye}>View on YouTube</Btn>
                  <Btn kind="secondary" size="sm" icon={I.Copy}>Clone & remix</Btn>
                  <Btn kind="secondary" size="sm" icon={I.Edit}>Edit metadata</Btn>
                  <Btn kind="ghost" size="sm" icon={I.Lock}>Unlist</Btn>
                  <Btn kind="danger" size="sm" icon={I.Trash}>Take down</Btn>
                </div>
              </div>
            </div>
          </div>

          {/* Charts row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, marginBottom: 20 }}>
            <ChartCard title="Views" delta="+18.2%" max={142}/>
            <ChartCard title="CTR" delta="+1.2pp" max={14}/>
          </div>

          {/* Audience + traffic + retention */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 20 }}>
            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 14 }}>Top audience</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[['US', 38], ['UK', 18], ['India', 12], ['Germany', 8], ['Brazil', 6]].map(([k, v]) => (
                  <div key={k}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span style={{ font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{k}</span>
                      <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}%</span>
                    </div>
                    <ProgressBar value={v} size="sm"/>
                  </div>
                ))}
              </div>
            </div>
            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 14 }}>Traffic source</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[['Suggested videos', 44], ['Browse features', 22], ['Search', 18], ['External', 12], ['Direct', 4]].map(([k, v]) => (
                  <div key={k}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span style={{ font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{k}</span>
                      <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}%</span>
                    </div>
                    <ProgressBar value={v} size="sm"/>
                  </div>
                ))}
              </div>
            </div>
            <div className="card">
              <div className="t-tiny" style={{ marginBottom: 14 }}>Retention curve</div>
              <svg width="100%" height="120" viewBox="0 0 200 120" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="retG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--brand)" stopOpacity="0.40"/>
                    <stop offset="100%" stopColor="var(--brand)" stopOpacity="0"/>
                  </linearGradient>
                </defs>
                {[0.25, 0.5, 0.75].map((y, i) => <line key={i} x1="0" x2="200" y1={120 * y} y2={120 * y} stroke="var(--border-hairline)" strokeWidth="1"/>)}
                <path d="M0,18 C30,22 60,42 90,52 C120,62 150,78 200,108 L200,120 L0,120 Z" fill="url(#retG)"/>
                <path d="M0,18 C30,22 60,42 90,52 C120,62 150,78 200,108" fill="none" stroke="var(--brand)" strokeWidth="2"/>
              </svg>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                <span className="t-tiny">0:00</span>
                <span className="t-tiny">5:51</span>
                <span className="t-tiny">11:42</span>
              </div>
              <div className="t-small" style={{ marginTop: 8 }}>Avg view duration <strong style={{ color: 'var(--fg-strong)' }}>7:28</strong> (64%)</div>
            </div>
          </div>

          {/* Top comments */}
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10 }}>
              <I.Message size={16} stroke="var(--fg-default)"/>
              <span className="t-h5">Top comments</span>
              <span className="chip">428 total</span>
              <div style={{ flex: 1 }}/>
              <Btn kind="ghost" size="sm">Open on YouTube</Btn>
            </div>
            {[
              { who: 'AncientGearheads',  ago: '2 days', body: 'The Pompeii cross-reference at 7:42 was *unreal*. Bingewatching the whole channel now.', likes: 2840 },
              { who: 'cornucopia_history', ago: '2 days', body: 'Hoping for a follow-up on Nineveh next 🙏', likes: 1284 },
              { who: 'lonzobrah',          ago: '3 days', body: 'How long does it take you to make these?', likes: 612 },
            ].map((c, i) => (
              <div key={i} style={{ padding: '12px 18px', borderBottom: i < 2 ? '1px solid var(--border-hairline)' : 0, display: 'flex', gap: 12 }}>
                <Avatar name={c.who} size={36}/>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>@{c.who}</span>
                    <span className="t-small">{c.ago}</span>
                  </div>
                  <div style={{ font: '500 14px/1.5 var(--font-sans)', color: 'var(--fg-default)', marginTop: 4, textWrap: 'pretty' }}>{c.body}</div>
                  <div style={{ display: 'flex', gap: 12, marginTop: 6 }}>
                    <span className="t-small"><I.ThumbUp size={11} style={{ verticalAlign: '-1px' }}/> {c.likes.toLocaleString()}</span>
                    <a href="#" className="t-small" style={{ color: 'var(--brand)' }}>Reply</a>
                    <a href="#" className="t-small" style={{ color: 'var(--brand)' }}>Heart</a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ l, v, d, up }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
      <span className="t-small" style={{ flex: 1 }}>{l}</span>
      <span style={{ font: '700 17px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em' }}>{v}</span>
      {d && <span style={{ font: '600 11px/1 var(--font-sans)', color: up ? 'var(--success)' : 'var(--danger)' }}>{d}</span>}
    </div>
  );
}

function ChartCard({ title, delta, max = 100 }) {
  const W = 460, H = 140;
  const data = Array.from({ length: 28 }, (_, i) => max * (0.4 + Math.sin(i * 0.5) * 0.15 + i * 0.018));
  const points = data.map((v, i) => `${(i / (data.length - 1)) * W},${H - (v / max) * (H - 20)}`);
  const path = `M${points.join(" L")}`;
  return (
    <div className="card">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
        <span className="t-h5">{title}</span>
        <span className="chip chip--success">{delta}</span>
      </div>
      <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        <defs>
          <linearGradient id={`g-${title}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--brand)" stopOpacity="0.40"/>
            <stop offset="100%" stopColor="var(--brand)" stopOpacity="0"/>
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((y, i) => <line key={i} x1="0" x2={W} y1={H * y} y2={H * y} stroke="var(--border-hairline)" strokeWidth="1"/>)}
        <path d={`${path} L${W},${H} L0,${H} Z`} fill={`url(#g-${title})`}/>
        <path d={path} fill="none" stroke="var(--brand)" strokeWidth="2"/>
      </svg>
    </div>
  );
}

/* ============================================================
   2.  CHANNEL ANALYTICS (deep-dive)
   ============================================================ */
function ChannelAnalyticsScreen({ channelId, onBack }) {
  const ch = MOCK.channels.find(c => c.id === channelId) || MOCK.channels[0];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ width: 40, height: 40, borderRadius: '50%', background: ch.color, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>{ch.emoji || ch.name[0]}</span>
            <div>
              <div className="t-h3">{ch.name}</div>
              <div className="t-small">{ch.subs} · {ch.handle}</div>
            </div>
          </div>
          <div style={{ flex: 1 }}/>
          <Tabs value="30d" onChange={()=>{}} items={[{id:'7d',label:'7d'},{id:'30d',label:'30d'},{id:'90d',label:'90d'},{id:'all',label:'All time'}]}/>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          <StatTile label="Views"            value="1.4M"     sub="+22% vs prior 30d" icon={I.Eye}     gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-tint-3), transparent)"/>
          <StatTile label="Subscribers"      value="127K"     sub="+8.4K new"          icon={I.User}    gradient="radial-gradient(50% 100% at 50% 0%, var(--success-bg), transparent)"/>
          <StatTile label="Watch hours"      value="84.2K"    sub="Best month ever"    icon={I.Clock}   gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-tint-2), transparent)"/>
          <StatTile label="Revenue"          value="$1,284"   sub="$0.92 RPM"          icon={I.Credit}  gradient="radial-gradient(50% 100% at 50% 0%, var(--success-bg), transparent)"/>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, marginBottom: 16 }}>
          <ChartCard title="Views" delta="+22%" max={1400}/>
          <ChartCard title="New subscribers" delta="+8.4K" max={84}/>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}><span className="t-h5">Top videos · 30 days</span></div>
            {MOCK.publishedRecent.slice(0, 4).map((v, i) => (
              <div key={v.id} style={{ display: 'grid', gridTemplateColumns: '32px 60px 1fr 80px', gap: 12, alignItems: 'center', padding: '12px 18px', borderBottom: i < 3 ? '1px solid var(--border-hairline)' : 0 }}>
                <span style={{ font: '700 16px/1 var(--font-display)', color: 'var(--fg-faint)' }}>{String(i+1).padStart(2,'0')}</span>
                <div style={{ width: 60, height: 36, borderRadius: 4, background: v.thumb }}/>
                <div style={{ minWidth: 0 }}>
                  <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.title}</div>
                  <div className="t-small">{v.published}</div>
                </div>
                <div style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)', textAlign: 'right' }}>{v.views}</div>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="t-h5" style={{ marginBottom: 12 }}>Posting cadence</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
              {Array.from({ length: 7 * 12 }).map((_, i) => {
                const intensity = Math.random();
                return <div key={i} style={{ aspectRatio: '1', borderRadius: 3, background: `rgba(6,78,59,${intensity * 0.7})`, opacity: intensity > 0.1 ? 1 : 0.15 }}/>;
              })}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10 }}>
              <span className="t-tiny">Less</span>
              <span className="t-tiny">More</span>
            </div>
            <div className="t-small" style={{ marginTop: 14 }}>12 weeks · Mon Tue Wed Thu Fri Sat Sun</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   3.  A/B TEST RESULTS
   ============================================================ */
function ABResultsScreen({ video, onBack }) {
  const variants = [
    { id: 'A', label: 'Hero close-up',     thumb: 'linear-gradient(135deg,#2A1810,#7B4F2C)', impressions: '24.2K', ctr: '12.8%', wins: 'Best for first 24h' },
    { id: 'B', label: 'Wide harbor + text',thumb: 'linear-gradient(135deg,#7B4F2C,#D4A574)', impressions: '24.4K', ctr: '11.4%' },
    { id: 'C', label: 'Fire — high contrast', thumb: 'linear-gradient(135deg,#D4A574,#F38181)', impressions: '24.0K', ctr: '14.2%', wins: 'Winner', promoted: true },
  ];
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <div style={{ flex: 1 }}>
            <div className="t-h3">A/B test results</div>
            <div className="t-small" style={{ marginTop: 4 }}>The Lost Library of Alexandria · 72-hour rotation · Mythic Tales</div>
          </div>
          <span className="chip chip--success"><I.Check size={11}/> Test complete</span>
        </div>

        <div className="card" style={{ marginBottom: 16, padding: 18, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <I.Sparkles size={22} stroke="var(--accent-fg)"/>
            <div style={{ flex: 1 }}>
              <div className="t-h5" style={{ marginBottom: 4 }}>Variant C is the winner with 14.2% CTR</div>
              <div className="t-small">+1.4pp over variant A (95% statistical confidence). We've already promoted it as the primary thumbnail.</div>
            </div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 18 }}>
          {variants.map(v => (
            <div key={v.id} className="card" style={{ padding: 0, overflow: 'hidden', border: v.promoted ? '1px solid var(--brand)' : '1px solid var(--border-hairline)', boxShadow: v.promoted ? '0 0 0 3px var(--brand-soft-bg)' : 'none' }}>
              <div style={{ aspectRatio: '16/9', background: v.thumb, position: 'relative' }}>
                <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.18), transparent 60%)' }}/>
                <span style={{ position: 'absolute', top: 10, left: 10, width: 28, height: 28, borderRadius: '50%', background: 'rgba(0,0,0,0.55)', color: 'white', font: '700 13px/1 var(--font-display)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{v.id}</span>
                {v.promoted && <span style={{ position: 'absolute', top: 10, right: 10 }} className="chip chip--success"><I.Check size={11}/> primary</span>}
                <div style={{ position: 'absolute', bottom: 8, left: 12, right: 12, font: '800 14px/1.2 var(--font-display)', color: 'white', textShadow: '0 2px 6px rgba(0,0,0,0.7)', textTransform: 'uppercase', letterSpacing: '-0.01em' }}>THE LOST LIBRARY</div>
              </div>
              <div style={{ padding: 16 }}>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)', marginBottom: 12 }}>{v.label}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <Stat l="Impressions" v={v.impressions}/>
                  <Stat l="CTR"         v={v.ctr}/>
                </div>
                {v.wins && <div style={{ marginTop: 10, padding: '6px 10px', borderRadius: 6, background: v.promoted ? 'var(--success-bg)' : 'var(--surface-subtle)', font: '500 12px/1.3 var(--font-sans)', color: v.promoted ? 'var(--success-fg)' : 'var(--fg-default)' }}>{v.wins}</div>}
                {!v.promoted && <Btn kind="ghost" size="sm" icon={I.Check} style={{ marginTop: 10, width: '100%' }}>Promote this one</Btn>}
              </div>
            </div>
          ))}
        </div>

        {/* CTR over time chart */}
        <div className="card">
          <div className="t-h5" style={{ marginBottom: 12 }}>CTR over the 72-hour test</div>
          <svg width="100%" height="180" viewBox="0 0 600 180" preserveAspectRatio="none">
            {[0.25, 0.5, 0.75].map((y, i) => <line key={i} x1="0" x2="600" y1={180 * y} y2={180 * y} stroke="var(--border-hairline)" strokeWidth="1"/>)}
            {[
              { c: '#A78BFA', d: 'M0,80 C60,82 120,72 180,68 C240,64 300,62 360,60 C420,58 480,56 540,55 L600,55' },
              { c: '#22D3EE', d: 'M0,85 C60,82 120,80 180,78 C240,76 300,75 360,76 C420,77 480,78 540,78 L600,78' },
              { c: 'var(--brand)', d: 'M0,76 C60,72 120,64 180,55 C240,46 300,40 360,36 C420,32 480,28 540,24 L600,22' },
            ].map((s, i) => <path key={i} d={s.d} fill="none" stroke={s.c} strokeWidth="2.5"/>)}
          </svg>
          <div style={{ display: 'flex', gap: 16, marginTop: 12, justifyContent: 'center' }}>
            {[['A', '#A78BFA'], ['B', '#22D3EE'], ['C (winner)', 'var(--brand)']].map(([l, c]) => (
              <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <span style={{ width: 12, height: 12, borderRadius: 2, background: c }}/>
                <span className="t-small">{l}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   4.  TICKET THREAD
   ============================================================ */
function TicketThreadScreen({ ticketId, onBack }) {
  const msgs = [
    { from: 'user',  body: "Hey — my Mythic Tales channel uploaded an Instagram Reel that's only 9 seconds when the source is 58 seconds. Something's clipping it. Project ID: p1.",        ts: 'Yesterday · 4:18 PM', who: 'Mihir Vaishnav' },
    { from: 'agent', body: "Hey Mihir, sorry about that. Looking at the job logs now — looks like the Reel reformatter trimmed early because we mis-detected the hook. Fixing this on our side and re-running the IG export. Should be up in ~6 minutes.", ts: 'Yesterday · 6:02 PM', who: 'Priya R · Support', avatarColor: 'var(--magic-grad)' },
    { from: 'system',body: 'Re-export queued · job j_8431-re', ts: 'Yesterday · 6:03 PM' },
    { from: 'agent', body: "It's up and looking great — full 58s. We've also flagged your hook-detection model so the team can tune it. You shouldn't need to do anything else.", ts: 'Yesterday · 6:14 PM', who: 'Priya R · Support', avatarColor: 'var(--magic-grad)' },
    { from: 'user',  body: 'Beautiful, thanks!', ts: 'Yesterday · 6:18 PM', who: 'Mihir Vaishnav' },
  ];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="t-small" style={{ cursor: 'pointer' }} onClick={onBack}>Help & Support</span>
            <I.ChevRight size={12} stroke="var(--fg-faint)"/>
            <span className="t-small" style={{ color: 'var(--fg-default)' }}>Ticket {ticketId || 't_2103'}</span>
          </div>
          <div style={{ flex: 1 }}/>
          <span className="chip chip--success"><I.Check size={10}/> Resolved</span>
          <Btn kind="ghost" size="sm" icon={I.Refresh}>Reopen</Btn>
        </div>
        <div className="t-h3">Instagram Reel is clipped — only 9s of 58s</div>
        <div className="t-small" style={{ marginTop: 6 }}>Opened yesterday · Priya R · Support · Linked: project p1</div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px' }}>
        <div style={{ maxWidth: 800, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {msgs.map((m, i) => {
            if (m.from === 'system') {
              return (
                <div key={i} style={{ textAlign: 'center', padding: '6px 0' }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 12px', borderRadius: 999, background: 'var(--surface-subtle)', border: '1px solid var(--border-hairline)' }}>
                    <I.Spark size={11} stroke="var(--accent-fg)"/>
                    <span className="t-small">{m.body}</span>
                    <span className="t-small" style={{ color: 'var(--fg-faint)' }}>· {m.ts}</span>
                  </span>
                </div>
              );
            }
            const isMe = m.from === 'user';
            return (
              <div key={i} style={{ display: 'flex', gap: 12, flexDirection: isMe ? 'row-reverse' : 'row', alignItems: 'flex-start' }}>
                <Avatar name={m.who} size={36} color={m.avatarColor || 'var(--brand)'}/>
                <div style={{ maxWidth: '70%' }}>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 4, flexDirection: isMe ? 'row-reverse' : 'row' }}>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.who}</span>
                    <span className="t-small">{m.ts}</span>
                  </div>
                  <div style={{
                    padding: '12px 14px',
                    borderRadius: isMe ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                    background: isMe ? 'var(--brand)' : 'var(--bg-surface)',
                    border: isMe ? 0 : '1px solid var(--border-hairline)',
                    color: isMe ? 'var(--fg-on-brand)' : 'var(--fg-default)',
                    font: '500 14px/1.5 var(--font-sans)',
                    textWrap: 'pretty',
                  }}>{m.body}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ padding: 16, borderTop: '1px solid var(--border-hairline)' }}>
        <div style={{ maxWidth: 800, margin: '0 auto', display: 'flex', gap: 8, alignItems: 'flex-end' }}>
          <button className="btn btn--ghost btn--icon"><I.Upload size={16}/></button>
          <textarea rows={2} placeholder="Reply…" style={{ flex: 1 }}/>
          <Btn kind="primary" icon={I.Send}>Send</Btn>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   5.  NOTIFICATION PREFS
   ============================================================ */
function NotificationPrefsScreen() {
  const rows = [
    { event: 'A video needs your review',          desc: 'A stage paused for human approval' },
    { event: 'A video was published',              desc: 'Confirmation when a video goes live' },
    { event: 'A job failed',                       desc: 'Pipeline failed and exhausted retries' },
    { event: 'Weekly performance digest',          desc: 'Every Sunday at 9 AM' },
    { event: 'Trending topic opportunities',       desc: 'When a topic spikes in your niche' },
    { event: 'Low credit warning',                 desc: 'When you hit 90% of your plan' },
    { event: 'Plan renewal reminder',              desc: '7 days before renewal' },
    { event: 'YouTube/Instagram OAuth disconnected', desc: 'A connected account needs re-auth' },
    { event: 'New comment on a video',             desc: 'Top-rated comments only' },
    { event: 'Team invite accepted',               desc: 'A teammate joined your workspace' },
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1080, margin: '0 auto' }}>
        <div className="t-h3" style={{ marginBottom: 4 }}>Notification preferences</div>
        <div className="t-small" style={{ marginBottom: 22 }}>Choose how and where each event reaches you.</div>

        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '14px 18px', display: 'grid', gridTemplateColumns: '1fr 80px 80px 80px 80px', gap: 12, alignItems: 'center', background: 'var(--surface-subtle)', borderBottom: '1px solid var(--border-hairline)' }}>
            <span className="t-tiny">Event</span>
            <span className="t-tiny" style={{ textAlign: 'center' }}>In-app</span>
            <span className="t-tiny" style={{ textAlign: 'center' }}>Email</span>
            <span className="t-tiny" style={{ textAlign: 'center' }}>Push</span>
            <span className="t-tiny" style={{ textAlign: 'center' }}>Slack</span>
          </div>
          {rows.map((r, i) => (
            <div key={i} style={{ padding: '14px 18px', display: 'grid', gridTemplateColumns: '1fr 80px 80px 80px 80px', gap: 12, alignItems: 'center', borderBottom: i < rows.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
              <div>
                <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{r.event}</div>
                <div className="t-small" style={{ marginTop: 4 }}>{r.desc}</div>
              </div>
              {[true, i % 2 === 0, i % 3 === 0, i === 0].map((on, j) => (
                <div key={j} style={{ display: 'flex', justifyContent: 'center' }}>
                  <Switch on={on} size="sm" onChange={()=>{}}/>
                </div>
              ))}
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 16 }}>
          <div className="card">
            <div className="t-h5" style={{ marginBottom: 14 }}>Quiet hours</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <Switch on={true} size="sm"/>
              <span className="t-body">Don't notify between</span>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input defaultValue="22:00" style={{ width: 100 }}/>
              <span style={{ alignSelf: 'center' }} className="t-small">and</span>
              <input defaultValue="08:00" style={{ width: 100 }}/>
            </div>
            <div className="t-small" style={{ marginTop: 8 }}>Timezone · America/New_York</div>
          </div>
          <div className="card">
            <div className="t-h5" style={{ marginBottom: 14 }}>Email digest frequency</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[['realtime','Real-time'], ['hourly','Hourly digest'], ['daily','Daily digest (8 AM)'], ['weekly','Weekly digest']].map(([id, l], i) => (
                <label key={id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 8, background: id === 'daily' ? 'var(--brand-soft-bg)' : 'transparent', cursor: 'pointer' }}>
                  <input type="radio" name="digest" defaultChecked={id === 'daily'} style={{ accentColor: 'var(--brand)' }}/>
                  <span className="t-body">{l}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   6.  REFER & EARN
   ============================================================ */
function ReferEarnScreen() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1280, margin: '0 auto' }}>
        <div className="card" style={{ padding: 28, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', position: 'relative', overflow: 'hidden', marginBottom: 16 }}>
          <SparkleField count={10} intensity={0.40}/>
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 22 }}>
            <span style={{ width: 72, height: 72, borderRadius: 20, background: 'var(--magic-grad)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'white', flexShrink: 0, boxShadow: 'var(--shadow-glow)' }}>
              <I.Sparkles size={32}/>
            </span>
            <div style={{ flex: 1 }}>
              <div className="t-h2" style={{ fontSize: 26, marginBottom: 6 }}>Bring a friend, both get a month free</div>
              <div className="t-small" style={{ maxWidth: 540 }}>You and your friend both get one free month of Studio Pro when they upgrade. There's no cap — refer as many people as you want.</div>
            </div>
          </div>
        </div>

        <div className="card" style={{ marginBottom: 16 }}>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Your referral link</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input value="https://aicreators.cloud/r/mihir-v" readOnly style={{ flex: 1, fontFamily: 'var(--font-mono)' }}/>
            <Btn kind="primary" icon={I.Copy}>Copy</Btn>
            <Btn kind="secondary" icon={I.Send}>Email it</Btn>
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
            <Btn kind="ghost" size="sm">Twitter</Btn>
            <Btn kind="ghost" size="sm">LinkedIn</Btn>
            <Btn kind="ghost" size="sm">WhatsApp</Btn>
            <Btn kind="ghost" size="sm">Discord</Btn>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          <StatTile label="Invited"            value="24"    sub="this year"   icon={I.Send}    gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-tint-2), transparent)"/>
          <StatTile label="Joined"             value="14"    sub="58% conversion" icon={I.User}    gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-tint-2), transparent)"/>
          <StatTile label="Months earned"      value="9"     sub="$801 saved"  icon={I.Sparkles} gradient="radial-gradient(50% 100% at 50% 0%, var(--success-bg), transparent)"/>
          <StatTile label="Rank"               value="#42"   sub="Top creator referrers" icon={I.TrendUp} gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-tint-3), transparent)"/>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
            <span className="t-h5">Recent referrals</span>
          </div>
          {[
            { name: 'Priya Shah', email: 'priya@studio.co', status: 'joined', plan: 'Studio Pro', when: '4 days ago' },
            { name: 'Daniel Cho', email: 'daniel@noir.tv', status: 'joined', plan: 'Studio Pro', when: '2 weeks ago' },
            { name: 'Sofia Costa', email: 'sofia@costa.br', status: 'joined', plan: 'Starter',  when: '3 weeks ago' },
            { name: 'Aarav Patel', email: 'aarav@studio.in', status: 'pending', plan: '—',        when: 'invited 1 day ago' },
            { name: 'Lila Becker', email: 'lila@bnights.de', status: 'expired', plan: '—',        when: 'invited 6 weeks ago' },
          ].map((r, i, arr) => (
            <div key={i} style={{ padding: '14px 18px', display: 'grid', gridTemplateColumns: '40px 1fr auto auto', gap: 14, alignItems: 'center', borderBottom: i < arr.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
              <Avatar name={r.name} size={36}/>
              <div>
                <div style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{r.name}</div>
                <div className="t-small" style={{ marginTop: 4 }}>{r.email} · {r.when}</div>
              </div>
              <span className="chip">{r.plan}</span>
              {r.status === 'joined'  && <span className="chip chip--success">Joined</span>}
              {r.status === 'pending' && <span className="chip chip--warning">Pending</span>}
              {r.status === 'expired' && <span className="chip">Expired</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   7.  SECURITY (2FA, passkeys, sessions)
   ============================================================ */
function SecurityScreen() {
  const sessions = [
    { id: 's_1', device: 'MacBook Pro · Chrome', loc: 'New York, US', ip: '76.84.…', current: true, lastActive: 'just now' },
    { id: 's_2', device: 'iPhone 15 · Safari',   loc: 'New York, US', ip: '24.181.…',                lastActive: '2 h ago' },
    { id: 's_3', device: 'iPad · Safari',         loc: 'New York, US', ip: '76.84.…',                lastActive: '3 days ago' },
    { id: 's_4', device: 'Linux · Firefox',       loc: 'Frankfurt, DE', ip: '88.99.…',  suspicious: true, lastActive: '8 days ago' },
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1080, margin: '0 auto' }}>
        <div className="t-h3" style={{ marginBottom: 4 }}>Security</div>
        <div className="t-small" style={{ marginBottom: 22 }}>Password, 2FA, passkeys, active sessions.</div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Password */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
              <I.Lock size={18} stroke="var(--fg-default)"/>
              <span className="t-h5">Password</span>
              <div style={{ flex: 1 }}/>
              <Btn kind="secondary" size="sm" icon={I.Edit}>Change</Btn>
            </div>
            <div className="t-small">Last changed 84 days ago. Strong (12 chars, mixed case, symbols).</div>
          </div>

          {/* 2FA */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
              <I.Spark size={18} stroke="var(--fg-default)"/>
              <span className="t-h5">Two-factor authentication</span>
              <span className="chip chip--success"><I.Check size={11}/> Enabled</span>
              <div style={{ flex: 1 }}/>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <SecRow icon={I.Sparkles} title="Authenticator app (TOTP)"   sub="1Password · added Mar 12" status="active" actionLabel="Reset"/>
              <SecRow icon={I.Mail}     title="SMS backup"                sub="+1 (***) ***-2841"     status="active" actionLabel="Disable"/>
              <SecRow icon={I.Key}      title="Backup codes"              sub="8 of 10 remaining"     actionLabel="View / regenerate"/>
            </div>
          </div>

          {/* Passkeys */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
              <I.Key size={18} stroke="var(--fg-default)"/>
              <span className="t-h5">Passkeys</span>
              <div style={{ flex: 1 }}/>
              <Btn kind="secondary" size="sm" icon={I.Plus}>Add passkey</Btn>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <SecRow icon={I.User} title="MacBook · Touch ID"  sub="Added Apr 18 · last used 2 h ago" status="active" actionLabel="Remove"/>
              <SecRow icon={I.User} title="iPhone · Face ID"    sub="Added Apr 22 · last used yesterday" status="active" actionLabel="Remove"/>
            </div>
          </div>

          {/* SSO (enterprise) */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
              <I.Users size={18} stroke="var(--fg-default)"/>
              <span className="t-h5">Single sign-on (SSO)</span>
              <span className="chip chip--info">Enterprise</span>
              <div style={{ flex: 1 }}/>
              <Btn kind="ghost" size="sm">Contact sales</Btn>
            </div>
            <div className="t-small">SAML 2.0 / OIDC available on the Studio plan with annual billing. Okta, Google Workspace, Azure AD supported.</div>
          </div>

          {/* Sessions */}
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center' }}>
              <I.Globe size={18} stroke="var(--fg-default)"/>
              <span className="t-h5" style={{ marginLeft: 8 }}>Active sessions</span>
              <div style={{ flex: 1 }}/>
              <Btn kind="danger" size="sm" icon={I.Logout}>Sign out everywhere</Btn>
            </div>
            {sessions.map((s, i) => (
              <div key={s.id} style={{ padding: '14px 18px', display: 'grid', gridTemplateColumns: '32px 1fr auto auto', gap: 14, alignItems: 'center', borderBottom: i < sessions.length - 1 ? '1px solid var(--border-hairline)' : 0, background: s.suspicious ? 'var(--warning-bg)' : 'transparent' }}>
                <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--fg-default)' }}>
                  <I.User size={14}/>
                </span>
                <div>
                  <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', display: 'flex', alignItems: 'center', gap: 8 }}>
                    {s.device}
                    {s.current && <span className="chip chip--success">this device</span>}
                    {s.suspicious && <span className="chip chip--warning">Unrecognized</span>}
                  </div>
                  <div className="t-small" style={{ marginTop: 4 }}>{s.loc} · {s.ip} · {s.lastActive}</div>
                </div>
                {!s.current && <Btn kind="ghost" size="sm">Sign out</Btn>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function SecRow({ icon: Ico, title, sub, status, actionLabel }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 10, background: 'var(--surface-subtle)' }}>
      <Ico size={16} stroke="var(--fg-default)"/>
      <div style={{ flex: 1 }}>
        <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{title}</div>
        <div className="t-small" style={{ marginTop: 4 }}>{sub}</div>
      </div>
      {status === 'active' && <span className="chip chip--success"><I.Check size={10}/> active</span>}
      {actionLabel && <Btn kind="ghost" size="sm">{actionLabel}</Btn>}
    </div>
  );
}

/* ============================================================
   8.  USER API KEYS
   ============================================================ */
function UserAPIKeysScreen() {
  const keys = [
    { id: 'k_001', label: 'Production',         prefix: 'aic_live_8a4Bk2…',  scopes: ['videos:write','channels:read','analytics:read'], lastUsed: '4 min ago' },
    { id: 'k_002', label: 'Webhook receiver',    prefix: 'aic_live_QzKx9R…',  scopes: ['webhooks:receive'], lastUsed: '1 h ago' },
    { id: 'k_003', label: 'Zapier integration',  prefix: 'aic_live_p3MnY7…',  scopes: ['videos:read','topics:write'], lastUsed: '12 h ago' },
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">API keys</div>
            <div className="t-small" style={{ marginTop: 4 }}>Build on top of AIcreators. Read the <a href="#" style={{ color: 'var(--brand)' }}>full API reference</a>.</div>
          </div>
          <Btn kind="ghost" icon={I.Code}>API docs</Btn>
          <Btn kind="primary" icon={I.Plus}>New key</Btn>
        </div>

        <div className="card" style={{ marginBottom: 16, padding: 16, background: 'var(--info-bg)', border: '1px solid var(--info-bd)', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
          <I.Help size={16} stroke="var(--info-fg)" style={{ marginTop: 2 }}/>
          <div className="t-small" style={{ color: 'var(--fg-default)', flex: 1 }}>
            We only show the full key once, at creation time. Store it somewhere safe — we can't recover it. To rotate, revoke and issue a new one.
          </div>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Label','Key','Scopes','Last used',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {keys.map(k => (
                <tr key={k.id} style={{ borderBottom: '1px solid var(--border-hairline)' }}>
                  <td style={{ padding: '12px 16px', font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{k.label}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span className="t-mono" style={{ font: '500 12px/1 var(--font-mono)', color: 'var(--fg-default)', padding: '4px 8px', background: 'var(--surface-hover)', borderRadius: 6, border: '1px solid var(--border-hairline)' }}>{k.prefix}</span>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', maxWidth: 280 }}>
                      {k.scopes.map(s => <span key={s} className="chip" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>{s}</span>)}
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{k.lastUsed}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button className="btn btn--ghost btn--icon btn--sm"><I.Copy size={12}/></button>
                    <button className="btn btn--ghost btn--icon btn--sm"><I.Trash size={12}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card" style={{ marginTop: 16 }}>
          <div className="t-h5" style={{ marginBottom: 10 }}>Webhook endpoints</div>
          <div className="t-small" style={{ marginBottom: 14 }}>POST our events to your URL. Payloads are signed (HMAC-SHA256).</div>
          {[
            { url: 'https://api.studio.co/aic-events', events: ['video.published','job.failed'], ok: true },
            { url: 'https://hook.zapier.com/hooks/...3jKx9', events: ['topic.queued'], ok: true },
          ].map((w, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderTop: i > 0 ? '1px solid var(--border-hairline)' : 0 }}>
              <HealthDot status={w.ok ? 'ok' : 'warn'}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="t-mono" style={{ font: '500 12px/1 var(--font-mono)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{w.url}</div>
                <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
                  {w.events.map(e => <span key={e} className="chip" style={{ height: 18, fontSize: 10, padding: '0 6px' }}>{e}</span>)}
                </div>
              </div>
              <Btn kind="ghost" size="sm">Test</Btn>
              <Btn kind="ghost" size="sm">Edit</Btn>
            </div>
          ))}
          <Btn kind="secondary" size="sm" icon={I.Plus} style={{ marginTop: 12 }}>Add endpoint</Btn>
        </div>
      </div>
    </div>
  );
}

/* HealthDot helper if not present */
function HealthDot({ status }) {
  const color = { ok: 'var(--success)', warn: 'var(--warning)', down: 'var(--danger)' }[status] || 'var(--fg-muted)';
  return <span style={{ width: 8, height: 8, borderRadius: '50%', background: color, boxShadow: `0 0 6px ${color}` }}/>;
}

/* ============================================================
   9.  INVOICES
   ============================================================ */
function InvoicesScreen() {
  const invoices = [
    { id: 'inv_2025_05', date: 'May 1, 2025',  amount: '$89.00', plan: 'Studio Pro', status: 'paid' },
    { id: 'inv_2025_04', date: 'Apr 1, 2025',  amount: '$89.00', plan: 'Studio Pro', status: 'paid' },
    { id: 'inv_2025_03', date: 'Mar 1, 2025',  amount: '$89.00', plan: 'Studio Pro', status: 'paid' },
    { id: 'inv_2025_02', date: 'Feb 1, 2025',  amount: '$29.00', plan: 'Starter',    status: 'paid' },
    { id: 'inv_2025_01', date: 'Jan 1, 2025',  amount: '$29.00', plan: 'Starter',    status: 'paid' },
    { id: 'inv_2024_12', date: 'Dec 1, 2024',  amount: '$29.00', plan: 'Starter',    status: 'paid' },
    { id: 'inv_2024_11', date: 'Nov 12, 2024', amount: '$0.00',  plan: 'Trial',      status: 'free' },
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1080, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Invoices</div>
            <div className="t-small" style={{ marginTop: 4 }}>Receipts and billing history. Tax-deductible · downloadable PDFs.</div>
          </div>
          <Btn kind="secondary" icon={I.Download}>Download CSV</Btn>
          <Btn kind="ghost" icon={I.Edit}>Billing details</Btn>
        </div>

        {/* Billing details summary */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            <KV3 k="Billed to" v="Mihir Vaishnav"/>
            <KV3 k="Email" v="mihir@aicreators.cloud"/>
            <KV3 k="Payment method" v="Visa · ending 4242 (Razorpay)"/>
            <KV3 k="Tax ID" v="—"/>
          </div>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Invoice','Date','Plan','Amount','Status',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv, i) => (
                <tr key={inv.id} style={{ borderBottom: i < invoices.length - 1 ? '1px solid var(--border-hairline)' : 0 }}>
                  <td style={{ padding: '12px 16px' }}>
                    <span className="t-mono" style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{inv.id}</span>
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small" >{inv.date}</td>
                  <td style={{ padding: '12px 16px' }}><span className="chip">{inv.plan}</span></td>
                  <td style={{ padding: '12px 16px', font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{inv.amount}</td>
                  <td style={{ padding: '12px 16px' }}>
                    {inv.status === 'paid' && <span className="chip chip--success"><I.Check size={10}/> Paid</span>}
                    {inv.status === 'free' && <span className="chip">Trial</span>}
                  </td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button className="btn btn--ghost btn--icon btn--sm" title="Download PDF"><I.Download size={12}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function KV3({ k, v }) {
  return (
    <div>
      <div className="t-tiny" style={{ marginBottom: 6 }}>{k}</div>
      <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}</div>
    </div>
  );
}

/* Export */
Object.assign(window, {
  VideoDetailScreen, ChannelAnalyticsScreen, ABResultsScreen,
  TicketThreadScreen, NotificationPrefsScreen, ReferEarnScreen,
  SecurityScreen, UserAPIKeysScreen, InvoicesScreen,
});
