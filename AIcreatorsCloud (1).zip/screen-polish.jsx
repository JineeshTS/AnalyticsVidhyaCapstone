/* ============================================================
   AIcreators.cloud · Onboarding tour, 404, empty states,
   voice/face consent, workspace switcher, status incident detail,
   admin DSAR queue, DMCA counter-notice form
   ============================================================

   Everything in this file is glue / polish that wires existing
   components to remaining surfaces. Mounted into:
     - main app (Tour, NotFound, EmptyChannels, EmptyLibrary,
       VoiceConsentStep, WorkspaceSwitcher)
     - admin app (DSARQueue)
     - status page (StatusIncidentDetail)
     - legal page (DMCACounterNotice section added)
   ============================================================ */

/* ============================================================
   1.  ONBOARDING TOUR — coachmark overlays
   ----
   First-time-after-signup experience. 5 spotlight tips that
   highlight the production line, autopilot, channels, etc.
   Skippable. Re-launchable from Help.
   ============================================================ */
function OnboardingTour({ onClose }) {
  const [step, setStep] = React.useState(0);
  const tips = [
    {
      anchor: { top: 90, left: 290, w: 600, h: 320 },
      title: 'This is the Production Line.',
      body: 'Every video flows left → right through 8 stages. Click any stage dot to drop in and review what AIcreators made.',
      placement: 'right',
    },
    {
      anchor: { top: 90, left: 12, w: 268, h: 100 },
      title: 'Autopilot is on by default.',
      body: 'AIcreators picks topics, scripts them, animates, voices, edits, and publishes on schedule. Toggle off any time to pause.',
      placement: 'right',
    },
    {
      anchor: { top: 200, left: 12, w: 268, h: 200 },
      title: 'Run as many channels as you want.',
      body: 'Each channel has its own identity, voice, visual style, and schedule. Studio Pro and Studio plans are unlimited.',
      placement: 'right',
    },
    {
      anchor: { top: 16, right: 200, w: 320, h: 40, isRight: true },
      title: 'Press ⌘K to search anything.',
      body: 'Projects, channels, topics, settings — all instantly searchable.',
      placement: 'bottom',
    },
    {
      anchor: { top: 16, right: 16, w: 140, h: 40, isRight: true },
      title: 'Make your first video.',
      body: 'Click here when you\'re ready. AIcreators will walk you through the pipeline the first time, then take over.',
      placement: 'bottom',
    },
  ];
  const tip = tips[step];

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 9000, pointerEvents: 'none' }}>
      {/* Backdrop with spotlight hole */}
      <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0, pointerEvents: 'auto' }} onClick={onClose}>
        <defs>
          <mask id="tourMask">
            <rect width="100%" height="100%" fill="white"/>
            <rect
              x={tip.anchor.isRight ? `calc(100% - ${tip.anchor.right || 0}px - ${tip.anchor.w}px)` : tip.anchor.left}
              y={tip.anchor.top}
              width={tip.anchor.w}
              height={tip.anchor.h}
              rx="14"
              fill="black"
            />
          </mask>
        </defs>
        <rect width="100%" height="100%" fill="rgba(0,0,0,0.55)" mask="url(#tourMask)"/>
      </svg>

      {/* Highlight ring */}
      <div style={{
        position: 'absolute',
        top: tip.anchor.top - 4,
        left: tip.anchor.isRight ? undefined : tip.anchor.left - 4,
        right: tip.anchor.isRight ? (tip.anchor.right || 0) - 4 : undefined,
        width: tip.anchor.w + 8,
        height: tip.anchor.h + 8,
        borderRadius: 18,
        border: '2px solid var(--accent)',
        boxShadow: '0 0 0 4px var(--accent-tint-2)',
        pointerEvents: 'none',
        animation: 'sparklePing 1.8s ease-out infinite',
      }}/>

      {/* Tooltip card */}
      <div style={{
        position: 'absolute',
        top: tip.placement === 'bottom' ? tip.anchor.top + tip.anchor.h + 14 : tip.anchor.top,
        left: tip.placement === 'right' ? tip.anchor.left + tip.anchor.w + 14
            : tip.placement === 'bottom' ? (tip.anchor.isRight ? `calc(100% - 360px - ${tip.anchor.right || 0}px)` : tip.anchor.left + tip.anchor.w - 320)
            : tip.anchor.left,
        width: 340,
        background: 'var(--bg-surface)',
        border: '1px solid var(--accent-border)',
        borderRadius: 14,
        boxShadow: 'var(--shadow-modal)',
        padding: 18,
        pointerEvents: 'auto',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <span className="chip chip--magic"><I.Sparkles size={11}/> Tour · {step + 1} / {tips.length}</span>
          <div style={{ flex: 1 }}/>
          <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={12}/></button>
        </div>
        <div className="t-h5" style={{ marginBottom: 8 }}>{tip.title}</div>
        <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 18, textWrap: 'pretty' }}>{tip.body}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ display: 'flex', gap: 4 }}>
            {tips.map((_, i) => (
              <span key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: i === step ? 'var(--brand)' : 'var(--surface-elev)' }}/>
            ))}
          </div>
          <div style={{ flex: 1 }}/>
          {step > 0 && <Btn kind="ghost" size="sm" onClick={() => setStep(step - 1)}>Back</Btn>}
          {step < tips.length - 1
            ? <Btn kind="primary" size="sm" iconRight={I.ChevRight} onClick={() => setStep(step + 1)}>Next</Btn>
            : <Btn kind="primary" size="sm" icon={I.Check} onClick={onClose}>Got it</Btn>}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   2.  EMPTY STATES — wired to specific surfaces
   ============================================================ */
function EmptyChannels({ onConnect }) {
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
      <EmptyState
        magic
        icon={I.Youtube}
        title="Connect your first channel"
        body="Link a YouTube channel and AIcreators will study its style, audience, and best-performing videos to bootstrap your autopilot."
        action={<Btn kind="magic" size="lg" icon={I.Youtube} onClick={onConnect}>Connect YouTube</Btn>}
        secondary={<Btn kind="ghost" size="lg">Or create a new channel</Btn>}
      />
    </div>
  );
}

function EmptyLibrary() {
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <EmptyState
        icon={I.Folder}
        title="No published videos yet"
        body="Your library fills up automatically as AIcreators ships videos. Want to start your first one now?"
        action={<a href="#topics" style={{ textDecoration: 'none' }}><Btn kind="primary" icon={I.Spark}>Pick a topic</Btn></a>}
      />
    </div>
  );
}

function EmptyTopics({ onScout }) {
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <EmptyState
        magic
        icon={I.Spark}
        title="No topic ideas yet"
        body="Our AI scout finds ideas based on your channel identity. It usually surfaces 20-40 ideas per week."
        action={<Btn kind="magic" icon={I.Refresh} onClick={onScout}>Scout for ideas now</Btn>}
        secondary={<Btn kind="ghost" icon={I.Plus}>Or add my own</Btn>}
      />
    </div>
  );
}

function EmptySearch({ q, onClear }) {
  return (
    <EmptyState
      icon={I.Search}
      title={`No results for "${q}"`}
      body="Try a different keyword, or browse projects and topics by section."
      action={<Btn kind="ghost" onClick={onClear}>Clear search</Btn>}
    />
  );
}

/* ============================================================
   3.  404 / NOT FOUND
   ----
   Imported on every HTML; routed to when no other route matches.
   ============================================================ */
function NotFoundScreen({ onHome, backLabel = 'Back to studio' }) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', padding: 40, position: 'relative', overflow: 'hidden' }}>
      <SparkleField count={14} intensity={0.3}/>
      <div style={{ position: 'relative', textAlign: 'center', maxWidth: 520, zIndex: 1 }}>
        <div style={{ font: '900 144px/1 var(--font-display)', letterSpacing: '-0.05em', marginBottom: 12 }} className="fg-grad">404</div>
        <div className="t-h2" style={{ marginBottom: 14 }}>This page got lost in production</div>
        <div className="t-body" style={{ color: 'var(--fg-secondary)', marginBottom: 24, textWrap: 'pretty' }}>
          Either the URL is broken, or the page moved. Take you home?
        </div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
          <Btn kind="magic" icon={I.Home} onClick={onHome}>{backLabel}</Btn>
          <a href="AIcreators Cloud.html#help" style={{ textDecoration: 'none' }}>
            <Btn kind="ghost" icon={I.Help}>Help</Btn>
          </a>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   4.  VOICE / FACE CONSENT STEP
   ----
   Inserted into VoiceCloneModal step 0 + AvatarCreateModal step 1.
   Captures explicit consent before cloning a voice or meshing a
   face that isn't the API caller's own.

   Backend
     POST /voices/clone        – body now includes consent_proof_url?
     POST /avatars             – body now includes consent_proof_url?

   Required when consent_subject !== 'self':
     - Name of subject
     - Email of subject (we send them a verification link)
     - Uploaded signed consent form (PDF)
     - OR upload of a video where subject reads a stated phrase
   ============================================================ */
function VoiceConsentStep({ onContinue, onBack }) {
  const [subject, setSubject] = React.useState('self');
  return (
    <div>
      <div className="t-h5" style={{ marginBottom: 6 }}>Before we clone — who is this voice?</div>
      <div className="t-small" style={{ marginBottom: 18 }}>
        Cloning someone else's voice without their explicit consent is prohibited. We log this answer.
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 18 }}>
        <ConsentChoice
          icon={I.User}
          title="This is my own voice"
          sub="Most common. Skip ahead."
          active={subject === 'self'}
          onClick={() => setSubject('self')}
        />
        <ConsentChoice
          icon={I.Users}
          title="It's someone else and they've consented"
          sub="You'll upload their signed consent and we'll email them to verify."
          active={subject === 'other'}
          onClick={() => setSubject('other')}
        />
      </div>

      {subject === 'other' && (
        <div className="card" style={{ background: 'var(--warning-bg)', border: '1px solid var(--warning-bd)', marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <I.Warn size={16} stroke="var(--warning-fg)" style={{ marginTop: 2 }}/>
            <div style={{ flex: 1 }}>
              <div className="t-h5" style={{ marginBottom: 8, color: 'var(--warning-fg)' }}>Consent required</div>

              <label className="label">Subject's full legal name</label>
              <input placeholder="Jane Doe"/>

              <label className="label" style={{ marginTop: 12 }}>Subject's email</label>
              <input placeholder="jane@example.com" type="email"/>
              <div className="t-small" style={{ marginTop: 6 }}>We'll email them a 24-hour verify link. The clone is held until they confirm.</div>

              <label className="label" style={{ marginTop: 14 }}>Upload signed consent</label>
              <div style={{ padding: 12, borderRadius: 10, border: '1px dashed var(--border-default)', background: 'var(--bg-surface)', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                <I.Upload size={14} stroke="var(--fg-muted)"/>
                <span className="t-small" style={{ flex: 1 }}>PDF · signed consent form · max 10MB</span>
                <Btn kind="ghost" size="sm">Choose file</Btn>
              </div>
              <div style={{ marginTop: 6 }}>
                <a href="#" className="t-small" style={{ color: 'var(--brand)' }}>Download our template ↓</a>
              </div>
            </div>
          </div>
        </div>
      )}

      <label style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 18 }}>
        <input type="checkbox" defaultChecked style={{ width: 16, height: 16, accentColor: 'var(--brand)', marginTop: 2 }}/>
        <span className="t-small" style={{ color: 'var(--fg-default)' }}>
          I confirm I have the legal right to clone this voice and have read the <a href="AIcreators Cloud Legal.html#content-policy" style={{ color: 'var(--brand)' }}>AI Content Policy</a>.
        </span>
      </label>

      <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between' }}>
        <Btn kind="ghost" onClick={onBack}>Cancel</Btn>
        <Btn kind="magic" iconRight={I.ChevRight} onClick={onContinue}>Continue</Btn>
      </div>
    </div>
  );
}

function ConsentChoice({ icon: Ico, title, sub, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      padding: 14, borderRadius: 12,
      border: '1px solid',
      borderColor: active ? 'var(--brand)' : 'var(--border-hairline)',
      background: active ? 'var(--brand-soft-bg)' : 'var(--bg-surface)',
      display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', textAlign: 'left',
    }}>
      <span style={{ width: 36, height: 36, borderRadius: 10, background: active ? 'var(--brand)' : 'var(--surface-hover)', color: active ? 'white' : 'var(--fg-default)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Ico size={16}/>
      </span>
      <div style={{ flex: 1 }}>
        <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{title}</div>
        <div className="t-small" style={{ marginTop: 4 }}>{sub}</div>
      </div>
      <span style={{ width: 18, height: 18, borderRadius: '50%', border: `2px solid ${active ? 'var(--brand)' : 'var(--border-default)'}`, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
        {active && <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--brand)' }}/>}
      </span>
    </button>
  );
}

/* ============================================================
   5.  WORKSPACE / TEAM SWITCHER
   ----
   Top-of-sidebar pill that drops down a list of orgs / personal
   workspace the user belongs to. Add a new org from here.
   ============================================================ */
function WorkspaceSwitcher({ user }) {
  const [open, setOpen] = React.useState(false);
  const workspaces = [
    { id: 'ws_personal', name: 'Mihir · Personal',  type: 'personal', plan: 'Studio Pro', active: true,  initial: 'M' },
    { id: 'ws_priya',    name: 'Priya Studio',       type: 'team',     plan: 'Studio',     active: false, initial: 'P' },
    { id: 'ws_noir',     name: 'Noir Films Inc.',    type: 'team',     plan: 'Starter',    active: false, initial: 'N' },
  ];
  const current = workspaces.find(w => w.active);

  return (
    <div style={{ position: 'relative', padding: '0 12px 8px' }}>
      <button onClick={() => setOpen(o => !o)} style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 10,
        padding: 10, borderRadius: 12,
        background: open ? 'var(--surface-hover)' : 'var(--surface-subtle)',
        border: '1px solid var(--border-hairline)',
        cursor: 'pointer', textAlign: 'left',
      }}>
        <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--magic-grad)', color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', font: '700 14px/1 var(--font-display)' }}>{current.initial}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{current.name}</div>
          <div style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 4 }}>{current.plan}</div>
        </div>
        {open ? <I.ChevUp size={14} stroke="var(--fg-muted)"/> : <I.ChevDown size={14} stroke="var(--fg-muted)"/>}
      </button>

      {open && (
        <div style={{
          position: 'absolute', top: '100%', left: 12, right: 12, zIndex: 100,
          background: 'var(--bg-surface)',
          border: '1px solid var(--border-default)',
          borderRadius: 12,
          boxShadow: 'var(--shadow-modal)',
          padding: 6, marginTop: 4,
        }}>
          <div className="t-tiny" style={{ padding: '8px 10px 4px' }}>Switch workspace</div>
          {workspaces.map(w => (
            <button key={w.id} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 10,
              padding: '8px 10px', borderRadius: 8,
              background: w.active ? 'var(--brand-soft-bg)' : 'transparent',
              border: 0, cursor: 'pointer', textAlign: 'left',
            }}>
              <span style={{ width: 28, height: 28, borderRadius: 8, background: 'var(--magic-grad)', color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', font: '700 12px/1 var(--font-display)' }}>{w.initial}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: w.active ? 'var(--brand)' : 'var(--fg-strong)' }}>{w.name}</div>
                <div style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 3 }}>{w.plan} · {w.type}</div>
              </div>
              {w.active && <I.Check size={14} stroke="var(--brand)"/>}
            </button>
          ))}
          <div className="divider" style={{ margin: '6px 0' }}/>
          <button style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 8, background: 'transparent', border: 0, cursor: 'pointer', textAlign: 'left', font: '500 13px/1.2 var(--font-sans)', color: 'var(--fg-default)' }}>
            <I.Plus size={14} stroke="var(--fg-default)"/>
            Create new workspace
          </button>
          <button style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 8, background: 'transparent', border: 0, cursor: 'pointer', textAlign: 'left', font: '500 13px/1.2 var(--font-sans)', color: 'var(--fg-default)' }}>
            <I.Users size={14} stroke="var(--fg-default)"/>
            Join a workspace by invite code
          </button>
        </div>
      )}
    </div>
  );
}

/* ============================================================
   6.  STATUS INCIDENT DETAIL — drill-in from status page
   ============================================================ */
function StatusIncidentDetail({ incident, onBack }) {
  const updates = [
    { ts: '11:42', kind: 'identified', body: 'GPU node A100-W4 hit an NCCL timeout. Routing keyframe traffic to other regions. Investigating root cause.' },
    { ts: '11:58', kind: 'investigating', body: 'NCCL ring init failure on A100-W4 after a routine OS patch. We\'ve cordoned the node and are rolling its replacement.' },
    { ts: '12:32', kind: 'monitoring', body: 'Replacement node is online and accepting traffic. Queue depth is dropping. Watching for stability over the next hour.' },
    { ts: '13:08', kind: 'resolved',   body: 'Queue back to baseline. No keyframe jobs failed — they were re-routed and retried automatically. We\'re leaving A100-W4 down pending hardware diagnostics; capacity is +1 ahead of replacement.' },
  ];
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-app)', overflowY: 'auto' }}>
      <header style={{ padding: '20px 32px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid var(--border-hairline)' }}>
        <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
        <a href="AIcreators Cloud Status.html" style={{ textDecoration: 'none' }}>
          <span className="t-small" style={{ color: 'var(--fg-muted)' }}>Status →</span>
        </a>
        <div style={{ flex: 1 }}/>
        <Btn kind="ghost" size="sm" icon={I.Bell}>Subscribe</Btn>
      </header>

      <div style={{ maxWidth: 880, margin: '0 auto', padding: '40px 32px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <span className="chip chip--warning">Minor incident</span>
          <span className="t-small">{incident?.date || 'May 16, 2025'}</span>
        </div>
        <h1 style={{ font: '700 32px/1.15 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)', marginBottom: 18 }}>
          {incident?.title || 'Keyframes queue lag'}
        </h1>

        <div className="card" style={{ marginBottom: 28, padding: 18 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            <KV5 k="Affected service" v="Pipeline · Keyframes"/>
            <KV5 k="Severity" v="Minor"/>
            <KV5 k="Duration" v="1h 26m"/>
            <KV5 k="Customers affected" v="~12% of paying users"/>
          </div>
        </div>

        <div className="t-h4" style={{ marginBottom: 14 }}>Timeline</div>
        <div style={{ position: 'relative', paddingLeft: 24 }}>
          <div style={{ position: 'absolute', left: 6, top: 6, bottom: 6, width: 2, background: 'var(--border-default)' }}/>
          {updates.map((u, i) => (
            <div key={i} style={{ position: 'relative', marginBottom: 28 }}>
              <span style={{
                position: 'absolute', left: -24, top: 4,
                width: 14, height: 14, borderRadius: '50%',
                background: u.kind === 'resolved' ? 'var(--success)' : u.kind === 'monitoring' ? 'var(--info)' : 'var(--warning)',
                boxShadow: `0 0 0 4px var(--bg-app), 0 0 0 5px var(--border-default)`,
              }}/>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 6 }}>
                <span className="t-mono" style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{u.ts}</span>
                <span className="chip" style={{ height: 22, fontSize: 11, padding: '0 8px' }}>
                  {u.kind === 'identified'    && 'Identified'}
                  {u.kind === 'investigating' && 'Investigating'}
                  {u.kind === 'monitoring'    && 'Monitoring'}
                  {u.kind === 'resolved'      && 'Resolved'}
                </span>
              </div>
              <div className="t-body" style={{ color: 'var(--fg-default)', textWrap: 'pretty' }}>{u.body}</div>
            </div>
          ))}
        </div>

        <div className="card" style={{ marginTop: 32, background: 'var(--surface-subtle)' }}>
          <div className="t-h5" style={{ marginBottom: 10 }}>Post-mortem</div>
          <div className="t-body" style={{ color: 'var(--fg-secondary)', textWrap: 'pretty' }}>
            Root cause: the patched kernel on A100-W4 broke NCCL collective communication for our keyframe inference workload. We don't auto-apply kernel patches to GPU nodes, but this one was rolled by our infra provider during scheduled maintenance.
            <br/><br/>
            <strong>What we changed:</strong> we now require an additional sign-off before any kernel patch hits a GPU node, and we added an NCCL smoke test to our liveness probe so degraded nodes are detected in seconds, not minutes.
          </div>
        </div>
      </div>
    </div>
  );
}

function KV5({ k, v }) {
  return (
    <div>
      <div className="t-tiny" style={{ marginBottom: 6 }}>{k}</div>
      <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}</div>
    </div>
  );
}

/* ============================================================
   7.  ADMIN DSAR (Data Subject Access Request) QUEUE
   ----
   GDPR/CCPA inbox. Admins fulfill access / deletion / rectification
   requests filed by customers (or by their lawyers).

   Backend
     GET    /admin/dsar?status=open
     GET    /admin/dsar/{id}
     POST   /admin/dsar/{id}/fulfill         {response_body, attachments[]}
     POST   /admin/dsar/{id}/reject          {reason}
     PATCH  /admin/dsar/{id}                 {assignee, due_date}
   ============================================================ */
const ADMIN_DSAR = [
  { id: 'dsar_001', subject: 'mihir@aicreators.cloud',   type: 'access',         filed: '12 h ago', dueIn: '29 days', status: 'open',     assignee: 'Mihir V', region: 'US',  note: 'Standard export — auto-fulfillable' },
  { id: 'dsar_002', subject: 'jane.doe@example.com',     type: 'erasure',        filed: '1 day',    dueIn: '29 days', status: 'verifying', assignee: 'Mihir V', region: 'EU',  note: 'Verifying identity — sent email magic link' },
  { id: 'dsar_003', subject: 'pranav@studio.in',         type: 'rectification', filed: '3 days',    dueIn: '27 days', status: 'open',     assignee: 'Priya R', region: 'IN',  note: 'Wants country corrected from US → IN' },
  { id: 'dsar_004', subject: '⚖ Counsel · lila@bnights.de', type: 'access',     filed: '5 days',    dueIn: '25 days', status: 'in-progress', assignee: 'Mihir V', region: 'EU',  note: 'Filed via legal — extra scope (oauth tokens history)' },
  { id: 'dsar_005', subject: 'akira@himitsu.jp',         type: 'portability',    filed: '6 days',    dueIn: '24 days', status: 'in-progress', assignee: 'Mihir V', region: 'JP',  note: 'Wants raw artifacts for export to competitor' },
];

function AdminDSAR() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Privacy requests · DSAR</div>
            <div className="t-small" style={{ marginTop: 4 }}>GDPR Articles 15-17 + CCPA. All requests must be fulfilled within 30 days.</div>
          </div>
          <Btn kind="ghost" size="sm" icon={I.Download}>Export queue</Btn>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          <AdminStat label="Open"          value={String(ADMIN_DSAR.filter(d => d.status === 'open').length)}        icon={I.Hourglass}/>
          <AdminStat label="In progress"    value={String(ADMIN_DSAR.filter(d => d.status === 'in-progress').length)} icon={I.Activity}/>
          <AdminStat label="Avg time to fulfill" value="4.2 days" delta="-1.1 days" trend="down" icon={I.Clock}/>
          <AdminStat label="Past 30d closed"     value="38"        delta="+12"       trend="up"   icon={I.Check}/>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['ID','Subject','Type','Region','Filed','Due','Status','Assignee',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ADMIN_DSAR.map(d => (
                <tr key={d.id} style={{ borderBottom: '1px solid var(--border-hairline)', cursor: 'pointer' }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{d.id}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{d.subject}</div>
                    <div className="t-small" style={{ marginTop: 4 }}>{d.note}</div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    {d.type === 'access'        && <span className="chip">Access (Art. 15)</span>}
                    {d.type === 'rectification' && <span className="chip">Rectification (Art. 16)</span>}
                    {d.type === 'erasure'       && <span className="chip chip--warning">Erasure (Art. 17)</span>}
                    {d.type === 'portability'   && <span className="chip chip--info">Portability (Art. 20)</span>}
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{d.region}</td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{d.filed}</td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{d.dueIn}</td>
                  <td style={{ padding: '12px 16px' }}>
                    {d.status === 'open'        && <span className="chip chip--info">Open</span>}
                    {d.status === 'verifying'   && <span className="chip chip--warning">Verifying</span>}
                    {d.status === 'in-progress' && <span className="chip chip--brand">In progress</span>}
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{d.assignee}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <Btn kind="secondary" size="sm" iconRight={I.ChevRight}>Open</Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   8.  Tour launcher (re-launchable from Help)
   ============================================================ */
function TourLauncher() {
  const [open, setOpen] = React.useState(false);
  React.useEffect(() => {
    window.openTour = () => setOpen(true);
    return () => { delete window.openTour; };
  }, []);
  if (!open) return null;
  return <OnboardingTour onClose={() => setOpen(false)}/>;
}

Object.assign(window, {
  OnboardingTour, TourLauncher,
  EmptyChannels, EmptyLibrary, EmptyTopics, EmptySearch,
  NotFoundScreen,
  VoiceConsentStep,
  WorkspaceSwitcher,
  StatusIncidentDetail,
  AdminDSAR, ADMIN_DSAR,
});
