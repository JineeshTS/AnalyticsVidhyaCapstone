/* ============================================================
   AIcreators.cloud — Project Detail
   Drop into any stage of a single video to review/approve.
   ============================================================ */

function ProjectHeader({ project, onBack, onAutopilot }) {
  const ch = MOCK.channels.find(c => c.id === project.channelId);
  return (
    <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
        <button className="btn btn--ghost btn--icon" onClick={onBack}>
          <I.ChevLeft size={18}/>
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="t-small" style={{ cursor: 'pointer' }} onClick={onBack}>Production Line</span>
          <I.ChevRight size={12} stroke="var(--fg-faint)"/>
          <span className="t-small" style={{ color: 'var(--fg-default)' }}>{ch.name}</span>
        </div>
        <div style={{ flex: 1 }}/>
        <span className="chip chip--magic">
          <I.Spark size={12}/> Best-fit prompting · auto
        </span>
        <Switch on={project.autopilot} label="Autopilot" onChange={onAutopilot}/>
        <Btn kind="secondary" icon={I.Eye} onClick={() => window.openPreview?.(project)}>Preview</Btn>
        <Btn kind="primary" icon={I.Upload}>Publish now</Btn>
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16 }}>
        <div style={{
          width: 96, height: 60, borderRadius: 10, flexShrink: 0,
          background: project.thumb,
          border: '1px solid var(--border-hairline)',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
          <span style={{ position:'absolute', bottom:4, right:4, font:'700 11px/1 var(--font-sans)', color:'white', textShadow:'0 1px 2px rgba(0,0,0,0.6)', padding:'2px 5px', background:'rgba(0,0,0,0.45)', borderRadius: 4 }}>{project.duration}</span>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="t-h3" style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{project.title}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 6 }}>
            <ChannelHeader ch={ch}/>
            <span className="t-small">{project.format}</span>
            <span style={{ color:'var(--fg-faint)' }}>•</span>
            <span className="t-small">Publish · {project.publishAt}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function StageStrip({ project, activeStage, onSelect }) {
  return (
    <div style={{
      padding: '16px 28px',
      borderBottom: '1px solid var(--border-hairline)',
      background: 'rgba(255,255,255,0.015)',
      overflowX: 'auto',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 0, minWidth: 'fit-content' }}>
        {PIPELINE_STAGES.map((s, idx) => {
          const state = project.stageStates[s.id] || 'todo';
          const isActive = activeStage === s.id;
          const Ico = I[s.icon];
          return (
            <React.Fragment key={s.id}>
              <button onClick={() => onSelect(s.id)} style={{
                border: 0, background: 'transparent', cursor: 'pointer', padding: 4,
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                minWidth: 80, flexShrink: 0,
              }}>
                <span className={state === 'running' ? 'process-pulse' : ''} style={{
                  width: 44, height: 44, borderRadius: 12,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  background:
                    isActive            ? 'linear-gradient(135deg, var(--violet-500), var(--violet-600))' :
                    state === 'done'    ? 'var(--success-bg)' :
                    state === 'running' ? 'var(--accent-tint-3)' :
                    state === 'review'  ? 'var(--warning-bg)' :
                                          'var(--surface-hover)',
                  border: `1px solid ${
                    isActive            ? 'var(--accent)' :
                    state === 'done'    ? 'var(--success-bd)' :
                    state === 'running' ? 'var(--accent-border)' :
                    state === 'review'  ? 'var(--warning-bd)' :
                                          'var(--border-default)'
                  }`,
                  color:
                    isActive            ? 'white' :
                    state === 'done'    ? 'var(--success)' :
                    state === 'running' ? 'var(--accent-fg)' :
                    state === 'review'  ? 'var(--warning)' :
                                          'var(--fg-faint)',
                  boxShadow: isActive ? '0 8px 20px rgba(124,58,237,0.40)' : 'none',
                  transition: 'all 160ms var(--ease-out)',
                }}>
                  {state === 'done' && !isActive ? <I.Check size={20}/> : <Ico size={20}/>}
                </span>
                <div style={{ textAlign: 'center', lineHeight: 1.2 }}>
                  <div className="t-tiny" style={{ color: 'var(--fg-faint)' }}>{String(idx + 1).padStart(2,'0')}</div>
                  <div style={{ font: `${isActive ? 600 : 500} 12px/1.2 var(--font-sans)`, color: isActive ? 'var(--fg-strong)' : 'var(--fg-default)', marginTop: 2 }}>{s.label}</div>
                </div>
              </button>
              {idx < PIPELINE_STAGES.length - 1 && (
                <div style={{
                  width: 28, height: 2,
                  background: project.stageStates[s.id] === 'done'
                    ? 'linear-gradient(90deg, rgba(52,211,153,0.55), var(--accent-border))'
                    : 'var(--border-hairline)',
                  margin: '0 -2px',
                  alignSelf: 'flex-start',
                  marginTop: 25,
                }}/>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Stage panes ---------- */

function StageHeader({ stage, state, blurb }) {
  const Ico = I[stage.icon];
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
      <span style={{
        width: 40, height: 40, borderRadius: 10,
        background: 'var(--magic-tint)',
        border: '1px solid var(--brand-soft-bd)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        color: 'var(--accent-fg)',
      }}>
        <Ico size={20}/>
      </span>
      <div style={{ flex: 1 }}>
        <div className="t-h4">{stage.label}</div>
        <div className="t-small" style={{ marginTop: 4 }}>{blurb}</div>
      </div>
      {state === 'running' && <span className="chip chip--brand"><I.Spark size={12}/> Working…</span>}
      {state === 'done' && <span className="chip chip--success"><I.Check size={12}/> Approved</span>}
      {state === 'review' && <span className="chip chip--warning"><I.Eye size={12}/> Awaiting review</span>}
    </div>
  );
}

function PaneIdea({ project, stage }) {
  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.idea} blurb="The seed idea — researched, scored, and approved."/>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
        <div className="card">
          <div className="t-tiny" style={{ marginBottom: 8 }}>Hook</div>
          <div style={{ font: '600 18px/1.4 var(--font-display)', color: 'var(--fg-strong)', marginBottom: 16, textWrap: 'pretty' }}>
            "It took 600 years to build the largest library in the ancient world. Then in one night, it was gone."
          </div>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Angle</div>
          <div className="t-body" style={{ marginBottom: 16 }}>
            A first-person walk-through of Alexandria's Mouseion at its peak — the scrolls, the scholars, the political tinder.
            Build to the fire and then puncture the myth (it wasn't just one fire).
          </div>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Why it'll work on this channel</div>
          <div className="t-body" style={{ color: 'var(--fg-secondary)' }}>
            Mythic Tales over-indexes on mystery + ancient history. Audience retention curve on similar
            videos peaks at 0:18 (hook) and 7:20 (revelation). This script is paced to match.
          </div>
        </div>
        <div className="card">
          <div className="t-tiny" style={{ marginBottom: 12 }}>Why now</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 16 }}>
            <span style={{ font: '700 40px/1 var(--font-display)', color: 'var(--accent-fg)' }}>94</span>
            <span className="t-small">Confidence score</span>
          </div>
          <div className="divider" style={{ margin: '16px 0' }}/>
          <div style={{ display:'flex', flexDirection:'column', gap: 10 }}>
            {[
              { label: 'Trend velocity',     value: '+24% w/w', color: 'var(--success)' },
              { label: 'Channel fit',        value: '92/100',   color: 'var(--accent-fg)' },
              { label: 'Search competition', value: 'Low',      color: 'var(--success)' },
              { label: 'Estimated CTR',      value: '10.4%',    color: 'var(--accent-fg)' },
            ].map((m,i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span className="t-small">{m.label}</span>
                <span style={{ font:'600 13px/1 var(--font-sans)', color: m.color }}>{m.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PaneScript({ project, stage }) {
  const isRunning = project.stageStates.script === 'running';
  const lines = [
    { t: 'HOOK', body: "It took six hundred years to build the largest library the ancient world had ever seen. And then, in one night — they say — it was gone.", color: 'var(--accent-fg)' },
    { t: 'BEAT 1', body: "You're walking through the Mouseion. The marble is still warm from the day's sun. Scribes pass you carrying scrolls, half a million of them, stacked in cedar shelves to the ceiling…" },
    { t: 'BEAT 2', body: "Egypt's Ptolemy II had built it not just as a library — but as a *trap*. Every ship that docked at Alexandria was searched. Any scroll on board? Copied. Returned, sometimes. Confiscated, usually." },
    { t: 'TURN', body: "And then in 48 BC, Julius Caesar's ships are burning in the harbor. The fire jumps. But here's the thing — the library doesn't end there.", color: 'var(--warning)' },
    { t: 'PAYOFF', body: "It dies four more times. Once to a riot. Once to the Christians. Once to the Muslims. Once, quietly, to no one at all. The myth of the one great fire is just easier to remember." },
    { t: 'CTA', body: "If you want to know what was actually inside it — the recipes, the maps, the half-million dreams — keep watching." },
  ];
  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.script} blurb={isRunning ? "Avyal is drafting v2 of the script using the Chain-of-Thought prompting technique." : "The full script — hook, beats, turn, payoff, CTA."}/>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className="chip chip--brand"><I.Robot size={12}/> Avyal Delta · 2.0</span>
            <span className="t-small">Tone · Storyteller</span>
            <span className="t-small">·</span>
            <span className="t-small">1,148 words · ~11 min</span>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--ghost btn--sm" title="Regenerate"><I.Refresh size={14}/></button>
            <button className="btn btn--ghost btn--sm" title="Edit"><I.Edit size={14}/></button>
          </div>
          <div style={{ padding: 22, maxHeight: 460, overflowY: 'auto' }}>
            {lines.map((ln, i) => (
              <div key={i} style={{ marginBottom: 18, opacity: isRunning && i > 3 ? 0.35 : 1 }}>
                <div style={{ font: '700 10px/1 var(--font-sans)', letterSpacing: '0.10em', color: ln.color || 'var(--fg-faint)', textTransform: 'uppercase', marginBottom: 6 }}>{ln.t}</div>
                <div style={{ font: '500 15px/1.65 var(--font-sans)', color: 'var(--fg-default)', textWrap: 'pretty' }}>{ln.body}</div>
              </div>
            ))}
            {isRunning && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8 }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', animation: 'sparklePing 1.2s ease-out infinite' }}/>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', animation: 'sparklePing 1.2s ease-out 0.15s infinite' }}/>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', animation: 'sparklePing 1.2s ease-out 0.30s infinite' }}/>
                <span className="t-small" style={{ marginLeft: 8 }}>writing…</span>
              </div>
            )}
          </div>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap: 12 }}>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 12 }}>Prompting technique</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <I.Spark size={20} stroke="var(--accent)"/>
              <div>
                <div style={{ font:'600 14px/1.2 var(--font-sans)', color:'var(--fg-strong)' }}>Chain-of-Thought + Persona</div>
                <div className="t-small" style={{ marginTop: 2 }}>Picked automatically for long-form mystery</div>
              </div>
            </div>
            <Btn kind="ghost" size="sm" icon={I.Sliders}>Override technique</Btn>
          </div>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 12 }}>Channel voice rules</div>
            <ul style={{ margin: 0, padding: '0 0 0 18px', font: '500 13px/1.7 var(--font-sans)', color: 'var(--fg-secondary)' }}>
              <li>Second-person walkthrough</li>
              <li>Reveal myths, don't repeat them</li>
              <li>No filler — kill any line that doesn't advance</li>
              <li>End on a question, not a summary</li>
            </ul>
          </div>
          <div className="card" style={{ display: 'flex', gap: 8 }}>
            <Btn kind="secondary" icon={I.Check}>Approve</Btn>
            <Btn kind="ghost" icon={I.Refresh}>Regenerate</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

function PaneStoryboard({ project, stage }) {
  const scenes = [
    { n: 1, label: 'Hook — wide aerial', shot: 'Drone-style night reveal of harbor', dur: '0:00–0:14', img: 'linear-gradient(135deg,#2A1810,#7B4F2C)' },
    { n: 2, label: 'Push in — library doors', shot: 'Slow dolly, torchlit hallway', dur: '0:14–0:38', img: 'linear-gradient(135deg,#7B4F2C,#D4A574)' },
    { n: 3, label: 'Scribe portrait', shot: 'Close-up hands on parchment', dur: '0:38–1:02', img: 'linear-gradient(135deg,#D4A574,#F4E1B5)' },
    { n: 4, label: 'Shelves to ceiling', shot: 'Tilt up cedar shelves',          dur: '1:02–1:26', img: 'linear-gradient(135deg,#F4E1B5,#7B4F2C)' },
    { n: 5, label: 'Ptolemy court',     shot: 'Wide regal interior',             dur: '1:26–1:50', img: 'linear-gradient(135deg,#2A1810,#D4A574)' },
    { n: 6, label: 'Ship search',       shot: 'Harbor + scrolls confiscated',    dur: '1:50–2:14', img: 'linear-gradient(135deg,#7B4F2C,#F4E1B5)' },
    { n: 7, label: 'Caesar fire',       shot: 'Burning ships, embers',           dur: '2:14–3:00', img: 'linear-gradient(135deg,#7B4F2C,#F38181)' },
    { n: 8, label: 'Library on fire',   shot: 'Library interior in flame',       dur: '3:00–4:20', img: 'linear-gradient(135deg,#F38181,#2A1810)' },
  ];
  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.storyboard} blurb="Each beat broken into a shot. These drive both keyframes and motion."/>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {scenes.map(s => (
          <div key={s.n} className="card card--hover" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{
              aspectRatio: '16/9',
              background: s.img,
              position: 'relative',
            }}>
              <span style={{ position:'absolute', top:8, left:8, font:'700 11px/1 var(--font-sans)', color:'white', padding:'4px 8px', background:'rgba(0,0,0,0.55)', borderRadius: 6 }}>Scene {s.n}</span>
              <span style={{ position:'absolute', bottom:8, right:8, font:'600 11px/1 var(--font-sans)', color:'white', padding:'4px 8px', background:'rgba(0,0,0,0.55)', borderRadius: 6 }}>{s.dur}</span>
            </div>
            <div style={{ padding: 12 }}>
              <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{s.label}</div>
              <div className="t-small" style={{ marginTop: 4 }}>{s.shot}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PaneImages({ project, stage }) {
  const isReview = project.stageStates.images === 'review';
  const frames = Array.from({ length: 8 }, (_, i) => ({
    n: i + 1,
    img: ['linear-gradient(135deg,#2A1810,#7B4F2C)','linear-gradient(135deg,#7B4F2C,#D4A574)','linear-gradient(135deg,#D4A574,#F4E1B5)','linear-gradient(135deg,#F4E1B5,#7B4F2C)','linear-gradient(135deg,#2A1810,#D4A574)','linear-gradient(135deg,#7B4F2C,#F4E1B5)','linear-gradient(135deg,#7B4F2C,#F38181)','linear-gradient(135deg,#F38181,#2A1810)'][i],
    locked: i < 5,
    selected: i === 2,
  }));
  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.images} blurb="One keyframe per scene. Lock the ones you love. We re-roll the rest."/>
      {isReview && (
        <div style={{
          padding: 14, borderRadius: 12, marginBottom: 16,
          background: 'rgba(251,191,36,0.10)', border: '1px solid rgba(251,191,36,0.30)',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <I.Eye size={18} stroke="var(--warning)"/>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--warning)' }}>Awaiting your review</div>
            <div className="t-small" style={{ marginTop: 2 }}>You turned autopilot off at this stage. Approve, re-roll, or edit the prompt to continue.</div>
          </div>
          <Btn kind="primary" icon={I.Check}>Approve all</Btn>
          <Btn kind="ghost" icon={I.Refresh}>Re-roll unlocked</Btn>
        </div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {frames.map(f => (
          <div key={f.n} style={{
            position: 'relative', borderRadius: 12, overflow: 'hidden',
            border: `1px solid ${f.selected ? 'var(--accent)' : 'var(--border-hairline)'}`,
            boxShadow: f.selected ? '0 0 0 3px rgba(139,92,246,0.20)' : 'none',
            cursor: 'pointer',
          }}>
            <div style={{ aspectRatio: '16/9', background: f.img, position: 'relative' }}>
              <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.16), transparent 50%)' }}/>
              <span style={{ position:'absolute', top:8, left:8, font:'700 11px/1 var(--font-sans)', color:'white', padding:'4px 8px', background:'rgba(0,0,0,0.55)', borderRadius: 6 }}>Scene {f.n}</span>
              <div style={{ position: 'absolute', top: 8, right: 8, display: 'flex', gap: 4 }}>
                {f.locked && <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 22, height: 22, borderRadius: 6, background: 'rgba(0,0,0,0.55)', color: 'var(--accent-fg)' }}><I.Lock size={12}/></span>}
              </div>
            </div>
            <div style={{ padding: 10, display: 'flex', alignItems: 'center', gap: 6, background: 'var(--bg-surface)' }}>
              <button className="btn btn--ghost btn--sm" style={{ flex: 1, height: 30, padding: 0 }}><I.Refresh size={12}/></button>
              <button className="btn btn--ghost btn--sm" style={{ flex: 1, height: 30, padding: 0 }}><I.Edit size={12}/></button>
              <button className="btn btn--ghost btn--sm" style={{ flex: 1, height: 30, padding: 0 }}><I.Eye size={12}/></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PaneMotion({ project, stage }) {
  const isRunning = project.stageStates.motion === 'running';
  const clips = Array.from({ length: 8 }, (_, i) => ({
    n: i + 1,
    img: ['linear-gradient(135deg,#2A1810,#7B4F2C)','linear-gradient(135deg,#7B4F2C,#D4A574)','linear-gradient(135deg,#D4A574,#F4E1B5)','linear-gradient(135deg,#F4E1B5,#7B4F2C)','linear-gradient(135deg,#2A1810,#D4A574)','linear-gradient(135deg,#7B4F2C,#F4E1B5)','linear-gradient(135deg,#7B4F2C,#F38181)','linear-gradient(135deg,#F38181,#2A1810)'][i],
    progress: i < 3 ? 100 : i === 3 ? 62 : 0,
    motion: ['Push in','Pan right','Tilt up','Dolly out','Static','Zoom','Push in','Static'][i],
  }));
  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.motion} blurb={isRunning ? "Generating motion from your locked keyframes. Image-to-video keeps characters consistent across scenes." : "Each scene animated from its keyframe."}/>
      <div className="card" style={{ padding: 16, marginBottom: 16, background: 'var(--magic-tint-soft)', border: '1px solid var(--brand-soft-bd)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <I.Film size={24} stroke="var(--accent-fg)"/>
          <div style={{ flex: 1 }}>
            <div style={{ font:'600 14px/1.3 var(--font-sans)', color:'var(--fg-strong)' }}>Image-to-video keeps your story consistent</div>
            <div className="t-small" style={{ marginTop: 4 }}>Same characters · same lighting · same world. The scribe's hands in scene 3 are the same hands in scene 8.</div>
          </div>
          <span className="chip chip--brand"><I.Robot size={12}/> Avyal Motion · v3</span>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {clips.map(c => (
          <div key={c.n} className="card card--hover" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ aspectRatio: '16/9', background: c.img, position: 'relative' }}>
              <div style={{ position: 'absolute', inset: 0, background: c.progress === 100 ? 'rgba(0,0,0,0)' : 'rgba(7,7,13,0.55)' }}/>
              <span style={{ position:'absolute', top:8, left:8, font:'700 11px/1 var(--font-sans)', color:'white', padding:'4px 8px', background:'rgba(0,0,0,0.55)', borderRadius: 6 }}>Scene {c.n}</span>
              <span style={{ position:'absolute', bottom:8, left:8, font:'600 11px/1 var(--font-sans)', color:'white', padding:'4px 8px', background:'rgba(0,0,0,0.55)', borderRadius: 6 }}>{c.motion}</span>
              {c.progress === 100 && (
                <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 38, height: 38, borderRadius: '50%', background: 'rgba(7,7,13,0.65)', display:'inline-flex', alignItems:'center', justifyContent:'center', color:'white' }}>
                  <I.Play size={14}/>
                </span>
              )}
              {c.progress > 0 && c.progress < 100 && (
                <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 8 }}>
                  <div style={{ width: 36, height: 36, borderRadius: '50%', border: '2px solid rgba(167,139,250,0.4)', borderTopColor: 'var(--accent)', animation: 'slowSpin 1s linear infinite' }}/>
                  <span style={{ font: '600 12px/1 var(--font-sans)', color: 'white' }}>{c.progress}%</span>
                </div>
              )}
              {c.progress === 0 && (
                <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <span className="chip">queued</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PaneVoice({ project, stage }) {
  const v = MOCK.voices.find(x => x.id === project.voice) || MOCK.voices[0];
  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.voice} blurb="Voiceover and music bed."/>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
            <span style={{
              width: 56, height: 56, borderRadius: '50%',
              background: 'var(--magic-grad)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 8px 20px rgba(124,58,237,0.40)',
              color: 'white', font: '700 22px/1 var(--font-display)',
            }}>{v.name[0]}</span>
            <div>
              <div className="t-h4">{v.name}</div>
              <div className="t-small" style={{ marginTop: 4 }}>{v.gender} · {v.accent} · {v.vibe}</div>
            </div>
            <div style={{ flex: 1 }}/>
            <Btn kind="secondary" icon={I.Refresh}>Change voice</Btn>
          </div>

          {/* Waveform */}
          <div style={{
            height: 96, padding: '0 16px',
            background: 'var(--surface-subtle)',
            border: '1px solid var(--border-hairline)',
            borderRadius: 12,
            display: 'flex', alignItems: 'center', gap: 2,
            position: 'relative', overflow: 'hidden',
          }}>
            {Array.from({ length: 96 }).map((_, i) => {
              const h = 8 + Math.abs(Math.sin(i * 0.4) * 28) + (Math.sin(i * 0.91) * 18);
              const played = i < 38;
              return (
                <span key={i} style={{
                  width: 3, height: Math.abs(h),
                  background: played
                    ? 'linear-gradient(180deg, var(--accent), var(--cyan-400))'
                    : 'var(--border-default)',
                  borderRadius: 2,
                }}/>
              );
            })}
            <span style={{ position:'absolute', left: '40%', top: 0, bottom: 0, width: 2, background: 'var(--accent-fg)', boxShadow: '0 0 8px var(--accent)' }}/>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 14 }}>
            <button className="btn btn--primary btn--icon-lg" style={{ width: 44, height: 44, borderRadius: '50%' }}>
              <I.Play size={18}/>
            </button>
            <span className="t-mono t-small" style={{ color: 'var(--fg-default)' }}>04:24 / 11:42</span>
            <div style={{ flex: 1 }}/>
            <button className="btn btn--ghost btn--icon"><I.Refresh size={16}/></button>
            <button className="btn btn--ghost btn--icon"><I.Download size={16}/></button>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 12 }}>Pacing</div>
            <div style={{ display: 'grid', gap: 10 }}>
              {[
                { l: 'Speed',    v: '1.00×' },
                { l: 'Pauses',   v: 'Story-paced' },
                { l: 'Emphasis', v: 'High on payoff' },
              ].map((m,i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span className="t-small">{m.l}</span>
                  <span style={{ font:'600 13px/1 var(--font-sans)', color:'var(--fg-strong)' }}>{m.v}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 12 }}>Music bed</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--accent-tint-1)', border: '1px solid var(--accent-tint-3)', display:'inline-flex', alignItems:'center', justifyContent:'center', color: 'var(--cyan-400)' }}>
                <I.Megaphone size={16}/>
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Antique Ascension</div>
                <div className="t-small" style={{ marginTop: 2 }}>Cinematic · 76 BPM · -18 LUFS</div>
              </div>
              <I.ChevDown size={14} stroke="var(--fg-muted)"/>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PaneEdit({ project, stage }) {
  const tracks = [
    { name: 'Voiceover',   color: 'var(--accent)', icon: I.Mic, segs: [[0,18],[20,44],[46,68],[70,98]] },
    { name: 'B-roll',      color: 'var(--cyan-400)',   icon: I.Film, segs: [[0,14],[14,34],[36,60],[60,88],[90,100]] },
    { name: 'Music',       color: 'var(--magenta-400)',icon: I.Megaphone, segs: [[0,100]] },
    { name: 'SFX',         color: 'var(--success)',    icon: I.Sparkles, segs: [[16,20],[40,42],[68,72]] },
    { name: 'Captions',    color: 'var(--warning)',    icon: I.Languages, segs: [[0,100]] },
  ];
  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.edit} blurb="Final assembly. Voice, b-roll, music, captions, color."/>
      <div className="card" style={{ padding: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <button className="btn btn--primary btn--icon-lg" style={{ width: 44, height: 44, borderRadius: '50%' }}><I.Play size={18}/></button>
          <span className="t-mono t-small" style={{ color: 'var(--fg-default)' }}>00:00 / 11:42</span>
          <div style={{ flex: 1 }}/>
          <Btn kind="ghost" size="sm" icon={I.Languages}>Captions</Btn>
          <Btn kind="ghost" size="sm" icon={I.Sliders}>Color</Btn>
          <Btn kind="ghost" size="sm" icon={I.Megaphone}>Mix</Btn>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {tracks.map((t, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 110, display: 'flex', alignItems: 'center', gap: 8 }}>
                <t.icon size={14} stroke={t.color}/>
                <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{t.name}</span>
              </div>
              <div style={{ flex: 1, height: 28, background: 'var(--surface-subtle)', borderRadius: 6, position: 'relative', border: '1px solid var(--border-hairline)' }}>
                {t.segs.map((s, j) => (
                  <div key={j} style={{
                    position: 'absolute', top: 3, bottom: 3,
                    left: `${s[0]}%`, width: `${s[1] - s[0]}%`,
                    background: t.color, opacity: 0.7,
                    borderRadius: 4,
                  }}/>
                ))}
              </div>
            </div>
          ))}
        </div>
        {/* Time ruler */}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, paddingLeft: 122 }}>
          {['0:00','2:20','4:40','7:00','9:20','11:42'].map((t,i)=>(
            <span key={i} className="t-tiny" style={{ color: 'var(--fg-faint)' }}>{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

function PanePublish({ project, stage }) {
  const ch = MOCK.channels.find(c=>c.id===project.channelId);

  // Mock: which destinations are connected, and their per-platform state for this project
  const destinations = [
    { platform: 'youtube',   color: '#FF0000', icon: 'Youtube', handle: '@mythictales',  type: 'Long-form',  status: 'ready',     scheduledAt: 'Today · 6:00 PM',  aspect: '16:9', length: '11:42' },
    { platform: 'youtube',   color: '#FF0000', icon: 'Youtube', handle: '@mythictales',  type: 'Shorts cut', status: 'reformatting', scheduledAt: 'Today · 6:05 PM', aspect: '9:16', length: '0:58', extracted: 'Hook + payoff' },
    { platform: 'instagram', color: '#E1306C', icon: 'Image',   handle: '@mythictales.ig', type: 'Reel',      status: 'ready',     scheduledAt: 'Today · 7:00 PM',  aspect: '9:16', length: '0:58', extracted: 'Hook + payoff' },
    { platform: 'tiktok',    color: '#000000', icon: 'Film',    handle: '@mythictales.tt', type: 'Video',     status: 'pending_connect', scheduledAt: '—',          aspect: '9:16', length: '0:58' },
    { platform: 'x',         color: '#0F1419', icon: 'Send',    handle: '@mihir_creates',  type: 'Thread',    status: 'paused',    scheduledAt: 'Manual',           aspect: '16:9', length: '2:20', extracted: '4-tweet breakdown' },
  ];

  return (
    <div>
      <StageHeader stage={stage} state={project.stageStates.publish} blurb="Where the video goes when it's ready. We auto-reformat per platform."/>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 16 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>

          {/* Master metadata (used as base, then per-platform rewrites) */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <I.Edit size={16} stroke="var(--fg-default)"/>
              <span className="t-h5">Master title & description</span>
              <span className="t-small" style={{ marginLeft: 4 }}>auto-rewritten for each platform</span>
            </div>
            <label className="label">Title</label>
            <input defaultValue="The Lost Library of Alexandria | What was actually inside?"/>
            <div className="t-small" style={{ marginTop: 6, color: 'var(--fg-faint)' }}>54 chars · within every platform's limit</div>

            <label className="label" style={{ marginTop: 14 }}>Description</label>
            <textarea defaultValue="The largest library of the ancient world didn't die in one night. We walk you through what was inside it — and the four other times it burned.&#10;&#10;Chapters:&#10;0:00 The night · 0:38 Building it · 3:00 The fire · 7:20 The myth"/>

            <label className="label" style={{ marginTop: 14 }}>Tags</label>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {['alexandria','library','ancient history','julius caesar','egypt','mystery','documentary','ptolemy'].map(t=>(
                <span key={t} className="chip">{t} <I.Close size={10}/></span>
              ))}
              <button className="btn btn--ghost btn--sm" style={{ height: 28 }}><I.Plus size={12}/> Add</button>
            </div>
          </div>

          {/* Multi-platform distribution */}
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10 }}>
              <I.Megaphone size={16} stroke="var(--fg-default)"/>
              <span className="t-h5">Distribution</span>
              <span className="chip chip--magic"><I.Sparkles size={11}/> Auto-reformatted</span>
              <div style={{ flex: 1 }}/>
              <Btn kind="ghost" size="sm" icon={I.Plus}>Add destination</Btn>
            </div>

            {destinations.map((d, i) => (
              <div key={i} style={{
                padding: '14px 18px',
                borderBottom: i < destinations.length - 1 ? '1px solid var(--border-hairline)' : 0,
                display: 'grid', gridTemplateColumns: '40px 1fr auto auto', gap: 14, alignItems: 'center',
              }}>
                <span style={{
                  width: 40, height: 40, borderRadius: 10,
                  background: d.color, color: 'white',
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.20)',
                }}>{React.createElement(I[d.icon], { size: 18 })}</span>

                <div style={{ minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{d.platform === 'youtube' ? 'YouTube' : d.platform === 'instagram' ? 'Instagram' : d.platform === 'tiktok' ? 'TikTok' : d.platform === 'x' ? 'X' : d.platform}</span>
                    <span className="chip" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>{d.type}</span>
                    <span className="t-small" style={{ color: 'var(--fg-muted)' }}>· {d.handle}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
                    <span className="t-small">{d.aspect}</span>
                    <span style={{ color: 'var(--fg-faint)' }}>·</span>
                    <span className="t-small">{d.length}</span>
                    {d.extracted && (<>
                      <span style={{ color: 'var(--fg-faint)' }}>·</span>
                      <span className="t-small" style={{ color: 'var(--accent-fg)' }}>{d.extracted}</span>
                    </>)}
                  </div>
                </div>

                <div style={{ textAlign: 'right' }}>
                  <div className="t-tiny">When</div>
                  <div style={{ font: '600 12px/1.3 var(--font-sans)', color: 'var(--fg-default)', marginTop: 4, whiteSpace: 'nowrap' }}>{d.scheduledAt}</div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {d.status === 'ready' && <span className="chip chip--success"><I.Check size={10}/> ready</span>}
                  {d.status === 'reformatting' && <span className="chip chip--brand"><I.Spark size={10}/> reformatting</span>}
                  {d.status === 'pending_connect' && <Btn kind="secondary" size="sm" icon={I.Plus}>Connect</Btn>}
                  {d.status === 'paused' && <span className="chip">Paused</span>}
                  <button className="btn btn--ghost btn--icon btn--sm"><I.Edit size={12}/></button>
                </div>
              </div>
            ))}

            <div style={{ padding: '12px 18px', display: 'flex', gap: 10, alignItems: 'center', background: 'var(--surface-subtle)' }}>
              <I.Help size={14} stroke="var(--fg-muted)"/>
              <span className="t-small">Need more platforms? See <a href="#integrations" style={{ color: 'var(--brand)' }}>Integrations</a> for LinkedIn, Facebook, Threads, Pinterest, Reddit, Snapchat.</span>
            </div>
          </div>

          {/* Per-platform copy preview */}
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
              <span className="t-h5">Per-platform copy preview</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1, background: 'var(--border-hairline)' }}>
              {[
                { p: 'YouTube',   col: '#FF0000', icon: 'Youtube', title: 'The Lost Library of Alexandria | What was actually inside?', body: 'The largest library of the ancient world didn\'t die in one night. We walk you through what was inside it — and the four other times it burned…\n\nChapters\n0:00 The night · 0:38 Building it · 3:00 The fire · 7:20 The myth' },
                { p: 'Instagram', col: '#E1306C', icon: 'Image',   title: '',  body: 'They told you it burned in one night.\nThat\'s not what happened.\n\nThe Library of Alexandria died four more times.\nFull story up — link in bio.\n\n#history #ancientegypt #alexandria #mystery #didyouknow #curiousmind #historytok #storytelling #facts #toldyou' },
                { p: 'TikTok',    col: '#000000', icon: 'Film',    title: '',  body: 'pov: they told u the library of alexandria burned in one night… that\'s not what happened 👀\n\n#historytok #mystery #didyouknow #fyp' },
                { p: 'X',         col: '#0F1419', icon: 'Send',    title: '',  body: '1/ They told you the Library of Alexandria burned in one night.\n\nThat\'s not what happened. It died four times. Here\'s the real story 🧵' },
              ].map((c, i) => (
                <div key={i} style={{ padding: 16, background: 'var(--bg-surface)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                    <span style={{ width: 24, height: 24, borderRadius: 6, background: c.col, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{React.createElement(I[c.icon], { size: 13 })}</span>
                    <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{c.p}</span>
                    <div style={{ flex: 1 }}/>
                    <button className="btn btn--ghost btn--icon btn--sm"><I.Refresh size={11}/></button>
                  </div>
                  {c.title && <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)', marginBottom: 6 }}>{c.title}</div>}
                  <div style={{ font: '500 12px/1.5 var(--font-sans)', color: 'var(--fg-default)', whiteSpace: 'pre-line', textWrap: 'pretty' }}>{c.body}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right column — thumbnails + master schedule */}
        <div style={{ display:'flex', flexDirection:'column', gap: 12 }}>
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: 14, borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span className="t-tiny">Thumbnail / cover · A/B</span>
              <span className="chip chip--brand">3 variants</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1, background: 'var(--border-hairline)' }}>
              {['linear-gradient(135deg,#2A1810,#7B4F2C)','linear-gradient(135deg,#7B4F2C,#D4A574)','linear-gradient(135deg,#D4A574,#F38181)','linear-gradient(135deg,#F4E1B5,#2A1810)'].map((g, i) => (
                <div key={i} style={{ aspectRatio: '16/9', background: g, position: 'relative' }}>
                  {i === 0 && <span style={{ position: 'absolute', top: 6, left: 6 }} className="chip chip--success"><I.Check size={10}/> primary</span>}
                  <div style={{ position: 'absolute', bottom: 6, left: 6, right: 6, font: '800 13px/1.2 var(--font-display)', color: 'white', textShadow: '0 2px 6px rgba(0,0,0,0.7)', letterSpacing: '-0.01em', textTransform: 'uppercase' }}>The Lost Library</div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 10 }}>Master schedule</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <ChannelHeader ch={ch}/>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
              <I.Calendar size={16} stroke="var(--fg-muted)"/>
              <span style={{ font:'600 14px/1 var(--font-sans)', color:'var(--fg-strong)' }}>Today · 6:00 PM</span>
            </div>
            <div className="t-small" style={{ marginTop: 6 }}>Optimal slot · 84% confidence</div>
            <div className="divider" style={{ margin: '14px 0' }}/>
            <div className="t-tiny" style={{ marginBottom: 8 }}>Cascade offsets</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <KV k="Shorts cut" v="+5 min"/>
              <KV k="Instagram Reel" v="+60 min"/>
              <KV k="TikTok" v="+90 min"/>
              <KV k="X thread" v="manual"/>
            </div>
            <Btn kind="ghost" size="sm" icon={I.Edit} style={{ marginTop: 14, width: '100%' }}>Adjust cascade</Btn>
          </div>

          <Btn kind="magic" size="lg" icon={I.Upload}>Publish everywhere</Btn>
        </div>
      </div>
    </div>
  );
}

// helper used in publish pane
function KV({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span className="t-small">{k}</span>
      <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}</span>
    </div>
  );
}

function ProjectScreen({ project, initialStage, onBack, onAutopilot }) {
  const [activeStage, setActiveStage] = React.useState(initialStage || project.stage);

  React.useEffect(() => {
    setActiveStage(initialStage || project.stage);
  }, [project.id, initialStage]);

  const stage = STAGE_BY_ID[activeStage];

  const Pane = {
    idea:       PaneIdea,
    script:     PaneScript,
    storyboard: PaneStoryboard,
    images:     PaneImages,
    motion:     PaneMotion,
    voice:      PaneVoice,
    edit:       PaneEdit,
    publish:    PanePublish,
  }[activeStage] || PaneIdea;

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ProjectHeader project={project} onBack={onBack} onAutopilot={onAutopilot}/>
      <StageStrip project={project} activeStage={activeStage} onSelect={setActiveStage}/>
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px 40px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <Pane project={project} stage={stage}/>
        </div>
      </div>
    </div>
  );
}

window.ProjectScreen = ProjectScreen;
