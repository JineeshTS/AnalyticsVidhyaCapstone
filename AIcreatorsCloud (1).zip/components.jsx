/* ============================================================
   AIcreators.cloud — Shared Components
   Logo, Sidebar, Header, Buttons, Cards, Sparkle, Avatar, etc.
   ============================================================ */

/* ---------- Logo Mark ----------
   Custom 4-pointed AI sparkle inside a soft-cornered tile,
   with a tiny companion sparkle. Gradient violet → cyan.
*/
function LogoMark({ size = 28, glow = false }) {
  const id = React.useId();
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      width: size, height: size, borderRadius: size * 0.28,
      background: 'var(--logo-tile-bg)',
      border: '1px solid var(--logo-tile-border)',
      boxShadow: glow
        ? '0 6px 18px rgba(6,78,59,0.18), inset 0 1px 0 rgba(255,255,255,0.18)'
        : 'inset 0 1px 0 rgba(255,255,255,0.10)',
      position: 'relative', flexShrink: 0,
    }}>
      <svg width={size * 0.7} height={size * 0.7} viewBox="0 0 24 24" fill="none">
        <defs>
          <linearGradient id={`lg-${id}`} x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
            <stop offset="0%"   stopColor="var(--logo-stop-1)"/>
            <stop offset="50%"  stopColor="var(--logo-stop-2)"/>
            <stop offset="100%" stopColor="var(--logo-stop-3)"/>
          </linearGradient>
        </defs>
        {/* main 4-point star */}
        <path
          d="M12 2 C 12.6 8 14.6 10 22 12 C 14.6 14 12.6 16 12 22 C 11.4 16 9.4 14 2 12 C 9.4 10 11.4 8 12 2 Z"
          fill={`url(#lg-${id})`}/>
        {/* tiny companion sparkle */}
        <path
          d="M19 4.4 C 19.18 6 19.7 6.5 21.4 7 C 19.7 7.5 19.18 8 19 9.6 C 18.82 8 18.3 7.5 16.6 7 C 18.3 6.5 18.82 6 19 4.4 Z"
          fill="#FFFFFF" fillOpacity="0.9"/>
      </svg>
    </span>
  );
}

function Wordmark({ size = 18 }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'baseline', fontFamily: 'var(--font-display)', letterSpacing: '-0.04em' }}>
      <span style={{ fontWeight: 700, fontSize: size, color: 'var(--fg-strong)' }}>aicreators</span>
      <span style={{ fontWeight: 600, fontSize: size, color: 'var(--accent)' }}>.cloud</span>
    </span>
  );
}

function LogoLockup({ markSize = 30, wordSize = 18, glow = false }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
      <LogoMark size={markSize} glow={glow}/>
      <Wordmark size={wordSize}/>
    </span>
  );
}

/* ---------- Sparkle decoration ---------- */
function SparkleField({ count = 14, intensity = 0.6 }) {
  // deterministic pseudo-random
  const rnd = (seed) => {
    const x = Math.sin(seed * 9999) * 10000; return x - Math.floor(x);
  };
  const stars = [];
  for (let i = 0; i < count; i++) {
    const top  = rnd(i + 1) * 100;
    const left = rnd(i + 11) * 100;
    const size = 4 + rnd(i + 21) * 6;
    const delay = rnd(i + 31) * 3;
    const op = (0.3 + rnd(i + 41) * 0.5) * intensity;
    stars.push(
      <svg key={i} width={size} height={size} viewBox="0 0 24 24"
           className="sparkle-ping"
           style={{ position:'absolute', top:`${top}%`, left:`${left}%`, opacity: op, animationDelay: `${delay}s`, color: 'white' }}>
        <path d="M12 2 C 12.6 8 14.6 10 22 12 C 14.6 14 12.6 16 12 22 C 11.4 16 9.4 14 2 12 C 9.4 10 11.4 8 12 2 Z" fill="currentColor"/>
      </svg>
    );
  }
  return <div style={{ position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden' }}>{stars}</div>;
}

/* ---------- Avatar ---------- */
function Avatar({ name, size = 32, color = 'var(--violet-600)', src }) {
  const initials = (name || "U").split(/\s+/).slice(0, 2).map(s => s[0]).join("").toUpperCase();
  if (src) {
    return <img src={src} alt={name} style={{ width:size, height:size, borderRadius:'50%', objectFit:'cover', flexShrink:0 }}/>;
  }
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', justifyContent:'center',
      width:size, height:size, borderRadius:'50%',
      background: color, color:'white',
      fontWeight: 700, fontSize: size * 0.4, flexShrink:0,
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.18)',
    }}>{initials}</span>
  );
}

/* ---------- ChannelBubble (YouTube channel chip) ---------- */
function ChannelBubble({ ch, size = 32 }) {
  return (
    <span style={{
      width: size, height: size, borderRadius: '50%',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      background: ch.color, color: 'white', fontWeight: 700, fontSize: size * 0.42,
      flexShrink: 0, boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.20)',
    }}>{ch.emoji || ch.name[0]}</span>
  );
}

/* ---------- ButtonGroup ---------- */
function Btn({ children, kind = "secondary", size = "md", icon: IconComp, iconRight: IconR, ...rest }) {
  const cls = ["btn", `btn--${kind}`, size === "lg" ? "btn--lg" : size === "sm" ? "btn--sm" : ""].filter(Boolean).join(" ");
  return (
    <button className={cls} {...rest}>
      {IconComp && <IconComp size={size === "lg" ? 18 : 16}/>}
      {children}
      {IconR && <IconR size={size === "lg" ? 18 : 16}/>}
    </button>
  );
}

/* ---------- Pipeline stages definition ---------- */
const PIPELINE_STAGES = [
  { id: 'idea',       label: 'Idea',       icon: 'Spark',     blurb: 'Topic researched and approved' },
  { id: 'script',     label: 'Script',     icon: 'Edit',      blurb: 'Hook, body, CTA written' },
  { id: 'storyboard', label: 'Storyboard', icon: 'Layers',    blurb: 'Scenes & shots broken down' },
  { id: 'images',     label: 'Keyframes',  icon: 'Image',     blurb: 'AI-generated keyframes per scene' },
  { id: 'motion',     label: 'Motion',     icon: 'Film',      blurb: 'Image-to-video for consistency' },
  { id: 'voice',      label: 'Voiceover',  icon: 'Mic',       blurb: 'TTS + pacing + music bed' },
  { id: 'edit',       label: 'Assembly',   icon: 'Sliders',   blurb: 'Cuts, captions, color, sound' },
  { id: 'publish',    label: 'Publish',    icon: 'Youtube',   blurb: 'Title, thumbnail, schedule' },
];

const STAGE_BY_ID = Object.fromEntries(PIPELINE_STAGES.map((s, i) => [s.id, { ...s, index: i }]));

/* ---------- StageDot — small icon dot used in timeline ---------- */
function StageDot({ stage, state = 'todo', size = 36, onClick, active }) {
  const Ico = I[stage.icon] || I.Spark;
  const palette = {
    todo:     { bg: 'var(--surface-hover)', bd: 'var(--border-default)',   fg: 'var(--fg-faint)' },
    queued:   { bg: 'var(--surface-hover)', bd: 'var(--border-default)',   fg: 'var(--fg-muted)' },
    running:  { bg: 'var(--accent-tint-3)',  bd: 'var(--accent-border)',  fg: 'var(--accent-fg)' },
    review:   { bg: 'var(--warning-bg)',  bd: 'var(--warning-bd)',   fg: 'var(--warning)' },
    done:     { bg: 'var(--success-bg)',  bd: 'var(--success-bd)',   fg: 'var(--success)' },
    error:    { bg: 'var(--danger-bg)', bd: 'var(--danger-bd)',  fg: 'var(--danger)' },
  }[state];
  return (
    <span
      onClick={onClick}
      title={`${stage.label} · ${state}`}
      className={state === 'running' ? 'process-pulse' : ''}
      style={{
        width: size, height: size, borderRadius: 10,
        background: palette.bg, border: `1px solid ${active ? 'var(--accent)' : palette.bd}`,
        color: palette.fg, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0, cursor: onClick ? 'pointer' : 'default',
        transition: 'all 160ms var(--ease-out)',
        boxShadow: active ? '0 0 0 3px rgba(139,92,246,0.20)' : 'none',
      }}
    >
      <Ico size={size * 0.5}/>
    </span>
  );
}

/* ---------- ProgressBar ---------- */
function ProgressBar({ value, max = 100, size = 'md', gradient = true, label }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ width: '100%' }}>
      {label && <div className="t-small" style={{ marginBottom: 6, color: 'var(--fg-muted)' }}>{label}</div>}
      <div style={{
        width: '100%', height: size === 'sm' ? 4 : 6,
        background: 'var(--surface-elev)', borderRadius: 999, overflow: 'hidden',
      }}>
        <div style={{
          height: '100%', width: `${pct}%`,
          background: gradient
            ? 'linear-gradient(90deg, var(--violet-500), var(--cyan-400))'
            : 'var(--violet-500)',
          borderRadius: 999, transition: 'width 400ms var(--ease-out)',
        }}/>
      </div>
    </div>
  );
}

/* ---------- Switch (toggle) ---------- */
function Switch({ on, onChange, size = 'md', label }) {
  const w = size === 'lg' ? 48 : size === 'sm' ? 32 : 40;
  const h = size === 'lg' ? 28 : size === 'sm' ? 18 : 24;
  const knob = h - 4;
  const handle = () => onChange && onChange(!on);
  const sw = (
    <span onClick={handle} role="switch" aria-checked={on}
      style={{
        width: w, height: h, borderRadius: h,
        background: on ? 'var(--magic-grad)' : 'var(--border-default)',
        border: '1px solid', borderColor: on ? 'var(--accent-border)' : 'var(--border-default)',
        display: 'inline-flex', alignItems: 'center', padding: 2, cursor: 'pointer',
        transition: 'background 180ms var(--ease-out), border-color 180ms var(--ease-out)',
        position: 'relative', flexShrink: 0,
        boxShadow: on ? '0 0 12px rgba(139,92,246,0.40)' : 'none',
      }}>
      <span style={{
        width: knob, height: knob, borderRadius: '50%',
        background: 'white', boxShadow: '0 1px 4px rgba(0,0,0,0.40)',
        transform: `translateX(${on ? w - knob - 6 : 0}px)`,
        transition: 'transform 180ms var(--ease-out)',
      }}/>
    </span>
  );
  if (label) {
    return (
      <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
        {sw}
        <span className="t-body" style={{ color: 'var(--fg-default)' }}>{label}</span>
      </label>
    );
  }
  return sw;
}

/* ---------- Tabs ---------- */
function Tabs({ items, value, onChange }) {
  return (
    <div style={{
      display: 'inline-flex', gap: 2, padding: 4,
      background: 'var(--surface-subtle)',
      border: '1px solid var(--border-hairline)',
      borderRadius: 10,
    }}>
      {items.map(item => (
        <button key={item.id}
          onClick={() => onChange(item.id)}
          style={{
            border: 0, background: value === item.id ? 'var(--surface-active)' : 'transparent',
            color: value === item.id ? 'var(--fg-strong)' : 'var(--fg-muted)',
            padding: '6px 12px', borderRadius: 8, cursor: 'pointer',
            font: '600 13px/1 var(--font-sans)', letterSpacing: '-0.01em',
            display: 'inline-flex', alignItems: 'center', gap: 6,
          }}>
          {item.icon && <item.icon size={14}/>}
          {item.label}
        </button>
      ))}
    </div>
  );
}

/* ---------- Sidebar ---------- */
function Sidebar({ active, onNavigate, user }) {
  const nav1 = [
    { id: 'dashboard',  label: 'Production Line', icon: I.Pipeline },
    { id: 'channels',   label: 'Channels',        icon: I.Youtube },
    { id: 'topics',     label: 'Topics & Calendar', icon: I.Calendar },
    { id: 'library',    label: 'Library',         icon: I.Folder },
    { id: 'analytics',  label: 'Analytics',       icon: I.BarChart },
  ];
  const nav2 = [
    { id: 'voices',     label: 'Voice Library',   icon: I.Mic },
    { id: 'avatars',    label: 'Avatars & Lip Sync', icon: I.User },
    { id: 'styles',     label: 'Visual Styles',   icon: I.Image },
    { id: 'integrations', label: 'Integrations',  icon: I.Globe },
  ];
  const nav3 = [
    { id: 'settings',   label: 'Settings',        icon: I.Settings },
    { id: 'security',   label: 'Security · 2FA',  icon: I.Lock },
    { id: 'notif-prefs', label: 'Notifications',  icon: I.Bell },
    { id: 'api-keys',   label: 'API keys',        icon: I.Code },
    { id: 'invoices',   label: 'Invoices',        icon: I.Credit },
    { id: 'billing',    label: 'Billing & Plan',  icon: I.Credit },
    { id: 'refer',      label: 'Refer & Earn',    icon: I.Sparkles },
    { id: 'help',       label: 'Help & Support',  icon: I.Help },
  ];

  const Section = ({ title, items }) => (
    <>
      <div style={{ padding: '14px 22px 6px', font: '700 10px/1 var(--font-sans)', letterSpacing: '0.10em', color: 'var(--fg-faint)', textTransform: 'uppercase' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: '0 12px' }}>
        {items.map(it => {
          const isActive = active === it.id;
          return (
            <button key={it.id} onClick={() => onNavigate(it.id)}
              style={{
                border: 0, background: isActive ? 'var(--brand-soft-bg)' : 'transparent',
                color: isActive ? 'var(--accent-fg)' : 'var(--fg-default)',
                display: 'flex', alignItems: 'center', gap: 12,
                height: 38, padding: '0 12px', borderRadius: 10,
                font: '500 14px/1 var(--font-sans)', letterSpacing: '-0.01em',
                cursor: 'pointer', textAlign: 'left',
                transition: 'background 120ms var(--ease-out), color 120ms var(--ease-out)',
              }}
              onMouseEnter={(e)=>{ if(!isActive) e.currentTarget.style.background='var(--surface-hover)'; }}
              onMouseLeave={(e)=>{ if(!isActive) e.currentTarget.style.background='transparent'; }}>
              <it.icon size={18}/>
              <span style={{ flex: 1 }}>{it.label}</span>
              {isActive && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }}/>}
            </button>
          );
        })}
      </div>
    </>
  );

  return (
    <aside style={{
      width: 'var(--sidebar-w)', height: '100%',
      background: 'var(--glass-bg)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      borderRight: '1px solid var(--border-hairline)',
      display: 'flex', flexDirection: 'column',
      flexShrink: 0, zIndex: 2, position: 'relative',
    }}>
      {/* Logo (top) */}
      <div style={{ padding: '18px 22px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <LogoLockup markSize={30} wordSize={16}/>
      </div>

      {/* Autopilot status pill */}
      <div style={{ padding: '0 12px 8px' }}>
        <div style={{
          padding: '10px 12px', borderRadius: 12,
          background: 'var(--magic-tint)',
          border: '1px solid var(--accent-border-soft)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--success)', boxShadow: '0 0 8px var(--success)' }}/>
          <div style={{ flex: 1, lineHeight: 1.2 }}>
            <div style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>Autopilot active</div>
            <div style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 3 }}>3 videos in production</div>
          </div>
          <Switch on={true} size="sm" onChange={()=>{}}/>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 8 }}>
        <Section title="Studio" items={nav1}/>
        <Section title="Assets" items={nav2}/>
        <Section title="Account" items={nav3}/>
      </div>

      {/* User card */}
      <div style={{ padding: '10px 12px 14px' }}>
        <div style={{
          padding: 10, borderRadius: 12,
          background: 'var(--surface-subtle)',
          border: '1px solid var(--border-hairline)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <Avatar name={user.name} size={32} color="var(--magic-grad)"/>
          <div onClick={() => onNavigate('settings')} style={{ flex: 1, lineHeight: 1.2, minWidth: 0, cursor: 'pointer' }}>
            <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.name}</div>
            <div style={{ font: '500 11px/1.2 var(--font-sans)', color: 'var(--fg-muted)' }}>{user.plan}</div>
          </div>
          <button
            title="Sign out"
            aria-label="Sign out"
            onClick={(e) => { e.stopPropagation(); window.location.href = 'AIcreators Cloud Auth.html'; }}
            style={{
              width: 30, height: 30, borderRadius: 8, border: 0,
              background: 'transparent', color: 'var(--fg-muted)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
              transition: 'background 120ms var(--ease-out), color 120ms var(--ease-out)',
            }}
            onMouseEnter={e => { e.currentTarget.style.background = 'var(--danger-bg)'; e.currentTarget.style.color = 'var(--danger-fg)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--fg-muted)'; }}
          >
            <I.Logout size={15}/>
          </button>
        </div>
      </div>
      {/* Help link rail */}
      <div style={{ padding: '0 22px 14px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap' }}>
          {[
            { l: 'Terms',   href: 'AIcreators Cloud Legal.html#terms' },
            { l: 'Privacy', href: 'AIcreators Cloud Legal.html#privacy' },
            { l: 'Status',  href: 'AIcreators Cloud Status.html' },
          ].map((x, i, arr) => (
            <React.Fragment key={x.l}>
              <a href={x.href} target="_blank" rel="noopener" style={{ font: '500 11px/1.4 var(--font-sans)', color: 'var(--fg-faint)', textDecoration: 'none' }}>{x.l}</a>
              {i < arr.length - 1 && <span style={{ color: 'var(--fg-faint)', font: '500 11px/1 var(--font-sans)' }}>·</span>}
            </React.Fragment>
          ))}
        </div>
      </div>
    </aside>
  );
}

/* ---------- Header ---------- */
function Header({ title, subtitle, actions, breadcrumb }) {
  return (
    <header style={{
      height: 'var(--header-h)', flexShrink: 0,
      padding: '0 28px', display: 'flex', alignItems: 'center', gap: 16,
      borderBottom: '1px solid var(--border-hairline)',
      background: 'var(--glass-bg-header)',
      backdropFilter: 'blur(10px)',
      WebkitBackdropFilter: 'blur(10px)',
      position: 'relative', zIndex: 2,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        {breadcrumb && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
            {breadcrumb.map((b, i) => (
              <React.Fragment key={i}>
                <span style={{ font: '500 12px/1 var(--font-sans)', color: 'var(--fg-muted)' }}>{b}</span>
                {i < breadcrumb.length - 1 && <I.ChevRight size={12} stroke="var(--fg-faint)"/>}
              </React.Fragment>
            ))}
          </div>
        )}
        <div className="t-h4" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</div>
        {subtitle && <div className="t-small" style={{ marginTop: 2 }}>{subtitle}</div>}
      </div>
      {actions}
    </header>
  );
}

/* ---------- Modal scaffold ---------- */
function Modal({ open, onClose, children, width = 480 }) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, zIndex: 1000, background: 'var(--bg-scrim)',
      backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', maxWidth: width, maxHeight: '92vh', overflowY: 'auto',
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-default)',
        borderRadius: 'var(--r-xl)',
        boxShadow: 'var(--shadow-modal)',
      }}>{children}</div>
    </div>
  );
}

/* Export */
Object.assign(window, {
  LogoMark, Wordmark, LogoLockup, SparkleField, Avatar, ChannelBubble,
  Btn, StageDot, ProgressBar, Switch, Tabs, Sidebar, Header, Modal,
  PIPELINE_STAGES, STAGE_BY_ID,
});
