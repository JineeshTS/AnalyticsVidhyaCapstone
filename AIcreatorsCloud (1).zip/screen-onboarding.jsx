/* ============================================================
   AIcreators.cloud — Onboarding flow
   Welcome → Connect YouTube → Channel Identity → First idea → Done
   Designed to live in its own full-bleed surface (no sidebar).
   ============================================================ */

function OnboardingScreen({ onDone }) {
  const [step, setStep] = React.useState(0);
  const total = 5;

  return (
    <div style={{
      flex: 1, position: 'relative', overflow: 'hidden',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <SparkleField count={28} intensity={0.45}/>
      {/* Aurora wash */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(60% 50% at 50% 30%, var(--accent-tint-3) 0%, transparent 60%), radial-gradient(40% 30% at 80% 80%, var(--accent-tint-2) 0%, transparent 60%)',
        pointerEvents: 'none',
      }}/>

      {/* Header bar */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '22px 32px', display: 'flex', alignItems: 'center', zIndex: 2 }}>
        <LogoLockup markSize={32} wordSize={17}/>
        <div style={{ flex: 1 }}/>
        {step > 0 && step < total - 1 && (
          <span className="t-small">Step {step} of {total - 2}</span>
        )}
        <button className="btn btn--ghost btn--sm" onClick={onDone} style={{ marginLeft: 16 }}>Skip for now</button>
      </div>

      {/* Step progress bar */}
      {step > 0 && step < total - 1 && (
        <div style={{ position: 'absolute', top: 64, left: 32, right: 32, height: 3, background: 'var(--surface-elev)', borderRadius: 999, zIndex: 2 }}>
          <div style={{ height: '100%', width: `${(step / (total - 2)) * 100}%`, background: 'linear-gradient(90deg, var(--violet-500), var(--cyan-400))', borderRadius: 999, transition: 'width 300ms var(--ease-out)' }}/>
        </div>
      )}

      <div style={{ width: '100%', maxWidth: 720, padding: 32, position: 'relative', zIndex: 1 }}>
        {step === 0 && <OnbWelcome onNext={() => setStep(1)}/>}
        {step === 1 && <OnbConnect onNext={() => setStep(2)} onBack={() => setStep(0)}/>}
        {step === 2 && <OnbIdentity onNext={() => setStep(3)} onBack={() => setStep(1)}/>}
        {step === 3 && <OnbFirstIdea onNext={() => setStep(4)} onBack={() => setStep(2)}/>}
        {step === 4 && <OnbReady onDone={onDone}/>}
      </div>
    </div>
  );
}

function OnbWelcome({ onNext }) {
  return (
    <div style={{ textAlign: 'center' }}>
      {/* Big logo mark */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 28, position: 'relative' }}>
        <div style={{ position: 'relative' }}>
          <div style={{
            position: 'absolute', inset: -40, borderRadius: '50%',
            background: 'radial-gradient(circle, var(--accent-tint-3) 0%, transparent 70%)',
            filter: 'blur(20px)',
          }}/>
          <LogoMark size={88} glow/>
        </div>
      </div>
      <div className="t-display" style={{ marginBottom: 14, fontSize: 56 }}>
        Make videos <span className="fg-grad">on autopilot</span>.
      </div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', fontSize: 17, maxWidth: 520, margin: '0 auto', textWrap: 'pretty' }}>
        Connect a YouTube channel, tell us who it is, and we'll script, render, voice and publish — on a schedule you set. Drop in to review any step. Or don't.
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginTop: 36 }}>
        <Btn kind="magic" size="lg" icon={I.Spark} onClick={onNext}>Start your studio</Btn>
        <Btn kind="ghost" size="lg" icon={I.Play}>Watch the 90s tour</Btn>
      </div>
      <div style={{ marginTop: 40, display: 'flex', gap: 18, justifyContent: 'center', flexWrap: 'wrap' }}>
        {[
          { ic: I.Film,   t: 'Shorts · Reels · Long-form · Cartoons · Features' },
          { ic: I.Robot,  t: 'Best-fit prompting picked automatically' },
          { ic: I.Youtube, t: 'Direct YouTube publishing on schedule' },
        ].map((f, i) => (
          <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
            <f.ic size={14} stroke="var(--accent-fg)"/>
            <span className="t-small" style={{ color: 'var(--fg-default)' }}>{f.t}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function OnbConnect({ onNext, onBack }) {
  const [connected, setConnected] = React.useState(false);
  return (
    <div className="card card--lift" style={{ padding: 32, background: 'var(--glass-bg)', backdropFilter: 'blur(20px)' }}>
      <div className="t-h2" style={{ marginBottom: 6, fontSize: 30 }}>Connect a YouTube channel</div>
      <div className="t-small" style={{ marginBottom: 22 }}>We need permission to upload, schedule, and read analytics. You can disconnect any time.</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button onClick={() => setConnected(true)} style={{
          padding: 18, borderRadius: 14, border: '1px solid var(--border-default)',
          background: connected ? 'var(--success-bg)' : 'var(--surface-subtle)',
          display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer', textAlign: 'left',
          borderColor: connected ? 'rgba(52,211,153,0.40)' : 'var(--border-default)',
        }}>
          <span style={{ width: 44, height: 44, borderRadius: 10, background: '#FF0000', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.Youtube size={24} stroke="white"/>
          </span>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 16px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Sign in with Google / YouTube</div>
            <div className="t-small" style={{ marginTop: 4 }}>OAuth · we never see your password</div>
          </div>
          {connected
            ? <span className="chip chip--success"><I.Check size={10}/> Connected</span>
            : <Btn kind="primary" size="sm">Connect</Btn>}
        </button>

        <button style={{
          padding: 18, borderRadius: 14, border: '1px solid var(--border-default)',
          background: 'var(--surface-subtle)',
          display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer', textAlign: 'left',
        }}>
          <span style={{ width: 44, height: 44, borderRadius: 10, background: 'var(--surface-hover)', border: '1px solid var(--border-default)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--fg-default)' }}>
            <I.Plus size={24}/>
          </span>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 16px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Don't have one yet?</div>
            <div className="t-small" style={{ marginTop: 4 }}>We'll create a fresh channel for you, brand it, and ship the first video.</div>
          </div>
          <I.ChevRight size={18} stroke="var(--fg-muted)"/>
        </button>
      </div>

      {connected && (
        <div style={{ marginTop: 18, padding: 14, borderRadius: 12, background: 'rgba(52,211,153,0.06)', border: '1px solid rgba(52,211,153,0.24)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <I.Check size={18} stroke="var(--success)"/>
          <div style={{ flex: 1 }}>
            <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>@mythictales · 127K subscribers</div>
            <div className="t-small" style={{ marginTop: 2 }}>Upload + analytics permissions granted</div>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, marginTop: 28 }}>
        <Btn kind="ghost" onClick={onBack}>Back</Btn>
        <div style={{ flex: 1 }}/>
        <Btn kind="primary" iconRight={I.ChevRight} onClick={onNext} disabled={!connected}>Continue</Btn>
      </div>
    </div>
  );
}

function OnbIdentity({ onNext, onBack }) {
  return (
    <div className="card card--lift" style={{ padding: 32, background: 'var(--glass-bg)', backdropFilter: 'blur(20px)' }}>
      <div className="t-h2" style={{ marginBottom: 6, fontSize: 30 }}>Who is this channel?</div>
      <div className="t-small" style={{ marginBottom: 22 }}>This is the brain we'll use for every video. Be specific — boring channels eat boring scripts.</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <label className="label">What does this channel do, in one sentence?</label>
          <input defaultValue="Cinematic walk-throughs of the ancient world's strangest stories."/>
        </div>
        <div>
          <label className="label">What format are most videos?</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {[
              { id: 'shorts',   label: 'Shorts',     sub: '15–60s', icon: I.Lightning },
              { id: 'longform', label: 'Long-form',  sub: '6–14 min', icon: I.Film, active: true },
              { id: 'cartoon',  label: 'Cartoon',    sub: '2–5 min', icon: I.Image },
              { id: 'feature',  label: 'Feature',    sub: '1–3 min', icon: I.Play },
            ].map(f => (
              <button key={f.id} style={{
                border: 0, padding: 12, borderRadius: 10, cursor: 'pointer', textAlign: 'left',
                background: f.active ? 'var(--accent-tint-2)' : 'var(--surface-subtle)',
                borderColor: f.active ? 'var(--accent)' : 'var(--border-hairline)',
                borderStyle: 'solid', borderWidth: 1,
              }}>
                <f.icon size={16} stroke={f.active ? 'var(--accent-fg)' : 'var(--fg-muted)'}/>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', marginTop: 8 }}>{f.label}</div>
                <div className="t-small" style={{ marginTop: 2 }}>{f.sub}</div>
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="label">Pick a visual style</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
            {MOCK.styles.slice(0, 6).map((s, i) => (
              <div key={s.id} style={{
                aspectRatio: '16/9', borderRadius: 10, cursor: 'pointer',
                background: `linear-gradient(135deg, ${s.swatch.join(', ')})`,
                border: i === 4 ? '1px solid var(--accent)' : '1px solid var(--border-hairline)',
                boxShadow: i === 4 ? '0 0 0 3px rgba(139,92,246,0.20)' : 'none',
                position: 'relative',
              }}>
                <span style={{ position: 'absolute', bottom: 6, left: 8, font: '700 10px/1 var(--font-sans)', color: 'white', textShadow: '0 1px 2px rgba(0,0,0,0.7)' }}>{s.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 28 }}>
        <Btn kind="ghost" onClick={onBack}>Back</Btn>
        <div style={{ flex: 1 }}/>
        <Btn kind="primary" iconRight={I.ChevRight} onClick={onNext}>Continue</Btn>
      </div>
    </div>
  );
}

function OnbFirstIdea({ onNext, onBack }) {
  const [picked, setPicked] = React.useState('seed2');
  const seeds = [
    { id: 'seed1', title: 'The Lost Library of Alexandria — what was actually inside?', score: 94 },
    { id: 'seed2', title: 'The shipwreck that rewrote 200 years of history',           score: 91, ai: true },
    { id: 'seed3', title: 'How a 12-year-old kid found the Antikythera mechanism',     score: 88 },
  ];
  return (
    <div className="card card--lift" style={{ padding: 32, background: 'var(--glass-bg)', backdropFilter: 'blur(20px)' }}>
      <div className="t-h2" style={{ marginBottom: 6, fontSize: 30 }}>Let's pick your first video</div>
      <div className="t-small" style={{ marginBottom: 22 }}>We scouted the YouTube graph for ideas that fit your channel. Pick one — or write your own.</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {seeds.map(s => {
          const isPicked = picked === s.id;
          return (
            <button key={s.id} onClick={() => setPicked(s.id)} style={{
              padding: 14, borderRadius: 12, cursor: 'pointer', textAlign: 'left',
              border: '1px solid', borderColor: isPicked ? 'var(--accent)' : 'var(--border-hairline)',
              background: isPicked ? 'var(--accent-tint-1)' : 'var(--surface-subtle)',
              boxShadow: isPicked ? '0 0 0 3px rgba(139,92,246,0.16)' : 'none',
              display: 'flex', alignItems: 'center', gap: 14,
            }}>
              <span style={{
                width: 40, height: 40, borderRadius: 10,
                background: 'var(--accent-tint-2)', border: '1px solid var(--brand-soft-bd)',
                color: 'var(--accent-fg)', font: '700 14px/1 var(--font-display)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              }}>{s.score}</span>
              <div style={{ flex: 1 }}>
                <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{s.title}</div>
                <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                  {s.ai && <span className="chip chip--magic"><I.Spark size={12}/> AI scouted</span>}
                  <span className="chip">~11 min long-form</span>
                </div>
              </div>
              {isPicked && <I.Check size={20} stroke="var(--accent-fg)"/>}
            </button>
          );
        })}

        <div style={{
          padding: 14, borderRadius: 12,
          border: '1px dashed var(--border-default)',
          background: 'var(--surface-subtle)',
        }}>
          <input placeholder="…or type your own idea"/>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 28 }}>
        <Btn kind="ghost" onClick={onBack}>Back</Btn>
        <div style={{ flex: 1 }}/>
        <Btn kind="magic" iconRight={I.Spark} onClick={onNext}>Generate first video</Btn>
      </div>
    </div>
  );
}

function OnbReady({ onDone }) {
  return (
    <div style={{ textAlign: 'center', position: 'relative' }}>
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <SparkleField count={20} intensity={0.7}/>
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 28, position: 'relative' }}>
        <div style={{ position: 'relative' }}>
          <div style={{ position: 'absolute', inset: -50, borderRadius: '50%', background: 'radial-gradient(circle, var(--success-bd) 0%, transparent 70%)', filter: 'blur(20px)' }}/>
          <span style={{ width: 96, height: 96, borderRadius: 28, background: 'linear-gradient(135deg, var(--success-bd), rgba(34,211,238,0.20))', border: '1px solid var(--success-bd)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--success)', boxShadow: '0 12px 32px var(--success-bd)' }}>
            <I.Check size={48}/>
          </span>
        </div>
      </div>
      <div className="t-display" style={{ marginBottom: 14, fontSize: 48 }}>
        Your studio is <span className="fg-grad">live</span>.
      </div>
      <div className="t-body" style={{ color: 'var(--fg-secondary)', fontSize: 17, maxWidth: 520, margin: '0 auto', textWrap: 'pretty' }}>
        Your first video is being scripted now. We'll ping you the moment it's ready to publish.
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginTop: 36 }}>
        <Btn kind="magic" size="lg" icon={I.Pipeline} onClick={onDone}>Enter the studio</Btn>
      </div>
    </div>
  );
}

window.OnboardingScreen = OnboardingScreen;
