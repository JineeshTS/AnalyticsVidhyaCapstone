/* ============================================================
   AIcreators.cloud — Mobile (PWA) Preview
   Demo phone-frame with full bottom-tab navigation across
   every primary surface — Studio, Channels, Topics, Library,
   Analytics, Profile — plus a project drill-in.
   ============================================================ */

function MobilePreview() {
  const [view, setView] = React.useState('dashboard');
  const [project, setProject] = React.useState(null);
  const [video, setVideo]     = React.useState(null);

  const open = (v) => setView(v);
  const openProject = (p) => { setProject(p); setView('project'); };
  const openVideo   = (v) => { setVideo(v);   setView('video');   };

  return (
    <div style={{
      width: 380, height: 760, borderRadius: 44,
      background: 'linear-gradient(135deg, #1a1a25 0%, #0a0a14 100%)',
      border: '1px solid rgba(255,255,255,0.08)',
      boxShadow: '0 0 0 12px #050509, 0 30px 80px rgba(0,0,0,0.6)',
      padding: 10,
      flexShrink: 0,
    }}>
      <div style={{
        width: '100%', height: '100%', borderRadius: 36, overflow: 'hidden',
        background: 'var(--bg-app)', position: 'relative',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Status bar */}
        <div style={{ height: 40, paddingTop: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 22px 0', position: 'relative', zIndex: 4 }}>
          <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>9:41</span>
          <span style={{ position: 'absolute', left: '50%', top: 8, transform: 'translateX(-50%)', width: 90, height: 24, borderRadius: 14, background: '#000' }}/>
          <span style={{ display: 'inline-flex', gap: 4, color: 'var(--fg-strong)' }}>
            <span style={{ font: '700 11px/1 var(--font-sans)' }}>5G</span>
            <span style={{ width: 14, height: 9, border: '1px solid currentColor', borderRadius: 2, position: 'relative' }}>
              <span style={{ position: 'absolute', inset: 1, background: 'currentColor', width: '70%', borderRadius: 1 }}/>
            </span>
          </span>
        </div>

        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(50% 30% at 20% 10%, var(--accent-tint-3), transparent 60%), radial-gradient(40% 30% at 90% 100%, var(--accent-tint-1), transparent 60%)', pointerEvents: 'none', zIndex: 0 }}/>

        <div style={{ flex: 1, overflowY: 'auto', position: 'relative', zIndex: 1 }}>
          {view === 'dashboard' && <MobDashboard onProject={openProject}/>}
          {view === 'channels'  && <MobChannels/>}
          {view === 'topics'    && <MobTopics onProject={openProject}/>}
          {view === 'library'   && <MobLibrary onVideo={openVideo}/>}
          {view === 'analytics' && <MobAnalytics/>}
          {view === 'profile'   && <MobProfile/>}
          {view === 'project'   && project && <MobProject project={project} onBack={() => setView('dashboard')}/>}
          {view === 'video'     && video   && <MobVideoDetail video={video} onBack={() => setView('library')}/>}
        </div>

        {/* Tabbar */}
        <div style={{
          height: 84, paddingBottom: 24, paddingTop: 8,
          display: 'flex', justifyContent: 'space-around', alignItems: 'flex-start',
          background: 'var(--glass-bg)', backdropFilter: 'blur(20px)',
          borderTop: '1px solid var(--border-hairline)',
          position: 'relative', zIndex: 3,
        }}>
          {[
            { id: 'dashboard', label: 'Studio',    icon: I.Pipeline },
            { id: 'topics',    label: 'Topics',    icon: I.Spark },
            { id: 'library',   label: 'Library',   icon: I.Folder },
            { id: 'analytics', label: 'Stats',     icon: I.BarChart },
            { id: 'profile',   label: 'Profile',   icon: I.User },
          ].map(t => {
            const active = view === t.id;
            return (
              <button key={t.id} onClick={() => open(t.id)} style={{
                border: 0, background: 'transparent', cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                color: active ? 'var(--accent-fg)' : 'var(--fg-muted)', padding: 4,
              }}>
                <t.icon size={20}/>
                <span style={{ font: '600 10px/1 var(--font-sans)' }}>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ---------- Dashboard ---------- */
function MobDashboard({ onProject }) {
  return (
    <div style={{ padding: '12px 20px 16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
        <LogoMark size={32} glow/>
        <div style={{ flex: 1 }}>
          <div style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)' }}>Good evening,</div>
          <div style={{ font: '700 16px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 4 }}>Mihir 👋</div>
        </div>
        <button className="btn btn--ghost btn--icon"><I.Bell size={18}/></button>
      </div>

      <div style={{ padding: 16, borderRadius: 16, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', marginBottom: 16, position: 'relative', overflow: 'hidden' }}>
        <SparkleField count={5} intensity={0.4}/>
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--success)', boxShadow: '0 0 8px var(--success)' }}/>
            <span style={{ font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--success)', textTransform: 'uppercase' }}>Autopilot active</span>
          </div>
          <div style={{ font: '700 20px/1.2 var(--font-display)', color: 'var(--fg-strong)' }}>3 in production</div>
          <div style={{ font: '500 12px/1.4 var(--font-sans)', color: 'var(--fg-secondary)', marginTop: 4 }}>Publishing today at 6:00 PM</div>
          <button className="btn btn--magic btn--sm" style={{ marginTop: 12, width: '100%' }}><I.Spark size={14}/> New video</button>
        </div>
      </div>

      <div className="t-h5" style={{ marginBottom: 10 }}>In production</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {MOCK.projects.slice(0, 4).map(p => {
          const ch = MOCK.channels.find(c=>c.id===p.channelId);
          return (
            <div key={p.id} onClick={() => onProject(p)} style={{ display: 'flex', gap: 12, padding: 12, borderRadius: 12, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)', cursor: 'pointer' }}>
              <div style={{ width: 56, height: 36, borderRadius: 6, background: p.thumb, flexShrink: 0, border: '1px solid var(--border-hairline)' }}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: '600 12px/1.3 var(--font-sans)', color: 'var(--fg-strong)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.title}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                  <span style={{ width: 14, height: 14, borderRadius: '50%', background: ch.color, color:'white', display:'inline-flex', alignItems:'center', justifyContent:'center', font: '700 8px/1 var(--font-sans)' }}>{ch.emoji || ch.name[0]}</span>
                  <span style={{ font: '500 10px/1 var(--font-sans)', color: 'var(--fg-muted)' }}>{ch.name}</span>
                </div>
                <div style={{ marginTop: 8 }}>
                  <ProgressBar value={p.progress}/>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                    <span style={{ font: '500 10px/1 var(--font-sans)', color: 'var(--accent-fg)' }}>{STAGE_BY_ID[p.stage].label}</span>
                    <span style={{ font: '500 10px/1 var(--font-sans)', color: 'var(--fg-faint)' }}>{p.eta}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Channels ---------- */
function MobChannels() {
  return (
    <div style={{ padding: '12px 20px 16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
        <div className="t-h4" style={{ flex: 1 }}>Channels</div>
        <button className="btn btn--ghost btn--icon"><I.Plus size={18}/></button>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {MOCK.channels.map(c => (
          <div key={c.id} style={{ padding: 14, borderRadius: 14, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 44, height: 44, borderRadius: '50%', background: c.color, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 18 }}>{c.emoji || c.name[0]}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{c.name}</div>
                <div style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 4 }}>{c.handle} · {c.subs}</div>
              </div>
              <Switch on={c.autopilot} size="sm"/>
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
              <span className="chip" style={{ height: 22, fontSize: 10, padding: '0 6px' }}>{c.format}</span>
              <span className="chip" style={{ height: 22, fontSize: 10, padding: '0 6px' }}>{c.videosInQueue} queued</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Topics ---------- */
function MobTopics({ onProject }) {
  return (
    <div style={{ padding: '12px 20px 16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
        <div className="t-h4" style={{ flex: 1 }}>Topics</div>
        <button className="btn btn--ghost btn--icon"><I.Refresh size={18}/></button>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {MOCK.topicIdeas.map(t => {
          const ch = MOCK.channels.find(c => c.id === t.channelId);
          return (
            <div key={t.id} style={{ padding: 12, borderRadius: 12, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <span style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-fg)', font: '700 14px/1 var(--font-display)', flexShrink: 0 }}>{t.score}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: '500 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{t.title}</div>
                <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                  <span style={{ width: 14, height: 14, borderRadius: '50%', background: ch.color, color:'white', display:'inline-flex', alignItems:'center', justifyContent:'center', font: '700 8px/1 var(--font-sans)' }}>{ch.emoji || ch.name[0]}</span>
                  <span style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)' }}>{ch.name}</span>
                  <span style={{ color: 'var(--fg-faint)' }}>·</span>
                  <span style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)' }}>{t.est}</span>
                </div>
              </div>
              <button className="btn btn--ghost btn--icon btn--sm" style={{ width: 28, height: 28 }}><I.Spark size={12}/></button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Library ---------- */
function MobLibrary({ onVideo }) {
  const videos = MOCK.publishedRecent.concat(MOCK.publishedRecent).slice(0, 6);
  return (
    <div style={{ padding: '12px 20px 16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
        <div className="t-h4" style={{ flex: 1 }}>Library</div>
        <button className="btn btn--ghost btn--icon"><I.Search size={18}/></button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
        {videos.map((v, i) => {
          const ch = MOCK.channels.find(c=>c.id===v.channelId);
          return (
            <div key={i} onClick={() => onVideo(v)} style={{ borderRadius: 10, overflow: 'hidden', background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)', cursor: 'pointer' }}>
              <div style={{ aspectRatio: '16/9', background: v.thumb, position: 'relative' }}>
                <span style={{ position: 'absolute', bottom: 4, right: 4, font: '700 9px/1 var(--font-sans)', color: 'white', padding: '2px 5px', background: 'rgba(0,0,0,0.55)', borderRadius: 3 }}>{['11:42','0:52','3:08','2:14'][i % 4]}</span>
              </div>
              <div style={{ padding: 8 }}>
                <div style={{ font: '600 11px/1.3 var(--font-sans)', color: 'var(--fg-strong)', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{v.title}</div>
                <div style={{ font: '500 10px/1 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 4 }}>{v.views} · {v.published}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Analytics ---------- */
function MobAnalytics() {
  const W = 320, H = 100, data = [12,14,16,20,24,28,26,32,38,36,42,48,46,52,58];
  const max = Math.max(...data);
  const points = data.map((v, i) => `${(i / (data.length - 1)) * W},${H - (v / max) * (H - 14)}`);
  return (
    <div style={{ padding: '12px 20px 16px' }}>
      <div className="t-h4" style={{ marginBottom: 14 }}>Stats · 30 days</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 16 }}>
        {[
          { l: 'Views',    v: '2.4M',  d: '+18%' },
          { l: 'New subs', v: '+14.2K',d: '+24%' },
          { l: 'Watch hrs',v: '128.4K',d: 'best ever' },
          { l: 'Revenue',  v: '$2,184',d: '$1.92 RPM' },
        ].map((s, i) => (
          <div key={i} style={{ padding: 12, borderRadius: 12, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)' }}>
            <div className="t-tiny">{s.l}</div>
            <div style={{ font: '700 20px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 6, letterSpacing: '-0.02em' }}>{s.v}</div>
            <div style={{ font: '600 10px/1 var(--font-sans)', color: 'var(--success)', marginTop: 6 }}>{s.d}</div>
          </div>
        ))}
      </div>
      <div style={{ padding: 14, borderRadius: 12, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)' }}>
        <div className="t-h5" style={{ marginBottom: 10 }}>Views</div>
        <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
          <defs>
            <linearGradient id="mGr" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--brand)" stopOpacity="0.40"/>
              <stop offset="100%" stopColor="var(--brand)" stopOpacity="0"/>
            </linearGradient>
          </defs>
          <path d={`M${points.join(' L')} L${W},${H} L0,${H} Z`} fill="url(#mGr)"/>
          <path d={`M${points.join(' L')}`} fill="none" stroke="var(--brand)" strokeWidth="2"/>
        </svg>
      </div>
      <div className="t-h5" style={{ marginTop: 18, marginBottom: 10 }}>Per channel</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {MOCK.analytics.perChannel.map(c => {
          const ch = MOCK.channels.find(x=>x.id===c.id);
          return (
            <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 10, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)' }}>
              <span style={{ width: 12, height: 12, borderRadius: 3, background: c.color }}/>
              <span style={{ flex: 1, font: '500 12px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{ch.name}</span>
              <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{c.views}</span>
              <span className="t-small" style={{ width: 36, textAlign: 'right' }}>{c.pct}%</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Profile / Settings ---------- */
function MobProfile() {
  const rows = [
    { ic: I.Spark,    l: 'Autopilot rules' },
    { ic: I.Robot,    l: 'AI models' },
    { ic: I.Mic,      l: 'Voice Library' },
    { ic: I.User,     l: 'Avatars & Lip Sync' },
    { ic: I.Image,    l: 'Visual Styles' },
    { ic: I.Globe,    l: 'Integrations' },
    { ic: I.Bell,     l: 'Notifications' },
    { ic: I.Lock,     l: 'Security · 2FA' },
    { ic: I.Code,     l: 'API keys' },
    { ic: I.Credit,   l: 'Billing & invoices' },
    { ic: I.Sparkles, l: 'Refer & Earn' },
    { ic: I.Help,     l: 'Help & Support' },
    { ic: I.Logout,   l: 'Log out',  danger: true },
  ];
  return (
    <div style={{ padding: '12px 20px 16px' }}>
      <div className="card" style={{ padding: 14, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
        <Avatar name="Mihir Vaishnav" size={48} color="var(--magic-grad)"/>
        <div style={{ flex: 1 }}>
          <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Mihir Vaishnav</div>
          <div style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 4 }}>Studio Pro · 2,840 / 5,000 credits</div>
        </div>
        <I.ChevRight size={16} stroke="var(--fg-muted)"/>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--border-hairline)', borderRadius: 12, overflow: 'hidden' }}>
        {rows.map((r, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', background: 'var(--bg-surface)', cursor: 'pointer' }}>
            <r.ic size={16} stroke={r.danger ? 'var(--danger)' : 'var(--fg-default)'}/>
            <span style={{ flex: 1, font: '500 13px/1 var(--font-sans)', color: r.danger ? 'var(--danger)' : 'var(--fg-default)' }}>{r.l}</span>
            {!r.danger && <I.ChevRight size={14} stroke="var(--fg-muted)"/>}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Project drill-in ---------- */
function MobProject({ project, onBack }) {
  const ch = MOCK.channels.find(c => c.id === project.channelId);
  return (
    <div>
      <div style={{ aspectRatio: '16/10', background: project.thumb, position: 'relative' }}>
        <button onClick={onBack} className="btn btn--icon" style={{ position: 'absolute', top: 12, left: 14, width: 36, height: 36, background: 'rgba(0,0,0,0.45)', borderColor: 'rgba(255,255,255,0.20)', color: 'white', borderRadius: 999 }}>
          <I.ChevLeft size={18}/>
        </button>
        <button className="btn btn--icon" style={{ position: 'absolute', top: 12, right: 14, width: 36, height: 36, background: 'rgba(0,0,0,0.45)', borderColor: 'rgba(255,255,255,0.20)', color: 'white', borderRadius: 999 }}>
          <I.More size={18}/>
        </button>
        <span style={{ position: 'absolute', bottom: 12, right: 14, font: '700 11px/1 var(--font-sans)', color: 'white', padding: '4px 8px', background: 'rgba(0,0,0,0.55)', borderRadius: 6 }}>{project.duration}</span>
      </div>

      <div style={{ padding: '14px 20px 20px' }}>
        <div className="t-h5" style={{ fontSize: 17 }}>{project.title}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
          <span style={{ width: 18, height: 18, borderRadius: '50%', background: ch.color, color:'white', display:'inline-flex', alignItems:'center', justifyContent:'center', font: '700 9px/1 var(--font-sans)' }}>{ch.emoji}</span>
          <span style={{ font: '500 12px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{ch.name}</span>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <Switch on={project.autopilot} label="Autopilot" size="sm"/>
        </div>

        <div className="divider" style={{ margin: '16px 0' }}/>

        <div className="t-tiny" style={{ marginBottom: 10 }}>Pipeline</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {PIPELINE_STAGES.map(s => {
            const state = project.stageStates[s.id] || 'todo';
            const Ico = I[s.icon];
            return (
              <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, background: 'var(--surface-subtle)', border: '1px solid var(--border-hairline)' }}>
                <span className={state === 'running' ? 'process-pulse' : ''} style={{
                  width: 32, height: 32, borderRadius: 8,
                  background: state === 'done' ? 'var(--success-bg)' : state === 'running' ? 'var(--accent-tint-3)' : state === 'review' ? 'var(--warning-bg)' : 'var(--surface-subtle)',
                  border: `1px solid ${state === 'done' ? 'var(--success-bd)' : state === 'running' ? 'var(--accent-border)' : state === 'review' ? 'var(--warning-bd)' : 'var(--border-default)'}`,
                  color: state === 'done' ? 'var(--success)' : state === 'running' ? 'var(--accent-fg)' : state === 'review' ? 'var(--warning)' : 'var(--fg-faint)',
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {state === 'done' ? <I.Check size={14}/> : <Ico size={14}/>}
                </span>
                <span style={{ flex: 1, font: '600 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{s.label}</span>
                {state === 'running' && <span className="chip chip--brand" style={{ height: 22, fontSize: 10, padding: '0 8px' }}>{project.progress}%</span>}
                {state === 'done' && <I.Check size={14} stroke="var(--success)"/>}
              </div>
            );
          })}
        </div>

        <button className="btn btn--magic btn--lg" style={{ width: '100%', marginTop: 16 }}>
          <I.Eye size={16}/> Preview latest cut
        </button>
      </div>
    </div>
  );
}

/* ---------- Video detail (mobile) ---------- */
function MobVideoDetail({ video, onBack }) {
  const ch = MOCK.channels.find(c => c.id === video.channelId);
  return (
    <div>
      <div style={{ aspectRatio: '16/9', background: video.thumb, position: 'relative' }}>
        <button onClick={onBack} className="btn btn--icon" style={{ position: 'absolute', top: 12, left: 14, width: 36, height: 36, background: 'rgba(0,0,0,0.45)', borderColor: 'rgba(255,255,255,0.20)', color: 'white', borderRadius: 999 }}>
          <I.ChevLeft size={18}/>
        </button>
        <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 56, height: 56, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'white' }}>
          <I.Play size={24}/>
        </span>
      </div>
      <div style={{ padding: '14px 20px 20px' }}>
        <div className="t-h5" style={{ fontSize: 16 }}>{video.title}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
          <span style={{ width: 18, height: 18, borderRadius: '50%', background: ch.color, color:'white', display:'inline-flex', alignItems:'center', justifyContent:'center', font: '700 9px/1 var(--font-sans)' }}>{ch.emoji}</span>
          <span style={{ font: '500 12px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{ch.name}</span>
          <span style={{ color: 'var(--fg-faint)' }}>·</span>
          <span className="t-small">{video.published}</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 14 }}>
          {[['Views', video.views], ['CTR', video.ctr], ['AVD', video.avd]].map(([l, v]) => (
            <div key={l} style={{ padding: 10, borderRadius: 10, background: 'var(--bg-surface)', border: '1px solid var(--border-hairline)' }}>
              <div className="t-tiny">{l}</div>
              <div style={{ font: '700 15px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 4 }}>{v}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 14 }}>
          <Btn kind="primary" size="sm" icon={I.Eye}>Open on YouTube</Btn>
          <Btn kind="secondary" size="sm" icon={I.Copy}>Clone & remix</Btn>
          <Btn kind="ghost" size="sm" icon={I.BarChart}>Full analytics</Btn>
        </div>
      </div>
    </div>
  );
}

window.MobilePreview = MobilePreview;
