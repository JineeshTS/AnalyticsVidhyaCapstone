/* ============================================================
   AIcreators.cloud — Icon Library
   Stroke-1.6 inline SVGs at 22px in 24px frame, Lucide/Vuesax style.
   ============================================================ */

const Icon = ({ size = 20, stroke = "currentColor", strokeWidth = 1.7, fill = "none", children, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
       stroke={stroke} strokeWidth={strokeWidth}
       strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {children}
  </svg>
);

const I = {
  Sparkles:  (p)=> <Icon {...p}><path d="M12 3l1.7 4.5L18 9l-4.3 1.5L12 15l-1.7-4.5L6 9l4.3-1.5z"/><path d="M19 14l.8 2 2 .8-2 .8L19 19.6l-.8-2-2-.8 2-.8z"/><path d="M5 4l.5 1.3L7 5.7l-1.5.5L5 7.6 4.5 6.2 3 5.7l1.5-.4z"/></Icon>,
  Spark:     (p)=> <Icon {...p}><path d="M12 2l1.6 6.4L20 10l-6.4 1.6L12 18l-1.6-6.4L4 10l6.4-1.6z"/></Icon>,
  Home:      (p)=> <Icon {...p}><path d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-3v-7H10v7H5a2 2 0 0 1-2-2z"/></Icon>,
  Pipeline:  (p)=> <Icon {...p}><circle cx="5" cy="7" r="2.2"/><circle cx="12" cy="17" r="2.2"/><circle cx="19" cy="7" r="2.2"/><path d="M5 9v2a3 3 0 0 0 3 3h2"/><path d="M19 9v2a3 3 0 0 1-3 3h-2"/></Icon>,
  Calendar:  (p)=> <Icon {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="16" y1="3" x2="16" y2="7"/></Icon>,
  Youtube:   (p)=> <Icon {...p}><rect x="2.5" y="5" width="19" height="14" rx="3"/><polygon points="10,9 15.5,12 10,15" fill="currentColor" stroke="none"/></Icon>,
  Film:      (p)=> <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></Icon>,
  Image:     (p)=> <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></Icon>,
  Mic:       (p)=> <Icon {...p}><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0"/><line x1="12" y1="18" x2="12" y2="22"/></Icon>,
  Wand:      (p)=> <Icon {...p}><path d="M15 4l-1 1"/><path d="M20 9l-1 1"/><path d="M19 4l1 1"/><path d="M14 9l1 1"/><path d="M16.5 6.5l-12 12"/><path d="M3 18l3 3"/></Icon>,
  Play:      (p)=> <Icon {...p}><polygon points="6,4 20,12 6,20" fill="currentColor" stroke="none"/></Icon>,
  Pause:     (p)=> <Icon {...p}><rect x="6" y="4" width="4" height="16" rx="1" fill="currentColor" stroke="none"/><rect x="14" y="4" width="4" height="16" rx="1" fill="currentColor" stroke="none"/></Icon>,
  Plus:      (p)=> <Icon {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Icon>,
  Search:    (p)=> <Icon {...p}><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/></Icon>,
  Settings:  (p)=> <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6 1.65 1.65 0 0 0 10 3.09V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.18.44.27.92.27 1.4 0 .48-.09.96-.27 1.4z"/></Icon>,
  Bell:      (p)=> <Icon {...p}><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></Icon>,
  ChevDown:  (p)=> <Icon {...p}><polyline points="6,9 12,15 18,9"/></Icon>,
  ChevUp:    (p)=> <Icon {...p}><polyline points="18,15 12,9 6,15"/></Icon>,
  ChevRight: (p)=> <Icon {...p}><polyline points="9,18 15,12 9,6"/></Icon>,
  ChevLeft:  (p)=> <Icon {...p}><polyline points="15,18 9,12 15,6"/></Icon>,
  ArrowUR:   (p)=> <Icon {...p}><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7,7 17,7 17,17"/></Icon>,
  ArrowRight:(p)=> <Icon {...p}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12,5 19,12 12,19"/></Icon>,
  Close:     (p)=> <Icon {...p}><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></Icon>,
  Check:     (p)=> <Icon {...p}><polyline points="20,6 9,17 4,12"/></Icon>,
  Upload:    (p)=> <Icon {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/></Icon>,
  Download:  (p)=> <Icon {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></Icon>,
  More:      (p)=> <Icon {...p}><circle cx="5"  cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/></Icon>,
  Edit:      (p)=> <Icon {...p}><path d="M11 4H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2v-6"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"/></Icon>,
  Trash:     (p)=> <Icon {...p}><polyline points="3,6 5,6 21,6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></Icon>,
  Eye:       (p)=> <Icon {...p}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></Icon>,
  User:      (p)=> <Icon {...p}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></Icon>,
  Users:     (p)=> <Icon {...p}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></Icon>,
  Layers:    (p)=> <Icon {...p}><polygon points="12,2 2,7 12,12 22,7"/><polyline points="2,17 12,22 22,17"/><polyline points="2,12 12,17 22,12"/></Icon>,
  Folder:    (p)=> <Icon {...p}><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></Icon>,
  Cloud:     (p)=> <Icon {...p}><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></Icon>,
  Lightning: (p)=> <Icon {...p}><polygon points="13,2 3,14 12,14 11,22 21,10 12,10 13,2" fill="currentColor" fillOpacity="0.0"/></Icon>,
  Globe:     (p)=> <Icon {...p}><circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></Icon>,
  Clock:     (p)=> <Icon {...p}><circle cx="12" cy="12" r="9"/><polyline points="12,7 12,12 16,14"/></Icon>,
  ThumbUp:   (p)=> <Icon {...p}><path d="M7 10v12"/><path d="M15 5.88L14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H6a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L14 2h0a3.13 3.13 0 0 1 1 5.88z"/></Icon>,
  Send:      (p)=> <Icon {...p}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22,2 15,22 11,13 2,9"/></Icon>,
  TrendUp:   (p)=> <Icon {...p}><polyline points="22,7 13.5,15.5 8.5,10.5 2,17"/><polyline points="16,7 22,7 22,13"/></Icon>,
  BarChart:  (p)=> <Icon {...p}><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6"  y1="20" x2="6"  y2="14"/></Icon>,
  Logout:    (p)=> <Icon {...p}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></Icon>,
  Lock:      (p)=> <Icon {...p}><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></Icon>,
  Credit:    (p)=> <Icon {...p}><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></Icon>,
  Refresh:   (p)=> <Icon {...p}><polyline points="23,4 23,10 17,10"/><polyline points="1,20 1,14 7,14"/><path d="M3.5 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></Icon>,
  Robot:     (p)=> <Icon {...p}><rect x="4" y="7" width="16" height="13" rx="3"/><circle cx="9" cy="13" r="1.4" fill="currentColor" stroke="none"/><circle cx="15" cy="13" r="1.4" fill="currentColor" stroke="none"/><path d="M12 4v3"/><circle cx="12" cy="3" r="1" fill="currentColor" stroke="none"/></Icon>,
  Megaphone: (p)=> <Icon {...p}><path d="M3 11l13-5v12L3 13z"/><path d="M16 9v6"/><path d="M19 8v8"/><path d="M5 14v3a2 2 0 0 0 4 0v-2"/></Icon>,
  Languages: (p)=> <Icon {...p}><path d="M5 5h7"/><path d="M9 3v2c0 6-4 7-4 7"/><path d="M5 9c0 3 3 5 6 5"/><path d="M14 21l4-9 4 9"/><path d="M15.5 18h5"/></Icon>,
  Pin:       (p)=> <Icon {...p}><path d="M12 21v-7"/><path d="M9 14h6l-1-7H10z"/><path d="M9 7h6"/></Icon>,
  Sliders:   (p)=> <Icon {...p}><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></Icon>,
  Filter:    (p)=> <Icon {...p}><polygon points="22,3 2,3 10,12.5 10,19 14,21 14,12.5"/></Icon>,
  Help:      (p)=> <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4"/><line x1="12" y1="17.5" x2="12" y2="17.51"/></Icon>,
  Copy:      (p)=> <Icon {...p}><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></Icon>,
  Hourglass: (p)=> <Icon {...p}><path d="M6 2h12"/><path d="M6 22h12"/><path d="M7 2v3a5 5 0 0 0 10 0V2"/><path d="M7 22v-3a5 5 0 0 1 10 0v3"/></Icon>,
  Ticket:    (p)=> <Icon {...p}><path d="M3 8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4z"/><line x1="12" y1="6" x2="12" y2="18" strokeDasharray="2 3"/></Icon>,
  GIF:       (p)=> <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/></Icon>,
  Drag:      (p)=> <Icon {...p}><circle cx="9" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="9" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="9" cy="18" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="18" r="1" fill="currentColor" stroke="none"/></Icon>,
  Code:      (p)=> <Icon {...p}><polyline points="16,18 22,12 16,6"/><polyline points="8,6 2,12 8,18"/></Icon>,
  Key:       (p)=> <Icon {...p}><circle cx="8" cy="15" r="4"/><path d="M10.85 12.15L19 4"/><path d="M18 5l2 2"/><path d="M15 8l2 2"/></Icon>,
  Mail:      (p)=> <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 7 9-7"/></Icon>,
  Sun:       (p)=> <Icon {...p}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></Icon>,
  Moon:      (p)=> <Icon {...p}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></Icon>,
  Activity:  (p)=> <Icon {...p}><polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/></Icon>,
  Warn:      (p)=> <Icon {...p}><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12" y2="17.01"/></Icon>,
  Message:   (p)=> <Icon {...p}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></Icon>,
};

window.I = I;
