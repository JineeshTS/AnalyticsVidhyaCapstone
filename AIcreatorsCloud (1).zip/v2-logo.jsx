/* ============================================================
   AIcreators V2 — Logo + brand mark
   ============================================================
   Mark concept: a film APERTURE (camera iris) fused with a PLAY
   triangle. The iris has 6 blades — 4 lime, 2 amber-tinted to
   represent the autopilot (AI) and human-review states. The
   wedge cut on the right reads as a play button.

   Three lockups:
     <LogoMark/>        — just the symbol
     <Wordmark/>        — just the text
     <Logo/>            — full lockup
     <LogoBig/>         — hero size with orbital ring
   ============================================================ */

function LogoMark({ size = 32 }) {
  const id = React.useId();
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" style={{ flexShrink: 0 }}>
      <defs>
        <linearGradient id={`lm-lime-${id}`} x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0%"   stopColor="#E9FF99"/>
          <stop offset="50%"  stopColor="#CCFF00"/>
          <stop offset="100%" stopColor="#9FCC00"/>
        </linearGradient>
        <linearGradient id={`lm-amb-${id}`} x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0%"   stopColor="#FFB45A"/>
          <stop offset="100%" stopColor="#FF9F1C"/>
        </linearGradient>
      </defs>
      {/* outer ring */}
      <circle cx="32" cy="32" r="29" stroke="rgba(255,255,255,0.08)" strokeWidth="2"/>
      {/* aperture blades (5 lime, 1 amber for the "review" wedge) */}
      {/* Each blade is a triangle from the center outward, rotated. */}
      {[0,60,120,180,240,300].map((deg, i) => {
        const fillId = i === 5 ? `lm-amb-${id}` : `lm-lime-${id}`;
        return (
          <g key={i} transform={`rotate(${deg} 32 32)`}>
            <path
              d="M32 32 L42 12 A22 22 0 0 1 50 22 Z"
              fill={`url(#${fillId})`}
            />
          </g>
        );
      })}
      {/* center dot — the play "lens" */}
      <circle cx="32" cy="32" r="7" fill="#050507"/>
      <circle cx="32" cy="32" r="5" fill="url(#lm-lime-${id})" opacity="0.0"/>
      {/* play triangle inside the lens */}
      <path d="M30 28 L37 32 L30 36 Z" fill="#CCFF00"/>
    </svg>
  );
}

function Wordmark({ size = 22 }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'baseline', fontFamily: 'var(--font-display)', letterSpacing: '-0.04em' }}>
      <span style={{ fontWeight: 700, fontSize: size, color: 'var(--fg-strong)' }}>aicreators</span>
      <span style={{ fontWeight: 600, fontSize: size, color: 'var(--accent)' }}>.cloud</span>
    </span>
  );
}

function Logo({ markSize = 32, wordSize = 22, gap = 10 }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap }}>
      <LogoMark size={markSize}/>
      <Wordmark size={wordSize}/>
    </span>
  );
}

function LogoBig({ size = 200 }) {
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      {/* orbital ring */}
      <div className="orbit" style={{
        position: 'absolute', inset: -20,
        borderRadius: '50%',
        border: '1px dashed rgba(204,255,0,0.30)',
        pointerEvents: 'none',
      }}/>
      <div style={{
        position: 'absolute', inset: -10,
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(204,255,0,0.18) 0%, transparent 60%)',
        filter: 'blur(20px)',
        pointerEvents: 'none',
      }}/>
      <div style={{ position: 'relative', width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <LogoMark size={size}/>
      </div>
    </div>
  );
}

window.LogoMark = LogoMark;
window.Wordmark = Wordmark;
window.Logo = Logo;
window.LogoBig = LogoBig;
