/* ============================================================
   AIcreators.cloud · Admin shell
   ============================================================

   This is the operator/ops console. It is intentionally SEPARATE
   from the customer app — different bundle, different auth domain,
   different deploy target.

   ROUTING
     #overview | #users | #user/{id} | #jobs | #models | #gpu
     #moderation | #channels | #plans | #tickets | #audit

   AUTH (backend)
     - JWT cookie `aic_admin_session`
     - Verify on every request via /admin/me
     - 401 → redirect to /admin/login
     - 403 → render "you don't have access" stub

   ENV VARS the backend needs
     - DATABASE_URL
     - REDIS_URL
     - YOUTUBE_OAUTH_CLIENT_ID / SECRET
     - STRIPE_SECRET_KEY / WEBHOOK_SECRET
     - JWT_ADMIN_SECRET
     - S3_BUCKET + AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY
     - OPENAI_API_KEY (or equivalent LLM provider)
     - REPLICATE_API_KEY (or equivalent T2I/I2V/TTS)
     - SENTRY_DSN

   See HANDOFF.md for full API map.
   ============================================================ */

const { useState: useStateA, useEffect: useEffectA } = React;

function AdminSidebar({ active, onNavigate }) {
  const nav1 = [
    { id: 'overview',   label: 'Overview',     icon: I.Activity },
    { id: 'users',      label: 'Users',        icon: I.Users },
    { id: 'jobs',       label: 'Jobs queue',   icon: I.Pipeline },
    { id: 'moderation', label: 'Moderation',   icon: I.Eye },
    { id: 'tickets',    label: 'Support',      icon: I.Ticket },
  ];
  const nav2 = [
    { id: 'models',     label: 'Models',       icon: I.Robot },
    { id: 'gpu',        label: 'GPU pool',     icon: I.Lightning },
    { id: 'channels',   label: 'Channels',     icon: I.Youtube },
    { id: 'cohorts',    label: 'Cohorts',      icon: I.TrendUp },
    { id: 'flags',      label: 'Feature flags', icon: I.Spark },
  ];
  const nav3 = [
    { id: 'plans',      label: 'Plans & coupons', icon: I.Credit },
    { id: 'refunds',    label: 'Refunds',         icon: I.Credit },
    { id: 'emails',     label: 'Email templates', icon: I.Mail },
    { id: 'api',        label: 'API & webhooks',  icon: I.Code },
    { id: 'dsar',       label: 'Privacy requests', icon: I.Lock },
    { id: 'audit',      label: 'Audit log',       icon: I.Lock },
  ];

  const Section = ({ title, items }) => (
    <>
      <div style={{ padding: '14px 22px 6px', font: '700 10px/1 var(--font-sans)', letterSpacing: '0.10em', color: 'var(--fg-faint)', textTransform: 'uppercase' }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: '0 12px' }}>
        {items.map(it => {
          const isActive = active === it.id || (active === 'user' && it.id === 'users');
          return (
            <button key={it.id} onClick={() => onNavigate(it.id)}
              style={{
                border: 0, background: isActive ? 'var(--brand-soft-bg)' : 'transparent',
                color: isActive ? 'var(--brand-fg)' : 'var(--fg-default)',
                display: 'flex', alignItems: 'center', gap: 12,
                height: 38, padding: '0 12px', borderRadius: 10,
                font: '500 14px/1 var(--font-sans)', letterSpacing: '-0.01em',
                cursor: 'pointer', textAlign: 'left',
                transition: 'background 120ms var(--ease-out)',
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = 'var(--surface-hover)'; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}>
              <it.icon size={18}/>
              <span style={{ flex: 1 }}>{it.label}</span>
              {isActive && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--brand)' }}/>}
            </button>
          );
        })}
      </div>
    </>
  );

  return (
    <aside style={{
      width: 'var(--sidebar-w)', height: '100%',
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-hairline)',
      display: 'flex', flexDirection: 'column',
      flexShrink: 0, zIndex: 2, position: 'relative',
    }}>
      <div style={{ padding: '18px 22px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, whiteSpace: 'nowrap' }}>
          <LogoMark size={28}/>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, letterSpacing: '-0.02em', color: 'var(--fg-strong)' }}>AIcreators</span>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 10, letterSpacing: '0.10em', color: 'var(--fg-muted)', textTransform: 'uppercase' }}>· admin</span>
        </span>
      </div>

      <div style={{ padding: '0 12px 8px' }}>
        <div style={{
          padding: '10px 12px', borderRadius: 12,
          background: 'var(--danger-bg)',
          border: '1px solid var(--danger-bd)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--danger)', boxShadow: '0 0 8px var(--danger)' }}/>
          <div style={{ flex: 1, lineHeight: 1.2 }}>
            <div style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--danger-fg)' }}>1 alert</div>
            <div style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 3 }}>GPU A100-W4 down</div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 8 }}>
        <Section title="Operate" items={nav1}/>
        <Section title="Infra" items={nav2}/>
        <Section title="Business" items={nav3}/>
      </div>

      <div style={{ padding: '10px 12px 14px' }}>
        <a href="AIcreators Cloud.html" style={{
          padding: 10, borderRadius: 12,
          background: 'var(--surface-subtle)',
          border: '1px solid var(--border-hairline)',
          display: 'flex', alignItems: 'center', gap: 10,
          textDecoration: 'none',
        }}>
          <Avatar name={ADMIN.operator.name} size={32}/>
          <div style={{ flex: 1, lineHeight: 1.2, minWidth: 0 }}>
            <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{ADMIN.operator.name}</div>
            <div style={{ font: '500 11px/1.2 var(--font-sans)', color: 'var(--fg-muted)' }}>{ADMIN.operator.role}</div>
          </div>
          <I.ChevRight size={16} stroke="var(--fg-muted)"/>
        </a>
      </div>
    </aside>
  );
}

function AdminApp() {
  const [route, setRoute] = useStateA(() => {
    const hash = (window.location.hash || '').replace(/^#/, '');
    if (hash) {
      const parts = hash.split('/');
      return { name: parts[0] || 'overview', params: parts.slice(1) };
    }
    return { name: 'overview', params: [] };
  });
  const [activeUser, setActiveUser] = useStateA(null);
  const [activeJob, setActiveJob]   = useStateA(null);
  const [activeTicket, setActiveTicket] = useStateA(null);

  const go = (name, ...params) => {
    setRoute({ name, params });
    window.location.hash = [name, ...params].join('/');
  };

  const openUser = (u) => { setActiveUser(u); go('user', u.id); };
  const openJob = (j) => { setActiveJob(j); go('job', j.id); };
  const openTicket = (t) => { setActiveTicket(t); go('ticket', t.id); };

  useEffectA(() => {
    if (route.name === 'user' && route.params[0] && !activeUser) {
      const u = ADMIN.users.find(x => x.id === route.params[0]);
      if (u) setActiveUser(u);
    }
  }, [route.name]);

  const title = {
    overview:   'Overview',
    users:      'Users',
    user:       activeUser ? activeUser.name : 'User',
    jobs:       'Jobs queue',
    job:        activeJob ? `Job ${activeJob.id}` : 'Job',
    models:     'Models',
    gpu:        'GPU pool',
    moderation: 'Moderation',
    channels:   'Channels',
    plans:      'Plans & coupons',
    refunds:    'Refunds',
    emails:     'Email templates',
    api:        'API & webhooks',
    dsar:       'Privacy requests · DSAR',
    tickets:    'Support tickets',
    ticket:     'Ticket',
    cohorts:    'Cohorts & retention',
    flags:      'Feature flags',
    audit:      'Audit log',
  }[route.name] || 'Admin';

  const subtitle = {
    overview:   'KPIs, MRR, system health',
    users:      'Search, filter, impersonate',
    user:       activeUser ? activeUser.email : '',
    jobs:       'Every pipeline job, realtime',
    job:        'Live logs · retry · cancel',
    models:     'Usage, cost, latency per model',
    gpu:        'GPU pool utilisation across regions',
    moderation: 'Content flagged for human review',
    channels:   'All YouTube OAuth connections',
    plans:      'Pricing tiers + coupon codes',
    refunds:    'Pending requests · approved · rejected',
    emails:     'Transactional email templates',
    api:        'Developer API keys + outgoing webhooks',
    tickets:    'Open support tickets',
    ticket:     'Conversation · canned replies · context',
    cohorts:    'Retention heatmap · LTV · M1/M3/M6',
    flags:      'Rollout · experiments · targeting',
    audit:      'Immutable admin action log',
  }[route.name] || '';

  return (
    <div style={{ height: '100%', display: 'flex', position: 'relative', zIndex: 1 }}>
      <AdminSidebar active={route.name} onNavigate={go}/>
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>
        {route.name === 'user' && activeUser
          ? <AdminUserDetail user={activeUser} onBack={() => go('users')}/>
        : route.name === 'job'
          ? <AdminJobDetail jobId={activeJob?.id || route.params[0]} onBack={() => go('jobs')}/>
        : route.name === 'ticket'
          ? <AdminTicketThread ticketId={activeTicket?.id || route.params[0]} onBack={() => go('tickets')}/>
          : <>
              <Header title={title} subtitle={subtitle} actions={<AdminTopBar/>}/>
              {route.name === 'overview'   && <AdminOverview/>}
              {route.name === 'users'      && <AdminUsers onOpenUser={openUser}/>}
              {route.name === 'jobs'       && <AdminJobs onOpenJob={openJob}/>}
              {route.name === 'models'     && <AdminModels/>}
              {route.name === 'gpu'        && <AdminGPU/>}
              {route.name === 'moderation' && <AdminModeration/>}
              {route.name === 'channels'   && <AdminChannels/>}
              {route.name === 'plans'      && <AdminPlans/>}
              {route.name === 'refunds'    && <AdminRefunds/>}
              {route.name === 'emails'     && <AdminEmailTemplates/>}
              {route.name === 'api'        && <AdminAPIKeys/>}
              {route.name === 'cohorts'    && <AdminCohorts/>}
              {route.name === 'flags'      && <AdminFlags/>}
              {route.name === 'dsar'       && <AdminDSAR/>}
              {route.name === 'tickets'    && <AdminTickets onOpenTicket={openTicket}/>}
              {route.name === 'audit'      && <AdminAudit/>}
            </>
        }
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<AdminApp/>);
