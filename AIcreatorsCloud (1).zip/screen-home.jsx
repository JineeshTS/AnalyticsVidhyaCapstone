/* ============================================================
   AIcreators.cloud · Marketing landing page
   ============================================================
   PURPOSE
     Public, unauthenticated homepage. Converts cold visitors
     to signups. Lives at aicreators.cloud (apex).

   SECTIONS (in scroll order)
     1. Top nav (logo · features · pricing · docs · sign in · sign up)
     2. Hero — headline + value prop + dual CTA + product peek
     3. Social proof — logo wall + creator stats
     4. The Production Line — animated 8-stage explainer
     5. Multi-platform demo — one video, all platforms
     6. Voice & avatar feature row
     7. Visual styles strip
     8. Autopilot explanation
     9. Channel showcase (faceless YT examples)
     10. Pricing (3 tiers)
     11. FAQ accordion
     12. Final CTA
     13. Footer

   This is a SHIPPABLE marketing page — copy written assuming a
   creator-economy audience, not enterprise. We can ship a
   second variant for enterprise later.

   PERFORMANCE / SEO NOTES (for backend dev)
     - Render server-side (Next.js / Astro / etc.) for indexability
     - Lazy-load below-the-fold sections
     - Pre-render OG image with channel screenshot
     - Schema.org SoftwareApplication + Product markup
     - Sitemap incl. all /legal/* slugs
   ============================================================ */

function MarketingHomeApp() {
  const [openFAQ, setOpenFAQ] = React.useState(0);
  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-app)', overflowY: 'auto', overflowX: 'hidden' }}>

      {/* TOP NAV */}
      <MarketingNav/>

      {/* HERO */}
      <section style={{ position: 'relative', padding: '64px 32px 80px', overflow: 'hidden' }}>
        <SparkleField count={14} intensity={0.25}/>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(50% 50% at 75% 20%, var(--accent-tint-3) 0%, transparent 60%), radial-gradient(40% 40% at 20% 80%, var(--accent-tint-2) 0%, transparent 60%)', pointerEvents: 'none' }}/>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'center', position: 'relative', zIndex: 1 }}>
          <div>
            <span className="chip chip--magic" style={{ marginBottom: 18 }}>
              <I.Spark size={12}/> New · Multi-platform publishing
            </span>
            <h1 style={{ font: '700 56px/1.05 var(--font-display)', letterSpacing: '-0.03em', color: 'var(--fg-strong)', marginBottom: 18 }}>
              Make YouTube videos<br/>
              <span className="fg-grad">on autopilot.</span>
            </h1>
            <p style={{ font: '500 18px/1.55 var(--font-sans)', color: 'var(--fg-secondary)', maxWidth: 540, marginBottom: 28, textWrap: 'pretty' }}>
              AIcreators scripts, voices, animates, and publishes your videos — on a schedule you set. Cross-post to YouTube, Instagram, TikTok, X. Drop in to review any step, or don't.
            </p>
            <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
              <a href="AIcreators Cloud Auth.html#signup" style={{ textDecoration: 'none' }}>
                <Btn kind="magic" size="lg" icon={I.Spark}>Start free — 14 days</Btn>
              </a>
              <Btn kind="secondary" size="lg" icon={I.Play}>Watch the 90s tour</Btn>
            </div>
            <div style={{ display: 'flex', gap: 18, flexWrap: 'wrap' }}>
              {[
                { ic: I.Check, t: 'No credit card to start' },
                { ic: I.Check, t: 'Cancel anytime' },
                { ic: I.Check, t: 'Your videos, your rights' },
              ].map((f, i) => (
                <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  <f.ic size={14} stroke="var(--success)"/>
                  <span className="t-small" style={{ color: 'var(--fg-default)' }}>{f.t}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Right: floating product preview */}
          <HeroProductPeek/>
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section style={{ padding: '40px 32px', borderTop: '1px solid var(--border-hairline)', borderBottom: '1px solid var(--border-hairline)', background: 'var(--bg-surface)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div className="t-tiny" style={{ textAlign: 'center', marginBottom: 18 }}>
            Trusted by 12,000+ creators · 184M views shipped in 2025
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-around', gap: 24, flexWrap: 'wrap', alignItems: 'center' }}>
            {['Mythic Tales','Snackable Science','Noir Reels','Tiny Toon Theatre','Volcano Tales','Aztec Daily','Himitsu Story'].map(b => (
              <span key={b} style={{ font: '700 17px/1 var(--font-display)', color: 'var(--fg-faint)', letterSpacing: '-0.01em', opacity: 0.65 }}>{b}</span>
            ))}
          </div>
        </div>
      </section>

      {/* THE PRODUCTION LINE */}
      <section style={{ padding: '80px 32px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <span className="chip chip--brand" style={{ marginBottom: 14 }}>The centerpiece</span>
            <h2 style={{ font: '700 44px/1.1 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)', marginBottom: 14 }}>
              Every video flows through <span className="fg-grad">8 stages</span>.
            </h2>
            <p style={{ font: '500 17px/1.55 var(--font-sans)', color: 'var(--fg-secondary)', maxWidth: 640, margin: '0 auto', textWrap: 'pretty' }}>
              Idea to upload, autopilot moves your video left → right. Pause any stage to review. Override anything. Or let it run.
            </p>
          </div>

          <PipelineExplainer/>
        </div>
      </section>

      {/* MULTI-PLATFORM */}
      <section style={{ padding: '80px 32px', background: 'var(--bg-surface)', borderTop: '1px solid var(--border-hairline)', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
          <div>
            <span className="chip chip--magic" style={{ marginBottom: 14 }}><I.Megaphone size={12}/> 10 destinations</span>
            <h2 style={{ font: '700 36px/1.15 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)', marginBottom: 14 }}>
              One video.<br/>Posted everywhere.
            </h2>
            <p style={{ font: '500 16px/1.6 var(--font-sans)', color: 'var(--fg-secondary)', marginBottom: 22, textWrap: 'pretty' }}>
              Auto-reformat per platform: aspect ratio, length, caption length, hashtags, cover frame. Connect once, post to YouTube + Shorts + Instagram Reels + TikTok + X + LinkedIn + Facebook + Threads + Pinterest + Snapchat.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { ic: I.Youtube,  c: '#FF0000', t: 'YouTube long-form + Shorts auto-cut from the same source' },
                { ic: I.Image,    c: '#E1306C', t: 'Instagram Reel + Story + carousel — captioned per surface' },
                { ic: I.Film,     c: '#000000', t: 'TikTok with trending-sound suggester + brand compliance' },
                { ic: I.Send,     c: '#0F1419', t: 'X auto-thread when source is longer than 2:20' },
              ].map((f, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ width: 32, height: 32, borderRadius: 8, background: f.c, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <f.ic size={15}/>
                  </span>
                  <span style={{ font: '500 14px/1.5 var(--font-sans)', color: 'var(--fg-default)' }}>{f.t}</span>
                </div>
              ))}
            </div>
          </div>
          <MultiPlatformPeek/>
        </div>
      </section>

      {/* FEATURE ROWS */}
      <section style={{ padding: '80px 32px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <FeatureRow
            badge="Voice cloning"
            title={<>Sound like <span className="fg-grad">yourself</span> in every language</>}
            body="Record 60 seconds. We clone your voice — your cadence, your inflections — and narrate every video. In any language. Only you can use it."
            cta={{ l: 'See Voice Library', href: 'AIcreators Cloud.html#voices' }}
            visual={<VoicePeek/>}
            reverse={false}
          />
          <FeatureRow
            badge="Avatars & lip sync"
            title={<>Your face. <span className="fg-grad">Talking-head</span> for every video.</>}
            body="One front-facing photo. We mesh 62 anchor points, lock identity across cuts, and lip-sync to any voiceover — yours or studio. Cartoon, realistic, painterly."
            cta={{ l: 'See Avatars', href: 'AIcreators Cloud.html#avatars' }}
            visual={<AvatarPeek/>}
            reverse={true}
          />
          <FeatureRow
            badge="Visual styles"
            title={<>One <span className="fg-grad">look</span> across every frame</>}
            body="Pick a preset or train a style from 5-20 reference images. Every keyframe and motion clip inherits the palette, the lighting, the world. Build a signature aesthetic."
            cta={{ l: 'See Visual Styles', href: 'AIcreators Cloud.html#styles' }}
            visual={<StylesPeek/>}
            reverse={false}
          />
          <FeatureRow
            badge="Autopilot"
            title={<>Set a schedule. <span className="fg-grad">Walk away.</span></>}
            body="Daily, weekly, whatever cadence. AIcreators scouts topics, scripts, renders, voices, and publishes — on the times your audience watches. Drop in any time to review."
            cta={{ l: 'How autopilot works', href: 'AIcreators Cloud Legal.html#content-policy' }}
            visual={<AutopilotPeek/>}
            reverse={true}
          />
        </div>
      </section>

      {/* CHANNEL SHOWCASE */}
      <section style={{ padding: '80px 32px', background: 'var(--bg-surface)', borderTop: '1px solid var(--border-hairline)', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', textAlign: 'center' }}>
          <span className="chip" style={{ marginBottom: 14 }}>What you can make</span>
          <h2 style={{ font: '700 36px/1.15 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)', marginBottom: 14 }}>
            Faceless channels. Cartoon shorts. Long-form essays. Cinematic features.
          </h2>
          <p style={{ font: '500 16px/1.55 var(--font-sans)', color: 'var(--fg-secondary)', maxWidth: 640, margin: '0 auto 40px', textWrap: 'pretty' }}>
            Real channels making real revenue, end-to-end on AIcreators.
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
            {MOCK.channels.map(ch => (
              <ChannelShowcase key={ch.id} ch={ch}/>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" style={{ padding: '80px 32px' }}>
        <PricingBlock/>
      </section>

      {/* FAQ */}
      <section style={{ padding: '80px 32px', background: 'var(--bg-surface)', borderTop: '1px solid var(--border-hairline)' }}>
        <div style={{ maxWidth: 800, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <span className="chip" style={{ marginBottom: 14 }}>FAQ</span>
            <h2 style={{ font: '700 36px/1.15 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)' }}>Frequently asked</h2>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {FAQ_ITEMS.map((f, i) => (
              <FAQItem key={i} q={f.q} a={f.a} open={openFAQ === i} onClick={() => setOpenFAQ(openFAQ === i ? -1 : i)}/>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section style={{ padding: '80px 32px', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(50% 80% at 50% 100%, var(--accent-tint-3) 0%, transparent 60%)', pointerEvents: 'none' }}/>
        <SparkleField count={10} intensity={0.35}/>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <h2 style={{ font: '700 48px/1.1 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)', marginBottom: 18 }}>
            Your studio is one click away.
          </h2>
          <p style={{ font: '500 17px/1.55 var(--font-sans)', color: 'var(--fg-secondary)', marginBottom: 28 }}>
            14 days free. No credit card. Cancel anytime.
          </p>
          <a href="AIcreators Cloud Auth.html#signup" style={{ textDecoration: 'none' }}>
            <Btn kind="magic" size="lg" icon={I.Spark}>Start your studio</Btn>
          </a>
        </div>
      </section>

      {/* FOOTER */}
      <MarketingFooter/>

      {/* COOKIE BANNER (mounted globally) */}
      <CookieBanner/>
    </div>
  );
}

/* ---------- NAV ---------- */
function MarketingNav() {
  return (
    <header style={{
      padding: '16px 32px', display: 'flex', alignItems: 'center', gap: 24,
      borderBottom: '1px solid var(--border-hairline)',
      background: 'var(--glass-bg-header)', backdropFilter: 'blur(20px)',
      position: 'sticky', top: 0, zIndex: 100,
    }}>
      <a href="AIcreators Cloud Home.html" style={{ textDecoration: 'none', display: 'inline-flex' }}>
        <LogoLockup markSize={30} wordSize={17}/>
      </a>
      <nav style={{ display: 'flex', gap: 4, marginLeft: 16 }}>
        {[
          { l: 'Features',     href: '#features' },
          { l: 'Pricing',      href: '#pricing' },
          { l: 'Status',       href: 'AIcreators Cloud Status.html' },
          { l: 'Docs',         href: 'AIcreators Cloud API.html' },
        ].map(n => (
          <a key={n.l} href={n.href} style={{
            padding: '8px 12px', borderRadius: 8,
            font: '500 14px/1 var(--font-sans)', color: 'var(--fg-default)',
            textDecoration: 'none', transition: 'background 120ms var(--ease-out)',
          }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
            {n.l}
          </a>
        ))}
      </nav>
      <div style={{ flex: 1 }}/>
      <a href="AIcreators Cloud Auth.html#login" style={{ textDecoration: 'none' }}>
        <Btn kind="ghost">Sign in</Btn>
      </a>
      <a href="AIcreators Cloud Auth.html#signup" style={{ textDecoration: 'none' }}>
        <Btn kind="primary">Start free</Btn>
      </a>
    </header>
  );
}

/* ---------- HERO PEEK ---------- */
function HeroProductPeek() {
  return (
    <div style={{ position: 'relative' }}>
      {/* Floating shadow */}
      <div style={{ position: 'absolute', top: 30, left: 30, right: -30, bottom: -30, borderRadius: 24, background: 'radial-gradient(circle, var(--accent-tint-3) 0%, transparent 70%)', filter: 'blur(40px)', zIndex: 0 }}/>
      {/* Main card */}
      <div className="card" style={{ position: 'relative', padding: 16, transform: 'rotate(-1deg)', background: 'var(--bg-surface)', boxShadow: 'var(--shadow-soft)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <span style={{ width: 56, height: 36, borderRadius: 6, background: 'linear-gradient(135deg,#2A1810,#7B4F2C)' }}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>The Lost Library of Alexandria</div>
            <div className="t-small">Mythic Tales · 11:42 · long-form</div>
          </div>
          <span className="chip chip--success" style={{ height: 22, fontSize: 11 }}>Live</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {['Idea','Script','Story','Frames','Motion','Voice','Edit','Pub'].map((s, i) => (
            <React.Fragment key={s}>
              <span style={{
                width: 28, height: 28, borderRadius: 7,
                background: i < 7 ? 'var(--success-bg)' : 'var(--magic-tint)',
                border: `1px solid ${i < 7 ? 'var(--success-bd)' : 'var(--accent-border-soft)'}`,
                color: i < 7 ? 'var(--success)' : 'var(--accent-fg)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              }}>{i < 7 ? <I.Check size={11}/> : <I.Spark size={11}/>}</span>
              {i < 7 && <span style={{ flex: 1, height: 2, background: 'linear-gradient(90deg, var(--success), var(--accent))', opacity: 0.4 }}/>}
            </React.Fragment>
          ))}
        </div>
        <div className="divider" style={{ margin: '14px 0' }}/>
        <div style={{ display: 'flex', gap: 4 }}>
          {[
            { c: '#FF0000', ic: 'Youtube' },
            { c: '#E1306C', ic: 'Image' },
            { c: '#000', ic: 'Film' },
            { c: '#0F1419', ic: 'Send' },
            { c: '#0A66C2', ic: 'Users' },
          ].map((p, i) => (
            <span key={i} style={{ width: 20, height: 20, borderRadius: 5, background: p.c, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
              {React.createElement(I[p.ic], { size: 10 })}
            </span>
          ))}
          <span className="chip" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>5 destinations</span>
        </div>
      </div>

      {/* Second floating card */}
      <div className="card" style={{ position: 'absolute', top: -40, right: -40, padding: 14, transform: 'rotate(4deg)', background: 'var(--bg-surface)', boxShadow: 'var(--shadow-soft)', width: 240 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <I.Robot size={14} stroke="var(--accent-fg)"/>
          <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>Autopilot</span>
          <div style={{ flex: 1 }}/>
          <Switch on={true} size="sm"/>
        </div>
        <div className="t-small">3 videos in production today</div>
      </div>

      <div className="card" style={{ position: 'absolute', bottom: -50, left: -30, padding: 12, transform: 'rotate(-3deg)', background: 'var(--bg-surface)', boxShadow: 'var(--shadow-soft)', width: 220 }}>
        <div className="t-tiny" style={{ marginBottom: 6 }}>Last 30d views</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <span style={{ font: '700 24px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em' }}>2.4M</span>
          <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--success)' }}>+18.2%</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- PIPELINE EXPLAINER ---------- */
function PipelineExplainer() {
  return (
    <div className="card" style={{ padding: 24, position: 'relative', overflow: 'hidden' }}>
      <SparkleField count={6} intensity={0.20}/>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${PIPELINE_STAGES.length}, 1fr)`, gap: 0, position: 'relative', zIndex: 1 }}>
        {PIPELINE_STAGES.map((s, i) => {
          const Ico = I[s.icon];
          return (
            <div key={s.id} style={{ textAlign: 'center', padding: '0 8px', position: 'relative' }}>
              {/* Connector line (except last) */}
              {i < PIPELINE_STAGES.length - 1 && (
                <div style={{ position: 'absolute', top: 20, left: '60%', right: '-40%', height: 2, background: 'linear-gradient(90deg, var(--accent), var(--brand))', opacity: 0.3, zIndex: 0 }}/>
              )}
              <span style={{
                position: 'relative', zIndex: 1,
                width: 44, height: 44, borderRadius: 12,
                background: 'var(--magic-tint)',
                border: '1px solid var(--accent-border-soft)',
                color: 'var(--accent-fg)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                marginBottom: 12,
                boxShadow: 'var(--shadow-soft)',
              }}><Ico size={20}/></span>
              <div className="t-tiny" style={{ marginBottom: 4 }}>{String(i+1).padStart(2,'0')}</div>
              <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)', marginBottom: 6 }}>{s.label}</div>
              <div className="t-small" style={{ minHeight: 36, textWrap: 'pretty' }}>{s.blurb}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- MULTI-PLATFORM PEEK ---------- */
function MultiPlatformPeek() {
  const platforms = [
    { c: '#FF0000', ic: 'Youtube', name: 'YouTube', ar: '16:9', dur: '11:42' },
    { c: '#FF0000', ic: 'Youtube', name: 'Shorts',  ar: '9:16', dur: '0:58' },
    { c: '#E1306C', ic: 'Image',   name: 'Reel',    ar: '9:16', dur: '0:58' },
    { c: '#000000', ic: 'Film',    name: 'TikTok',  ar: '9:16', dur: '0:58' },
  ];
  return (
    <div style={{ position: 'relative', height: 460 }}>
      <SparkleField count={5} intensity={0.3}/>
      <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 14, height: '100%' }}>
        {platforms.map((p, i) => (
          <div key={i} style={{ position: 'relative', borderRadius: 14, overflow: 'hidden', background: 'linear-gradient(135deg,#2A1810,#7B4F2C)', border: '1px solid var(--border-default)', boxShadow: 'var(--shadow-soft)' }}>
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.25), transparent 60%)' }}/>
            <span style={{ position: 'absolute', top: 10, left: 10, width: 24, height: 24, borderRadius: 6, background: p.c, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
              {React.createElement(I[p.ic], { size: 12 })}
            </span>
            <span style={{ position: 'absolute', top: 10, right: 10, padding: '3px 7px', borderRadius: 6, background: 'rgba(0,0,0,0.55)', font: '600 10px/1 var(--font-sans)', color: 'white' }}>{p.ar}</span>
            <span style={{ position: 'absolute', bottom: 10, left: 10, font: '700 13px/1 var(--font-display)', color: 'white', textShadow: '0 1px 4px rgba(0,0,0,0.8)' }}>{p.name}</span>
            <span style={{ position: 'absolute', bottom: 10, right: 10, padding: '3px 6px', borderRadius: 4, background: 'rgba(0,0,0,0.55)', font: '600 10px/1 var(--font-mono)', color: 'white' }}>{p.dur}</span>
            <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 36, height: 36, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'white' }}>
              <I.Play size={14}/>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- FEATURE ROW ---------- */
function FeatureRow({ badge, title, body, cta, visual, reverse }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center',
      padding: '60px 0', borderTop: '1px solid var(--border-hairline)',
    }}>
      <div style={{ order: reverse ? 2 : 1 }}>
        <span className="chip chip--magic" style={{ marginBottom: 14 }}>{badge}</span>
        <h3 style={{ font: '700 32px/1.15 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)', marginBottom: 14 }}>{title}</h3>
        <p style={{ font: '500 16px/1.6 var(--font-sans)', color: 'var(--fg-secondary)', marginBottom: 22, textWrap: 'pretty' }}>{body}</p>
        <a href={cta.href} style={{ textDecoration: 'none' }}>
          <Btn kind="secondary" iconRight={I.ChevRight}>{cta.l}</Btn>
        </a>
      </div>
      <div style={{ order: reverse ? 1 : 2 }}>{visual}</div>
    </div>
  );
}

/* ---------- PEEK VISUALS ---------- */
function VoicePeek() {
  return (
    <div className="card card--lift" style={{ padding: 22 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
        <span style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--magic-grad)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'white', flexShrink: 0, boxShadow: 'var(--shadow-glow)' }}>
          <I.Mic size={26}/>
        </span>
        <div style={{ flex: 1 }}>
          <div style={{ font: '600 16px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>My Storyteller</div>
          <div className="t-small" style={{ marginTop: 4 }}>Cloned · 60s sample · 96% match · 12 languages</div>
        </div>
        <button className="btn btn--primary btn--icon" style={{ width: 44, height: 44, borderRadius: '50%' }}><I.Play size={16}/></button>
      </div>
      <div style={{ height: 56, display: 'flex', alignItems: 'center', gap: 2 }}>
        {Array.from({ length: 64 }).map((_, i) => {
          const h = 6 + Math.abs(Math.sin(i * 0.4) * 32) + Math.abs(Math.sin(i * 0.9) * 18);
          const played = i < 22;
          return <span key={i} style={{ flex: 1, height: h, background: played ? 'var(--magic-grad)' : 'var(--surface-elev)', borderRadius: 2 }}/>;
        })}
      </div>
      <div className="t-tiny" style={{ marginTop: 14 }}>Same voice in</div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
        {['English','हिंदी','Español','Français','日本語','한국어','العربية','Português','中文','Deutsch','Italiano','Русский'].map(l => (
          <span key={l} className="chip" style={{ height: 24, fontSize: 11 }}>{l}</span>
        ))}
      </div>
    </div>
  );
}

function AvatarPeek() {
  return (
    <div className="card card--lift" style={{ padding: 22 }}>
      <div style={{
        aspectRatio: '4/3', borderRadius: 14,
        background: 'linear-gradient(135deg,#3D405B,#81B29A,#F2CC8F)',
        position: 'relative', overflow: 'hidden',
      }}>
        <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          <ellipse cx="50" cy="42" rx="18" ry="22" fill="rgba(255,255,255,0.20)"/>
          <path d="M22,100 C22,72 36,62 50,62 C64,62 78,72 78,100 Z" fill="rgba(255,255,255,0.20)"/>
        </svg>
        <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          {[[40,30],[60,30],[50,38],[42,46],[58,46],[50,50],[44,55],[56,55],[45,30],[55,30],[36,40],[64,40],[38,50],[62,50],[42,33],[58,33],[50,42],[40,58],[60,58],[46,60],[54,60],[50,60],[34,66],[66,66],[50,70],[42,72],[58,72],[50,76]].map(([x,y], i) => <circle key={i} cx={x} cy={y} r="0.7" fill="var(--cyan-300)" stroke="white" strokeWidth="0.2"/>)}
        </svg>
        <span style={{ position: 'absolute', top: 12, left: 12 }} className="chip chip--magic"><I.Sparkles size={11}/> Lip sync ready</span>
        <span style={{ position: 'absolute', top: 12, right: 12 }} className="chip">98% match</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 14 }}>
        {['Realistic','Cartoon','Painterly'].map((s, i) => (
          <div key={s} style={{ padding: '10px 12px', textAlign: 'center', borderRadius: 8, background: i === 0 ? 'var(--accent-tint-1)' : 'var(--surface-subtle)', border: `1px solid ${i === 0 ? 'var(--accent-border)' : 'var(--border-hairline)'}`, font: '600 12px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{s}</div>
        ))}
      </div>
    </div>
  );
}

function StylesPeek() {
  const styles = [
    { name: 'Mythic',  swatch: ['#2A1810','#7B4F2C','#D4A574','#F4E1B5'] },
    { name: 'Cyber',   swatch: ['#FF006E','#8338EC','#3A86FF','#06D6A0'] },
    { name: 'Ghibli',  swatch: ['#A8D8EA','#FCE38A','#F38181','#95E1D3'] },
    { name: 'Noir',    swatch: ['#1A1024','#3B1F47','#85547E','#E0D2E6'] },
  ];
  return (
    <div className="card card--lift" style={{ padding: 22 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
        {styles.map(s => (
          <div key={s.name} style={{ borderRadius: 10, overflow: 'hidden', border: '1px solid var(--border-hairline)' }}>
            <div style={{ aspectRatio: '16/9', background: `linear-gradient(135deg, ${s.swatch.join(', ')})`, position: 'relative' }}>
              <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.20), transparent 60%)' }}/>
              <span style={{ position: 'absolute', bottom: 6, left: 8, font: '700 11px/1 var(--font-display)', color: 'white', textShadow: '0 1px 3px rgba(0,0,0,0.6)' }}>{s.name}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AutopilotPeek() {
  return (
    <div className="card card--lift" style={{ padding: 22 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        <I.Robot size={20} stroke="var(--accent-fg)"/>
        <span className="t-h5">Autopilot · this week</span>
        <div style={{ flex: 1 }}/>
        <span className="chip chip--success"><I.Check size={11}/> 8 videos</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {[
          { d: 'Mon', t: '6:00 PM', s: 'Lost Library · YouTube',           ok: true },
          { d: 'Tue', t: '9:00 AM', s: 'Why phones hate cold · Shorts',     ok: true },
          { d: 'Wed', t: '6:00 PM', s: 'Volcano lightning · Shorts',        ok: true },
          { d: 'Thu', t: '7:00 PM', s: 'Detective · Noir Reels',            review: true },
          { d: 'Fri', t: '6:00 PM', s: 'Pompeii 72 hours · Long-form',     queued: true },
          { d: 'Sat', t: '10 AM',   s: 'Honey Star · Tiny Toon Theatre',    queued: true },
        ].map((e, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '40px 60px 1fr auto', gap: 8, alignItems: 'center', padding: '6px 0', borderTop: i > 0 ? '1px solid var(--border-hairline)' : 0 }}>
            <span className="t-tiny">{e.d}</span>
            <span className="t-mono t-small">{e.t}</span>
            <span style={{ font: '500 12px/1.3 var(--font-sans)', color: 'var(--fg-default)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{e.s}</span>
            {e.ok && <I.Check size={14} stroke="var(--success)"/>}
            {e.review && <span className="chip chip--warning" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>review</span>}
            {e.queued && <span className="chip" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>queued</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

function ChannelShowcase({ ch }) {
  return (
    <div className="card card--hover" style={{ padding: 0, overflow: 'hidden', textAlign: 'left' }}>
      <div style={{ height: 100, background: ch.color, position: 'relative' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.30), transparent 60%)' }}/>
        <span style={{ position: 'absolute', left: 14, bottom: -18, width: 48, height: 48, borderRadius: '50%', background: ch.color, color: 'white', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 700, border: '3px solid var(--bg-surface)', boxShadow: 'var(--shadow-soft)' }}>{ch.emoji || ch.name[0]}</span>
      </div>
      <div style={{ padding: '28px 16px 16px' }}>
        <div style={{ font: '600 15px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{ch.name}</div>
        <div className="t-small" style={{ marginTop: 4 }}>{ch.handle} · {ch.subs}</div>
        <div className="t-small" style={{ marginTop: 8, minHeight: 36, textWrap: 'pretty' }}>{ch.niche}</div>
      </div>
    </div>
  );
}

/* ---------- PRICING ---------- */
function PricingBlock() {
  return (
    <div style={{ maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: 48 }}>
        <span className="chip" style={{ marginBottom: 14 }}>Pricing</span>
        <h2 style={{ font: '700 56px/1.05 var(--font-display)', letterSpacing: '-0.03em', color: 'var(--fg-strong)', marginBottom: 18 }}>
          <span className="fg-grad">$0.20</span> per second of video.
        </h2>
        <p style={{ font: '500 18px/1.55 var(--font-sans)', color: 'var(--fg-secondary)', maxWidth: 560, margin: '0 auto' }}>
          Pay only for what you make. No subscriptions, no minimums, no per-platform fees. The first $20 of generation is on us.
        </p>
      </div>

      {/* Big rate card */}
      <div className="card card--glow" style={{ padding: 36, marginBottom: 28, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <SparkleField count={10} intensity={0.35}/>
        <div style={{ position: 'relative' }}>
          <div className="t-tiny" style={{ marginBottom: 14 }}>One rate · all formats · all platforms</div>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 10, marginBottom: 18 }}>
            <span style={{ font: '700 96px/1 var(--font-display)', letterSpacing: '-0.04em', color: 'var(--fg-strong)' }}>$0.20</span>
            <span className="t-h4" style={{ color: 'var(--fg-secondary)' }}>/ second of finished video</span>
          </div>
          <div className="t-body" style={{ color: 'var(--fg-secondary)', maxWidth: 540, margin: '0 auto 24px', textWrap: 'pretty' }}>
            Includes script, keyframes, image-to-video, voiceover, edit, captions, and publishing to every connected platform. We bill only for the seconds of video you actually keep.
          </div>
          <a href="AIcreators Cloud Auth.html#signup" style={{ textDecoration: 'none' }}>
            <Btn kind="magic" size="lg" icon={I.Spark}>Start free with $20 credit</Btn>
          </a>
        </div>
      </div>

      {/* Examples */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 28 }}>
        {[
          { l: 'Instagram Reel',   d: '30 seconds',   p: '$6' },
          { l: 'YouTube Shorts',   d: '60 seconds',   p: '$12' },
          { l: 'TikTok video',     d: '3 minutes',    p: '$36' },
          { l: 'Long-form essay',  d: '11 minutes',   p: '$132' },
        ].map((e, i) => (
          <div key={i} className="card" style={{ textAlign: 'center', padding: 18 }}>
            <div className="t-tiny" style={{ marginBottom: 8 }}>{e.l}</div>
            <div className="t-h4" style={{ marginBottom: 6 }}>{e.d}</div>
            <div style={{ font: '700 28px/1 var(--font-display)', color: 'var(--accent-fg)', letterSpacing: '-0.02em' }}>{e.p}</div>
          </div>
        ))}
      </div>

      {/* Included with every second */}
      <div className="card" style={{ padding: 28 }}>
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Every second includes</div>
          <div className="t-h4">No add-ons. No upsells. No watermark.</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {[
            { ic: I.Edit,      t: 'Script generation',     d: 'Best-fit prompting auto-picked' },
            { ic: I.Image,     t: 'AI keyframes',          d: 'Locked to your visual style' },
            { ic: I.Film,      t: 'Image-to-video motion', d: 'Identity-locked across cuts' },
            { ic: I.Mic,       t: 'Voiceover (any voice)', d: 'Studio voices OR your clone' },
            { ic: I.User,      t: 'Avatar + lip sync',     d: 'Talking head if you want it' },
            { ic: I.Languages, t: 'Captions',              d: '128 languages' },
            { ic: I.Sliders,   t: 'Edit + render',         d: 'Up to 4K · no watermark' },
            { ic: I.Megaphone, t: 'Multi-platform publish', d: 'All 10 destinations included' },
            { ic: I.Robot,     t: 'Autopilot',             d: 'Daily, weekly, your cadence' },
          ].map((f, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: 14, borderRadius: 10, background: 'var(--surface-subtle)' }}>
              <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', color: 'var(--accent-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <f.ic size={15}/>
              </span>
              <div>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{f.t}</div>
                <div className="t-small" style={{ marginTop: 4 }}>{f.d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


/* ---------- FAQ ---------- */
const FAQ_ITEMS = [
  { q: 'Who owns the videos I make?', a: 'You do. Full IP rights. We claim no ownership over your scripts, voice clones, avatars, or finished videos. We claim a narrow license to process and deliver them as needed to run the service.' },
  { q: 'Will YouTube ban my channel for AI content?', a: 'YouTube allows AI-generated content. They require disclosure for synthetic/altered content depicting realistic people or events — we embed C2PA provenance metadata in every render to satisfy this. You\'re responsible for following each platform\'s policies; we make following them easy.' },
  { q: 'Can I clone someone else\'s voice?', a: 'Only with their explicit, documented consent. The platform asks every cloning session whether the voice is yours or someone else\'s, and stores the consent record. Impersonation of public figures or third parties without consent results in immediate account termination.' },
  { q: 'What if a stage of the pipeline produces something bad?', a: 'You can pause autopilot at any stage. By default we hold for review when our confidence score is below 80. You can also re-roll, edit prompts, or override the model selection per stage.' },
  { q: 'Do credits roll over?', a: 'No, unused credits expire at the end of each billing period on Starter and Studio Pro. Studio plan credits roll over for up to 90 days. Annual customers get a 20% credit boost on signup.' },
  { q: 'How do refunds work?', a: 'Within the 14-day free trial, no charge. After that, refunds are reviewed case-by-case — if our pipeline failed and your video never shipped, we refund. Email support@aicreators.cloud.' },
  { q: 'Is my data used to train AI models?', a: 'No. Your scripts, voice samples, photos, and generated content are never used to train foundation models. Our providers (OpenAI, Anthropic, Replicate) operate under zero-retention contracts.' },
  { q: 'Can I cancel anytime?', a: 'Yes, from Billing & Plan. You\'ll keep access until the end of your current billing cycle. After cancellation, your account is preserved for 30 days, then permanently deleted.' },
  { q: 'Where is my data stored?', a: 'AWS us-east-1 by default. Studio plan customers can pin storage to eu-west-1 for GDPR. See our Privacy Policy and DPA for details.' },
  { q: 'Do you have a free plan?', a: 'No, but every paid plan has a 14-day free trial with no credit card. Most creators ship their first video within 30 minutes of signup.' },
];

function FAQItem({ q, a, open, onClick }) {
  return (
    <div className="card" style={{ padding: 0 }}>
      <button onClick={onClick} style={{
        width: '100%', border: 0, background: 'transparent', cursor: 'pointer',
        padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left',
      }}>
        <span style={{ flex: 1, font: '600 16px/1.3 var(--font-display)', color: 'var(--fg-strong)' }}>{q}</span>
        {open ? <I.ChevUp size={16} stroke="var(--fg-muted)"/> : <I.ChevDown size={16} stroke="var(--fg-muted)"/>}
      </button>
      {open && (
        <div style={{ padding: '0 20px 20px', font: '500 15px/1.65 var(--font-sans)', color: 'var(--fg-default)', textWrap: 'pretty' }}>
          {a}
        </div>
      )}
    </div>
  );
}

/* ---------- FOOTER ---------- */
function MarketingFooter() {
  const columns = [
    { title: 'Product',  links: [
      { l: 'The Studio',     href: 'AIcreators Cloud.html' },
      { l: 'Pricing',        href: '#pricing' },
      { l: 'Voices',         href: 'AIcreators Cloud.html#voices' },
      { l: 'Avatars',        href: 'AIcreators Cloud.html#avatars' },
      { l: 'Integrations',   href: 'AIcreators Cloud.html#integrations' },
      { l: 'Mobile',         href: 'AIcreators Cloud.html#mobile' },
    ]},
    { title: 'Developers', links: [
      { l: 'API reference',  href: 'AIcreators Cloud API.html' },
      { l: 'Webhooks',       href: 'AIcreators Cloud API.html#webhooks' },
      { l: 'Status',         href: 'AIcreators Cloud Status.html' },
      { l: 'Changelog',      href: '#' },
    ]},
    { title: 'Company',    links: [
      { l: 'Sign in',         href: 'AIcreators Cloud Auth.html#login' },
      { l: 'Sign up',         href: 'AIcreators Cloud Auth.html#signup' },
      { l: 'Refer & earn',    href: 'AIcreators Cloud.html#refer' },
      { l: 'Careers',         href: '#' },
      { l: 'Contact',         href: 'mailto:hello@aicreators.cloud' },
    ]},
    { title: 'Legal',      links: [
      { l: 'Terms',                  href: 'AIcreators Cloud Legal.html#terms' },
      { l: 'Privacy',                href: 'AIcreators Cloud Legal.html#privacy' },
      { l: 'Cookies',                href: 'AIcreators Cloud Legal.html#cookies' },
      { l: 'Acceptable use',         href: 'AIcreators Cloud Legal.html#aup' },
      { l: 'DPA',                    href: 'AIcreators Cloud Legal.html#dpa' },
      { l: 'Sub-processors',         href: 'AIcreators Cloud Legal.html#subprocessors' },
      { l: 'Security',               href: 'AIcreators Cloud Legal.html#security' },
      { l: 'AI content policy',      href: 'AIcreators Cloud Legal.html#content-policy' },
      { l: 'Copyright / DMCA',       href: 'AIcreators Cloud Legal.html#copyright' },
      { l: 'Delete my account',      href: 'AIcreators Cloud Legal.html#data-deletion' },
    ]},
  ];
  return (
    <footer style={{ padding: '64px 32px 32px', borderTop: '1px solid var(--border-hairline)', background: 'var(--bg-surface)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr repeat(4, 1fr)', gap: 40, marginBottom: 48 }}>
          <div>
            <LogoLockup markSize={32} wordSize={18}/>
            <p style={{ font: '500 14px/1.6 var(--font-sans)', color: 'var(--fg-muted)', marginTop: 16, maxWidth: 280 }}>
              The AI studio for creators who want to ship more, sleep better.
            </p>
            <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
              {['Youtube','Send','Message','Globe'].map(ic => (
                <button key={ic} className="btn btn--ghost btn--icon"><span style={{ color: 'var(--fg-muted)' }}>{React.createElement(I[ic], { size: 16 })}</span></button>
              ))}
            </div>
          </div>
          {columns.map(c => (
            <div key={c.title}>
              <div className="t-tiny" style={{ marginBottom: 12 }}>{c.title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {c.links.map(l => (
                  <a key={l.l} href={l.href} style={{ font: '500 13px/1.4 var(--font-sans)', color: 'var(--fg-default)', textDecoration: 'none' }}>{l.l}</a>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, paddingTop: 24, borderTop: '1px solid var(--border-hairline)' }}>
          <span className="t-small">© 2026 AIcreators, Inc. · San Francisco, CA</span>
          <div style={{ flex: 1 }}/>
          <button style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 10px', borderRadius: 8, background: 'var(--surface-subtle)', border: '1px solid var(--border-hairline)', cursor: 'pointer', font: '500 12px/1 var(--font-sans)', color: 'var(--fg-default)' }} onClick={() => { localStorage.removeItem('aic_consent'); location.reload(); }}>
            <I.Help size={12}/>
            Cookie preferences
          </button>
        </div>
      </div>
    </footer>
  );
}

/* ---------- COOKIE BANNER ---------- */
function CookieBanner() {
  const [show, setShow] = React.useState(() => !localStorage.getItem('aic_consent'));
  const [customizing, setCustomizing] = React.useState(false);
  if (!show) return null;

  const accept = (mode) => {
    localStorage.setItem('aic_consent', JSON.stringify({ mode, ts: Date.now(), analytics: mode === 'all', preferences: mode !== 'essential' }));
    setShow(false);
  };

  return (
    <div style={{
      position: 'fixed', bottom: 16, left: 16, right: 16, maxWidth: 720, margin: '0 auto',
      background: 'var(--bg-surface)', border: '1px solid var(--border-default)',
      borderRadius: 16, boxShadow: 'var(--shadow-modal)', padding: 18,
      zIndex: 9999,
    }}>
      {!customizing ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', color: 'var(--accent-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <I.Help size={20}/>
          </span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>We use cookies</div>
            <div className="t-small" style={{ marginTop: 4 }}>
              Essential cookies are always on. Optional analytics help us improve. <a href="AIcreators Cloud Legal.html#cookies" style={{ color: 'var(--brand)' }}>Read the policy</a>.
            </div>
          </div>
          <Btn kind="ghost" size="sm" onClick={() => setCustomizing(true)}>Customize</Btn>
          <Btn kind="secondary" size="sm" onClick={() => accept('essential')}>Reject non-essential</Btn>
          <Btn kind="primary" size="sm" onClick={() => accept('all')}>Accept all</Btn>
        </div>
      ) : (
        <div>
          <div className="t-h5" style={{ marginBottom: 12 }}>Cookie preferences</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 }}>
            {[
              { id: 'essential', l: 'Essential', sub: 'Required for sign-in and security. Cannot be disabled.', forced: true },
              { id: 'analytics', l: 'Analytics', sub: 'Aggregated usage stats (Plausible).', forced: false },
              { id: 'preferences', l: 'Preferences', sub: 'Theme, last visited page, language.', forced: false },
            ].map(c => (
              <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, background: 'var(--surface-subtle)' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{c.l}</div>
                  <div className="t-small" style={{ marginTop: 4 }}>{c.sub}</div>
                </div>
                <Switch on={c.forced || true} size="sm" onChange={()=>{}}/>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Btn kind="ghost" onClick={() => setCustomizing(false)}>Back</Btn>
            <Btn kind="primary" onClick={() => accept('custom')}>Save preferences</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<MarketingHomeApp/>);
