/* ============================================================
   AIcreators.cloud · Public API reference
   ============================================================
   Stripe / Linear-style developer docs. Sidebar of endpoints
   grouped by resource; right-rail with code examples in cURL +
   JS + Python; main column shows request / response shapes.

   This is a UI surface, not the live API spec — when shipping,
   the live spec at developers.aicreators.cloud would be
   rendered from an OpenAPI definition. The data on this page
   mirrors HANDOFF.md so engineers can reason about API surface
   while the spec is being authored.
   ============================================================ */

const API_NAV = [
  { group: 'Getting started', items: [
    { id: 'intro',        label: 'Introduction' },
    { id: 'auth',         label: 'Authentication' },
    { id: 'errors',       label: 'Errors' },
    { id: 'pagination',   label: 'Pagination' },
    { id: 'rate-limits',  label: 'Rate limits' },
    { id: 'versioning',   label: 'Versioning' },
  ]},
  { group: 'Core resources', items: [
    { id: 'channels',     label: 'Channels' },
    { id: 'topics',       label: 'Topics' },
    { id: 'projects',     label: 'Projects' },
    { id: 'jobs',         label: 'Jobs' },
    { id: 'videos',       label: 'Videos' },
  ]},
  { group: 'Assets', items: [
    { id: 'voices',       label: 'Voices' },
    { id: 'avatars',      label: 'Avatars' },
    { id: 'styles',       label: 'Visual styles' },
  ]},
  { group: 'Publishing', items: [
    { id: 'integrations', label: 'Integrations' },
    { id: 'destinations', label: 'Distribution targets' },
  ]},
  { group: 'Account', items: [
    { id: 'me',           label: 'User' },
    { id: 'billing',      label: 'Billing & credits' },
    { id: 'notifications',label: 'Notifications' },
    { id: 'team',         label: 'Team' },
  ]},
  { group: 'Realtime', items: [
    { id: 'websockets',   label: 'WebSockets' },
    { id: 'webhooks',     label: 'Webhooks' },
  ]},
];

const API_ENDPOINTS = {
  intro: {
    title: 'Introduction',
    body: [
      ['p', 'The AIcreators API is REST-based, uses JSON, and is secured with bearer tokens. Every endpoint is prefixed with /api/v1.'],
      ['p', 'Base URL: ', ['code', 'https://api.aicreators.cloud/v1']],
      ['p', 'Use this API to run the full video pipeline programmatically — kick off topic generation, advance pipeline stages, fetch analytics, manage channels, distribute to social platforms.'],
    ],
    sample: { language: 'bash', code: `curl https://api.aicreators.cloud/v1/me \\
  -H "Authorization: Bearer aic_live_…"` },
  },
  auth: {
    title: 'Authentication',
    body: [
      ['p', 'All requests must include an API key in the Authorization header.'],
      ['p', 'Get your keys from ', ['link', 'AIcreators Cloud.html#api-keys', 'Settings → API keys'], '.'],
      ['p', 'Use ', ['code', 'aic_test_*'], ' keys against the test environment. ', ['code', 'aic_live_*'], ' keys touch production.'],
      ['h3', 'Scopes'],
      ['ul', [
        ['code', 'videos:read'], ' · ',
        ['code', 'videos:write'], ' · ',
        ['code', 'channels:read'], ' · ',
        ['code', 'channels:write'], ' · ',
        ['code', 'topics:read'], ' · ',
        ['code', 'topics:write'], ' · ',
        ['code', 'analytics:read'], ' · ',
        ['code', 'webhooks:receive'],
      ]],
    ],
    sample: { language: 'bash', code: `# Test against the test environment first
curl https://api.aicreators.cloud/v1/me \\
  -H "Authorization: Bearer aic_test_8a4Bk2..."

# Then switch to live
curl https://api.aicreators.cloud/v1/me \\
  -H "Authorization: Bearer aic_live_..."` },
  },
  errors: {
    title: 'Errors',
    body: [
      ['p', 'Errors follow a consistent JSON shape with a stable error code, a human-readable message, and a request ID for support.'],
      ['table', { cols: ['Code','HTTP','Meaning'], rows: [
        ['invalid_request',    400, 'Malformed body / missing field'],
        ['unauthorized',       401, 'Missing or invalid API key'],
        ['forbidden',          403, 'Key lacks required scope'],
        ['not_found',          404, 'Resource does not exist'],
        ['rate_limited',       429, 'Too many requests — retry after the Retry-After header'],
        ['credits_depleted',   402, 'Account is out of credits'],
        ['platform_oauth_revoked', 422, 'YouTube / IG / etc. revoked our access'],
        ['moderation_blocked', 451, 'Content blocked by moderation classifier'],
        ['internal_error',     500, 'Bug on our side; the request ID will help us debug'],
      ]}],
    ],
    sample: { language: 'json', code: `{
  "error": {
    "code": "credits_depleted",
    "message": "Studio Pro plan has 0 credits remaining this period.",
    "request_id": "req_8a4Bk2QzKx9R",
    "doc_url": "https://docs.aicreators.cloud/errors#credits_depleted"
  }
}` },
  },
  pagination: {
    title: 'Pagination',
    body: [
      ['p', 'Collection endpoints support cursor-based pagination. Pass ', ['code', '?cursor=…'], ' from the previous response\'s ', ['code', 'next_cursor'], '.'],
      ['p', 'Default page size is 50. Override with ', ['code', '?limit=…'], ' (max 200).'],
    ],
    sample: { language: 'bash', code: `curl "https://api.aicreators.cloud/v1/projects?limit=20&cursor=eyJpZCI6InAxIn0" \\
  -H "Authorization: Bearer aic_live_…"

# Response includes
# {
#   "data": [ ... ],
#   "next_cursor": "eyJpZCI6InAyMSJ9",
#   "has_more": true
# }` },
  },
  'rate-limits': {
    title: 'Rate limits',
    body: [
      ['p', 'Rate limits are per-API-key. Headers on every response report your current state:'],
      ['ul', [
        ['code', 'X-RateLimit-Limit'], ' · ',
        ['code', 'X-RateLimit-Remaining'], ' · ',
        ['code', 'X-RateLimit-Reset'],
      ]],
      ['table', { cols: ['Plan', 'Read/min', 'Write/min', 'Burst'], rows: [
        ['Starter',    60,  10, 100],
        ['Studio Pro', 240, 60, 600],
        ['Studio',     600, 200, 2000],
        ['Enterprise', 'custom', 'custom', 'custom'],
      ]}],
      ['p', 'Heavy operations (e.g. ', ['code', 'POST /projects'], ') count as multiple writes.'],
    ],
    sample: { language: 'bash', code: `# Always honor Retry-After on 429s
curl -i https://api.aicreators.cloud/v1/projects \\
  -H "Authorization: Bearer aic_live_…"

HTTP/2 429
Retry-After: 28
X-RateLimit-Limit: 240
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1715890800` },
  },
  versioning: {
    title: 'Versioning',
    body: [
      ['p', 'We version by URL path (/v1). Breaking changes ship to a new major (/v2). Additive changes ship to /v1 without notice; subscribe to ', ['link', '#changelog', 'the changelog'], ' for additions.'],
      ['p', 'Sunset policy: a deprecated major gets 12 months notice via the ', ['code', 'Sunset'], ' header.'],
    ],
    sample: { language: 'bash', code: `# All requests target /v1
curl https://api.aicreators.cloud/v1/me

# Deprecated endpoints return a Sunset header
HTTP/2 200
Sunset: Sat, 31 Dec 2026 00:00:00 GMT
Deprecation: true
Link: <https://docs.aicreators.cloud/migrate/v1-to-v2>; rel="successor-version"` },
  },
  channels: {
    title: 'Channels',
    body: [
      ['endpoint', 'GET',   '/channels',                  'List all your channels'],
      ['endpoint', 'GET',   '/channels/{id}',             'Retrieve a channel'],
      ['endpoint', 'POST',  '/channels',                  'Create a channel'],
      ['endpoint', 'PATCH', '/channels/{id}',             'Update identity / format / autopilot'],
      ['endpoint', 'DELETE','/channels/{id}',             'Disconnect (data preserved 30 days)'],
      ['endpoint', 'GET',   '/channels/{id}/topics',      'List topic ideas for this channel'],
      ['endpoint', 'POST',  '/channels/{id}/regenerate-topics', 'Force-rescan trends'],
      ['h3', 'Channel object'],
      ['code-block', `{
  "id": "ch_001",
  "name": "Mythic Tales",
  "handle": "@mythictales",
  "youtube_channel_id": "UCxxxxxxxxxxxxxxxxxx",
  "format": "longform",
  "voice_id": "v4",
  "style_id": "s5",
  "avatar_id": null,
  "autopilot_enabled": true,
  "publish_cadence": {
    "days": ["mon","wed","fri"],
    "time_local": "18:00",
    "timezone": "America/New_York"
  },
  "topic_likes": ["ancient mystery","lost cities"],
  "topic_avoids": ["conspiracy","politics"],
  "min_confidence_to_autoqueue": 80,
  "created_at": "2024-11-12T14:32:00Z"
}`],
    ],
    sample: { language: 'bash', code: `curl https://api.aicreators.cloud/v1/channels/ch_001 \\
  -H "Authorization: Bearer aic_live_…"` },
  },
  topics: {
    title: 'Topics',
    body: [
      ['endpoint', 'GET',   '/topics',                'List topic ideas (paginated)'],
      ['endpoint', 'POST',  '/topics',                'Submit your own idea (bypasses scout)'],
      ['endpoint', 'POST',  '/topics/{id}/approve',   'Move to queued'],
      ['endpoint', 'POST',  '/topics/{id}/start',     'Create Project + queue first pipeline stage'],
      ['p', 'New topics are produced by our background scout (~every 6h) and from your own submissions. Subscribe to ', ['code', 'topic.idea'], ' webhook events to get pinged in realtime.'],
    ],
    sample: { language: 'js', code: `const t = await aic.topics.create({
  channel_id: 'ch_001',
  title: 'The Antikythera mechanism, decoded',
});
await aic.topics.start(t.id);  // → creates a Project and starts stage 1` },
  },
  projects: {
    title: 'Projects',
    body: [
      ['endpoint', 'GET',   '/projects',                  'List videos in production'],
      ['endpoint', 'GET',   '/projects/{id}',             'Retrieve a project (full state)'],
      ['endpoint', 'PATCH', '/projects/{id}',             'Title, schedule, autopilot toggle'],
      ['endpoint', 'POST',  '/projects/{id}/cancel',      'Abort + refund unused credits'],
      ['endpoint', 'POST',  '/projects/{id}/publish-now', 'Skip remaining stages, publish immediately'],
      ['h3', 'Per-stage actions'],
      ['endpoint', 'POST',  '/projects/{id}/script/regenerate',  'Re-roll script · body: { technique?, tone? }'],
      ['endpoint', 'POST',  '/projects/{id}/script/approve',     'Approve, advance to storyboard'],
      ['endpoint', 'POST',  '/projects/{id}/images/reroll',      'Re-roll scenes · body: { scene_indices? }'],
      ['endpoint', 'POST',  '/projects/{id}/images/lock',        'Lock a frame · body: { scene_index, frame_id }'],
      ['endpoint', 'POST',  '/projects/{id}/motion/regenerate',  'Re-roll motion clips'],
      ['endpoint', 'POST',  '/projects/{id}/voice/regenerate',   'Re-roll voiceover · body: { voice_id?, speed?, emphasis? }'],
      ['endpoint', 'POST',  '/projects/{id}/voice/preview',      'Generate a short TTS sample'],
      ['endpoint', 'POST',  '/projects/{id}/publish/save-meta',  'Title / description / tags / scheduled_at / thumbnail_idx'],
    ],
    sample: { language: 'js', code: `// Listen to a project advancing in realtime
const ws = aic.projects.stream('p_001', (patch) => {
  console.log(patch); // { stage: 'voice', progress_pct: 42, eta_seconds: 18 }
});` },
  },
  jobs: {
    title: 'Jobs',
    body: [
      ['p', 'A Job is one execution of one pipeline stage. Most you don\'t touch — they\'re created by Project state transitions. Inspect them when debugging failures.'],
      ['endpoint', 'GET',   '/jobs',                'List recent jobs'],
      ['endpoint', 'GET',   '/jobs/{id}',           'Retrieve job + logs URL'],
      ['endpoint', 'POST',  '/jobs/{id}/retry',     'Retry a failed job'],
      ['endpoint', 'POST',  '/jobs/{id}/cancel',    'Cancel a running job'],
    ],
    sample: { language: 'json', code: `{
  "id": "j_8424",
  "project_id": "p_006",
  "stage": "voice",
  "status": "failed",
  "model_id": "avyal-voice-pro",
  "started_at": "2026-05-17T14:02:18.412Z",
  "finished_at": "2026-05-17T14:03:46.318Z",
  "elapsed_ms": 88_906,
  "credits_billed": 4,
  "retries": 3,
  "error_code": "TTS_RATE_LIMIT",
  "logs_url": "https://api.aicreators.cloud/v1/jobs/j_8424/logs"
}`],
    ],
    sample: { language: 'bash', code: `# Retry a failed job, optionally forcing a model swap
curl -X POST https://api.aicreators.cloud/v1/jobs/j_8424/retry \\
  -H "Authorization: Bearer aic_live_…" \\
  -H "Content-Type: application/json" \\
  -d '{"model_id":"avyal-voice-clone"}'` },
  },
  videos: {
    title: 'Videos',
    body: [
      ['endpoint', 'GET',   '/videos',              'List published videos'],
      ['endpoint', 'GET',   '/videos/{id}',         'Retrieve video + per-destination state'],
      ['endpoint', 'POST',  '/videos/{id}/unlist',  'Set platform visibility to unlisted'],
      ['endpoint', 'DELETE','/videos/{id}',         'Take down across all destinations'],
      ['endpoint', 'GET',   '/videos/{id}/analytics?window=7d', 'Views, CTR, AVD, audience, traffic source, retention curve'],
      ['endpoint', 'GET',   '/videos/{id}/ab-tests', 'Thumbnail variants + impressions/CTR'],
      ['endpoint', 'POST',  '/videos/{id}/ab-tests/{variant_id}/promote', 'Promote a variant to primary'],
    ],
    sample: { language: 'js', code: `const stats = await aic.videos.analytics('vid_8431', { window: '30d' });
console.log(stats.views, stats.ctr, stats.avd);` },
  },
  voices: {
    title: 'Voices',
    body: [
      ['endpoint', 'GET',    '/voices',                  'Studio voices + your cloned voices'],
      ['endpoint', 'POST',   '/voices/clone',            'Clone a voice · multipart: { audio_sample, name, consent_proof_url }'],
      ['endpoint', 'GET',    '/voices/{id}/sample.mp3?text=…', 'Preview synthesis'],
      ['endpoint', 'DELETE', '/voices/{id}',             'Delete (immediate, even before account 30-day window)'],
      ['p', '⚠️ Cloning a voice requires consent. If the sample isn\'t the API caller\'s own voice, pass a signed consent record URL.'],
    ],
    sample: { language: 'js', code: `const v = await aic.voices.clone({
  name: 'My Storyteller',
  audio_sample: fs.createReadStream('me-reading-the-script.mp3'),
  consent_proof_url: null,  // null = it's my own voice
});
// Voice is async; poll v.status until 'ready' (~2 min)` },
  },
  avatars: {
    title: 'Avatars',
    body: [
      ['endpoint', 'GET',    '/avatars',                 'List avatars'],
      ['endpoint', 'POST',   '/avatars',                 'Create · multipart: { photo, name, render_style, consent_proof_url? }'],
      ['endpoint', 'POST',   '/avatars/{id}/preview',    'Talking-head sample · body: { voice_id, text }'],
      ['endpoint', 'DELETE', '/avatars/{id}',            'Delete (immediate)'],
    ],
    sample: { language: 'js', code: `const a = await aic.avatars.create({
  name: 'Mihir · talking-head',
  photo: fs.createReadStream('selfie.jpg'),
  render_style: 'realistic',
});` },
  },
  styles: {
    title: 'Visual styles',
    body: [
      ['endpoint', 'GET',    '/styles',          'Studio presets + your custom styles'],
      ['endpoint', 'POST',   '/styles',          'Create style · body: { name, swatch[], notes, prompt_lift?, reference_image_urls?[] }'],
      ['endpoint', 'PATCH',  '/styles/{id}',     'Update'],
      ['endpoint', 'DELETE', '/styles/{id}',     'Delete'],
      ['endpoint', 'POST',   '/styles/{id}/preview', 'Generate a test render with this style'],
    ],
    sample: null,
  },
  integrations: {
    title: 'Integrations',
    body: [
      ['p', 'Each social platform is treated as an integration. Connect via OAuth — we never see passwords.'],
      ['endpoint', 'GET',    '/integrations',                              'List connected accounts grouped by platform'],
      ['endpoint', 'POST',   '/integrations/{platform}/connect',           'Returns OAuth start URL'],
      ['endpoint', 'DELETE', '/integrations/{platform}/accounts/{id}',     'Disconnect'],
      ['endpoint', 'PATCH',  '/integrations/{platform}/accounts/{id}',     'Per-account defaults: { default_visibility, default_hashtags, auto_post }'],
      ['p', 'Supported platforms: ', ['code', 'youtube'], ', ', ['code', 'instagram'], ', ', ['code', 'tiktok'], ', ', ['code', 'x'], ', ', ['code', 'linkedin'], ', ', ['code', 'facebook'], ', ', ['code', 'threads'], ', ', ['code', 'pinterest'], ', ', ['code', 'reddit'], ', ', ['code', 'snapchat'], '.'],
    ],
    sample: null,
  },
  destinations: {
    title: 'Distribution targets',
    body: [
      ['p', 'A DistributionTarget binds a Project to one platform-surface (e.g. "this video → YouTube Long-form" or "this video → Instagram Reel"). Most are created automatically by Project.publish; you can create more.'],
      ['endpoint', 'GET',    '/projects/{id}/destinations',     'List all targets for a project'],
      ['endpoint', 'POST',   '/projects/{id}/destinations',     'Add target · body: { integration_account_id, surface }'],
      ['endpoint', 'PATCH',  '/destinations/{id}',              'Per-target metadata + schedule'],
      ['endpoint', 'POST',   '/destinations/{id}/publish-now',  'Force-publish skipping schedule'],
      ['endpoint', 'POST',   '/destinations/{id}/retry',        'Retry failed publish'],
    ],
    sample: { language: 'json', code: `{
  "id": "dt_001",
  "project_id": "p_001",
  "integration_account_id": "ig_001",
  "platform": "instagram",
  "surface": "reel",
  "status": "scheduled",
  "scheduled_at": "2026-05-17T19:00:00Z",
  "reformat_aspect": "9:16",
  "reformat_duration_seconds": 58,
  "platform_title": "",
  "platform_description": "They told you it burned in one night...",
  "platform_hashtags": ["#history","#mystery","#didyouknow"]
}`],
    ],
  },
  me: {
    title: 'User (you)',
    body: [
      ['endpoint', 'GET',    '/me',                           'Your profile'],
      ['endpoint', 'PATCH',  '/me',                           'Update name / timezone / country'],
      ['endpoint', 'POST',   '/me/data-export',               'Queue a GDPR export job'],
      ['endpoint', 'POST',   '/me/data-deletion',             'Schedule account deletion (30-day grace)'],
      ['endpoint', 'GET',    '/me/api-keys',                  'Your API keys'],
      ['endpoint', 'POST',   '/me/api-keys',                  'Create a key · body: { label, scopes }'],
      ['endpoint', 'DELETE', '/me/api-keys/{id}',             'Revoke'],
    ],
    sample: null,
  },
  billing: {
    title: 'Billing & credits',
    body: [
      ['endpoint', 'GET',  '/billing/plan',              'Current plan + renewal date'],
      ['endpoint', 'POST', '/billing/upgrade',           'Switch plan · body: { plan_id, prorate? }'],
      ['endpoint', 'POST', '/billing/portal',            'Stripe Billing Portal URL'],
      ['endpoint', 'GET',  '/billing/credits/history',   'Credit usage by stage / project'],
      ['endpoint', 'POST', '/billing/credits/topup',     'Buy extra credits · body: { amount }'],
      ['endpoint', 'GET',  '/me/invoices',               'List receipts'],
      ['endpoint', 'GET',  '/me/invoices/{id}.pdf',      'Download a single receipt'],
    ],
    sample: null,
  },
  notifications: {
    title: 'Notifications',
    body: [
      ['endpoint', 'GET',  '/notifications?cursor=&unread_only=', 'List'],
      ['endpoint', 'POST', '/notifications/mark-read',            'Body: { ids[] }'],
      ['endpoint', 'WS',   '/ws/notifications',                   'Realtime push'],
      ['endpoint', 'GET',  '/me/notification-prefs',              'Per-event delivery channel matrix'],
      ['endpoint', 'PATCH','/me/notification-prefs',              'Update'],
    ],
    sample: null,
  },
  team: {
    title: 'Team',
    body: [
      ['endpoint', 'GET',    '/team',                'List members'],
      ['endpoint', 'POST',   '/team/invite',         'Body: { email, role: "editor" | "reviewer" | "viewer" }'],
      ['endpoint', 'PATCH',  '/team/{user_id}',      'Change role'],
      ['endpoint', 'DELETE', '/team/{user_id}',      'Remove'],
    ],
    sample: null,
  },
  websockets: {
    title: 'WebSockets',
    body: [
      ['p', 'WebSocket endpoints push state patches in realtime. Auth with the same Bearer token as REST, via the ', ['code', '?token='], ' query param.'],
      ['ul', [
        ['code', 'wss://api.aicreators.cloud/v1/ws/projects/{id}'], ' · ',
        ['code', 'wss://api.aicreators.cloud/v1/ws/notifications'], ' · ',
        ['code', 'wss://api.aicreators.cloud/v1/ws/jobs/{id}/logs'],
      ]],
      ['p', 'Patches are JSON frames matching the shape of the resource. We don\'t ship the whole resource on every update — just the changed keys.'],
    ],
    sample: { language: 'js', code: `const ws = new WebSocket(
  \`wss://api.aicreators.cloud/v1/ws/projects/p_001?token=\${apiKey}\`
);
ws.onmessage = (e) => {
  const patch = JSON.parse(e.data);
  // { stage: 'voice', stage_state: 'running', progress_pct: 42, eta_seconds: 18 }
};` },
  },
  webhooks: {
    title: 'Webhooks',
    body: [
      ['p', 'Register URLs to receive event POSTs. Payloads are signed with HMAC-SHA256; verify the ', ['code', 'X-Aic-Signature'], ' header before acting.'],
      ['endpoint', 'GET',    '/webhooks',                 'List'],
      ['endpoint', 'POST',   '/webhooks',                 'Body: { url, events[], secret }'],
      ['endpoint', 'PATCH',  '/webhooks/{id}',            'Pause / resume'],
      ['endpoint', 'POST',   '/webhooks/{id}/test',       'Fire a test payload'],
      ['endpoint', 'DELETE', '/webhooks/{id}',            'Delete'],
      ['h3', 'Event types'],
      ['table', { cols: ['Event', 'Fires when'], rows: [
        ['video.published',       'A video is live on a destination'],
        ['video.scheduled',       'Distribution target is scheduled'],
        ['job.failed',            'A pipeline job failed all retries'],
        ['job.done',              'A pipeline job completed'],
        ['topic.idea',            'A new AI-scouted topic appears'],
        ['topic.queued',          'A topic is approved for production'],
        ['channel.connected',     'A new YouTube / IG / etc. account is linked'],
        ['channel.disconnected',  'OAuth was revoked'],
        ['user.upgraded',         'Plan upgrade'],
        ['user.cancelled',        'Subscription cancelled'],
        ['credits.depleted',      'Account hit 0 credits'],
        ['moderation.flagged',    'Content was held for review'],
      ]}],
    ],
    sample: { language: 'js', code: `// Express verification example
import { createHmac } from 'crypto';

app.post('/webhooks/aic', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.header('X-Aic-Signature');
  const expected = createHmac('sha256', process.env.AIC_WEBHOOK_SECRET)
    .update(req.body).digest('hex');
  if (sig !== expected) return res.status(400).send('bad signature');

  const event = JSON.parse(req.body);
  switch (event.type) {
    case 'video.published':   /* ... */ break;
    case 'job.failed':        /* ... */ break;
  }
  res.sendStatus(200);
});` },
  },
};

function APIDocsApp() {
  const [active, setActive] = React.useState(() => (window.location.hash || '#intro').replace(/^#/, ''));
  const [lang, setLang] = React.useState('bash');

  React.useEffect(() => {
    const onHash = () => setActive((window.location.hash || '#intro').replace(/^#/, ''));
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const ep = API_ENDPOINTS[active] || API_ENDPOINTS.intro;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-app)' }}>
      <header style={{ padding: '14px 32px', display: 'flex', alignItems: 'center', gap: 16, borderBottom: '1px solid var(--border-hairline)', background: 'var(--glass-bg-header)', backdropFilter: 'blur(20px)', position: 'sticky', top: 0, zIndex: 50 }}>
        <a href="AIcreators Cloud Home.html" style={{ textDecoration: 'none', display: 'inline-flex' }}>
          <LogoLockup markSize={28} wordSize={15}/>
        </a>
        <span style={{ padding: '4px 10px', borderRadius: 999, background: 'var(--surface-hover)', font: '600 11px/1 var(--font-sans)', color: 'var(--fg-muted)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>API · v1</span>
        <div style={{ flex: 1 }}/>
        <div style={{ position: 'relative' }}>
          <I.Search size={14} stroke="var(--fg-muted)" style={{ position: 'absolute', top: 11, left: 12 }}/>
          <input placeholder="Search the docs… ⌘ K" style={{ height: 36, width: 320, paddingLeft: 36, fontSize: 13 }}/>
        </div>
        <a href="AIcreators Cloud.html#api-keys" style={{ textDecoration: 'none' }}><Btn kind="secondary" size="sm">Get an API key</Btn></a>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr 420px', maxWidth: 1440, margin: '0 auto', minHeight: 'calc(100vh - 65px)' }}>
        {/* Sidebar */}
        <aside style={{ padding: '24px 16px 24px 32px', borderRight: '1px solid var(--border-hairline)' }}>
          {API_NAV.map(group => (
            <div key={group.group} style={{ marginBottom: 22 }}>
              <div className="t-tiny" style={{ marginBottom: 8 }}>{group.group}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {group.items.map(it => {
                  const isActive = active === it.id;
                  return (
                    <a key={it.id} href={`#${it.id}`} style={{
                      padding: '7px 10px', borderRadius: 8,
                      font: `${isActive ? 600 : 500} 13px/1.3 var(--font-sans)`,
                      color: isActive ? 'var(--brand)' : 'var(--fg-default)',
                      textDecoration: 'none',
                      background: isActive ? 'var(--brand-soft-bg)' : 'transparent',
                    }}>{it.label}</a>
                  );
                })}
              </div>
            </div>
          ))}
        </aside>

        {/* Content */}
        <main style={{ padding: '32px 40px 80px', minWidth: 0 }}>
          <div className="t-tiny" style={{ marginBottom: 8 }}>{API_NAV.find(g => g.items.some(i => i.id === active))?.group}</div>
          <h1 style={{ font: '700 36px/1.1 var(--font-display)', letterSpacing: '-0.02em', color: 'var(--fg-strong)', marginBottom: 24 }}>{ep.title}</h1>
          {ep.body.map((node, i) => <RenderNode key={i} node={node}/>)}
        </main>

        {/* Right rail — code samples */}
        <aside style={{ padding: '32px 32px 32px 24px', borderLeft: '1px solid var(--border-hairline)', background: 'var(--surface-subtle)' }}>
          {ep.sample ? (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                <span className="t-tiny" style={{ flex: 1 }}>Code sample</span>
                <Tabs value={lang} onChange={setLang} items={[
                  { id: 'bash', label: 'cURL' },
                  { id: 'js',   label: 'Node' },
                  { id: 'py',   label: 'Python' },
                ]}/>
              </div>
              <CodeBlock code={ep.sample.code}/>
            </div>
          ) : (
            <div style={{ position: 'sticky', top: 100 }}>
              <div className="t-tiny" style={{ marginBottom: 12 }}>Browse SDKs</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {['Node / TypeScript','Python','Go','Ruby','PHP','Java'].map(sdk => (
                  <a key={sdk} href="#" className="card card--hover" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 12, textDecoration: 'none' }}>
                    <I.Code size={14} stroke="var(--brand)"/>
                    <span style={{ font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)', flex: 1 }}>{sdk} SDK</span>
                    <I.ChevRight size={12} stroke="var(--fg-muted)"/>
                  </a>
                ))}
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

function CodeBlock({ code }) {
  return (
    <div style={{ position: 'relative' }}>
      <button className="btn btn--ghost btn--icon btn--sm" style={{ position: 'absolute', top: 8, right: 8, width: 28, height: 28, background: 'rgba(255,255,255,0.08)' }}><I.Copy size={12} stroke="white"/></button>
      <pre style={{
        margin: 0, padding: '14px 16px',
        background: '#0B0C16', color: '#E5E7F2',
        font: '500 12px/1.6 var(--font-mono)',
        borderRadius: 10, overflow: 'auto',
        border: '1px solid var(--border-default)',
        whiteSpace: 'pre',
      }}><code>{code}</code></pre>
    </div>
  );
}

function RenderNode({ node }) {
  if (typeof node === 'string') return <span>{node}</span>;
  if (!Array.isArray(node)) return null;
  const [tag, ...rest] = node;
  switch (tag) {
    case 'p':
      return <p style={{ font: '500 15px/1.7 var(--font-sans)', color: 'var(--fg-default)', margin: '0 0 16px', textWrap: 'pretty' }}>
        {rest.map((r, i) => <RenderNode key={i} node={r}/>)}
      </p>;
    case 'h3':
      return <h3 style={{ font: '600 18px/1.3 var(--font-display)', color: 'var(--fg-strong)', marginTop: 24, marginBottom: 10 }}>{rest[0]}</h3>;
    case 'code':
      return <code style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)', padding: '2px 6px', background: 'var(--surface-hover)', borderRadius: 4, border: '1px solid var(--border-hairline)' }}>{rest[0]}</code>;
    case 'link':
      return <a href={rest[0]} style={{ color: 'var(--brand)', fontWeight: 600 }}>{rest[1]}</a>;
    case 'ul':
      return <ul style={{ font: '500 14px/1.8 var(--font-sans)', color: 'var(--fg-default)', margin: '0 0 16px', paddingLeft: 22 }}>
        {(rest[0] || []).map((r, i) => <li key={i}><RenderNode node={r}/></li>)}
      </ul>;
    case 'endpoint':
      const [method, path, desc] = rest;
      const colors = { GET: '#10B981', POST: 'var(--brand)', PATCH: '#F59E0B', DELETE: 'var(--danger)', WS: '#8B5CF6' };
      return (
        <div style={{ display: 'grid', gridTemplateColumns: '64px 1fr 2fr', gap: 12, alignItems: 'center', padding: '10px 12px', borderRadius: 8, background: 'var(--surface-subtle)', border: '1px solid var(--border-hairline)', marginBottom: 6 }}>
          <span style={{ padding: '4px 8px', borderRadius: 4, font: '700 11px/1 var(--font-mono)', color: 'white', background: colors[method] || 'var(--fg-muted)', textAlign: 'center' }}>{method}</span>
          <span className="t-mono" style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{path}</span>
          <span className="t-small">{desc}</span>
        </div>
      );
    case 'table':
      const { cols, rows } = rest[0];
      return (
        <div className="card" style={{ padding: 0, marginBottom: 18, overflow: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {cols.map(c => <th key={c} style={{ padding: '10px 14px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{c}</th>)}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} style={{ borderTop: '1px solid var(--border-hairline)' }}>
                  {r.map((cell, j) => <td key={j} style={{ padding: '10px 14px', font: j === 0 ? '600 13px/1.3 var(--font-mono)' : '500 13px/1.3 var(--font-sans)', color: j === 0 ? 'var(--fg-strong)' : 'var(--fg-default)' }}>{cell}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    case 'code-block':
      return <pre style={{ margin: '0 0 16px', padding: 14, background: '#0B0C16', color: '#E5E7F2', font: '500 12px/1.6 var(--font-mono)', borderRadius: 10, overflow: 'auto' }}><code>{rest[0]}</code></pre>;
    default: return null;
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(<APIDocsApp/>);
