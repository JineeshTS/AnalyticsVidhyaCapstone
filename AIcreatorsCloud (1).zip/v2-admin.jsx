/* ============================================================
   AIcreators V2 — Admin / ops console
   ============================================================
   Dark, dense, mono-typography, lime accents on alerts and
   active states. Same brand DNA as customer app but tuned for
   operators monitoring infrastructure.
   ============================================================ */

const I = V2I;

function V2AdminApp() {
  const [active, setActive] = React.useState('overview');
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <V2AdminNav/>
      <div style={{ display: 'flex', flex: 1, minHeight: 0 }}>
        <V2AdminSidebar active={active} onNav={setActive}/>
        <main style={{ flex: 1, overflow: 'auto' }}>
          {active === 'overview' && <V2AdminOverview/>}
          {active === 'users' && <V2AdminUsers/>}
          {active === 'jobs' && <V2AdminJobs/>}
          {active === 'moderation' && <V2AdminModeration/>}
          {active === 'gpu' && <V2AdminGPU/>}
          {active === 'cohorts' && <V2AdminCohorts/>}
          {active === 'plans' && <V2AdminPlans/>}
          {!['overview','users','jobs','moderation','gpu','cohorts','plans'].includes(active) && (
            <V2AdminPlaceholder section={active}/>
          )}
        </main>
      </div>
      <V2ThemeToggle/>
    </div>
  );
}

/* ---------- TOP NAV ---------- */
function V2AdminNav() {
  return (
    <header style={{
      padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 14,
      borderBottom: '1px solid var(--border-hairline)',
      background: 'var(--ink-950)',
    }}>
      <Logo markSize={26} wordSize={15}/>
      <span style={{ padding: '4px 8px', borderRadius: 999, background: 'rgba(255,255,255,0.06)', font: '600 10px/1 var(--font-mono)', color: 'var(--fg-muted)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>OPS · v2</span>
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 12px', background: 'var(--ink-850)', borderRadius: 8, border: '1px solid var(--border-hairline)' }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }} className="ai-pulse"/>
        <span className="t-mono" style={{ font: '600 11px/1 var(--font-mono)', color: 'var(--fg-default)', letterSpacing: '0.04em' }}>ALL SYSTEMS OK</span>
      </div>
      <button className="btn btn--ghost btn--sm">
        <I.Search size={14}/>
        <span style={{ font: '500 12px/1 var(--font-mono)', color: 'var(--fg-muted)' }}>⌘K</span>
      </button>
      <button className="btn btn--ghost btn--icon"><I.Bell size={16}/></button>
      <div style={{
        width: 32, height: 32, borderRadius: '50%',
        background: 'var(--accent)', color: 'var(--ink-950)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        font: '700 12px/1 var(--font-display)',
      }}>MV</div>
    </header>
  );
}

/* ---------- SIDEBAR ---------- */
function V2AdminSidebar({ active, onNav }) {
  const groups = [
    { l: 'OPERATE', items: [
      { id: 'overview',   l: 'Overview',    icon: 'BarChart' },
      { id: 'users',      l: 'Users',       icon: 'User' },
      { id: 'jobs',       l: 'Jobs queue',  icon: 'Pipeline', badge: 12 },
      { id: 'moderation', l: 'Moderation',  icon: 'Eye',      badge: 5 },
      { id: 'tickets',    l: 'Support',     icon: 'Bell' },
    ]},
    { l: 'INFRA', items: [
      { id: 'models',   l: 'Models',        icon: 'Robot' },
      { id: 'gpu',      l: 'GPU pool',      icon: 'Bolt' },
      { id: 'cohorts',  l: 'Cohorts',       icon: 'Layers' },
      { id: 'flags',    l: 'Feature flags', icon: 'Spark' },
    ]},
    { l: 'BUSINESS', items: [
      { id: 'plans',    l: 'Pricing',       icon: 'Credit' },
      { id: 'emails',   l: 'Email',         icon: 'Send' },
      { id: 'api',      l: 'API · webhooks', icon: 'Folder' },
      { id: 'audit',    l: 'Audit',         icon: 'Settings' },
    ]},
  ];
  return (
    <aside style={{
      width: 240, flexShrink: 0,
      background: 'var(--ink-950)',
      borderRight: '1px solid var(--border-hairline)',
      padding: '16px 12px',
      overflowY: 'auto',
    }}>
      {groups.map(g => (
        <div key={g.l} style={{ marginBottom: 22 }}>
          <div className="t-tiny" style={{ padding: '0 10px 8px' }}>{g.l}</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {g.items.map(it => {
              const Ico = I[it.icon];
              const isActive = active === it.id;
              return (
                <button key={it.id} onClick={() => onNav(it.id)} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '8px 10px', borderRadius: 8,
                  background: isActive ? 'var(--accent-tint)' : 'transparent',
                  color: isActive ? 'var(--accent)' : 'var(--fg-default)',
                  font: `${isActive ? 600 : 500} 13px/1 var(--font-sans)`,
                  border: 0, cursor: 'pointer', textAlign: 'left',
                }}>
                  <Ico size={14}/>
                  <span style={{ flex: 1 }}>{it.l}</span>
                  {it.badge && (
                    <span style={{
                      padding: '2px 6px', borderRadius: 4, font: '600 10px/1 var(--font-mono)',
                      background: 'var(--warning)', color: 'var(--ink-950)', letterSpacing: '0.04em',
                    }}>{it.badge}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </aside>
  );
}

/* ---------- OVERVIEW ---------- */
function V2AdminOverview() {
  const W = 920, H = 200;
  const data = [22,23,24,24,25,26,27,28,29,30,31,32,33,34,35,37,38,40,42,43,45,46,47,48,49,50,51,52,53,54];
  const max = Math.max(...data);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * W},${H - ((v - 20) / (max - 20)) * (H - 16)}`);
  const path = `M${pts.join(' L')}`;
  return (
    <div style={{ padding: '28px 32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginBottom: 28 }}>
        <div style={{ flex: 1 }}>
          <div className="t-tiny">today · {new Date().toDateString().toUpperCase()}</div>
          <h1 className="t-h2" style={{ marginTop: 6 }}>Overview</h1>
          <div className="t-small" style={{ marginTop: 6 }}>KPIs, MRR, system health · polling 10s</div>
        </div>
        <button className="btn btn--secondary btn--sm"><I.Calendar size={14}/> 30 days</button>
      </div>

      {/* Top KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
        {[
          { l: 'MRR equivalent', v: '$48.2k', d: '+12.4%', up: true, accent: true },
          { l: 'Active users',   v: '2,184',  d: '+8.1%',  up: true },
          { l: 'Videos shipped 30d', v: '6,420', d: '+22%', up: true },
          { l: 'Spent on compute', v: '$11.8k', d: '+18%', up: false },
        ].map((s, i) => (
          <div key={i} className="card" style={s.accent ? { background: 'var(--accent-tint)', borderColor: 'var(--accent-border)' } : {}}>
            <div className="t-tiny" style={s.accent ? { color: 'var(--accent)' } : {}}>{s.l}</div>
            <div style={{ font: '700 32px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 12, letterSpacing: '-0.025em' }}>{s.v}</div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginTop: 8, font: '600 12px/1 var(--font-mono)', color: s.up ? 'var(--accent)' : 'var(--warning)' }}>
              <I.ArrowRight size={11} style={{ transform: s.up ? 'rotate(-45deg)' : 'rotate(45deg)' }}/>
              {s.d}
            </div>
          </div>
        ))}
      </div>

      {/* Big chart */}
      <div className="card" style={{ marginBottom: 16, padding: 22 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <div className="t-h4">MRR — last 30 days</div>
          <span className="chip chip--accent">+12.4%</span>
          <div style={{ flex: 1 }}/>
          <div style={{ display: 'flex', gap: 4 }}>
            {['MRR','ARR','ARPU'].map((t, i) => (
              <button key={t} className={i === 0 ? 'btn btn--secondary btn--sm' : 'btn btn--ghost btn--sm'}>{t}</button>
            ))}
          </div>
        </div>
        <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block' }}>
          <defs>
            <linearGradient id="mrrGr" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#CCFF00" stopOpacity="0.55"/>
              <stop offset="100%" stopColor="#CCFF00" stopOpacity="0"/>
            </linearGradient>
          </defs>
          {[0.25, 0.5, 0.75].map((y, i) => <line key={i} x1="0" x2={W} y1={H * y} y2={H * y} stroke="rgba(255,255,255,0.04)" strokeWidth="1"/>)}
          <path d={`${path} L${W},${H} L0,${H} Z`} fill="url(#mrrGr)"/>
          <path d={path} fill="none" stroke="#CCFF00" strokeWidth="2"/>
        </svg>
      </div>

      {/* System health grid */}
      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: '16px 22px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center' }}>
          <div className="t-h4">System health</div>
          <div style={{ flex: 1 }}/>
          <button className="btn btn--ghost btn--sm"><I.ChevDown size={14}/> All services</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 0 }}>
          {[
            ['API gateway',          'ok',   '420 rps', '38ms',   '0.02%'],
            ['Script (LLM)',         'ok',   '14 rps',  '4.2s',   '0.10%'],
            ['Image-to-video',       'warn', '8 rps',   '38s',    '0.62%', 'Queue lag · W4 down'],
            ['Voice TTS',            'ok',   '48 rps',  '0.9s',   '0.04%'],
            ['YouTube uploader',     'warn', '1.2 rps', '34s',    '1.20%', 'OAuth refresh failing'],
            ['Razorpay webhook',     'ok',   '2 rps',   '180ms',  '0.00%'],
            ['Postgres primary',     'ok',   '2.4k qps','4ms',    '0.00%'],
            ['Redis · queue',        'ok',   '8.4k ops','1.2ms',  '0.00%'],
          ].map(([svc, status, rps, p95, err, note], i) => (
            <div key={svc} style={{
              padding: '14px 22px', display: 'grid', gridTemplateColumns: '12px 1fr 80px 80px 60px',
              gap: 12, alignItems: 'center', borderBottom: '1px solid var(--border-hairline)',
              borderRight: i % 2 === 0 ? '1px solid var(--border-hairline)' : 'none',
            }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: status === 'ok' ? 'var(--accent)' : 'var(--warning)' }}/>
              <div style={{ minWidth: 0 }}>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{svc}</div>
                {note && <div className="t-small" style={{ marginTop: 4, color: status === 'warn' ? 'var(--warning)' : 'var(--fg-muted)' }}>{note}</div>}
              </div>
              <span className="t-mono t-small" style={{ color: 'var(--fg-default)' }}>{rps}</span>
              <span className="t-mono t-small">p95 {p95}</span>
              <span className="t-mono t-small">{err}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- USERS ---------- */
function V2AdminUsers() {
  const users = [
    ['u_001', 'Mihir Vaishnav',  'mihir@…',  'Pro',     '38',  '$890.40', 'active', 'IN'],
    ['u_002', 'Priya Shah',      'priya@…',  'Studio',  '142', '$2,840',  'active', 'IN'],
    ['u_003', 'Daniel Cho',      'daniel@…', 'Pro',     '22',  '$420.80', 'active', 'KR'],
    ['u_004', 'Lila Becker',     'lila@…',   'Starter', '6',   '$120',    'past_due', 'DE'],
    ['u_005', 'Akira Watanabe',  'akira@…',  'Pro',     '31',  '$620',    'active', 'JP'],
    ['u_006', 'Hossam K.',       'hossam@…', 'Pro',     '47',  '$940.20', 'active', 'EG'],
    ['u_007', 'Sofia Costa',     'sofia@…',  'Starter', '11',  '$220',    'active', 'BR'],
    ['u_008', 'Marie L.',        'marie@…',  'Trial',   '2',   '$0',      'trial', 'FR'],
    ['u_009', 'Carlos Ruiz',     'carlos@…', 'Studio',  '96',  '$1,920',  'active', 'MX'],
  ];
  return (
    <div style={{ padding: '28px 32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginBottom: 24 }}>
        <div style={{ flex: 1 }}>
          <div className="t-tiny">users · 2,184 active</div>
          <h1 className="t-h2" style={{ marginTop: 6 }}>Users</h1>
        </div>
        <button className="btn btn--ghost btn--sm"><I.Search size={14}/> Search · email, id, name</button>
        <button className="btn btn--secondary btn--sm">Export CSV</button>
      </div>

      {/* Filter pills */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
        {['All · 2.1k', 'Active · 2.0k', 'Past due · 14', 'Trial · 38', 'Banned · 3'].map((p, i) => (
          <button key={p} className={i === 0 ? 'chip chip--accent' : 'chip'} style={{ cursor: 'pointer', border: 0 }}>{p}</button>
        ))}
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--ink-850)' }}>
              {['User','Email','Plan','Videos 30d','Lifetime','Status','Region',''].map(h => (
                <th key={h} className="t-tiny" style={{ padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map(([id, name, email, plan, vids, ltv, status, region]) => (
              <tr key={id} style={{ borderBottom: '1px solid var(--border-hairline)', cursor: 'pointer' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--ink-800)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                <td style={{ padding: '12px 14px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--ink-700)', color: 'var(--fg-default)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', font: '600 11px/1 var(--font-display)' }}>{name.split(' ').map(n=>n[0]).join('').slice(0,2)}</span>
                    <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{name}</span>
                  </div>
                </td>
                <td style={{ padding: '12px 14px' }} className="t-mono t-small">{email}</td>
                <td style={{ padding: '12px 14px' }}><span className="chip" style={{ height: 22, fontSize: 10 }}>{plan}</span></td>
                <td style={{ padding: '12px 14px' }} className="t-mono t-small" style={{ color: 'var(--fg-default)' }}>{vids}</td>
                <td style={{ padding: '12px 14px' }} className="t-mono" style={{ font: '600 12px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{ltv}</td>
                <td style={{ padding: '12px 14px' }}>
                  {status === 'active'   && <span className="chip chip--accent">active</span>}
                  {status === 'past_due' && <span className="chip chip--warning">past due</span>}
                  {status === 'trial'    && <span className="chip">trial</span>}
                </td>
                <td style={{ padding: '12px 14px' }} className="t-mono t-small">{region}</td>
                <td style={{ padding: '12px 14px', textAlign: 'right' }}>
                  <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------- JOBS QUEUE ---------- */
function V2AdminJobs() {
  const jobs = [
    ['j_8421', 'Priya · Volcanic lightning',  'motion',  'running', 'A100-W2', '02:14', '$11.20', null],
    ['j_8422', 'Daniel · Detective',           'frames',  'review',  '—',       '00:00', '$8.40',  null],
    ['j_8423', 'Mihir · Lost Library',         'publish', 'running', '—',       '00:48', '$2.00',  null],
    ['j_8424', 'Hossam · Clouds talk',         'voice',   'failed',  '—',       '00:42', '$4.20',  'TTS_RATE_LIMIT'],
    ['j_8425', 'Carlos · Aztec calendars',     'script',  'running', '—',       '00:31', '$5.40',  null],
    ['j_8426', 'Akira · Pufferfish',           'motion',  'queued',  '—',       '00:00', '$0',     null],
    ['j_8427', 'Priya · Quantum tunneling',    'frames',  'running', 'A100-W7', '01:42', '$9.60',  null],
    ['j_8428', 'Lila · Berlin nights',         'edit',    'failed',  '—',       '04:18', '$8.00',  'RENDER_OOM'],
  ];
  return (
    <div style={{ padding: '28px 32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginBottom: 24 }}>
        <div style={{ flex: 1 }}>
          <div className="t-tiny">live · 147 jobs in flight</div>
          <h1 className="t-h2" style={{ marginTop: 6 }}>Jobs queue</h1>
        </div>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 10px', borderRadius: 8, background: 'var(--accent-tint)', border: '1px solid var(--accent-border)' }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)' }} className="ai-pulse"/>
          <span className="t-mono" style={{ font: '600 11px/1 var(--font-mono)', color: 'var(--accent)' }}>WS · LIVE</span>
        </span>
        <button className="btn btn--secondary btn--sm">Retry all failed</button>
      </div>

      {/* Status counters */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, marginBottom: 14 }}>
        {[
          { l: 'Running',  v: '34' },
          { l: 'Queued',   v: '84' },
          { l: 'Review',   v: '6',  tone: 'warning' },
          { l: 'Failed',   v: '7',  tone: 'danger' },
          { l: 'Done (1h)',v: '42', tone: 'accent' },
        ].map((s, i) => {
          const bg = s.tone === 'warning' ? 'var(--warning-tint)' : s.tone === 'danger' ? 'var(--danger-tint)' : s.tone === 'accent' ? 'var(--accent-tint)' : 'var(--bg-surface)';
          const bd = s.tone === 'warning' ? 'var(--warning-border)' : s.tone === 'danger' ? 'var(--danger-border)' : s.tone === 'accent' ? 'var(--accent-border)' : 'var(--border-hairline)';
          const c = s.tone === 'warning' ? 'var(--warning)' : s.tone === 'danger' ? 'var(--danger)' : s.tone === 'accent' ? 'var(--accent)' : 'var(--fg-default)';
          return (
            <div key={i} className="card" style={{ padding: 16, background: bg, borderColor: bd }}>
              <div className="t-tiny" style={{ color: c }}>{s.l}</div>
              <div style={{ font: '700 28px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 8 }}>{s.v}</div>
            </div>
          );
        })}
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--ink-850)' }}>
              {['Job','User · Project','Stage','GPU','Elapsed','Cost','Status',''].map(h => (
                <th key={h} className="t-tiny" style={{ padding: '10px 14px', textAlign: 'left', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {jobs.map(([id, proj, stage, status, gpu, el, cost, errCode]) => (
              <tr key={id} style={{ borderBottom: '1px solid var(--border-hairline)' }}>
                <td style={{ padding: '11px 14px' }} className="t-mono t-small" style={{ color: 'var(--fg-strong)' }}>{id}</td>
                <td style={{ padding: '11px 14px', font: '500 13px/1.3 var(--font-sans)', color: 'var(--fg-default)' }}>
                  {proj}
                  {errCode && <div className="t-mono t-small" style={{ marginTop: 4, color: 'var(--danger)' }}>{errCode}</div>}
                </td>
                <td style={{ padding: '11px 14px' }}><span className="chip" style={{ height: 22, fontSize: 10 }}>{stage}</span></td>
                <td style={{ padding: '11px 14px' }} className="t-mono t-small">{gpu}</td>
                <td style={{ padding: '11px 14px' }} className="t-mono t-small">{el}</td>
                <td style={{ padding: '11px 14px' }} className="t-mono" style={{ font: '600 12px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{cost}</td>
                <td style={{ padding: '11px 14px' }}>
                  {status === 'running' && <span className="chip chip--accent" style={{ height: 22, fontSize: 10 }}>running</span>}
                  {status === 'queued'  && <span className="chip" style={{ height: 22, fontSize: 10 }}>queued</span>}
                  {status === 'review'  && <span className="chip chip--warning" style={{ height: 22, fontSize: 10 }}>review</span>}
                  {status === 'failed'  && <span className="chip chip--danger" style={{ height: 22, fontSize: 10 }}>failed</span>}
                </td>
                <td style={{ padding: '11px 14px', textAlign: 'right', whiteSpace: 'nowrap' }}>
                  {status === 'failed' && <button className="btn btn--ghost btn--icon btn--sm" title="Retry"><I.ChevRight size={12}/></button>}
                  <button className="btn btn--ghost btn--icon btn--sm"><I.More size={12}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------- MODERATION ---------- */
function V2AdminModeration() {
  const items = [
    { id: 'mod_001', kind: 'script',    user: 'Hossam K.',     project: 'War footage explainer', flag: 'Violence', conf: 0.78, age: '12 min', snippet: '…describes graphic injuries to a civilian convoy…' },
    { id: 'mod_002', kind: 'image',     user: 'Daniel Cho',    project: 'Brand history',         flag: 'Trademark', conf: 0.91, age: '18 min', snippet: 'Generated Coca-Cola wordmark detected on bottle' },
    { id: 'mod_003', kind: 'thumbnail', user: 'Lila Becker',   project: 'Berlin nights',         flag: 'Misleading', conf: 0.62, age: '34 min', snippet: 'Title: "THE TRUTH GOVERNMENTS HIDE"' },
    { id: 'mod_004', kind: 'voice',     user: 'Sofia Costa',   project: 'Carnival history',      flag: 'Impersonation', conf: 0.84, age: '1h', snippet: 'Cloned voice 92% match — flagged celebrity vector' },
  ];
  return (
    <div style={{ padding: '28px 32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginBottom: 24 }}>
        <div style={{ flex: 1 }}>
          <div className="t-tiny">awaiting decision · pipeline paused for each</div>
          <h1 className="t-h2" style={{ marginTop: 6 }}>Moderation</h1>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {items.map(m => (
          <div key={m.id} className="card" style={{ display: 'grid', gridTemplateColumns: '64px 1fr auto', gap: 16, alignItems: 'center' }}>
            <div style={{ width: 64, height: 64, borderRadius: 12, background: m.kind === 'image' ? 'linear-gradient(135deg,#1F2030,#5F6479)' : 'var(--ink-800)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--fg-default)' }}>
              {React.createElement(I[m.kind === 'image' ? 'Image' : m.kind === 'thumbnail' ? 'Image' : m.kind === 'script' ? 'Edit' : 'Mic'], { size: 22 })}
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <span style={{ font: '600 14px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.flag}</span>
                <span className="chip" style={{ height: 22, fontSize: 10 }}>{m.kind}</span>
                <span className="chip chip--warning" style={{ height: 22, fontSize: 10 }}>{(m.conf*100).toFixed(0)}% conf</span>
                <span className="t-mono t-small">{m.id}</span>
              </div>
              <div className="t-small" style={{ marginBottom: 6 }}>{m.user} · {m.project} · {m.age}</div>
              <div style={{ font: '500 13px/1.5 var(--font-sans)', color: 'var(--fg-secondary)', fontStyle: 'italic' }}>"{m.snippet}"</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
              <button className="btn btn--accent btn--sm"><I.Check size={14}/> Approve · resume</button>
              <button className="btn btn--danger btn--sm"><I.Close size={14}/> Reject</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- GPU POOL ---------- */
function V2AdminGPU() {
  const gpus = [
    { id: 'A100-W1', util: 92, region: 'us-east',   status: 'ok' },
    { id: 'A100-W2', util: 86, region: 'us-east',   status: 'ok' },
    { id: 'A100-W3', util: 71, region: 'us-west',   status: 'ok' },
    { id: 'A100-W4', util:  0, region: 'us-west',   status: 'down', note: 'NCCL timeout · 02h 14m' },
    { id: 'A100-W5', util: 64, region: 'eu-west',   status: 'ok' },
    { id: 'A100-W6', util: 88, region: 'eu-west',   status: 'ok' },
    { id: 'A100-W7', util: 95, region: 'ap-south',  status: 'hot',  note: 'Thermal 78°C' },
    { id: 'A100-W8', util: 12, region: 'ap-south',  status: 'ok' },
  ];
  return (
    <div style={{ padding: '28px 32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginBottom: 24 }}>
        <div style={{ flex: 1 }}>
          <div className="t-tiny">8 nodes · 4 regions · 1 down · 1 hot</div>
          <h1 className="t-h2" style={{ marginTop: 6 }}>GPU pool</h1>
        </div>
        <button className="btn btn--accent btn--sm"><I.Plus size={14}/> Scale up</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {gpus.map(g => {
          const color = g.status === 'down' ? 'var(--danger)' : g.status === 'hot' ? 'var(--warning)' : 'var(--accent)';
          return (
            <div key={g.id} className="card" style={{ padding: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: color }}/>
                <span className="t-mono" style={{ font: '700 14px/1 var(--font-mono)', color: 'var(--fg-strong)' }}>{g.id}</span>
                <div style={{ flex: 1 }}/>
                <span className="t-tiny">{g.region}</span>
              </div>
              <div style={{ marginTop: 14, font: '700 36px/1 var(--font-display)', color: g.status === 'down' ? 'var(--danger)' : 'var(--fg-strong)', letterSpacing: '-0.02em' }}>{g.util}%</div>
              <div className="t-small" style={{ marginTop: 4 }}>utilization</div>
              <div style={{ height: 4, background: 'var(--ink-800)', borderRadius: 999, overflow: 'hidden', marginTop: 12 }}>
                <div style={{ width: `${g.util}%`, height: '100%', background: color }}/>
              </div>
              {g.note && <div className="t-small" style={{ marginTop: 10, color }}>{g.note}</div>}
              <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
                <button className="btn btn--ghost btn--sm" style={{ flex: 1 }}>Logs</button>
                <button className="btn btn--ghost btn--sm" style={{ flex: 1 }}>Drain</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- COHORTS / RETENTION ---------- */
function V2AdminCohorts() {
  const months = ['Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May'];
  const data = [
    [100, 78, 64, 58, 52, 49, 47, 45, 44],
    [100, 80, 67, 60, 55, 52, 50, 48, null],
    [100, 82, 70, 64, 58, 55, 53, null, null],
    [100, 85, 72, 67, 61, 58, null, null, null],
    [100, 86, 75, 69, 64, null, null, null, null],
    [100, 88, 78, 71, null, null, null, null, null],
    [100, 88, 80, null, null, null, null, null, null],
    [100, 90, null, null, null, null, null, null, null],
    [100, null, null, null, null, null, null, null, null],
  ];
  const sizes = ['184','212','244','268','312','356','402','488','536'];
  return (
    <div style={{ padding: '28px 32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginBottom: 24 }}>
        <div style={{ flex: 1 }}>
          <div className="t-tiny">retention by signup month · last 9 months</div>
          <h1 className="t-h2" style={{ marginTop: 6 }}>Cohorts</h1>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 18 }}>
        {[
          ['M1 retention',  '87.2%', '+2.4pp'],
          ['M3 retention',  '71.4%', '+4.1pp'],
          ['M6 retention',  '56.8%', '+1.8pp'],
          ['LTV (12mo)',    '$844',  '+12%'],
        ].map(([l, v, d]) => (
          <div key={l} className="card">
            <div className="t-tiny">{l}</div>
            <div style={{ font: '700 26px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 10, letterSpacing: '-0.02em' }}>{v}</div>
            <div style={{ font: '600 12px/1 var(--font-mono)', color: 'var(--accent)', marginTop: 8 }}>{d}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: 22 }}>
        <div className="t-h4" style={{ marginBottom: 16 }}>Retention heatmap</div>
        <div style={{ display: 'grid', gridTemplateColumns: '80px 60px repeat(9, 1fr)', gap: 4, font: '600 11px/1 var(--font-mono)' }}>
          <div className="t-tiny" style={{ alignSelf: 'center' }}>Cohort</div>
          <div className="t-tiny" style={{ alignSelf: 'center', textAlign: 'right' }}>Size</div>
          {months.map((m, i) => <div key={i} className="t-tiny" style={{ textAlign: 'center', alignSelf: 'center' }}>M{i}</div>)}

          {data.map((row, ri) => (
            <React.Fragment key={ri}>
              <div style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)', alignSelf: 'center' }}>{months[ri]} '24</div>
              <div className="t-mono t-small" style={{ textAlign: 'right', alignSelf: 'center' }}>{sizes[ri]}</div>
              {row.map((v, ci) => (
                <div key={ci} style={{
                  padding: '8px 0', textAlign: 'center', borderRadius: 4,
                  background: v == null ? 'transparent' : `rgba(204, 255, 0, ${0.05 + (v / 100) * 0.85})`,
                  color: v == null ? 'var(--fg-faint)' : v > 60 ? 'var(--ink-950)' : 'var(--fg-strong)',
                  font: '600 11px/1 var(--font-mono)',
                }}>{v == null ? '—' : `${v}%`}</div>
              ))}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- PLANS / PRICING ---------- */
function V2AdminPlans() {
  return (
    <div style={{ padding: '28px 32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, marginBottom: 24 }}>
        <div style={{ flex: 1 }}>
          <div className="t-tiny">flat rate · pay-as-you-go · razorpay</div>
          <h1 className="t-h2" style={{ marginTop: 6 }}>Pricing</h1>
        </div>
        <button className="btn btn--secondary btn--sm">Edit rates</button>
      </div>

      <div className="card card--accent" style={{ padding: 32, marginBottom: 20, background: 'var(--accent-tint)' }}>
        <div className="t-tiny" style={{ color: 'var(--accent)' }}>active rate</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 10 }}>
          <span style={{ font: '700 72px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.04em' }}>$0.20</span>
          <span className="t-h4" style={{ color: 'var(--fg-secondary)' }}>/ second of finished video</span>
        </div>
        <div className="t-small" style={{ marginTop: 12 }}>Flat. No tiers. No subscriptions. 100% first-recharge bonus auto-applied per user.</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { l: 'Avg revenue / user (30d)', v: '$22.10', d: '+8%' },
          { l: 'Avg sec / video',          v: '184',    d: '+12s' },
          { l: 'Gross margin',             v: '57.2%',  d: '+0.8pp' },
        ].map(([k, v]) => v) /* placeholder for KPIs */}

        {[
          ['Avg revenue / user (30d)', '$22.10', '+8%'],
          ['Avg sec / video',          '184',    '+12s'],
          ['Gross margin',             '57.2%',  '+0.8pp'],
        ].map(([l, v, d]) => (
          <div key={l} className="card">
            <div className="t-tiny">{l}</div>
            <div style={{ font: '700 26px/1 var(--font-display)', color: 'var(--fg-strong)', marginTop: 10, letterSpacing: '-0.02em' }}>{v}</div>
            <div style={{ font: '600 12px/1 var(--font-mono)', color: 'var(--accent)', marginTop: 6 }}>{d}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '14px 22px', borderBottom: '1px solid var(--border-hairline)' }}>
          <div className="t-h4">Provider cost breakdown · per second</div>
          <div className="t-small" style={{ marginTop: 4 }}>What we pay providers for one second of video</div>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <tbody>
            {[
              ['Script (LLM · OpenAI/Anthropic)',  '$0.005', '2.5%'],
              ['Keyframes (Imagine · Replicate)',  '$0.040', '20%'],
              ['Motion (Runway · Pika)',           '$0.080', '40%'],
              ['Voice (ElevenLabs · Cartesia)',    '$0.010', '5%'],
              ['Render (FFmpeg cluster · AWS)',    '$0.005', '2.5%'],
              ['Margin · ours',                     '$0.060', '30%', true],
            ].map(([l, v, p, accent], i) => (
              <tr key={i} style={{ borderTop: '1px solid var(--border-hairline)' }}>
                <td style={{ padding: '14px 22px', font: `${accent ? 700 : 500} 14px/1 var(--font-sans)`, color: accent ? 'var(--accent)' : 'var(--fg-default)' }}>{l}</td>
                <td style={{ padding: '14px 22px', textAlign: 'right', font: `600 14px/1 var(--font-mono)`, color: accent ? 'var(--accent)' : 'var(--fg-strong)' }}>{v}</td>
                <td style={{ padding: '14px 22px', width: 80, textAlign: 'right', font: '600 12px/1 var(--font-mono)', color: 'var(--fg-muted)' }}>{p}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------- PLACEHOLDER ---------- */
function V2AdminPlaceholder({ section }) {
  return (
    <div style={{ padding: '28px 32px' }}>
      <div className="t-tiny">section</div>
      <h1 className="t-h2" style={{ marginTop: 6, textTransform: 'capitalize' }}>{section}</h1>
      <div className="card" style={{ marginTop: 24, padding: 60, textAlign: 'center' }}>
        <div className="t-h4" style={{ marginBottom: 8 }}>Built in v1 — re-skin pending</div>
        <div className="t-small" style={{ marginBottom: 18 }}>This section exists in the v1 admin console with full functionality. The v2 visual refresh applies the same components from Overview/Users/Jobs above.</div>
        <a href="AIcreators Cloud Admin.html" className="btn btn--secondary btn--sm" style={{ textDecoration: 'none' }}>Open v1 version</a>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<V2AdminApp/>);
