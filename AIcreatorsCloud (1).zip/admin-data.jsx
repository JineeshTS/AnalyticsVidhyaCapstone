/* ============================================================
   AIcreators.cloud — Admin Mock Data
   Operator/Ops Console — backs the admin screens.
   ============================================================ */

const ADMIN = {
  operator: { name: 'Mihir V', email: 'admin@aicreators.cloud', role: 'Owner' },

  /* ============================================================
     KPIS — last 30 days
     Backed by: GET /admin/kpis?window=30d
     ============================================================ */
  kpis: {
    mrr:           { value: '$48,260', delta: '+12.4%', trend: 'up' },
    activeUsers:   { value: '2,184',   delta: '+8.1%',  trend: 'up' },
    paidUsers:     { value: '912',     delta: '+5.6%',  trend: 'up' },
    videosShipped: { value: '6,420',   delta: '+22.3%', trend: 'up' },
    jobsRunning:   { value: '147',     delta: '12 retrying', trend: 'neutral' },
    modelSpend:    { value: '$11,840', delta: '+18%',   trend: 'up' },
    churn:         { value: '2.1%',    delta: '-0.3%',  trend: 'down' },
    errorRate:     { value: '0.42%',   delta: '+0.08%', trend: 'down' },
  },
  mrrSparkline: [38,40,40.5,41,40.8,41.6,42,42.4,42.6,43,43.6,44,44.2,44.6,45,45.2,45.6,46,46.4,46.8,47,47.2,47.4,47.6,47.8,48.0,48.1,48.15,48.2,48.26],

  /* ============================================================
     SYSTEM HEALTH
     Backed by: GET /admin/health  (polls every 10s)
     ============================================================ */
  health: [
    { svc: 'API gateway',      status: 'ok',    rps: '420 rps', p95: '38 ms',  err: '0.02%' },
    { svc: 'Script (LLM)',     status: 'ok',    rps: '14 rps',  p95: '4.2 s',  err: '0.10%' },
    { svc: 'Imagine (T2I)',    status: 'warn',  rps: '22 rps',  p95: '11.4 s', err: '0.62%', note: 'Queue lag — GPU-W4 down' },
    { svc: 'Motion (I2V)',     status: 'ok',    rps: '8 rps',   p95: '38.0 s', err: '0.18%' },
    { svc: 'Voice (TTS)',      status: 'ok',    rps: '48 rps',  p95: '0.9 s',  err: '0.04%' },
    { svc: 'Voice Clone',      status: 'ok',    rps: '0.4 rps', p95: '124 s',  err: '0.10%' },
    { svc: 'Lip Sync',         status: 'ok',    rps: '6 rps',   p95: '22 s',   err: '0.20%' },
    { svc: 'Render/FFmpeg',    status: 'ok',    rps: '32 rps',  p95: '14 s',   err: '0.06%' },
    { svc: 'YouTube uploader', status: 'warn',  rps: '1.2 rps', p95: '34 s',   err: '1.20%', note: 'OAuth refresh failures' },
    { svc: 'Postgres primary', status: 'ok',    rps: '2.4k qps',p95: '4 ms',   err: '0.00%' },
    { svc: 'Redis (queue)',    status: 'ok',    rps: '8.4k ops/s',p95:'1.2 ms',err: '0.00%' },
    { svc: 'S3 / R2 storage',  status: 'ok',    rps: '180 ops/s',p95:'48 ms',  err: '0.01%' },
  ],

  /* ============================================================
     USERS
     Backed by: GET /admin/users?cursor=&search=&plan=
     ============================================================ */
  users: [
    { id: 'u_001', name: 'Mihir Vaishnav',  email: 'mihir@aicreators.cloud', plan: 'Studio Pro', credits: '2,840 / 5,000', channels: 4, videos30d: 38, mrr: '$89',  status: 'active',   joined: '2024-11-12', country: 'IN' },
    { id: 'u_002', name: 'Priya Shah',      email: 'priya@studio.co',         plan: 'Studio',     credits: '14,200 / 20,000', channels: 11, videos30d: 142, mrr: '$249', status: 'active',   joined: '2024-09-04', country: 'IN' },
    { id: 'u_003', name: 'Daniel Cho',      email: 'daniel@noir.tv',          plan: 'Studio Pro', credits: '4,820 / 5,000', channels: 2, videos30d: 22, mrr: '$89',  status: 'active',   joined: '2025-02-18', country: 'KR' },
    { id: 'u_004', name: 'Lila Becker',     email: 'lila@studio-noir.com',    plan: 'Starter',    credits: '420 / 1,000',  channels: 1, videos30d: 6,  mrr: '$29',  status: 'past_due', joined: '2025-04-08', country: 'DE' },
    { id: 'u_005', name: 'Akira Watanabe',  email: 'akira@himitsu.jp',        plan: 'Studio Pro', credits: '3,140 / 5,000', channels: 3, videos30d: 31, mrr: '$89',  status: 'active',   joined: '2025-01-22', country: 'JP' },
    { id: 'u_006', name: 'Hossam K.',        email: 'hossam@reel.eg',          plan: 'Studio Pro', credits: '60 / 5,000',    channels: 5, videos30d: 47, mrr: '$89',  status: 'active',   joined: '2024-12-30', country: 'EG' },
    { id: 'u_007', name: 'Sofia Costa',      email: 'sofia@costa.br',          plan: 'Starter',    credits: '910 / 1,000',  channels: 1, videos30d: 11, mrr: '$29',  status: 'active',   joined: '2025-05-01', country: 'BR' },
    { id: 'u_008', name: 'Marie L. (trial)',email: 'marie@trial.fr',          plan: 'Trial',      credits: '180 / 500',     channels: 1, videos30d: 2,  mrr: '$0',   status: 'trialing', joined: '2025-05-12', country: 'FR' },
    { id: 'u_009', name: 'Test Account',    email: 'test+1@aicreators.cloud', plan: 'Internal',   credits: '∞',             channels: 2, videos30d: 0,  mrr: '$0',   status: 'banned',   joined: '2024-08-01', country: 'US' },
    { id: 'u_010', name: 'Carlos Ruiz',     email: 'carlos@yt.mx',            plan: 'Studio',     credits: '8,920 / 20,000',channels: 9, videos30d: 96, mrr: '$249', status: 'active',   joined: '2024-10-19', country: 'MX' },
  ],

  /* ============================================================
     JOBS QUEUE — every pipeline job across all users
     Backed by:
       GET /admin/jobs?status=&stage=&user_id=&cursor=
       POST /admin/jobs/{id}/retry
       POST /admin/jobs/{id}/cancel
     Realtime: WS /admin/jobs/stream (status updates)
     ============================================================ */
  jobs: [
    { id: 'j_8421', user: 'u_002', userName: 'Priya Shah',     project: 'Volcanic lightning',           stage: 'motion',  status: 'running', model: 'avyal-motion-3', gpu: 'A100-W2', startedAt: '2 min ago', elapsed: '02:14', credits: 18, retries: 0, errorCode: null },
    { id: 'j_8422', user: 'u_003', userName: 'Daniel Cho',     project: 'Detective with no name',       stage: 'images',  status: 'review',  model: 'avyal-imagine-4', gpu: '—',     startedAt: '14 min ago', elapsed: '00:00', credits: 12, retries: 0, errorCode: null },
    { id: 'j_8423', user: 'u_001', userName: 'Mihir Vaishnav', project: 'The Lost Library of Alexandria', stage: 'publish', status: 'running', model: 'youtube-uploader', gpu: '—',  startedAt: '1 min ago',  elapsed: '00:48', credits: 2,  retries: 0, errorCode: null },
    { id: 'j_8424', user: 'u_006', userName: 'Hossam K.',       project: 'How clouds talk to each other', stage: 'voice',  status: 'failed',  model: 'avyal-voice-pro', gpu: '—',    startedAt: '8 min ago',  elapsed: '00:42', credits: 4,  retries: 2, errorCode: 'TTS_RATE_LIMIT' },
    { id: 'j_8425', user: 'u_010', userName: 'Carlos Ruiz',    project: 'Aztec calendars decoded',       stage: 'script',  status: 'running', model: 'avyal-delta-2',  gpu: '—',     startedAt: '4 min ago',  elapsed: '00:31', credits: 6,  retries: 0, errorCode: null },
    { id: 'j_8426', user: 'u_005', userName: 'Akira Watanabe', project: 'Why pufferfish are deadly',      stage: 'motion', status: 'queued',  model: 'avyal-motion-3', gpu: '—',     startedAt: 'just now',   elapsed: '00:00', credits: 18, retries: 0, errorCode: null },
    { id: 'j_8427', user: 'u_002', userName: 'Priya Shah',     project: 'Quantum tunneling for kids',    stage: 'images',  status: 'running', model: 'avyal-imagine-4', gpu: 'A100-W7', startedAt: '6 min ago', elapsed: '01:42', credits: 12, retries: 0, errorCode: null },
    { id: 'j_8428', user: 'u_004', userName: 'Lila Becker',    project: 'Berlin nights · 1923',          stage: 'edit',    status: 'failed',  model: 'render-ffmpeg',   gpu: '—',     startedAt: '22 min ago', elapsed: '04:18', credits: 8,  retries: 3, errorCode: 'RENDER_OOM' },
    { id: 'j_8429', user: 'u_007', userName: 'Sofia Costa',    project: 'Carnival drums history',         stage: 'voice',   status: 'done',    model: 'avyal-voice-pro', gpu: '—',     startedAt: '30 min ago', elapsed: '00:42', credits: 4,  retries: 0, errorCode: null },
    { id: 'j_8430', user: 'u_010', userName: 'Carlos Ruiz',    project: 'The shipwreck rewrite',          stage: 'storyboard', status: 'running', model: 'avyal-delta-2', gpu: '—',     startedAt: '3 min ago',  elapsed: '01:12', credits: 5, retries: 0, errorCode: null },
    { id: 'j_8431', user: 'u_002', userName: 'Priya Shah',     project: 'Black holes don\'t suck',         stage: 'publish',  status: 'done',    model: 'youtube-uploader', gpu: '—',  startedAt: '1h ago',     elapsed: '00:38', credits: 2, retries: 0, errorCode: null },
    { id: 'j_8432', user: 'u_008', userName: 'Marie L.',        project: 'La Tour du chocolat',            stage: 'idea',    status: 'queued',  model: 'avyal-delta-2',  gpu: '—',     startedAt: 'just now',   elapsed: '00:00', credits: 1, retries: 0, errorCode: null },
  ],

  /* ============================================================
     MODELS — usage + cost + latency
     Backed by: GET /admin/models?window=30d
     ============================================================ */
  models: [
    { id: 'avyal-delta-2',    label: 'Avyal Delta · 2.0',  family: 'LLM (script)',     calls: '128.4k', cost: '$3,420', avgLat: '4.2 s', p95: '7.8 s',  errs: '0.10%', enabled: true },
    { id: 'avyal-delta-1',    label: 'Avyal Delta · 1.0',  family: 'LLM (script)',     calls: '12.6k',  cost: '$260',   avgLat: '3.8 s', p95: '7.2 s',  errs: '0.14%', enabled: true },
    { id: 'avyal-imagine-4',  label: 'Avyal Imagine · 4',  family: 'Image generation', calls: '420k',   cost: '$3,890', avgLat: '6.4 s', p95: '11.4 s', errs: '0.62%', enabled: true },
    { id: 'avyal-motion-3',   label: 'Avyal Motion · 3',   family: 'Image-to-video',   calls: '38k',    cost: '$2,180', avgLat: '24 s',  p95: '38 s',   errs: '0.18%', enabled: true },
    { id: 'avyal-voice-pro',  label: 'Avyal Voice · Pro',  family: 'TTS',              calls: '184k',   cost: '$1,140', avgLat: '0.6 s', p95: '0.9 s',  errs: '0.04%', enabled: true },
    { id: 'avyal-voice-clone',label: 'Avyal Voice · Clone',family: 'TTS (cloned)',     calls: '24k',    cost: '$420',   avgLat: '1.4 s', p95: '2.2 s',  errs: '0.12%', enabled: true },
    { id: 'avyal-lipsync-2',  label: 'Avyal Lip Sync · 2', family: 'Talking-head',     calls: '6.2k',   cost: '$280',   avgLat: '14 s',  p95: '22 s',   errs: '0.20%', enabled: true },
    { id: 'avyal-whisper',    label: 'Avyal Whisper',      family: 'Captions',         calls: '92k',    cost: '$140',   avgLat: '1.2 s', p95: '2.0 s',  errs: '0.08%', enabled: true },
    { id: 'render-ffmpeg',    label: 'FFmpeg cluster',     family: 'Render',           calls: '12.4k',  cost: '$110',   avgLat: '8 s',   p95: '14 s',   errs: '0.06%', enabled: true },
    { id: 'beta-imagine-5',   label: 'Imagine · 5 (beta)', family: 'Image generation', calls: '420',    cost: '$8',     avgLat: '5.4 s', p95: '8.8 s',  errs: '0.40%', enabled: false },
  ],

  /* ============================================================
     GPU POOL
     Backed by: GET /admin/gpu-pool
     ============================================================ */
  gpuPool: [
    { id: 'A100-W1', util: 92, region: 'us-east',  status: 'healthy' },
    { id: 'A100-W2', util: 86, region: 'us-east',  status: 'healthy' },
    { id: 'A100-W3', util: 71, region: 'us-west',  status: 'healthy' },
    { id: 'A100-W4', util:  0, region: 'us-west',  status: 'down', note: 'NCCL timeout' },
    { id: 'A100-W5', util: 64, region: 'eu-west',  status: 'healthy' },
    { id: 'A100-W6', util: 88, region: 'eu-west',  status: 'healthy' },
    { id: 'A100-W7', util: 95, region: 'ap-south', status: 'hot',     note: 'temp 78°C' },
    { id: 'A100-W8', util: 12, region: 'ap-south', status: 'healthy' },
  ],

  /* ============================================================
     MODERATION QUEUE — content awaiting human review
     Backed by: GET /admin/moderation?status=open
     POST /admin/moderation/{id}/approve
     POST /admin/moderation/{id}/reject  body: {reason}
     ============================================================ */
  moderation: [
    { id: 'mod_001', kind: 'script',    flagged: 'Violence (auto)',      user: 'Hossam K.',     project: 'War footage explainer', confidence: 0.78, snippet: '…describes graphic injuries to a civilian convoy…', age: '12 min' },
    { id: 'mod_002', kind: 'image',     flagged: 'Trademark logo',       user: 'Daniel Cho',    project: 'Brand history',        confidence: 0.91, snippet: 'Generated Coca-Cola wordmark detected on bottle', age: '18 min' },
    { id: 'mod_003', kind: 'thumbnail', flagged: 'Misleading claim',     user: 'Lila Becker',   project: 'Berlin nights',        confidence: 0.62, snippet: 'Title: "THE TRUTH GOVERNMENTS HIDE"',              age: '34 min' },
    { id: 'mod_004', kind: 'voice',     flagged: 'Voice impersonation',  user: 'Sofia Costa',   project: 'Carnival history',     confidence: 0.84, snippet: 'Cloned voice 92% match — flagged celebrity vector', age: '1 h' },
    { id: 'mod_005', kind: 'image',     flagged: 'NSFW (auto)',          user: 'Test Account',  project: 'redacted',             confidence: 0.97, snippet: 'NSFW-2.3 classifier triggered',                    age: '1 h' },
  ],

  /* ============================================================
     PLANS — pricing tiers + feature flags
     Backed by:
       GET /admin/plans
       PATCH /admin/plans/{id}
     ============================================================ */
  plans: [
    { id: 'starter', name: 'Starter',    price: 29,  credits: 1000,  channels: 1,  features: { shorts: true, longform: false, motion: false, voiceClone: false, lipSync: false, watermark: true,  apiAccess: false, priorityQueue: false }, active: 1284 },
    { id: 'pro',     name: 'Studio Pro', price: 89,  credits: 5000,  channels: 'unlimited', features: { shorts: true, longform: true, motion: true, voiceClone: true,  lipSync: true,  watermark: false, apiAccess: false, priorityQueue: false }, active: 812 },
    { id: 'studio',  name: 'Studio',     price: 249, credits: 20000, channels: 'unlimited', features: { shorts: true, longform: true, motion: true, voiceClone: true,  lipSync: true,  watermark: false, apiAccess: true,  priorityQueue: true  }, active: 188 },
  ],

  coupons: [
    { code: 'CREATOR50',  discount: '50%', kind: 'percent', expires: '2025-06-30', redemptions: 124, cap: 500 },
    { code: 'FIRSTYR20',  discount: '20%', kind: 'percent', expires: '2026-12-31', redemptions: 318, cap: 1000 },
    { code: 'SPONSOR-MKBHD', discount: '$30 off', kind: 'fixed', expires: '2025-09-01', redemptions: 41, cap: 200 },
  ],

  /* ============================================================
     SUPPORT TICKETS
     Backed by: GET /admin/tickets?status=open
     ============================================================ */
  tickets: [
    { id: 't_4012', user: 'Hossam K.',     subject: 'YouTube upload fails with 403',       priority: 'high',   age: '12 min', status: 'open' },
    { id: 't_4011', user: 'Lila Becker',   subject: 'Refund please — past_due',            priority: 'medium', age: '1 h',    status: 'open' },
    { id: 't_4010', user: 'Sofia Costa',   subject: 'Voice clone language coverage?',      priority: 'low',    age: '2 h',    status: 'waiting' },
    { id: 't_4009', user: 'Akira Watanabe',subject: 'Bug: title duplicated on Shorts',     priority: 'medium', age: '4 h',    status: 'open' },
    { id: 't_4008', user: 'Carlos Ruiz',   subject: 'Bulk-import topics CSV format?',      priority: 'low',    age: '6 h',    status: 'open' },
  ],

  /* ============================================================
     CHANNELS — all OAuth connections, health
     Backed by: GET /admin/channels?cursor=
     ============================================================ */
  channels: [
    { id: 'ch_001', name: 'Mythic Tales',     handle: '@mythictales',  user: 'Mihir Vaishnav', subs: '127K', uploadsThisMonth: 12, oauthStatus: 'ok',       lastUpload: '2 days ago' },
    { id: 'ch_002', name: 'Snackable Science', handle: '@snackscience', user: 'Mihir Vaishnav', subs: '38K',  uploadsThisMonth: 22, oauthStatus: 'ok',       lastUpload: '8 h ago' },
    { id: 'ch_003', name: 'Noir Reels',        handle: '@noirreels',    user: 'Mihir Vaishnav', subs: '64K',  uploadsThisMonth:  8, oauthStatus: 'ok',       lastUpload: '1 day ago' },
    { id: 'ch_004', name: 'Volcano Tales',     handle: '@volcantales',  user: 'Priya Shah',     subs: '412K', uploadsThisMonth: 32, oauthStatus: 'ok',       lastUpload: '3 h ago' },
    { id: 'ch_005', name: 'Aztec Daily',       handle: '@aztecdaily',   user: 'Carlos Ruiz',    subs: '88K',  uploadsThisMonth: 18, oauthStatus: 'refresh',  lastUpload: '1 day ago', note: 'OAuth token refresh failed 3x' },
    { id: 'ch_006', name: 'Himitsu Story',     handle: '@himitsu',       user: 'Akira Watanabe', subs: '52K',  uploadsThisMonth: 14, oauthStatus: 'ok',       lastUpload: '12 h ago' },
    { id: 'ch_007', name: 'Berlin Nights',     handle: '@berlinnights',  user: 'Lila Becker',    subs: '7K',   uploadsThisMonth:  2, oauthStatus: 'revoked',  lastUpload: '3 weeks ago', note: 'User revoked OAuth scope' },
  ],

  /* ============================================================
     AUDIT LOG — admin actions (immutable, append-only)
     Backed by: GET /admin/audit?cursor=
     ============================================================ */
  audit: [
    { ts: '2026-05-17 14:32', actor: 'Mihir V', action: 'job.retry',          target: 'j_8424', meta: 'TTS_RATE_LIMIT' },
    { ts: '2026-05-17 14:18', actor: 'Mihir V', action: 'user.impersonate.start', target: 'u_006', meta: '' },
    { ts: '2026-05-17 14:22', actor: 'Mihir V', action: 'user.impersonate.end',   target: 'u_006', meta: 'duration 4m12s' },
    { ts: '2026-05-17 13:08', actor: 'Mihir V', action: 'moderation.reject',  target: 'mod_005', meta: 'NSFW content' },
    { ts: '2026-05-17 12:40', actor: 'system',   action: 'gpu.down',           target: 'A100-W4', meta: 'NCCL timeout' },
    { ts: '2026-05-17 11:22', actor: 'Mihir V', action: 'plan.update',         target: 'studio',  meta: 'priority queue → on' },
    { ts: '2026-05-17 09:01', actor: 'Priya R', action: 'coupon.create',       target: 'SPONSOR-MKBHD', meta: '$30 off, cap 200' },
  ],
};

window.ADMIN = ADMIN;
