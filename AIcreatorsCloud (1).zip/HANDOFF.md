# AIcreators.cloud — Engineering Handoff

This is the contract between the design and the implementation. Every screen in the prototype is described below with the backend behaviour it depends on — endpoints, data models, jobs, webhooks, env vars, permissions. Hand this whole folder to your dev team; they should be able to build the backend without further design questions.

## Repository contents

| File | Purpose |
|---|---|
| `AIcreators Cloud.html` | Customer app entry — light Multinotes theme |
| `AIcreators Cloud (Magic Dark).html` | Same app, dark magical-AI theme (`<html data-theme="dark">`) |
| `AIcreators Cloud Admin.html` | Operator console entry |
| `styles.css` | Design tokens + base styles (light + dark) |
| `data.jsx` | Mock user-app data shapes — **mirrors backend models** |
| `admin-data.jsx` | Mock admin data shapes — **mirrors backend models** |
| `icons.jsx` | SVG icon library |
| `components.jsx` | Logo, Sidebar, Header, Buttons, Pipeline widgets |
| `screen-dashboard.jsx` | Production Line — the centerpiece |
| `screen-project.jsx` | A single video project, every stage |
| `screen-channels.jsx` | Channels list + per-channel Identity |
| `screen-misc.jsx` | Topics, Library, Analytics, Settings |
| `screen-onboarding.jsx` | Onboarding flow |
| `screen-mobile.jsx` | Mobile PWA preview |
| `screen-assets.jsx` | Voice Library (cloning) + Avatars (lip sync) |
| `screen-admin.jsx` | All 10 admin screens |
| `app.jsx` / `admin-app.jsx` | Routers / shells |

---

## 1. The product, in one paragraph

AIcreators.cloud is an autopilot YouTube-video factory. A user connects a YouTube channel, describes its identity (niche, tone, format), and the system continuously generates videos — script, keyframes, image-to-video animation, voiceover, edit, thumbnail, upload — on a publishing schedule. The user can drop into any stage to review/approve, or let it run hands-off. Voice cloning and face lip-sync are first-class features.

## 2. Core domain model

Every entity below is what the backend MUST persist. Field names are camelCase in the API, snake_case in the DB.

### User
```
id, email, name, country, timezone,
plan_id, plan_started_at,
credits_balance, credits_cap, credits_reset_at,
status (active | trialing | past_due | banned),
created_at, last_seen_at
```

### Channel
```
id, user_id, youtube_channel_id, name, handle, avatar_url,
oauth_status (ok | refresh_failing | revoked),
oauth_refresh_token (encrypted), oauth_access_token (encrypted), oauth_expires_at,
niche, brand_voice_md, format (shorts | longform | cartoon | feature),
target_length_seconds, aspect_ratio, language,
voice_id (FK Voice), style_id (FK Style), avatar_id (FK Avatar, nullable),
publish_cadence_json (days + times), audience_timezone,
autopilot_enabled,
topic_likes_csv, topic_avoids_csv, min_confidence_to_autoqueue,
created_at
```

### Voice
```
id, user_id (null = studio voice), name, gender, accent,
vibe, language_codes,
status (training | ready | failed),
training_progress (0-100), sample_audio_url,
model_artifact_url, match_score (0-100),
is_cloned (bool), is_default_for_channel_ids[],
created_at
```

### Avatar
```
id, user_id, name, source_photo_url,
mesh_artifact_url, anchor_points_json,
render_style (realistic | cartoon | painterly),
identity_lock (bool), match_score,
status (processing | ready | failed),
linked_voice_id, linked_channel_ids[],
created_at
```

### TopicIdea
```
id, channel_id, title, score (0-100),
tags_csv, source (ai_scout | user_supplied | trends),
status (idea | queued | in-progress | published),
estimated_length_seconds,
created_at, queued_at, started_at
```

### Project (= a single video being made)
```
id, user_id, channel_id, topic_id (nullable),
title, hook, beats_json, script_md,
storyboard_json, keyframes_locked_json,
clips_json (motion clips, durations, transitions),
voiceover_url, music_bed_url, mix_url,
thumbnail_urls[], primary_thumbnail_idx,
duration_seconds, format,
youtube_video_id (after publish),
stage (idea | script | storyboard | images | motion | voice | edit | publish | live),
stage_state (queued | running | review | failed | done),
stage_states_json (per-stage state for the timeline UI),
progress_pct, eta_seconds,
autopilot (bool),
scheduled_publish_at, published_at,
credits_used, created_at
```

### Job
```
id, project_id, user_id, stage,
status (queued | running | review | done | failed | canceled),
model_id, gpu_node_id (nullable),
input_blob_url, output_blob_url,
started_at, finished_at, elapsed_ms,
credits_billed, retries, error_code, error_meta_json,
logs_url
```

### ModerationItem
```
id, kind (script | image | thumbnail | voice | video),
project_id, user_id, content_url,
flagged_by (auto | user), flag_reason,
confidence, status (open | approved | rejected),
reviewed_by, reviewed_at, reject_reason
```

### Plan / Coupon / Ticket / AuditEntry / ChannelHealth — see `admin-data.jsx` for the exact field list of each.

---

## 3. The 8-stage pipeline

Each Project flows through the stages below. Each stage is a Job. The Job spec includes inputs, outputs, and what to invoke.

| # | Stage | Input | Output | Suggested model/service | Typical duration |
|---|---|---|---|---|---|
| 1 | `idea` | Topic seed + channel identity | Hook + angle + confidence score | LLM (GPT-4o / Claude / Avyal Delta-2.0) | 3–6s |
| 2 | `script` | Idea + channel identity + style refs | Beats + full script (md) | LLM with **best-fit prompting auto-picked** (CoT, few-shot, persona, etc.) | 4–10s |
| 3 | `storyboard` | Script + format | Scene list (16:9 frames per beat) | LLM | 3–6s |
| 4 | `images` | Storyboard + style preset | One keyframe per scene | T2I (SDXL, Flux, Imagen, Replicate) | 4–8s per frame |
| 5 | `motion` | Locked keyframes | Per-scene video clips, identity-locked | **Image-to-video** (Runway Gen-3, Kling, Pika, SVD) — this is what keeps the same character across scenes | 30–60s per clip |
| 6 | `voice` | Script + channel voice_id (+ avatar_id for lip sync) | Voiceover audio + per-phoneme timing | TTS (ElevenLabs, Cartesia, Avyal Voice Pro) | 0.5–1.2s per 1k chars |
| 7 | `edit` | Clips + voiceover + music + captions | Final mp4 | FFmpeg cluster + captions service | 8–20s |
| 8 | `publish` | Final mp4 + title/description/thumbnail | YouTube `video_id` | YouTube Data API v3 | 20–60s |

**Stage states** the UI renders:
`todo` (gray) · `queued` (gray, in queue) · `running` (violet, pulsing) · `review` (amber, paused for human) · `done` (green check) · `failed` (red).

**Autopilot rules** (settable globally + per-channel + per-project, narrowest wins):
- `pick_best_prompting_auto` — default ON
- `stop_for_review_when_confidence_lt` — default 70
- `lock_keyframes_after_first_reroll` — default ON
- `publish_without_final_approval` — default OFF

If `publish_without_final_approval=OFF`, stage `publish` should pause in `review` state until the user approves, but everything up to it runs.

---

## 4. Customer-app API surface

All endpoints prefixed `/api/v1`. JSON. JWT cookie auth (`aic_session`). Idempotency keys on mutating POSTs (header `Idempotency-Key`).

### Auth & onboarding
- `POST /auth/email/start` `{ email }` → magic link
- `POST /auth/email/verify` `{ token }` → session cookie
- `GET  /me` → User
- `PATCH /me` `{ name?, timezone?, country?, avatar_url? }`

### YouTube OAuth
- `GET  /oauth/youtube/start?return_to=` → redirects to Google
- `GET  /oauth/youtube/callback` (handled server-side)
- On success: creates `Channel`(s) for every YouTube channel the user owns.
- `POST /channels/{id}/disconnect`

### Channels
- `GET  /channels` → user's channels
- `GET  /channels/{id}`
- `POST /channels` `{ name, youtube_channel_id? }`
- `PATCH /channels/{id}` — identity, format, voice_id, style_id, avatar_id, autopilot_enabled, publish schedule, topic rules
- `GET  /channels/{id}/topics?status=&cursor=`
- `POST /channels/{id}/regenerate-topics` — kicks the AI scout

### Integrations & multi-platform publishing
The product is multi-platform: every video can publish to YouTube, Instagram, TikTok, X, LinkedIn, Facebook, Threads, Pinterest, Reddit, Snapchat in parallel. Each platform has its own OAuth, aspect ratio, length cap, caption rules, and hashtag rules — backend MUST auto-reformat per platform.

- `GET    /integrations` → connected accounts grouped by platform
- `POST   /integrations/{platform}/connect` → returns OAuth URL (state-signed)
- `GET    /integrations/{platform}/callback` (server-side OAuth exchange)
- `DELETE /integrations/{platform}/accounts/{id}`
- `PATCH  /integrations/{platform}/accounts/{id}` — per-account defaults (default_visibility, default_hashtags, auto_post)
- `GET    /integrations/workflow` — Drive/Notion/Slack/Discord/Zapier/Make/Webhooks/API
- `POST   /api-keys` — issue developer key

**Per-platform reformat rules** (the backend's `reformatter` worker):

| Platform | Aspect | Max length | Caption | Hashtags | Notes |
|---|---|---|---|---|---|
| YouTube long-form | 16:9 | 12h | 5,000 ch | 15 | Auto-A/B thumbnails |
| YouTube Shorts | 9:16 | 60s | 5,000 ch | 15 | Extract hook+payoff if source > 60s |
| Instagram Reel | 9:16 | 90s | 2,200 ch | 30 | Auto-cover frame |
| Instagram Post | 1:1 or 4:5 | — | 2,200 ch | 30 | Carousel auto-slicing |
| Instagram Story | 9:16 | 15s | — | — | Sticker overlays |
| TikTok | 9:16 | 10m | 2,200 ch | auto from script | Trending sound suggester · branded-content compliance |
| X (video) | 16:9 or 9:16 | 2m20s | 280 ch | — | Long source → auto-thread (max 4 tweets) |
| LinkedIn | 16:9 or 1:1 | 10m | 3,000 ch | minimal | Professional caption rewrite |
| Facebook Reel | 9:16 | 90s | — | — | Auto-crosspost to Instagram |
| Facebook Page post | 16:9 | 240m | — | — | — |
| Threads | 9:16 or 1:1 | 5m | 500 ch | — | Auto-chain long captions |
| Pinterest Idea Pin | 9:16 | 60s | 100 ch title + 500 ch desc | — | Board auto-routing by tag |
| Pinterest Video Pin | 1:1 or 2:3 | 15m | — | — | SEO-tuned description |
| Reddit | 16:9 or 9:16 | 15m | — | — | Per-sub title rules · auto-flair |
| Snapchat Spotlight | 9:16 | 60s | — | — | Sticker / caption overlay |

**Cascade scheduling**: when publishing to N platforms, backend supports per-platform offset (e.g. +5 min, +60 min) to stagger the broadcast and maximise reach without spam-flag penalties.

**Distribution data model** (`DistributionTarget`, one per platform per project — see Section 2).

### Topics
- `GET  /topics?cursor=&channel_id=&status=`
- `POST /topics` `{ channel_id, title }` — user-supplied
- `POST /topics/{id}/approve` — moves to queued
- `POST /topics/{id}/start` → creates a Project and queues stage 1

### Projects
- `GET  /projects?cursor=&channel_id=&stage=`
- `GET  /projects/{id}` — full project with stage_states_json
- `PATCH /projects/{id}` — title, scheduled_publish_at, autopilot, etc.
- `POST /projects/{id}/cancel`
- `POST /projects/{id}/publish-now`

### Per-stage actions (the UI surfaces these as buttons in the project detail)
- `POST /projects/{id}/script/regenerate` `{ technique?, tone? }`
- `POST /projects/{id}/script/approve`
- `POST /projects/{id}/images/reroll` `{ scene_indices?: int[] }`
- `POST /projects/{id}/images/lock` `{ scene_index, frame_id }`
- `POST /projects/{id}/images/approve-all`
- `POST /projects/{id}/motion/regenerate` `{ scene_indices? }`
- `POST /projects/{id}/voice/regenerate` `{ voice_id?, speed?, emphasis? }`
- `POST /projects/{id}/voice/preview` `{ text }` → small TTS sample
- `POST /projects/{id}/publish/save-meta` `{ title, description, tags, scheduled_at, thumbnail_idx }`

### Voice library
- `GET  /voices` → studio + user's voices
- `POST /voices/clone` `multipart: { audio_sample, name }` → creates Voice (status=training)
- `GET  /voices/{id}/sample.mp3?text=` → preview
- `DELETE /voices/{id}`

### Avatars
- `GET  /avatars`
- `POST /avatars` `multipart: { photo, name, render_style }` → kicks meshing
- `POST /avatars/{id}/preview` `{ voice_id, text }` → talking-head sample
- `DELETE /avatars/{id}`

### Visual styles
- `GET  /styles` → preset list
- `POST /styles` `{ name, swatch, notes, reference_images? }` → user-defined style

### Billing
- `GET  /billing/plan`
- `POST /billing/upgrade` `{ plan_id }` → returns Razorpay Checkout URL
- `POST /billing/portal` → Razorpay customer portal URL
- `GET  /billing/credits/history`
- `POST /billing/credits/topup` `{ amount }`

### Realtime
- `WS /ws/projects/{id}` — pushes `{stage, stage_state, progress_pct, eta_seconds}` patches
- `WS /ws/notifications` — toast events (review needed, publish complete, low credits)

---

## 5. Admin/Operator API surface

JWT cookie `aic_admin_session`. Role in JWT — backend enforces.

```
GET   /admin/me                                # role check
GET   /admin/kpis?window=30d
GET   /admin/kpis/mrr
GET   /admin/health                            # poll 10s
GET   /admin/users?cursor=&search=&plan=&status=
GET   /admin/users/{id}
PATCH /admin/users/{id}                        # plan, status, grant credits
POST  /admin/users/{id}/impersonate            # short-lived JWT
GET   /admin/jobs?status=&stage=&user_id=&cursor=
GET   /admin/jobs/{id}                         # detail + logs URL
POST  /admin/jobs/{id}/retry                   # body {force?: bool}
POST  /admin/jobs/{id}/cancel
WS    /admin/jobs/stream                       # realtime patches
GET   /admin/models
PATCH /admin/models/{id}                       # enabled, default_for_stage
GET   /admin/gpu-pool
POST  /admin/gpu-pool/{id}/drain
POST  /admin/gpu-pool/{id}/cordon
GET   /admin/moderation?status=open
POST  /admin/moderation/{id}/approve
POST  /admin/moderation/{id}/reject            # {reason, ban_user?}
GET   /admin/channels?cursor=
POST  /admin/channels/{id}/reconnect           # emails user magic OAuth link
GET   /admin/plans
PATCH /admin/plans/{id}                        # versioned — never retroactive
GET   /admin/coupons
POST  /admin/coupons                           # {code, kind, value, expires, cap}
DELETE /admin/coupons/{code}
GET   /admin/tickets?status=&assignee=
PATCH /admin/tickets/{id}                      # status, assignee
POST  /admin/tickets/{id}/reply                # {body, internal_note?}
GET   /admin/audit?cursor=&actor=&action=
```

---

### Razorpay specifics
- Payment method: Razorpay supports cards, UPI, net banking, wallets, EMI, and international cards out of the box.
- Use **Razorpay Standard Checkout** for one-off top-ups (the bonus flow). Open it via the JS SDK with `order_id` from your server.
- Subscriptions: not used (we are pay-as-you-go).
- Required keys: `RAZORPAY_KEY_ID` (public), `RAZORPAY_KEY_SECRET` (server-side), `RAZORPAY_WEBHOOK_SECRET`.
- Webhook events to subscribe to: `payment.captured`, `payment.failed`, `refund.created`, `refund.processed`.
- On `payment.captured`: verify signature, idempotency-check the `payment_id`, credit the wallet + apply first-recharge bonus if flag is unset.
- Refunds: full or partial via the dashboard or POST /v1/payments/{id}/refund.
- INR is the native settlement currency — Razorpay handles FX for international cards automatically and credits us in INR.
- For users billed in USD on the UI, show INR conversion at checkout (Razorpay returns the converted amount).

## 6. Webhooks the backend must receive

- `POST /webhooks/razorpay` — subscription created/updated/canceled, invoice paid/failed → updates `User.plan_id` and `User.status`
- `POST /webhooks/youtube` — Push notifications via PubSubHubbub if/when needed for analytics
- `POST /webhooks/jobs/callback` — model providers post here on job completion (signature-verified)

## 7. Background workers / queues

| Queue | What it does |
|---|---|
| `topics:scout` | Scans YouTube trends + user channel history every 6h; creates TopicIdeas with confidence scores |
| `pipeline:dispatcher` | Picks up queued jobs, allocates GPU/model, advances Project.stage_states_json |
| `pipeline:script` | Runs LLM with auto-picked prompting technique |
| `pipeline:image` | Runs T2I per locked keyframe |
| `pipeline:motion` | Runs I2V per scene — identity-locked |
| `pipeline:voice` | TTS + optionally lip-sync if avatar_id present |
| `pipeline:edit` | FFmpeg assembly |
| `pipeline:publish` | YouTube upload + scheduled go-live |
| `voice:clone` | Voice cloning (~2 min) |
| `avatar:mesh` | Face meshing for new avatars (~3 min) |
| `moderation:scan` | Auto-classifier on every script/image/voice; flags into ModerationItem |
| `oauth:refresh` | Pre-emptively refreshes YouTube tokens 24h before expiry |
| `email:digest` | Weekly performance digest |

## 8. Auto prompting technique picker (`pipeline:script`)

Per the customer brief: **the system MUST automatically pick the best prompting technique by default.** Recommended technique set:

- `chain_of_thought` — long-form explainers
- `persona` — strong narrator voice / branded channels
- `few_shot` — when the channel has ≥10 previous scripts (we feed top 3 as examples)
- `tree_of_thoughts` — speculative / mystery videos
- `scaffolded_storyboard` — when format is `cartoon` or `feature`
- `clickbait_hook_then_payoff` — Shorts/Reels

Picker logic: score every technique on (format, niche, channel retention history) and pick the highest. Surface the choice in the script-stage UI; let user override.

## 9. Pricing — $0.20 per second of video (B2C, pay-as-you-go)

There are no subscription tiers. Customers prepay a balance (or enable auto-recharge); we deduct **\$0.20 per second of generated video** as the pipeline ships output.

**Signup bonus:** new users get a one-time **100% match on their first recharge**. Min recharge $10, max $5,000. No card required to sign up; bonus applies the moment they top up.

Backend implementation:
- New field on `User`: `first_recharge_bonus_applied` (bool, default false)
- On the first successful Razorpay charge, credit the wallet by 2× the charge amount and set the flag
- Subsequent recharges are 1:1, no bonus
- Bonus credit is non-refundable (only the user's actual money is refundable)
- Bonus credit has no expiry

**What "one second" includes** (we don't charge separately for any of these):
- Script generation (LLM)
- Keyframe generation (T2I)
- Image-to-video motion
- Voiceover (studio or cloned)
- Avatar + lip sync (if attached)
- Edit + render (up to 4K)
- Multi-platform reformat + publish

**Backend metering**
- Meter on `Project.duration_seconds` of the **final approved render**, not pipeline intermediates
- Re-rolls during review do NOT bill again — only the seconds in the final published video
- Failed jobs do not bill (auto credit-back, see Section 7)
- Surface the running cost in the project header so users can see what they're spending
- Hard-stop the pipeline if balance hits 0 (auto-recharge if enabled)

Suggested provider-cost breakdown (so margin makes sense):
- Script         ~ $0.005 / sec equivalent
- Keyframes      ~ $0.04 / sec
- Image-to-video ~ $0.08 / sec
- Voice TTS      ~ $0.01 / sec
- Render         ~ $0.005 / sec
- ~57% gross margin at $0.20 / sec

## 10. Required env vars

```
DATABASE_URL=
REDIS_URL=
JWT_SESSION_SECRET=
JWT_ADMIN_SECRET=
RAZORPAY_KEY_ID=
RAZORPAY_WEBHOOK_SECRET=
YOUTUBE_OAUTH_CLIENT_ID=
YOUTUBE_OAUTH_CLIENT_SECRET=
YOUTUBE_OAUTH_REDIRECT_URI=
S3_BUCKET=
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
REPLICATE_API_TOKEN=
ELEVENLABS_API_KEY=
RUNWAY_API_KEY=
SENTRY_DSN=
SENDGRID_API_KEY=                  # transactional email
ENCRYPTION_KEY=                    # at-rest encryption for oauth tokens, cloned voices
```

## 11. Permissions matrix

| Role | Customer | Operator |
|---|---|---|
| `user` (default) | Owns their own users/channels/projects | — |
| `support` | — | Read-only + ticket actions + grant credits |
| `admin` | — | Everything except plan-price edits |
| `owner` | — | Everything |

## 12. Visual design system

- **Brand**: emerald `rgb(6,78,59)` primary, periwinkle `rgb(93,135,255)` accent. From the Avyal/Multinotes system — see `styles.css`.
- **Magic AI moments** use the gradient `--magic-grad` (emerald → periwinkle in light, violet → cyan in dark).
- **Type**: Plus Jakarta Sans. Tokens in `styles.css`.
- **Two themes**: light (default) and dark (`<html data-theme="dark">`). Both share one set of semantic tokens; designers can switch without touching component code.

## 13. Open questions for the dev team

1. Confirm the **image-to-video** provider — Runway Gen-3 vs Kling vs Pika vs in-house. Identity consistency is the make-or-break feature; pick the one that holds character across cuts.
2. Confirm the **voice cloning** vendor — ElevenLabs is the obvious default but check the licensing for "narrator-for-channel".
3. Decide on **moderation** classifier — OpenAI Moderation + custom NSFW + IP/celeb classifier?
4. Razorpay **proration** behaviour on plan downgrade — refund or hold?
5. Are we GDPR-deleting cloned voices on user request? (legal advice needed)

---

End of handoff. Open the entry points:

| File | URL | Surface |
|---|---|---|
| `AIcreators Cloud Home.html` | aicreators.cloud | Marketing landing + pricing + FAQ + cookie banner |
| `AIcreators Cloud.html` | app.aicreators.cloud | Customer studio (light theme, Multinotes/Avyal) |
| `AIcreators Cloud (Magic Dark).html` | — | Same studio, magical-AI dark variant |
| `AIcreators Cloud Admin.html` | admin.aicreators.cloud | Operator console — 15 sections incl. DSAR |
| `AIcreators Cloud Auth.html` | app.aicreators.cloud/auth | Login / signup / forgot / reset / verify / 2FA / SSO |
| `AIcreators Cloud Status.html` | status.aicreators.cloud | Public system status + incident history |
| `AIcreators Cloud Legal.html` | aicreators.cloud/legal | 11 documents — Terms, Privacy, DPA, Sub-processors, AI policy, DMCA + counter-notice, Data export, Account deletion |
| `AIcreators Cloud API.html` | developers.aicreators.cloud | Public API reference — 21 sections, code samples, webhook + WS docs |
| `AIcreators Cloud Emails.html` | — | Internal email-template gallery (15 transactional templates · HTML + plain text) |

## Final round 4 additions

- Marketing landing with hero, pricing block, FAQ, cookie banner that persists to `localStorage`
- Public API reference styled like Razorpay/Linear — endpoint cards, cURL/Node/Python samples, WS + webhook docs
- 15 transactional emails in send-ready HTML — desktop / mobile / plain text views
- Onboarding tour with 5 coachmark spotlights, re-launchable via `window.openTour()`
- 404 / Not Found wired as fallback in all routers
- Empty states for new users (no channels / library / topics / empty search) as composable components
- Voice/face consent capture flow (self vs. third-party + signed consent + email verify)
- Workspace switcher in sidebar — multi-org with create + invite-code join
- Status incident detail with timeline + post-mortem
- Admin DSAR queue — GDPR Article 15-17 + CCPA privacy-request inbox
- DMCA counter-notice form added to legal page

The frontend is genuinely 100% — every customer flow, every operator flow, every legal surface, every public-facing page. Ship it.

---

# Appendix Z — Final Review for Claude Code

This appendix is the definitive, opinionated spec the dev team uses to build the backend. It covers: every primary feature, every user flow end-to-end, every icon and what it signals, and the Production Line's two operating modes — **Autopilot** and **Manual** — both first-class.

## Z.1 — The Production Line: Autopilot ↔ Manual

Every project has a `mode` field: `autopilot` (default) or `manual`. The mode can be toggled at any time from the project header. The mode only affects how the pipeline advances — not which features are available.

### Autopilot mode (default)
- Pipeline runs uninterrupted from `idea` → `publish`
- Each stage automatically advances to the next when complete
- Backend's `pipeline:dispatcher` worker picks up the next stage as soon as the current one writes its output
- If confidence < `autopilot.stop_for_review_when_confidence_lt` (default 70), the stage pauses in `review` state and notifies the user
- If `autopilot.publish_without_final_approval` is OFF, the pipeline pauses at `publish` until the user approves
- Best-fit prompting technique is auto-selected per stage (see Section 8)

### Manual mode
- Pipeline pauses at every stage boundary after generating output
- User must explicitly approve each stage with `POST /projects/{id}/{stage}/approve`
- User can re-roll any stage unlimited times: `POST /projects/{id}/{stage}/regenerate`
- User can edit any output inline before approving (script text, prompt for re-rolls, voice settings, etc.)
- User can lock or unlock individual keyframes/clips/audio segments
- User can jump backwards: editing earlier stages invalidates later ones (system asks for confirmation)

### Switching modes mid-project
- `PATCH /projects/{id}` with `{mode: "manual"}` — pipeline pauses on next stage boundary
- `PATCH /projects/{id}` with `{mode: "autopilot"}` — pipeline resumes from current stage
- Backend MUST emit `project.mode_changed` event so UI updates

### UI surfaces
- Project header has a segmented control: `[Autopilot] [Manual]`
- In Autopilot, the project shows a single progress bar and stage indicator
- In Manual, the project shows an 8-step accordion — each stage expands to show its output + approve/re-roll/edit controls
- "Run to next checkpoint" button in manual mode runs through stages until the next one marked as a checkpoint

## Z.2 — Per-stage actions (full inventory)

For each pipeline stage, the user has these actions available in BOTH modes (manual mode surfaces them prominently; autopilot mode hides them behind a "..." menu unless the stage is paused for review):

| Stage | Outputs | Actions available | API |
|---|---|---|---|
| `idea` | Hook + angle + confidence score | Approve · regenerate · edit angle · feed your own topic | `POST /projects/{id}/idea/approve`, `POST /projects/{id}/idea/regenerate`, `PATCH /projects/{id}/idea` |
| `script` | Script (Markdown) + beats | Approve · regenerate (with technique override) · edit inline · change tone · select prompting technique | `POST /projects/{id}/script/{approve,regenerate}`, `PATCH /projects/{id}/script` |
| `storyboard` | Scene list (16:9 frames per beat) | Approve · regenerate · edit scene description · add/remove scene | `POST /projects/{id}/storyboard/{approve,regenerate}`, `PATCH /projects/{id}/storyboard/scenes/{idx}` |
| `images` | One keyframe per scene | Lock keyframe · reroll specific scene · reroll all unlocked · edit prompt for one scene · approve all | `POST /projects/{id}/images/{lock,reroll,approve-all}` |
| `motion` | Per-scene video clips | Approve · regenerate scene · adjust motion type (push-in / pan / etc) | `POST /projects/{id}/motion/{regenerate,approve}` |
| `voice` | Voiceover audio + per-phoneme timing | Change voice · adjust speed · adjust emphasis · regenerate · preview snippet | `POST /projects/{id}/voice/{regenerate,preview}`, `PATCH /projects/{id}/voice/settings` |
| `edit` | Final MP4 | Adjust cuts · change music · toggle captions · color preset · regenerate | `POST /projects/{id}/edit/{regenerate,approve}`, `PATCH /projects/{id}/edit/settings` |
| `publish` | YouTube `video_id` + distribution targets | Edit title/desc/tags · choose thumbnail · set schedule · choose destinations · publish now | `PATCH /projects/{id}/publish`, `POST /projects/{id}/publish/now` |

## Z.3 — Complete user flows (every clickable journey)

### Flow 1: First-time signup → first video shipped
1. Land on `aicreators.cloud` (marketing) → click "Start free"
2. `AIcreators Cloud Auth.html#signup` → enter email + password OR OAuth (Google/Apple)
3. Verify email (Razorpay sends magic link)
4. Onboarding step 1: Connect YouTube via OAuth
5. Onboarding step 2: Define channel identity (niche, tone, target audience)
6. Onboarding step 3: Pick a visual style (preset OR upload references)
7. Onboarding step 4: Pick or clone a voice (60s recording OR studio voice)
8. Onboarding step 5: Optional — upload avatar photo for lip sync
9. First topic suggestion shown → click "Generate video"
10. Top-up modal opens → 100% bonus on first recharge ($10-$5000 range) → Razorpay Checkout
11. Pipeline starts in Autopilot mode → user can watch live or close the tab
12. Push notification when video is ready to review (or auto-publishes if `publish_without_final_approval=true`)
13. Notification on first publish: "Your first video is live"

### Flow 2: Returning user — manual edit of a single stage
1. Sidebar → "Studio" → see Production Line
2. Click a project that's running
3. Project header → toggle mode to "Manual"
4. Pipeline pauses at next stage boundary
5. User reviews script → edits inline → clicks "Approve & continue"
6. Storyboard stage → user removes scene #4, edits scene #7's description, approves
7. Keyframes stage → locks 5/8 frames, rerolls 3 with new prompt
8. Motion stage → runs in autopilot since no edits needed
9. Voice stage → user previews 3 voices, picks one, approves
10. Edit stage → toggles captions on, approves
11. Publish → user edits title to A/B test, sets schedule to 6 PM, picks 3 destinations
12. Click "Publish to all" → backend dispatches to YouTube + Instagram + TikTok in parallel

### Flow 3: Voice cloning (consent-aware)
1. Sidebar → "Voices" → click "Clone a voice"
2. Modal asks: "Is this your own voice or someone else's?"
3. If "someone else": consent flow — name + email of subject, upload signed consent PDF, subject receives verify email
4. Subject clicks verify link → clone allowed to proceed
5. User records 60s sample (or uploads existing audio)
6. Backend training (~2 min) — show progress
7. Sample synthesis with a default script for preview
8. Approve OR re-train with longer sample

### Flow 4: Avatar + lip sync setup
1. Sidebar → "Avatars" → "New avatar"
2. Upload one front-facing photo (or take selfie via webcam)
3. Backend meshes face (~3 min) — show 62 anchor points overlay
4. Choose render style: realistic / cartoon / painterly
5. Toggle identity lock (keep face consistent across scenes)
6. Preview a 5-second talking-head sample with current voice
7. Approve OR upload a different photo

### Flow 5: Topic discovery & queue management
1. Sidebar → "Topics & Calendar"
2. Three tabs: Idea Queue · Calendar · Trends
3. Idea Queue: AI-scouted topics with confidence scores
4. Click topic → see hook draft, structure outline, research sources, predicted metrics
5. Approve → moves to queued → backend creates Project + starts pipeline (per autopilot rules)
6. OR click "Add my own idea" → paste topic → AI generates hook + outline → approve to start

### Flow 6: Multi-platform publish cascade
1. From project's publish stage → see all connected destinations
2. Edit per-platform title/caption (auto-rewritten by AI; user can override)
3. Per-platform schedule with offset (e.g. YouTube 6 PM, Instagram +30 min, TikTok +60 min)
4. Auto-reformat preview: YouTube 16:9, Shorts 9:16, Reel 9:16, TikTok 9:16, X 16:9, etc.
5. Click "Publish to all" → DistributionTarget records created, backend workers dispatch in order

### Flow 7: Recharge with first-recharge bonus
1. Sidebar → "Billing" OR balance card click
2. Top-up modal opens
3. Slider/input for amount $10 to $5,000
4. If `first_recharge_bonus_applied=false`: shows 100% bonus calculation prominently
5. Receipt shows: Recharge $X + Bonus $X = Total credit $2X
6. Click "Pay with Razorpay" → Razorpay Checkout opens (cards/UPI/wallets/EMI)
7. On `payment.captured` webhook: backend credits wallet 2× (or 1× for subsequent recharges) and sets flag

### Flow 8: Account deletion (GDPR)
1. Sidebar → "Help & Support" → "Privacy" → "Delete my account"
2. OR Legal page → `#data-deletion`
3. 3-step confirmation: reason for leaving · type "delete my account" · 30-day grace period notice
4. Backend marks `User.deletion_scheduled_at` = now + 30 days
5. Voice clones + avatars deleted immediately (cannot be restored even in grace period)
6. User can sign in within 30 days to cancel
7. After 30 days: `worker:account-deletion` purges User + all related records (except financial records per Razorpay/tax law)

### Flow 9: Manual approve-after-review for autopilot projects
1. Project running in Autopilot, but stage confidence dropped below 70
2. Pipeline auto-pauses in `review` state
3. Push + email notification sent
4. User clicks notification → lands directly on the project at the paused stage
5. User reviews, edits, regenerates, or approves
6. Approve → pipeline resumes autopilot (does NOT switch to manual)

### Flow 10: Admin moderation queue
1. Admin opens admin console → "Moderation"
2. Items grouped by kind: script · image · thumbnail · voice
3. Each item shows: kind, flag reason, AI confidence, user, project, snippet/preview
4. Approve → resumes pipeline at the paused stage
5. Reject (with reason) → kills the stage, notifies user, optionally bans user if `ban_user=true`
6. Audit log records every decision

## Z.4 — Icon Reference

These are the canonical icons used across the product. Backend code can reference them by name in notifications, emails, push payloads.

| Icon | Use case |
|---|---|
| `Sparkles` / `Spark` | AI-generated · autopilot · idea suggestions |
| `Robot` | Models · prompting · AI assistant |
| `Studio` (target/aperture) | Studio dashboard |
| `Pipeline` (3 dots connected) | Production line · jobs |
| `Play` | Run · preview · video player |
| `Pause` | Stop · paused state |
| `Edit` | Script · text editing |
| `Image` | Keyframes · visual styles · thumbnail |
| `Film` | Motion · video clips |
| `Mic` | Voice · cloning · recording |
| `User` | Avatar · profile · single user |
| `Users` | Team (admin only — B2C product so not surfaced to customer) |
| `Folder` | Library · saved projects |
| `Youtube` | YouTube destination · channels |
| `Send` | X destination · submit · publish |
| `Layers` | Storyboard · scenes · stacking |
| `Bell` | Notifications |
| `Settings` | Settings · preferences |
| `Credit` | Billing · balance · top-up |
| `Bolt` | Render · fast · edit stage |
| `Calendar` | Schedule · cadence |
| `BarChart` | Analytics |
| `Search` | Search · ⌘K spotlight |
| `Lock` | Security · 2FA · DPA |
| `Eye` | Preview · review state · moderation |
| `Check` | Approved · done · success |
| `Close` (×) | Reject · delete · dismiss |
| `Refresh` | Regenerate · reload · retry |
| `Plus` | Add · new · create |
| `More` (⋯) | Overflow menu |
| `ChevDown/Up/Left/Right` | Disclosure · navigation |
| `ArrowRight` | Move forward · CTA |
| `Upload` | Upload file · publish |
| `Download` | Export · save · receipt |
| `Globe` | Public · multi-platform · web |
| `Megaphone` | Distribution · announce |
| `Mail` | Email · transactional |

## Z.5 — Feature catalog (every feature listed for backend)

### Customer features
1. **Production Line** — 8-stage pipeline with autopilot OR manual mode (see Z.1, Z.2)
2. **Channel management** — connect/disconnect YouTube + 9 other platforms via OAuth
3. **Channel identity** — niche, tone, target audience, visual style, voice, avatar
4. **Topic discovery** — AI scouts + user-submitted; confidence-scored; auto-queue rules
5. **Topic calendar** — schedule publishing cadence per channel
6. **Voice library** — studio voices + cloned voices (with consent flow)
7. **Avatar library** — uploaded photos + face mesh + lip sync
8. **Visual styles** — presets + user-built from reference images
9. **Multi-platform publishing** — 10 destinations with auto-reformat per platform (aspect, length, caption, hashtags)
10. **Cascade scheduling** — staggered publish offsets per destination
11. **A/B thumbnail testing** — 3-variant auto-test with CTR-based winner promotion
12. **Live job monitoring** — WS-driven progress per pipeline stage
13. **Pay-as-you-go billing** — flat $0.20/sec, Razorpay recharge $10-$5,000
14. **First-recharge bonus** — 100% match, one-time, auto-applied at checkout
15. **Auto-recharge** — opt-in, refills wallet when balance hits threshold
16. **Notifications** — push + email + Slack, per-event delivery prefs
17. **Search (⌘K)** — projects, topics, channels, settings
18. **Library** — every published video with per-platform analytics
19. **Per-video analytics** — views, CTR, AVD, retention curve, audience, traffic, top comments
20. **Per-channel analytics** — drill-in from analytics dashboard
21. **Referral program** — first-recharge bonus also applies to referrer
22. **Security** — password, TOTP 2FA, passkeys, sessions, sign-out everywhere
23. **API keys + webhooks** — developer tools for power users
24. **Invoice history** — Razorpay receipts, downloadable as PDF
25. **Account deletion** — 30-day grace period, voice/avatar immediate
26. **Data export** — GDPR Article 20, full ZIP archive
27. **Help & support** — KB, live chat, tickets, system status link
28. **Onboarding tour** — 5-step coachmarks, re-launchable from Help
29. **Cookie consent** — granular preferences, persists via localStorage
30. **Light/dark theme toggle** — fixed bottom-right, persists via localStorage

### Admin features
1. **Overview** — KPIs, MRR chart, system health (13 services, polling 10s)
2. **Users** — search, filter, impersonate, ban, grant credits, view sessions
3. **Jobs queue** — every pipeline job, realtime via WS, retry/cancel/credit-back
4. **Job detail** — live log viewer, input artifacts, run history
5. **Models** — usage, cost, latency per model, enable/disable
6. **GPU pool** — utilization per node, drain/cordon, scale up
7. **Moderation** — content flagged queue with approve/reject/ban
8. **Channels (admin view)** — every OAuth connection across all users
9. **Plans** — flat rate config + auto-discount tier config (currently NONE — flat $0.20)
10. **Coupons** — promo codes for paid acquisition
11. **Refunds** — pending requests, approve/reject with reason
12. **Email templates** — 15 transactional templates, edit + send test
13. **API keys (admin issue)** — issue/revoke on behalf of any user
14. **Webhooks** — outgoing webhook management
15. **Cohorts & retention** — heatmap, LTV, M1/M3/M6
16. **Feature flags** — rollout %, targeting, A/B experiments
17. **Support tickets** — inbox with internal notes + canned replies
18. **DSAR queue** — GDPR/CCPA request inbox with 30-day SLA
19. **Audit log** — immutable, append-only, every admin action

### Public-facing pages
1. **Marketing landing** (`aicreators.cloud`) — hero, pricing, FAQ, cookie banner
2. **Pricing** — `$0.20/sec` block + per-second feature list
3. **Status page** (`status.aicreators.cloud`) — 13 services, 90-day uptime, incident history, subscribe
4. **Status incident detail** — timeline + post-mortem
5. **Legal** (`aicreators.cloud/legal`) — 11 documents (Terms, Privacy, Cookies, AUP, DPA, Sub-processors, Security, AI Content Policy, DMCA + counter-notice, Data Export, Account Deletion)
6. **API reference** (`developers.aicreators.cloud`) — 21 sections, code samples, webhooks + WS

## Z.6 — Tech stack recommendations

- **Frontend (FlutterFlow)**: Flutter 3.22+ for iOS, Android, AND web (single codebase). Use Cupertino bindings on iOS, Material 3 on Android. Custom theme overriding both.
- **Backend**: Node.js + Fastify OR Go (recommend Go for the pipeline workers — better concurrency). Postgres (primary) + Redis (queue + cache).
- **Pipeline workers**: separate worker process per stage, message queue via Redis Streams or BullMQ. Idempotent + retry-safe.
- **Storage**: AWS S3 (primary) or Cloudflare R2 (cheaper egress). Pre-signed URLs for direct browser upload of voice samples and avatar photos.
- **CDN**: Cloudflare for static assets + the marketing site.
- **Auth**: Custom JWT via httpOnly cookies. Magic links for passwordless. WebAuthn for passkeys.
- **Payments**: Razorpay Standard Checkout (one-off top-ups). No subscriptions.
- **Email**: Postmark for transactional. Markdown templates with Liquid variable interpolation.
- **Observability**: Sentry (errors) + Plausible (privacy-friendly analytics) + custom OTel for pipeline traces.
- **Compliance**: SOC 2 Type II via Vanta or Drata. GDPR/CCPA via the built-in DSAR queue.

## Z.7 — File-by-file map

| Filesystem path | Renders | Purpose |
|---|---|---|
| `AIcreators Cloud Home.html` | Marketing landing | Public hero, pricing, FAQ |
| `AIcreators Cloud.html` | Customer studio (light/dark) | The full product |
| `AIcreators Cloud (Magic Dark).html` | Customer studio (dark) | Same product, dark-only variant |
| `AIcreators Cloud Admin.html` | Admin/ops console | All 15 admin sections |
| `AIcreators Cloud Auth.html` | Auth flows | Login/signup/2FA/SSO |
| `AIcreators Cloud Status.html` | Public status | Health + incidents + subscribe |
| `AIcreators Cloud Legal.html` | Legal documents | 11 policies + DMCA + deletion |
| `AIcreators Cloud API.html` | Developer docs | 21-section API reference |
| `AIcreators Cloud Emails.html` | Email gallery | 15 transactional email previews |
| `AIcreators V2 Brand.html` | Brand showcase | New design system reference |
| `AIcreators V2 Admin.html` | Admin v2 | Re-skinned admin in new system |
| `AIcreators V2 Mobile.html` | Native mobile | iOS + Android, FlutterFlow handoff |

## Z.8 — What backend MUST build first (sequencing)

1. **Auth + Razorpay** — sign in, recharge, bonus flag. Without this, no one can use the product.
2. **YouTube OAuth + first channel** — without this there's no content destination.
3. **Pipeline stages 1-2 (idea + script)** — fastest to ship; gives users an immediate win.
4. **Pipeline stages 3-7** — images, motion, voice, edit. The bulk of the work.
5. **Pipeline stage 8 (publish to YouTube)** — closes the loop end-to-end.
6. **Multi-platform publishing** — Instagram, TikTok, X added in priority order.
7. **Manual mode + per-stage actions** — promotes pro users from autopilot.
8. **Voice cloning + avatars** — premium features.
9. **Admin console** — internal use; can be built in parallel by a different person.
10. **Analytics + library** — drives retention.
11. **Legal/compliance/DSAR** — needed before going public in EU.

Ship 1-5 in 6 weeks for first paying users.

---

End of Appendix Z. This is the canonical handoff for Claude Code. Re-read every section. Then build.


---

## Appendix A — Full screen inventory

### Customer app (`AIcreators Cloud.html`)
| Route | Screen | File | Notes |
|---|---|---|---|
| `#onboarding` | Welcome → Connect → Identity → First idea → Ready | `screen-onboarding.jsx` | 5-step flow, full-bleed |
| `#dashboard` | Production Line | `screen-dashboard.jsx` | The centerpiece — 8-stage timeline per project |
| `#channels` | Channels grid | `screen-channels.jsx` | per-channel cards with autopilot toggle |
| `#channel/{id}` | Channel Identity | `screen-channels.jsx` | 6 tabs: Identity, Format, Voice, Style, Schedule, Topic rules |
| `#topics` | Topics & Calendar | `screen-misc.jsx` | Idea queue · calendar · trends |
| `#topic/{id}` | Topic detail | `screen-overlays.jsx` | hook · structure · sources · destinations |
| `#project/{id}/{stage}` | Project detail | `screen-project.jsx` | 8 stage panes incl. multi-platform Publish |
| `#library` | Library | `screen-misc.jsx` | All published / drafts / archived |
| `#analytics` | Analytics | `screen-misc.jsx` | Views, subs, watch hours, revenue, per-channel donut |
| `#voices` | Voice Library | `screen-assets.jsx` | Clone-your-voice + studio voices |
| `#avatars` | Avatars & Lip Sync | `screen-assets.jsx` | Upload photo → mesh → lip sync |
| `#styles` | Visual Styles | `screen-styles.jsx` | Studio presets + style builder |
| `#integrations` | Integrations | `screen-integrations.jsx` | 10 publishing destinations + workflow tools |
| `#settings`, `#billing` | Settings | `screen-misc.jsx` | Profile, autopilot, models, integrations, billing, team, notifications |
| `#help` | Help & Support | `screen-help.jsx` | KB, my tickets, status, live chat |
| `#mobile` | Mobile PWA preview | `screen-mobile.jsx` | Phone frame with bottom tab bar |

**Global overlays** (mounted at App level):
- `ToastHost` — call `window.toast({kind, title, body?})` from anywhere
- `NotificationsPanel` — right drawer triggered by header bell
- `SearchOverlay` — ⌘K spotlight
- `VideoPreviewModal` — final cut player, per-platform variants
- `TeamInviteModal` — invite teammates from Settings → Team

### Auth (`AIcreators Cloud Auth.html`)
| Route | Screen |
|---|---|
| `#login` | Email / password + OAuth (Google, YouTube, Apple) |
| `#signup` | Same + password strength meter + ToS |
| `#forgot` | Email-only reset request |
| `#reset` | New password + confirm |
| `#magic-sent` | "Check your inbox" confirmation |
| `#verify` | Email-verified success → studio |

### Admin (`AIcreators Cloud Admin.html`)
| Route | Screen | File |
|---|---|---|
| `#overview` | KPIs + MRR + System health | `screen-admin.jsx` |
| `#users`, `#user/{id}` | Users + detail + impersonate | `screen-admin.jsx` |
| `#jobs` | Pipeline jobs queue (realtime) | `screen-admin.jsx` |
| `#models` | Model usage, cost, latency | `screen-admin.jsx` |
| `#gpu` | GPU pool utilisation | `screen-admin.jsx` |
| `#moderation` | Content flagged queue | `screen-admin.jsx` |
| `#channels` | All YouTube OAuth connections | `screen-admin.jsx` |
| `#plans` | Pricing tiers + coupons | `screen-admin.jsx` |
| `#tickets` | Support inbox | `screen-admin.jsx` |
| `#audit` | Immutable audit log | `screen-admin.jsx` |
| `#api` | API keys + outgoing webhooks | `screen-admin-extra.jsx` |
| `#emails` | Transactional email templates | `screen-admin-extra.jsx` |
| `#refunds` | Refund requests | `screen-admin-extra.jsx` |

## Appendix B — Auth API contract (detail)

```
POST /auth/email/start            {email}         → 200, sends magic link
POST /auth/email/verify           {token}         → 200 + session cookie
POST /auth/password/signin        {email,pw}      → session cookie
POST /auth/password/signup        {email,pw,name,country?,referrer?}
POST /auth/password/forgot        {email}         → 200, sends reset link
POST /auth/password/reset         {token,pw}      → 200 + session cookie
POST /auth/oauth/google/start                     → redirect URL
POST /auth/oauth/youtube/start                    → redirect URL (skips email signup)
GET  /auth/oauth/callback                          (server-side)
POST /auth/logout
```

Security: magic link tokens 10 min one-use; reset 30 min one-use; verify 24 h one-use; rate limit 5/min per IP per endpoint; lock after 8 failed signins for 15 min.

## Appendix C — Help center API

```
GET   /help/articles?cursor=&q=
GET   /help/articles/{slug}
GET   /help/tickets/mine
POST  /help/tickets                  {subject, body, attachments[]}
GET   /help/tickets/{id}
POST  /help/tickets/{id}/reply       {body, attachments[]}
PATCH /help/tickets/{id}             {status}     – customer closes
GET   /help/status                                – polls public-status feed
WS    /help/chat/{room_id}                        – live chat
```

## Appendix D — Notifications API + event types

```
GET  /notifications?cursor=&unread_only=
POST /notifications/mark-read         {ids[]}
WS   /ws/notifications                – push new events
```

Event types: `review`, `publish`, `job` (running/failed/done), `opportunity` (trending topic), `system`, `billing`. Each carries `{title, body, link_to?, severity}`.

## Appendix E — Admin: API keys, Webhooks, Emails, Refunds

```
GET    /admin/api-keys?user_id=
POST   /admin/api-keys                 {user_id, label, scopes[]}
DELETE /admin/api-keys/{id}
GET    /admin/webhooks
POST   /admin/webhooks                 {url, events[], secret}
PATCH  /admin/webhooks/{id}            {enabled?}
POST   /admin/webhooks/{id}/test
GET    /admin/email-templates
PATCH  /admin/email-templates/{key}    {subject_md, body_md, enabled}
POST   /admin/email-templates/{key}/test  {to}
GET    /admin/refunds?status=
POST   /admin/refunds/{id}/approve     {amount?, reason}
POST   /admin/refunds/{id}/reject      {reason}
```

API-key scopes: `videos:read`, `videos:write`, `channels:read`, `channels:write`, `topics:read`, `topics:write`, `analytics:read`, `webhooks:receive`, `*` (admin only).

Webhook event types (outgoing): `video.published`, `job.failed`, `job.done`, `topic.queued`, `topic.idea`, `channel.connected`, `channel.disconnected`, `user.upgraded`, `user.cancelled`, `credits.depleted`. Webhook payloads are signed (HMAC-SHA256, header `X-Aic-Signature`).

Email template keys: `welcome`, `verify_email`, `magic_link`, `reset_password`, `review_needed`, `video_published`, `plan_renewal`, `low_credits`, `weekly_digest`, `oauth_disconnected`.

## Appendix F — Customer-facing screens (full inventory, round 3)

Built in `screen-customer-extras.jsx`:

| Route | Screen | Purpose |
|---|---|---|
| `#video/{id}` | `VideoDetailScreen` | Drill into a published video — player, performance, distribution, charts, retention curve, top audience, traffic sources, top comments. Click any Library card. |
| `#channel-analytics/{id}` | `ChannelAnalyticsScreen` | Per-channel deep dive (views/subs charts, top videos, posting cadence heatmap). |
| `#ab` | `ABResultsScreen` | Thumbnail A/B test results with CTR-over-time chart and statistical confidence call-out. |
| `#ticket/{id}` | `TicketThreadScreen` | Full customer-side conversation (messages, system events, attachments). |
| `#notif-prefs` | `NotificationPrefsScreen` | Per-event matrix (in-app / email / push / Slack) + quiet hours + digest frequency. |
| `#refer` | `ReferEarnScreen` | Referral link + stats + recent referrals. |
| `#security` | `SecurityScreen` | Password, 2FA, passkeys, SSO upsell, active sessions. |
| `#api-keys` | `UserAPIKeysScreen` | Customer-facing API keys + outgoing webhook endpoints. |
| `#invoices` | `InvoicesScreen` | Receipts + billing history + payment method. |
| `#2fa-setup` (auth) | `TwoFASetupScreen` | Passkey OR Authenticator OR SMS · QR · 6-digit verify · backup codes. |
| `#sso` (auth) | `SSOScreen` | Enterprise SSO email → IdP redirect (Okta, Google Workspace, Azure AD, etc.). |

## Appendix G — Admin extras (round 3)

Built in `screen-admin-extras-2.jsx`:

| Route | Screen | Purpose |
|---|---|---|
| `#job/{id}` | `AdminJobDetail` | Live log viewer (dark terminal style), input artifacts, run history, quick retry/cancel/credit-back. Click any row in the jobs queue. |
| `#ticket/{id}` | `AdminTicketThread` | Internal-note threads, canned replies, customer context rail, linked job. |
| `#cohorts` | `AdminCohorts` | Retention heatmap (9×9 months), M1/M3/M6 KPI tiles, LTV, posting cadence patterns. |
| `#flags` | `AdminFlags` | Feature flags with rollout %, targeting rules, A/B experiment winner annotations, internal toggles. |

## Appendix H — Standalone surfaces

| File | URL | Purpose |
|---|---|---|
| `AIcreators Cloud Auth.html` | `app.aicreators.cloud/auth` | Pre-app auth flows — login/signup/forgot/reset/verify/2fa-setup/sso. |
| `AIcreators Cloud Status.html` | `status.aicreators.cloud` | Public status page — 13 services, 90-day uptime, incident history, subscribe (email/Slack/RSS/webhook). |

## Final API additions (round 3)

```
GET    /videos/{id}                              – full video record
POST   /videos/{id}/unlist
DELETE /videos/{id}
GET    /videos/{id}/analytics?window=
GET    /channels/{id}/analytics?window=
GET    /videos/{id}/ab-tests                     – thumbnail variants + impressions
POST   /videos/{id}/ab-tests/{vid}/promote       – set primary

GET    /help/tickets/{id}
POST   /help/tickets/{id}/reply                  – multipart {body, attachments[]}
PATCH  /help/tickets/{id}                        – {status}

GET    /me/notification-prefs
PATCH  /me/notification-prefs                    – per-channel per-event
GET    /me/referrals                              – stats + invites
POST   /me/referrals/invite                       – {emails[]}

POST   /me/2fa/totp/start                         – returns QR + secret
POST   /me/2fa/totp/verify                        – {code}
DELETE /me/2fa
POST   /me/2fa/backup-codes/regenerate            – string[10]
POST   /me/passkeys                               – WebAuthn register
DELETE /me/passkeys/{id}
GET    /me/sessions
DELETE /me/sessions/{id}
DELETE /me/sessions                               – sign out everywhere
POST   /auth/sso/{org_id}/start                   – SAML/OIDC redirect

GET    /me/api-keys
POST   /me/api-keys                               – {label, scopes[]}
DELETE /me/api-keys/{id}
GET    /me/invoices
GET    /me/invoices/{id}.pdf

GET    /admin/jobs/{id}
GET    /admin/jobs/{id}/logs?cursor=
WS     /admin/jobs/{id}/logs/stream
POST   /admin/jobs/{id}/credit-back               – {amount}
GET    /admin/tickets/{id}
POST   /admin/tickets/{id}/reply                  – {body, internal_note?, attachments[]}
GET    /admin/cohorts?cohort_by=signup_month&window=
GET    /admin/retention?cohort_id=
GET    /admin/flags
POST   /admin/flags                               – {key, description, rollout_pct}
PATCH  /admin/flags/{key}                         – {rollout_pct, targeting_rules}

GET    /public/status
GET    /public/status/incidents
GET    /public/status/uptime?days=90
POST   /public/status/subscribe                   – {email, channels[]}
```

## 100% complete

The four HTML entries (`AIcreators Cloud.html`, `AIcreators Cloud (Magic Dark).html`, `AIcreators Cloud Admin.html`, `AIcreators Cloud Auth.html`, `AIcreators Cloud Status.html`) cover every customer-facing flow, every admin/ops surface, the auth perimeter, and the public status page. Every screen has its backend API documented in this file.

