/* ============================================================
   AIcreators.cloud · Admin (Operator) Console
   ============================================================

   PURPOSE
   -------
   Internal console for the team to operate the platform:
   monitor health, manage users, retry failed jobs, moderate
   content, tune plans/models, see revenue.

   SCREENS (each section below)
     1. AdminOverview     – KPIs, MRR chart, system health
     2. AdminUsers        – list + drill-in + impersonate
     3. AdminJobs         – every pipeline job in-flight
     4. AdminModels       – per-model usage + cost + latency
     5. AdminGPU          – GPU pool utilisation
     6. AdminModeration   – content moderation queue
     7. AdminChannels     – every connected YouTube channel
     8. AdminPlans        – pricing tiers + coupons
     9. AdminTickets      – support ticket inbox
    10. AdminAudit        – immutable audit log

   AUTHZ
   -----
   All admin routes require a JWT with role ∈ {owner, admin, support}.
   - 'support' is read-only + ticket actions
   - 'admin'   is everything except plan price edits
   - 'owner'   is everything
   The mock console doesn't enforce this; backend MUST.

   BACKEND ENDPOINTS (high level — full table in HANDOFF.md)
   ---------------------------------------------------------
     GET  /admin/kpis?window=30d
     GET  /admin/health
     GET  /admin/users?cursor=&search=&plan=&status=
     POST /admin/users/{id}/impersonate
     GET  /admin/jobs?status=&stage=&user_id=&cursor=
     POST /admin/jobs/{id}/retry
     POST /admin/jobs/{id}/cancel
     WS   /admin/jobs/stream
     GET  /admin/models
     PATCH /admin/models/{id}     {enabled, default}
     GET  /admin/gpu-pool
     GET  /admin/moderation?status=open
     POST /admin/moderation/{id}/approve
     POST /admin/moderation/{id}/reject  body: {reason}
     GET  /admin/channels?cursor=
     POST /admin/channels/{id}/reconnect
     GET  /admin/plans
     PATCH /admin/plans/{id}
     POST /admin/coupons         body: {code, kind, value, expires, cap}
     GET  /admin/tickets?status=
     PATCH /admin/tickets/{id}   {status, assignee, reply}
     GET  /admin/audit?cursor=

   REALTIME
   --------
   Jobs page subscribes to WS /admin/jobs/stream and patches the
   in-memory list on each frame.

   ============================================================ */

/* ----- shared widgets ----- */

function AdminTopBar() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ position: 'relative' }}>
        <I.Search size={14} stroke="var(--fg-muted)" style={{ position: 'absolute', top: 11, left: 12 }}/>
        <input placeholder="Find users, jobs, tickets…" style={{ height: 36, width: 320, paddingLeft: 36, fontSize: 13 }}/>
      </div>
      <button className="btn btn--ghost btn--icon" title="Alerts">
        <I.Bell size={18}/>
        <span style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: '50%', background: 'var(--danger)', boxShadow: '0 0 6px var(--danger)' }}/>
      </button>
      <Btn kind="secondary" size="sm" icon={I.Download}>Export</Btn>
    </div>
  );
}

function AdminStat({ label, value, delta, trend, icon: Ico }) {
  const color = trend === 'up' ? 'var(--success)' : trend === 'down' ? 'var(--danger)' : 'var(--fg-muted)';
  return (
    <div className="card">
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <span style={{
          width: 36, height: 36, borderRadius: 10,
          background: 'var(--surface-hover)',
          border: '1px solid var(--border-hairline)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--fg-default)',
        }}>{Ico && <Ico size={16}/>}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="t-tiny">{label}</div>
          <div style={{ font: '700 24px/1.1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em', marginTop: 6 }}>{value}</div>
          {delta && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 6, font: '600 12px/1 var(--font-sans)', color }}>
              {trend === 'up' && <I.TrendUp size={12}/>}
              {trend === 'down' && <I.TrendUp size={12} style={{ transform: 'scaleY(-1)' }}/>}
              <span>{delta}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function HealthDot({ status }) {
  const color = { ok: 'var(--success)', warn: 'var(--warning)', down: 'var(--danger)', hot: 'var(--warning)', healthy: 'var(--success)', refresh: 'var(--warning)', revoked: 'var(--danger)' }[status];
  return <span style={{ width: 8, height: 8, borderRadius: '50%', background: color, boxShadow: `0 0 8px ${color}` }}/>;
}

/* ============================================================
   1.  ADMIN OVERVIEW
   ----
   Backed by:
     GET /admin/kpis        – the 8 top-line numbers
     GET /admin/kpis/mrr    – the MRR sparkline
     GET /admin/health      – per-service status (poll 10s)
   Permissions: any admin role can read.
   ============================================================ */
function AdminOverview() {
  const k = ADMIN.kpis;
  const W = 920, H = 180, max = Math.max(...ADMIN.mrrSparkline);
  const points = ADMIN.mrrSparkline.map((v, i) => `${(i / (ADMIN.mrrSparkline.length - 1)) * W},${H - (v / max) * (H - 20)}`);
  const path = `M${points.join(" L")}`;
  const areaPath = `${path} L${W},${H} L0,${H} Z`;

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 14 }}>
          <AdminStat label="Monthly Recurring Revenue" value={k.mrr.value}     delta={k.mrr.delta}     trend={k.mrr.trend}     icon={I.Credit}/>
          <AdminStat label="Active users (30d)"        value={k.activeUsers.value} delta={k.activeUsers.delta} trend={k.activeUsers.trend} icon={I.Users}/>
          <AdminStat label="Paid users"                value={k.paidUsers.value}  delta={k.paidUsers.delta}  trend={k.paidUsers.trend}   icon={I.User}/>
          <AdminStat label="Videos shipped (30d)"      value={k.videosShipped.value} delta={k.videosShipped.delta} trend={k.videosShipped.trend} icon={I.Youtube}/>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 18 }}>
          <AdminStat label="Jobs in flight"   value={k.jobsRunning.value} delta={k.jobsRunning.delta} trend={k.jobsRunning.trend} icon={I.Pipeline}/>
          <AdminStat label="Model spend (30d)" value={k.modelSpend.value} delta={k.modelSpend.delta} trend={k.modelSpend.trend} icon={I.Robot}/>
          <AdminStat label="Churn"             value={k.churn.value}      delta={k.churn.delta}      trend="down" icon={I.Logout}/>
          <AdminStat label="Error rate"        value={k.errorRate.value}  delta={k.errorRate.delta}  trend="down" icon={I.Help}/>
        </div>

        {/* MRR chart */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <span className="t-h5">MRR — last 30 days</span>
            <span className="chip chip--success">+12.4%</span>
            <div style={{ flex: 1 }}/>
            <Tabs value="mrr" onChange={()=>{}} items={[
              { id: 'mrr', label: 'MRR' },
              { id: 'arr', label: 'ARR' },
              { id: 'arpu', label: 'ARPU' },
            ]}/>
          </div>
          <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block' }}>
            <defs>
              <linearGradient id="mrrG" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%"   stopColor="var(--brand)" stopOpacity="0.40"/>
                <stop offset="100%" stopColor="var(--brand)" stopOpacity="0"/>
              </linearGradient>
            </defs>
            {[0.25, 0.5, 0.75].map((y, i) => <line key={i} x1="0" x2={W} y1={H * y} y2={H * y} stroke="var(--border-hairline)" strokeWidth="1"/>)}
            <path d={areaPath} fill="url(#mrrG)"/>
            <path d={path} fill="none" stroke="var(--brand)" strokeWidth="2"/>
          </svg>
        </div>

        {/* System health */}
        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <I.Activity size={16} stroke="var(--fg-default)"/>
            <span className="t-h5">System health</span>
            <span className="t-small">polling every 10s</span>
            <div style={{ flex: 1 }}/>
            <Btn kind="ghost" size="sm" icon={I.Refresh}>Refresh</Btn>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 0 }}>
            {ADMIN.health.map((h, i) => (
              <div key={h.svc} style={{
                display: 'grid', gridTemplateColumns: '16px 1fr auto auto auto', gap: 14, alignItems: 'center',
                padding: '12px 18px',
                borderBottom: '1px solid var(--border-hairline)',
                borderRight: i % 2 === 0 ? '1px solid var(--border-hairline)' : 'none',
              }}>
                <HealthDot status={h.status}/>
                <div style={{ minWidth: 0 }}>
                  <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{h.svc}</div>
                  {h.note && <div className="t-small" style={{ color: h.status === 'warn' ? 'var(--warning-fg)' : 'var(--danger-fg)' }}>{h.note}</div>}
                </div>
                <span className="t-mono t-small" style={{ color: 'var(--fg-default)' }}>{h.rps}</span>
                <span className="t-mono t-small">p95 {h.p95}</span>
                <span className="t-mono t-small">err {h.err}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* Activity icon is in the shared library now */

/* ============================================================
   2.  ADMIN USERS
   ----
   Backed by:
     GET  /admin/users?cursor=&search=&plan=&status=
     POST /admin/users/{id}/impersonate     → returns short-lived JWT
     PATCH /admin/users/{id}                {credits_grant, plan, status}
   Permissions:
     - 'support' read-only + grant credits
     - 'admin' all except plan change
     - 'owner' all
   ============================================================ */
function AdminUsers({ onOpenUser }) {
  const [planFilter, setPlanFilter] = React.useState('all');
  const [statusFilter, setStatusFilter] = React.useState('all');
  const users = ADMIN.users.filter(u =>
    (planFilter === 'all' || u.plan.toLowerCase().includes(planFilter)) &&
    (statusFilter === 'all' || u.status === statusFilter)
  );
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Users</div>
            <div className="t-small" style={{ marginTop: 4 }}>{ADMIN.users.length} total · search, filter, impersonate</div>
          </div>
          <Tabs value={planFilter} onChange={setPlanFilter} items={[
            { id: 'all', label: 'All plans' }, { id: 'starter', label: 'Starter' }, { id: 'pro', label: 'Pro' }, { id: 'studio', label: 'Studio' }, { id: 'trial', label: 'Trial' },
          ]}/>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ position: 'relative' }}>
              <I.Search size={14} stroke="var(--fg-muted)" style={{ position: 'absolute', top: 11, left: 12 }}/>
              <input placeholder="email, name, user id…" style={{ height: 36, width: 320, paddingLeft: 36, fontSize: 13 }}/>
            </div>
            <div style={{ flex: 1 }}/>
            <Tabs value={statusFilter} onChange={setStatusFilter} items={[
              { id: 'all', label: 'All' }, { id: 'active', label: 'Active' }, { id: 'past_due', label: 'Past due' }, { id: 'trialing', label: 'Trial' }, { id: 'banned', label: 'Banned' },
            ]}/>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['User','Plan','Credits','Channels','Videos 30d','MRR','Status','Joined',''].map(h => (
                  <th key={h} style={{
                    padding: '10px 16px', textAlign: 'left',
                    font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em',
                    color: 'var(--fg-faint)', textTransform: 'uppercase',
                    borderBottom: '1px solid var(--border-hairline)',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} onClick={() => onOpenUser(u)} style={{ cursor: 'pointer', borderBottom: '1px solid var(--border-hairline)' }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <Avatar name={u.name} size={32}/>
                      <div>
                        <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{u.name}</div>
                        <div className="t-small" style={{ marginTop: 2 }}>{u.email} · {u.country}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }}><span className="chip">{u.plan}</span></td>
                  <td style={{ padding: '12px 16px', font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{u.credits}</td>
                  <td style={{ padding: '12px 16px', font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{u.channels}</td>
                  <td style={{ padding: '12px 16px', font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{u.videos30d}</td>
                  <td style={{ padding: '12px 16px', font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{u.mrr}</td>
                  <td style={{ padding: '12px 16px' }}>
                    {u.status === 'active'    && <span className="chip chip--success">Active</span>}
                    {u.status === 'past_due'  && <span className="chip chip--warning">Past due</span>}
                    {u.status === 'trialing'  && <span className="chip chip--info">Trial</span>}
                    {u.status === 'banned'    && <span className="chip chip--danger">Banned</span>}
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{u.joined}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button onClick={e=>e.stopPropagation()} className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* User detail drawer/page (opened from row click) */
function AdminUserDetail({ user, onBack }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <span className="t-small" style={{ cursor: 'pointer' }} onClick={onBack}>Users</span>
          <I.ChevRight size={12} stroke="var(--fg-faint)"/>
          <span className="t-small" style={{ color: 'var(--fg-default)' }}>{user.email}</span>
          <div style={{ flex: 1 }}/>
          <Btn kind="secondary" icon={I.Eye}>Impersonate</Btn>
          <Btn kind="secondary" icon={I.Plus}>Grant credits</Btn>
          <Btn kind="danger" icon={I.Lock}>Suspend</Btn>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <Avatar name={user.name} size={64}/>
          <div style={{ flex: 1 }}>
            <div className="t-h3">{user.name}</div>
            <div className="t-small" style={{ marginTop: 4 }}>{user.email} · {user.country} · joined {user.joined}</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <span className="chip">{user.plan}</span>
            {user.status === 'past_due' && <span className="chip chip--warning">Past due</span>}
            {user.status === 'active'   && <span className="chip chip--success">Active</span>}
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px 40px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
            <AdminStat label="Lifetime spend"      value="$2,148" icon={I.Credit}/>
            <AdminStat label="Videos lifetime"     value="318"    icon={I.Youtube}/>
            <AdminStat label="Credits used (mo)"   value={user.credits} icon={I.Spark}/>
            <AdminStat label="Open tickets"        value="0"      icon={I.Ticket}/>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 16 }}>
            <div className="card" style={{ padding: 0 }}>
              <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
                <span className="t-h5">Recent jobs</span>
              </div>
              {ADMIN.jobs.filter(j => j.user === user.id).slice(0, 4).map((j, i) => (
                <div key={j.id} style={{ padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: i < 3 ? '1px solid var(--border-hairline)' : 0 }}>
                  <JobStatusBadge status={j.status}/>
                  <div style={{ flex: 1 }}>
                    <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{j.project}</div>
                    <div className="t-small" style={{ marginTop: 4 }}>{j.stage} · {j.model} · {j.startedAt}</div>
                  </div>
                  <span className="t-mono t-small">{j.id}</span>
                </div>
              ))}
              {ADMIN.jobs.filter(j => j.user === user.id).length === 0 && (
                <div style={{ padding: '20px', textAlign: 'center' }} className="t-small">No recent jobs</div>
              )}
            </div>
            <div className="card">
              <div className="t-h5" style={{ marginBottom: 14 }}>Account</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <KV k="User ID" v={user.id}/>
                <KV k="Plan" v={user.plan}/>
                <KV k="MRR" v={user.mrr}/>
                <KV k="Country" v={user.country}/>
                <KV k="Joined" v={user.joined}/>
                <KV k="Channels" v={user.channels}/>
                <KV k="Videos 30d" v={user.videos30d}/>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function KV({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span className="t-small">{k}</span>
      <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}</span>
    </div>
  );
}

function JobStatusBadge({ status, size = 'md' }) {
  const map = {
    queued:  { label: 'Queued',  cls: 'chip' },
    running: { label: 'Running', cls: 'chip chip--brand' },
    review:  { label: 'Review',  cls: 'chip chip--warning' },
    failed:  { label: 'Failed',  cls: 'chip chip--danger' },
    done:    { label: 'Done',    cls: 'chip chip--success' },
  };
  const m = map[status] || map.queued;
  return <span className={m.cls} style={size === 'sm' ? { height: 22, fontSize: 11 } : {}}>{m.label}</span>;
}

/* ============================================================
   3.  ADMIN JOBS
   ----
   The pipeline-job queue across all users. Drill into one to
   see logs / retry / cancel.

   Backed by:
     GET  /admin/jobs?status=&stage=&user_id=&cursor=
     GET  /admin/jobs/{id}             – full detail w/ logs
     POST /admin/jobs/{id}/retry       – {force?: bool}
     POST /admin/jobs/{id}/cancel      – also bills back credits
     WS   /admin/jobs/stream           – patch frames

   Data model (Job):
     id (string)
     user_id (string)
     project_id (string)
     project_title (string)
     stage   (idea|script|storyboard|images|motion|voice|edit|publish)
     status  (queued|running|review|failed|done|canceled)
     model   (string)
     gpu     (string|null)
     started_at  (ISO)
     finished_at (ISO|null)
     credits_used (int)
     retries (int)
     error_code (string|null)
   ============================================================ */
function AdminJobs({ onOpenJob }) {
  const [status, setStatus] = React.useState('all');
  const [stage, setStage]   = React.useState('all');
  const list = ADMIN.jobs.filter(j =>
    (status === 'all' || j.status === status) &&
    (stage  === 'all' || j.stage  === stage)
  );
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Jobs queue</div>
            <div className="t-small" style={{ marginTop: 4 }}>{ADMIN.jobs.length} jobs in scope · realtime via WS · click any row for logs</div>
          </div>
          <Btn kind="secondary" size="sm" icon={I.Refresh}>Refresh</Btn>
          <Btn kind="danger" size="sm" icon={I.Refresh}>Retry all failed</Btn>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12, marginBottom: 16 }}>
          <AdminStat label="Running"  value="34" icon={I.Pipeline}/>
          <AdminStat label="Queued"   value="84" icon={I.Hourglass}/>
          <AdminStat label="Review"   value="6"  icon={I.Eye}/>
          <AdminStat label="Failed"   value="7"  delta="2 retrying" trend="down" icon={I.Help}/>
          <AdminStat label="Done (1h)" value="42" delta="+12 vs prior hr" trend="up" icon={I.Check}/>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid var(--border-hairline)' }}>
            <Tabs value={status} onChange={setStatus} items={[
              { id: 'all', label: 'All' }, { id: 'running', label: 'Running' }, { id: 'queued', label: 'Queued' }, { id: 'review', label: 'Review' }, { id: 'failed', label: 'Failed' }, { id: 'done', label: 'Done' },
            ]}/>
            <div style={{ flex: 1 }}/>
            <Tabs value={stage} onChange={setStage} items={[
              { id: 'all', label: 'All stages' }, ...PIPELINE_STAGES.map(s => ({ id: s.id, label: s.label })),
            ]}/>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Job','User','Project','Stage','Model','GPU','Started','Elapsed','Credits','Retries','Status',''].map(h => (
                  <th key={h} style={{ padding: '10px 12px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {list.map(j => (
                <tr key={j.id} onClick={() => onOpenJob && onOpenJob(j)} style={{ borderBottom: '1px solid var(--border-hairline)', cursor: 'pointer' }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <td style={{ padding: '10px 12px' }} className="t-mono t-small">{j.id}</td>
                  <td style={{ padding: '10px 12px' }}>
                    <div style={{ font: '600 12px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{j.userName}</div>
                    <div className="t-mono" style={{ font: '500 10px/1.2 var(--font-mono)', color: 'var(--fg-muted)' }}>{j.user}</div>
                  </td>
                  <td style={{ padding: '10px 12px', font: '500 12px/1.3 var(--font-sans)', color: 'var(--fg-default)', maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{j.project}</td>
                  <td style={{ padding: '10px 12px' }}>
                    <span className="chip" style={{ height: 22, fontSize: 11 }}>
                      {React.createElement(I[STAGE_BY_ID[j.stage]?.icon || 'Spark'], { size: 11 })}
                      {STAGE_BY_ID[j.stage]?.label || j.stage}
                    </span>
                  </td>
                  <td style={{ padding: '10px 12px' }} className="t-mono t-small">{j.model}</td>
                  <td style={{ padding: '10px 12px' }} className="t-mono t-small">{j.gpu}</td>
                  <td style={{ padding: '10px 12px' }} className="t-small">{j.startedAt}</td>
                  <td style={{ padding: '10px 12px' }} className="t-mono t-small">{j.elapsed}</td>
                  <td style={{ padding: '10px 12px' }} className="t-mono t-small">{j.credits}</td>
                  <td style={{ padding: '10px 12px', color: j.retries > 0 ? 'var(--warning-fg)' : 'var(--fg-muted)' }} className="t-mono t-small">{j.retries}</td>
                  <td style={{ padding: '10px 12px' }}><JobStatusBadge status={j.status} size="sm"/></td>
                  <td style={{ padding: '10px 12px', textAlign: 'right', whiteSpace: 'nowrap' }}>
                    {j.status === 'failed' && <button className="btn btn--ghost btn--icon btn--sm" title="Retry"><I.Refresh size={12}/></button>}
                    {j.status === 'running' && <button className="btn btn--ghost btn--icon btn--sm" title="Cancel"><I.Close size={12}/></button>}
                    <button className="btn btn--ghost btn--icon btn--sm" title="Details"><I.ChevRight size={12}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   4.  ADMIN MODELS
   ----
   Per-model dashboard: calls, cost, latency, error rate.
   Toggle availability and default-for-stage.

   Backed by:
     GET   /admin/models?window=30d
     PATCH /admin/models/{id}    {enabled?, default_for_stage?}
   ============================================================ */
function AdminModels() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Models</div>
            <div className="t-small" style={{ marginTop: 4 }}>Usage, cost, latency. Toggle off if a provider is misbehaving.</div>
          </div>
          <Btn kind="secondary" icon={I.Plus}>Register model</Btn>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Model','Family','Calls','Cost (30d)','Avg latency','p95','Errors','',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ADMIN.models.map(m => (
                <tr key={m.id} style={{ borderBottom: '1px solid var(--border-hairline)' }}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--brand-soft-bg)', border: '1px solid var(--brand-soft-bd)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand-fg)' }}>
                        <I.Robot size={16}/>
                      </span>
                      <div>
                        <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.label}</div>
                        <div className="t-mono t-small">{m.id}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{m.family}</td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{m.calls}</td>
                  <td style={{ padding: '12px 16px', font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.cost}</td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{m.avgLat}</td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{m.p95}</td>
                  <td style={{ padding: '12px 16px', color: parseFloat(m.errs) > 0.5 ? 'var(--warning-fg)' : 'var(--fg-default)' }} className="t-mono t-small">{m.errs}</td>
                  <td style={{ padding: '12px 16px' }}><Switch on={m.enabled} size="sm" onChange={()=>{}}/></td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   5.  ADMIN GPU POOL
   ----
   Backed by:
     GET /admin/gpu-pool                  – snapshot
     WS  /admin/gpu-pool/stream           – utilisation updates
     POST /admin/gpu-pool/{id}/drain      – stop scheduling new jobs
     POST /admin/gpu-pool/{id}/cordon     – mark unschedulable
   ============================================================ */
function AdminGPU() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">GPU pool</div>
            <div className="t-small" style={{ marginTop: 4 }}>8 nodes across 4 regions · 1 down · 1 hot</div>
          </div>
          <Btn kind="secondary" icon={I.Plus}>Scale up</Btn>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {ADMIN.gpuPool.map(g => (
            <div key={g.id} className="card" style={{ position: 'relative' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <HealthDot status={g.status}/>
                <span style={{ font: '700 14px/1 var(--font-display)', color: 'var(--fg-strong)' }}>{g.id}</span>
                <div style={{ flex: 1 }}/>
                <span className="t-small">{g.region}</span>
              </div>
              <div style={{ marginTop: 16 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 6 }}>
                  <span style={{ font: '700 28px/1 var(--font-display)', color: g.status === 'down' ? 'var(--danger)' : 'var(--fg-strong)', letterSpacing: '-0.02em' }}>{g.util}%</span>
                  <span className="t-small">utilization</span>
                </div>
                <div style={{ height: 6, background: 'var(--surface-elev)', borderRadius: 999, overflow: 'hidden' }}>
                  <div style={{
                    height: '100%', width: `${g.util}%`,
                    background: g.util > 90 ? 'var(--warning)' : g.status === 'down' ? 'var(--danger)' : 'var(--magic-grad)',
                    borderRadius: 999,
                  }}/>
                </div>
              </div>
              {g.note && (
                <div className="t-small" style={{ marginTop: 10, color: g.status === 'down' ? 'var(--danger-fg)' : 'var(--warning-fg)' }}>
                  {g.note}
                </div>
              )}
              <div style={{ display: 'flex', gap: 6, marginTop: 14 }}>
                <Btn kind="ghost" size="sm">Drain</Btn>
                <Btn kind="ghost" size="sm">Logs</Btn>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   6.  ADMIN MODERATION
   ----
   Backed by:
     GET  /admin/moderation?status=open
     GET  /admin/moderation/{id}    – full content + history
     POST /admin/moderation/{id}/approve
     POST /admin/moderation/{id}/reject   {reason, ban_user?}

   When a script/image/voice/thumbnail is auto-flagged at job
   stage, the job halts in 'review' status and a moderation
   ticket is created. Backend MUST hold the pipeline until
   resolved.
   ============================================================ */
function AdminModeration() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Moderation queue</div>
            <div className="t-small" style={{ marginTop: 4 }}>{ADMIN.moderation.length} items awaiting decision · pipeline is paused for each</div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {ADMIN.moderation.map(m => (
            <div key={m.id} className="card" style={{ display: 'grid', gridTemplateColumns: '64px 1fr auto', gap: 16, alignItems: 'center' }}>
              <div style={{
                width: 64, height: 64, borderRadius: 12,
                background: m.kind === 'image' ? 'linear-gradient(135deg,#1F2937,#7C3AED)' :
                            m.kind === 'thumbnail' ? 'linear-gradient(135deg,#7C3AED,#22D3EE)' :
                            'var(--surface-elev)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--fg-default)',
              }}>
                {m.kind === 'image' && <I.Image size={22}/>}
                {m.kind === 'thumbnail' && <I.Image size={22}/>}
                {m.kind === 'script' && <I.Edit size={22}/>}
                {m.kind === 'voice' && <I.Mic size={22}/>}
              </div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ font: '600 14px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.flagged}</span>
                  <span className="chip">{m.kind}</span>
                  <span className="chip chip--warning">{(m.confidence * 100).toFixed(0)}% confidence</span>
                </div>
                <div className="t-small" style={{ marginBottom: 6 }}>{m.user} · {m.project} · flagged {m.age}</div>
                <div style={{ font: '500 13px/1.5 var(--font-sans)', color: 'var(--fg-secondary)', fontStyle: 'italic', textWrap: 'pretty' }}>"{m.snippet}"</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
                <Btn kind="primary" size="sm" icon={I.Check}>Approve & resume</Btn>
                <Btn kind="danger" size="sm" icon={I.Close}>Reject</Btn>
                <Btn kind="ghost" size="sm">Open full preview</Btn>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   7.  ADMIN CHANNELS
   ----
   Every connected YouTube channel across all users.

   Backed by:
     GET  /admin/channels?cursor=
     POST /admin/channels/{id}/reconnect   – sends user notification + magic link
     DELETE /admin/channels/{id}            – revoke OAuth on our side
   ============================================================ */
function AdminChannels() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Connected channels</div>
            <div className="t-small" style={{ marginTop: 4 }}>{ADMIN.channels.length} channels · OAuth status across users</div>
          </div>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Channel','Owner','Subs','Uploads (mo)','OAuth','Last upload',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ADMIN.channels.map(c => (
                <tr key={c.id} style={{ borderBottom: '1px solid var(--border-hairline)' }}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{c.name}</div>
                    <div className="t-small">{c.handle}</div>
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{c.user}</td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{c.subs}</td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{c.uploadsThisMonth}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <HealthDot status={c.oauthStatus}/>
                      <span style={{ font: '500 12px/1 var(--font-sans)', color: c.oauthStatus === 'ok' ? 'var(--fg-default)' : c.oauthStatus === 'revoked' ? 'var(--danger-fg)' : 'var(--warning-fg)' }}>
                        {c.oauthStatus === 'ok' ? 'Connected' : c.oauthStatus === 'refresh' ? 'Refresh failing' : 'Revoked'}
                      </span>
                    </div>
                    {c.note && <div className="t-small" style={{ marginTop: 4 }}>{c.note}</div>}
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{c.lastUpload}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    {c.oauthStatus !== 'ok' ? <Btn kind="secondary" size="sm" icon={I.Refresh}>Reconnect</Btn> : <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   8.  ADMIN PLANS
   ----
   Edit pricing, included credits, feature flags. Manage coupons.

   Backed by:
     GET   /admin/plans
     PATCH /admin/plans/{id}        {price, credits, channels, features}
     GET   /admin/coupons
     POST  /admin/coupons           {code, kind, value, expires, cap}
     DELETE /admin/coupons/{code}

   IMPORTANT: changing a plan's price MUST not retroactively
   affect existing subscriptions. Backend versions plans.
   ============================================================ */
function AdminPlans() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Plans & Coupons</div>
            <div className="t-small" style={{ marginTop: 4 }}>Pricing tiers, feature flags, promo codes</div>
          </div>
          <Btn kind="secondary" icon={I.Plus}>New coupon</Btn>
        </div>

        <div className="t-h5" style={{ marginBottom: 10 }}>Tiers</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 24 }}>
          {ADMIN.plans.map(p => (
            <div key={p.id} className="card">
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                <span className="t-h4">{p.name}</span>
                <span className="t-small">· {p.active} active</span>
              </div>
              <div style={{ marginTop: 10, marginBottom: 14 }}>
                <span style={{ font: '700 32px/1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em' }}>${p.price}</span>
                <span className="t-small" style={{ marginLeft: 4 }}>/ mo</span>
              </div>
              <KV k="Credits / mo" v={p.credits.toLocaleString()}/>
              <KV k="Channels" v={p.channels}/>
              <div className="divider" style={{ margin: '12px 0' }}/>
              <div className="t-tiny" style={{ marginBottom: 8 }}>Features</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {Object.entries(p.features).map(([k, v]) => (
                  <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    {v ? <I.Check size={12} stroke="var(--success)"/> : <I.Close size={12} stroke="var(--fg-faint)"/>}
                    <span className="t-small" style={{ color: v ? 'var(--fg-default)' : 'var(--fg-faint)' }}>{k.replace(/([A-Z])/g, ' $1').toLowerCase()}</span>
                  </div>
                ))}
              </div>
              <Btn kind="secondary" size="sm" icon={I.Edit} style={{ marginTop: 14, width: '100%' }}>Edit tier</Btn>
            </div>
          ))}
        </div>

        <div className="t-h5" style={{ marginBottom: 10 }}>Coupons</div>
        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Code','Discount','Expires','Redemptions','',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ADMIN.coupons.map(c => (
                <tr key={c.code} style={{ borderBottom: '1px solid var(--border-hairline)' }}>
                  <td style={{ padding: '12px 16px', font: '700 13px/1 var(--font-mono)', color: 'var(--fg-strong)' }} className="t-mono">{c.code}</td>
                  <td style={{ padding: '12px 16px', font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{c.discount}</td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{c.expires}</td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{c.redemptions} / {c.cap}</td>
                  <td style={{ padding: '12px 16px', width: 200 }}>
                    <ProgressBar value={(c.redemptions / c.cap) * 100} size="sm"/>
                  </td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button className="btn btn--ghost btn--icon btn--sm"><I.Copy size={12}/></button>
                    <button className="btn btn--ghost btn--icon btn--sm"><I.Trash size={12}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   9.  ADMIN TICKETS
   ----
   Support inbox. Each ticket links to user, optionally to a job.

   Backed by:
     GET   /admin/tickets?status=&assignee=
     PATCH /admin/tickets/{id}    {status?, assignee?, reply?}
     POST  /admin/tickets/{id}/reply  {body, internal_note?}
   ============================================================ */
function AdminTickets({ onOpenTicket }) {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Support tickets</div>
            <div className="t-small" style={{ marginTop: 4 }}>{ADMIN.tickets.length} open · sorted by priority</div>
          </div>
          <Btn kind="secondary" size="sm" icon={I.Filter}>Filter</Btn>
        </div>

        <div className="card" style={{ padding: 0 }}>
          {ADMIN.tickets.map((t, i) => (
            <div key={t.id} onClick={() => onOpenTicket && onOpenTicket(t)} style={{
              display: 'grid', gridTemplateColumns: '64px 1fr 100px 80px 120px',
              gap: 16, alignItems: 'center', padding: '14px 18px',
              borderBottom: i < ADMIN.tickets.length - 1 ? '1px solid var(--border-hairline)' : 0,
              cursor: 'pointer',
            }}
                 onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                 onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
              <span className="t-mono t-small">{t.id}</span>
              <div>
                <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{t.subject}</div>
                <div className="t-small" style={{ marginTop: 4 }}>{t.user} · {t.age}</div>
              </div>
              <div>
                {t.priority === 'high'   && <span className="chip chip--danger">High</span>}
                {t.priority === 'medium' && <span className="chip chip--warning">Medium</span>}
                {t.priority === 'low'    && <span className="chip">Low</span>}
              </div>
              <div>
                {t.status === 'open'    && <span className="chip chip--info">Open</span>}
                {t.status === 'waiting' && <span className="chip">Waiting</span>}
              </div>
              <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                <Btn kind="secondary" size="sm" icon={I.Send}>Reply</Btn>
                <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   10. ADMIN AUDIT LOG
   ----
   Immutable, append-only. Every admin action lands here.

   Backed by:
     GET /admin/audit?cursor=&actor=&action=

   Backend MUST stamp:
     ts (UTC), actor (user_id), action (enum), target, meta (json),
     ip, user_agent.
   ============================================================ */
function AdminAudit() {
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Audit log</div>
            <div className="t-small" style={{ marginTop: 4 }}>Immutable · every admin action and system event</div>
          </div>
          <Btn kind="secondary" size="sm" icon={I.Filter}>Filter</Btn>
          <Btn kind="secondary" size="sm" icon={I.Download}>Export</Btn>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Timestamp','Actor','Action','Target','Meta'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ADMIN.audit.map((a, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border-hairline)' }}>
                  <td style={{ padding: '10px 16px' }} className="t-mono t-small">{a.ts}</td>
                  <td style={{ padding: '10px 16px' }}>
                    <span style={{ font: '600 12px/1 var(--font-sans)', color: a.actor === 'system' ? 'var(--fg-muted)' : 'var(--fg-strong)' }}>{a.actor}</span>
                  </td>
                  <td style={{ padding: '10px 16px' }}>
                    <span className="chip" style={{ height: 22, fontSize: 11 }}>{a.action}</span>
                  </td>
                  <td style={{ padding: '10px 16px' }} className="t-mono t-small">{a.target}</td>
                  <td style={{ padding: '10px 16px' }} className="t-small">{a.meta}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  AdminOverview, AdminUsers, AdminUserDetail, AdminJobs, AdminModels,
  AdminGPU, AdminModeration, AdminChannels, AdminPlans, AdminTickets, AdminAudit,
});
