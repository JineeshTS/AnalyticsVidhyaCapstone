/* ============================================================
   AIcreators V2 — minimal icon set (Geist-style 1.5px stroke)
   ============================================================ */

const Icon = ({ size = 20, stroke = "currentColor", strokeWidth = 1.5, fill = "none", children, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
       stroke={stroke} strokeWidth={strokeWidth}
       strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {children}
  </svg>
);

const V2I = {
  Home:      (p)=> <Icon {...p}><path d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-3v-7H10v7H5a2 2 0 0 1-2-2z"/></Icon>,
  Studio:    (p)=> <Icon {...p}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3" fill="currentColor"/></Icon>,
  Pipeline:  (p)=> <Icon {...p}><circle cx="5" cy="7" r="2"/><circle cx="12" cy="17" r="2"/><circle cx="19" cy="7" r="2"/><path d="M5 9v2a3 3 0 0 0 3 3h2"/><path d="M19 9v2a3 3 0 0 1-3 3h-2"/></Icon>,
  Play:      (p)=> <Icon {...p}><polygon points="6,4 20,12 6,20" fill="currentColor" stroke="none"/></Icon>,
  Pause:     (p)=> <Icon {...p}><rect x="6" y="4" width="4" height="16" rx="1" fill="currentColor" stroke="none"/><rect x="14" y="4" width="4" height="16" rx="1" fill="currentColor" stroke="none"/></Icon>,
  Plus:      (p)=> <Icon {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Icon>,
  Search:    (p)=> <Icon {...p}><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/></Icon>,
  Bell:      (p)=> <Icon {...p}><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></Icon>,
  Settings:  (p)=> <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></Icon>,
  Spark:     (p)=> <Icon {...p}><path d="M12 2L13.6 8.4 20 10 13.6 11.6 12 18 10.4 11.6 4 10 10.4 8.4 12 2Z" fill="currentColor"/></Icon>,
  Youtube:   (p)=> <Icon {...p}><rect x="2.5" y="5" width="19" height="14" rx="3"/><polygon points="10,9 15.5,12 10,15" fill="currentColor" stroke="none"/></Icon>,
  Mic:       (p)=> <Icon {...p}><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0"/><line x1="12" y1="18" x2="12" y2="22"/></Icon>,
  User:      (p)=> <Icon {...p}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></Icon>,
  ChevDown:  (p)=> <Icon {...p}><polyline points="6,9 12,15 18,9"/></Icon>,
  ChevUp:    (p)=> <Icon {...p}><polyline points="18,15 12,9 6,15"/></Icon>,
  ChevLeft:  (p)=> <Icon {...p}><polyline points="15,18 9,12 15,6"/></Icon>,
  ChevRight: (p)=> <Icon {...p}><polyline points="9,18 15,12 9,6"/></Icon>,
  ArrowRight:(p)=> <Icon {...p}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12,5 19,12 12,19"/></Icon>,
  Check:     (p)=> <Icon {...p}><polyline points="20,6 9,17 4,12"/></Icon>,
  Close:     (p)=> <Icon {...p}><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></Icon>,
  Film:      (p)=> <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/></Icon>,
  Image:     (p)=> <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></Icon>,
  Layers:    (p)=> <Icon {...p}><polygon points="12,2 2,7 12,12 22,7"/><polyline points="2,17 12,22 22,17"/><polyline points="2,12 12,17 22,12"/></Icon>,
  Calendar:  (p)=> <Icon {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/></Icon>,
  Folder:    (p)=> <Icon {...p}><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></Icon>,
  BarChart:  (p)=> <Icon {...p}><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></Icon>,
  More:      (p)=> <Icon {...p}><circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/></Icon>,
  Edit:      (p)=> <Icon {...p}><path d="M11 4H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2v-6"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"/></Icon>,
  Eye:       (p)=> <Icon {...p}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></Icon>,
  Send:      (p)=> <Icon {...p}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22,2 15,22 11,13 2,9"/></Icon>,
  Upload:    (p)=> <Icon {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/></Icon>,
  Bolt:      (p)=> <Icon {...p}><polygon points="13,2 3,14 12,14 11,22 21,10 12,10 13,2" fill="currentColor" stroke="none"/></Icon>,
  Robot:     (p)=> <Icon {...p}><rect x="4" y="7" width="16" height="13" rx="3"/><circle cx="9" cy="13" r="1.4" fill="currentColor" stroke="none"/><circle cx="15" cy="13" r="1.4" fill="currentColor" stroke="none"/><path d="M12 4v3"/><circle cx="12" cy="3" r="1" fill="currentColor" stroke="none"/></Icon>,
  Credit:    (p)=> <Icon {...p}><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></Icon>,
};

window.V2I = V2I;
