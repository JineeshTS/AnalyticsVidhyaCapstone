/* ============================================================
   AIcreators.cloud · Help & Support
   ============================================================
   Knowledge base · video tutorials · system status · my tickets · live chat

   ROUTES (within help)
     #help                – default landing (search + KB + my tickets)
     #help/docs/{slug}    – article detail (mock — opens an overlay)
     #help/ticket/{id}    – single ticket
     #help/new            – open new ticket form

   BACKEND CONTRACT
     GET   /help/articles?cursor=&q=
     GET   /help/articles/{slug}
     GET   /help/tickets/mine
     POST  /help/tickets                  {subject, body, attachments[]}
     GET   /help/tickets/{id}
     POST  /help/tickets/{id}/reply       {body, attachments[]}
     PATCH /help/tickets/{id}             {status}   – customer closes
     GET   /help/status                   – polls public-status feed
     WS    /help/chat/{room_id}           – live chat with support

   TICKET DATA MODEL (mirrors admin side)
     id, user_id, subject, priority (auto-classified),
     status (open|waiting|resolved|closed),
     channel_id (optional context), project_id (optional context),
     created_at, updated_at,
     messages[]: { id, from (user|agent|system), body_md, attachments[], created_at }
   ============================================================ */

const SUPPORT_ARTICLES = [
  { slug: 'connect-youtube', title: 'Connect a YouTube channel', cat: 'Getting started', read: '2 min', body: 'Click Connect YouTube in the Channels page…' },
  { slug: 'first-video',     title: 'Your first video, end to end', cat: 'Getting started', read: '5 min', body: 'Pick a channel, hit New Video, choose a topic…' },
  { slug: 'autopilot',       title: 'How autopilot decides what to run', cat: 'Autopilot', read: '4 min', body: 'Autopilot picks the best prompting technique per stage…' },
  { slug: 'voice-clone',     title: 'Clone your voice in 60 seconds', cat: 'Voices & Avatars', read: '3 min', body: 'Record a 60s sample…' },
  { slug: 'lip-sync',        title: 'Adding lip sync to your avatar', cat: 'Voices & Avatars', read: '4 min', body: 'Upload a single front-facing portrait…' },
  { slug: 'multi-platform',  title: 'Posting to YouTube, Instagram and TikTok at once', cat: 'Publishing', read: '6 min', body: 'Each platform has its own aspect ratio, caption, and length rules…' },
  { slug: 'review-stage',    title: 'Pausing the pipeline for review', cat: 'Pipeline', read: '3 min', body: 'Any stage can be set to pause for your approval…' },
  { slug: 'style-builder',   title: 'Building a visual style from reference images', cat: 'Visual styles', read: '5 min', body: 'Upload 5-20 reference images…' },
  { slug: 'credits',         title: 'How credits and billing work', cat: 'Billing', read: '4 min', body: 'Each pipeline stage costs credits — see the per-action table…' },
  { slug: 'plan-change',     title: 'Upgrading or downgrading your plan', cat: 'Billing', read: '2 min', body: 'Go to Billing & Plan…' },
  { slug: 'oauth-fails',     title: 'YouTube OAuth keeps disconnecting', cat: 'Troubleshooting', read: '3 min', body: 'If your OAuth refresh fails…' },
  { slug: 'gpu-queue',       title: 'Why my video is queued', cat: 'Troubleshooting', read: '2 min', body: 'During peak hours, jobs sit in queue…' },
];

const MY_TICKETS = [
  { id: 't_2103', subject: 'Can I clone a voice in Hindi?',         status: 'waiting',  age: '2 h',   priority: 'low' },
  { id: 't_2098', subject: 'My channel art looks pixelated',         status: 'resolved', age: '3 days',priority: 'medium' },
];

const SUPPORT_STATUS = [
  { svc: 'Pipeline · LLM scripts',  status: 'ok' },
  { svc: 'Pipeline · Keyframes',    status: 'warn', note: 'Slight queue lag — 12 min p95' },
  { svc: 'Pipeline · Image-to-video', status: 'ok' },
  { svc: 'Pipeline · Voice cloning', status: 'ok' },
  { svc: 'YouTube uploader',         status: 'ok' },
  { svc: 'Instagram publisher',      status: 'ok' },
  { svc: 'TikTok publisher',         status: 'ok' },
  { svc: 'Web app + API',            status: 'ok' },
];

function HelpSupportScreen() {
  const [tab, setTab] = React.useState('all');
  const [openArticle, setOpenArticle] = React.useState(null);
  const [openTicketForm, setOpenTicketForm] = React.useState(false);
  const [openChat, setOpenChat] = React.useState(false);

  const cats = ['Getting started','Autopilot','Voices & Avatars','Publishing','Pipeline','Visual styles','Billing','Troubleshooting'];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>

        {/* Big search hero */}
        <div className="card" style={{ padding: 28, marginBottom: 18, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', position: 'relative', overflow: 'hidden', textAlign: 'center' }}>
          <SparkleField count={8} intensity={0.35}/>
          <div style={{ position: 'relative' }}>
            <div className="t-h2" style={{ marginBottom: 8 }}>How can we help?</div>
            <div className="t-small" style={{ marginBottom: 22 }}>Search the docs, find an answer in seconds, or talk to a real human.</div>

            <div style={{ position: 'relative', maxWidth: 580, margin: '0 auto' }}>
              <I.Search size={18} stroke="var(--fg-muted)" style={{ position: 'absolute', top: 17, left: 18 }}/>
              <input placeholder="Search · e.g. clone voice, multi-platform, scheduling…" autoFocus
                     style={{ height: 52, paddingLeft: 48, fontSize: 15, background: 'var(--bg-surface)' }}/>
              <span style={{ position: 'absolute', right: 8, top: 8, padding: '4px 8px', borderRadius: 6, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', font: '600 11px/1 var(--font-mono)', color: 'var(--fg-muted)' }}>⌘ K</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 22, flexWrap: 'wrap' }}>
              <Btn kind="primary" icon={I.Message} onClick={() => setOpenChat(true)}>Live chat</Btn>
              <Btn kind="secondary" icon={I.Mail} onClick={() => setOpenTicketForm(true)}>Open ticket</Btn>
              <Btn kind="ghost" icon={I.Play}>Video tour</Btn>
            </div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 18 }}>
          {/* Left: KB */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <span className="t-h5">Knowledge base</span>
              <span className="chip">{SUPPORT_ARTICLES.length}</span>
              <div style={{ flex: 1 }}/>
              <Tabs value={tab} onChange={setTab} items={[
                { id: 'all', label: 'All' },
                { id: 'guide', label: 'Guides' },
                { id: 'trouble', label: 'Troubleshooting' },
              ]}/>
            </div>

            {/* Category tiles */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginBottom: 18 }}>
              {cats.map((c, i) => {
                const ic = ['Spark','Robot','Mic','Send','Pipeline','Image','Credit','Help'][i];
                return (
                  <div key={c} className="card card--hover" style={{ padding: 14, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', color: 'var(--accent-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                      {React.createElement(I[ic], { size: 14 })}
                    </span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{c}</div>
                      <div className="t-small" style={{ marginTop: 2 }}>{Math.floor(Math.random() * 12) + 3} articles</div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="card" style={{ padding: 0 }}>
              <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
                <span className="t-tiny">Popular this week</span>
              </div>
              {SUPPORT_ARTICLES.slice(0, 8).map((a, i) => (
                <div key={a.slug} onClick={() => setOpenArticle(a)} style={{
                  padding: '14px 18px',
                  borderBottom: i < 7 ? '1px solid var(--border-hairline)' : 0,
                  display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer',
                  transition: 'background 120ms var(--ease-out)',
                }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--fg-default)', flexShrink: 0 }}>
                    <I.Help size={16}/>
                  </span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{a.title}</div>
                    <div className="t-small" style={{ marginTop: 4 }}>{a.cat} · {a.read} read</div>
                  </div>
                  <I.ChevRight size={14} stroke="var(--fg-muted)"/>
                </div>
              ))}
            </div>
          </div>

          {/* Right rail: my tickets + status */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="card" style={{ padding: 0 }}>
              <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center' }}>
                <span className="t-h5">My tickets</span>
                <div style={{ flex: 1 }}/>
                <Btn kind="ghost" size="sm" icon={I.Plus} onClick={() => setOpenTicketForm(true)}>New</Btn>
              </div>
              {MY_TICKETS.length === 0 ? (
                <div style={{ padding: 20, textAlign: 'center' }} className="t-small">No open tickets</div>
              ) : MY_TICKETS.map((t, i) => (
                <div key={t.id} style={{
                  padding: '12px 18px',
                  borderBottom: i < MY_TICKETS.length - 1 ? '1px solid var(--border-hairline)' : 0,
                  display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer',
                }}>
                  <span className="t-mono t-small" style={{ width: 50, flexShrink: 0 }}>{t.id}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)' }}>{t.subject}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
                      {t.status === 'open'     && <span className="chip chip--info">Open</span>}
                      {t.status === 'waiting'  && <span className="chip chip--warning">Waiting on you</span>}
                      {t.status === 'resolved' && <span className="chip chip--success">Resolved</span>}
                      <span className="t-small">{t.age}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="card" style={{ padding: 0 }}>
              <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center' }}>
                <span className="t-h5">System status</span>
                <div style={{ flex: 1 }}/>
                <span className="chip chip--success"><I.Check size={10}/> Operational</span>
              </div>
              {SUPPORT_STATUS.map((s, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '10px 18px',
                  borderBottom: i < SUPPORT_STATUS.length - 1 ? '1px solid var(--border-hairline)' : 0,
                }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: s.status === 'ok' ? 'var(--success)' : 'var(--warning)' }}/>
                  <div style={{ flex: 1 }}>
                    <div style={{ font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{s.svc}</div>
                    {s.note && <div className="t-small" style={{ marginTop: 4, color: 'var(--warning-fg)' }}>{s.note}</div>}
                  </div>
                </div>
              ))}
            </div>

            <div className="card" style={{ background: 'var(--surface-subtle)' }}>
              <div className="t-tiny" style={{ marginBottom: 10 }}>Talk to us</div>
              <Btn kind="primary" size="sm" icon={I.Message} style={{ width: '100%', marginBottom: 6 }} onClick={() => setOpenChat(true)}>Start live chat</Btn>
              <Btn kind="ghost" size="sm" icon={I.Mail} style={{ width: '100%' }}>support@aicreators.cloud</Btn>
              <div className="t-small" style={{ marginTop: 8, textAlign: 'center' }}>Median reply · 14 min</div>
            </div>
          </div>
        </div>
      </div>

      {openArticle && <ArticleModal a={openArticle} onClose={() => setOpenArticle(null)}/>}
      {openTicketForm && <NewTicketModal onClose={() => setOpenTicketForm(false)}/>}
      {openChat && <LiveChatPanel onClose={() => setOpenChat(false)}/>}
    </div>
  );
}

function ArticleModal({ a, onClose }) {
  return (
    <Modal open={true} onClose={onClose} width={720}>
      <div style={{ padding: '28px 32px 32px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <span className="chip">{a.cat}</span>
          <span className="t-small">{a.read} read</span>
          <div style={{ flex: 1 }}/>
          <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
        </div>
        <div className="t-h2" style={{ marginBottom: 18, fontSize: 28 }}>{a.title}</div>
        <div style={{ font: '500 15px/1.7 var(--font-sans)', color: 'var(--fg-default)', textWrap: 'pretty' }}>
          {a.body}
        </div>
        <div style={{ marginTop: 18, padding: 14, borderRadius: 12, background: 'var(--surface-subtle)' }}>
          <div className="t-tiny" style={{ marginBottom: 8 }}>Related</div>
          <ul style={{ margin: 0, padding: '0 0 0 18px', font: '500 13px/1.8 var(--font-sans)' }}>
            {SUPPORT_ARTICLES.filter(x => x.cat === a.cat && x.slug !== a.slug).slice(0, 3).map(r => (
              <li key={r.slug}><a href="#" style={{ color: 'var(--brand)' }}>{r.title}</a></li>
            ))}
          </ul>
        </div>
        <div className="divider" style={{ margin: '24px 0 16px' }}/>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <span className="t-small">Was this helpful?</span>
          <div style={{ flex: 1 }}/>
          <Btn kind="ghost" size="sm" icon={I.ThumbUp}>Yes</Btn>
          <Btn kind="ghost" size="sm">No</Btn>
        </div>
      </div>
    </Modal>
  );
}

function NewTicketModal({ onClose }) {
  return (
    <Modal open={true} onClose={onClose} width={560}>
      <div style={{ padding: 26 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
          <span style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', color: 'var(--accent-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <I.Mail size={18}/>
          </span>
          <span className="t-h4">Open a ticket</span>
          <div style={{ flex: 1 }}/>
          <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
        </div>

        <label className="label">What's it about?</label>
        <select>
          <option>Pipeline failed</option>
          <option>Billing question</option>
          <option>Bug report</option>
          <option>Feature request</option>
          <option>Refund</option>
          <option>Other</option>
        </select>

        <label className="label" style={{ marginTop: 14 }}>Subject</label>
        <input placeholder="One line · be specific"/>

        <label className="label" style={{ marginTop: 14 }}>Details</label>
        <textarea rows={6} placeholder="What happened, what you expected, and any logs / screenshots"/>

        <label className="label" style={{ marginTop: 14 }}>Attachments</label>
        <div style={{
          padding: 12, borderRadius: 10,
          border: '1px dashed var(--border-default)',
          background: 'var(--surface-subtle)',
          display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
        }}>
          <I.Upload size={16} stroke="var(--fg-muted)"/>
          <span className="t-small">Drop files (screenshots, logs) — max 20MB each</span>
        </div>

        <div style={{ marginTop: 18, padding: 12, borderRadius: 10, background: 'var(--info-bg)', border: '1px solid var(--info-bd)', display: 'flex', alignItems: 'flex-start', gap: 8 }}>
          <I.Help size={14} stroke="var(--info-fg)" style={{ marginTop: 2 }}/>
          <div className="t-small" style={{ color: 'var(--fg-default)' }}>
            We auto-attach your most recent pipeline logs and your account info. You don't need to repeat it.
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 22 }}>
          <Btn kind="ghost" onClick={onClose}>Cancel</Btn>
          <Btn kind="primary" icon={I.Send}>Send ticket</Btn>
        </div>
      </div>
    </Modal>
  );
}

function LiveChatPanel({ onClose }) {
  return (
    <div style={{
      position: 'fixed', right: 24, bottom: 24, width: 380, maxHeight: 580,
      background: 'var(--bg-surface)', border: '1px solid var(--border-default)',
      borderRadius: 18, boxShadow: 'var(--shadow-modal)',
      display: 'flex', flexDirection: 'column', zIndex: 1100,
      overflow: 'hidden',
    }}>
      <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10, background: 'var(--magic-tint)' }}>
        <span style={{ position: 'relative' }}>
          <Avatar name="Avyal Support" size={36} color="var(--magic-grad)"/>
          <span style={{ position: 'absolute', bottom: 0, right: 0, width: 10, height: 10, borderRadius: '50%', background: 'var(--success)', border: '2px solid var(--bg-surface)' }}/>
        </span>
        <div style={{ flex: 1, lineHeight: 1.2 }}>
          <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>Support</div>
          <div className="t-small" style={{ marginTop: 2 }}>Median reply · 14 min</div>
        </div>
        <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
      </div>

      <div style={{ flex: 1, padding: 14, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <ChatBubble who="agent">Hey 👋 — I'm Priya from support. What's up?</ChatBubble>
        <ChatBubble who="agent">If you want, you can also <a href="#" style={{ color: 'var(--brand)' }}>send us a screenshot</a>.</ChatBubble>
        <div style={{ textAlign: 'center', padding: '6px 0' }}>
          <span className="t-small" style={{ background: 'var(--surface-subtle)', padding: '4px 10px', borderRadius: 999 }}>Today · 2:14 PM</span>
        </div>
      </div>

      <div style={{ padding: 10, borderTop: '1px solid var(--border-hairline)', display: 'flex', gap: 6, alignItems: 'center' }}>
        <button className="btn btn--ghost btn--icon btn--sm"><I.Upload size={14}/></button>
        <input placeholder="Reply…" style={{ flex: 1, height: 36, fontSize: 13 }}/>
        <button className="btn btn--primary btn--icon" style={{ width: 36, height: 36 }}><I.Send size={14}/></button>
      </div>
    </div>
  );
}

function ChatBubble({ who, children }) {
  const isMe = who === 'me';
  return (
    <div style={{
      alignSelf: isMe ? 'flex-end' : 'flex-start',
      maxWidth: '85%',
      padding: '10px 14px',
      borderRadius: isMe ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
      background: isMe ? 'var(--brand)' : 'var(--surface-hover)',
      color: isMe ? 'var(--fg-on-brand)' : 'var(--fg-default)',
      font: '500 13px/1.5 var(--font-sans)',
      textWrap: 'pretty',
    }}>{children}</div>
  );
}

window.HelpSupportScreen = HelpSupportScreen;
