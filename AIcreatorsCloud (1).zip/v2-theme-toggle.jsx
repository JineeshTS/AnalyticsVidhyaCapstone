/* ============================================================
   V2 — Theme toggle widget (light / dark)
   Persists via localStorage. Mount once per page.
   ============================================================ */
function V2ThemeToggle() {
  const [theme, setTheme] = React.useState(() => {
    return localStorage.getItem('aic_v2_theme') || 'v2-dark';
  });

  React.useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('aic_v2_theme', theme);
  }, [theme]);

  return (
    <div className="theme-toggle" role="radiogroup" aria-label="Theme">
      <button
        className={theme === 'v2-light' ? 'active' : ''}
        onClick={() => setTheme('v2-light')}
        aria-label="Light theme"
        title="Light theme"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="4"/>
          <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>
        </svg>
      </button>
      <button
        className={theme === 'v2-dark' ? 'active' : ''}
        onClick={() => setTheme('v2-dark')}
        aria-label="Dark theme"
        title="Dark theme"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
        </svg>
      </button>
    </div>
  );
}

window.V2ThemeToggle = V2ThemeToggle;
