/* ============================================================
   AIcreators.cloud · Admin — Operations deep-dives
   ============================================================

   SCREENS
     AdminJobDetail      – single pipeline job + live logs viewer
     AdminTicketThread   – admin-side ticket conversation w/ canned replies
     AdminCohorts        – cohort/retention analysis
     AdminFlags          – feature flags + experiments

   BACKEND CONTRACTS
     GET    /admin/jobs/{id}
     GET    /admin/jobs/{id}/logs?cursor=
     WS     /admin/jobs/{id}/logs/stream
     POST   /admin/jobs/{id}/retry         {force?: bool}
     POST   /admin/jobs/{id}/cancel
     POST   /admin/jobs/{id}/credit-back   {amount}

     GET    /admin/tickets/{id}
     POST   /admin/tickets/{id}/reply      {body, internal_note?, attachments[]}
     PATCH  /admin/tickets/{id}            {status, assignee, priority, tags}

     GET    /admin/cohorts?cohort_by=signup_month&window=
     GET    /admin/retention?cohort_id=

     GET    /admin/flags
     POST   /admin/flags                   {key, description, rollout_pct}
     PATCH  /admin/flags/{key}             {rollout_pct, targeting_rules}
   ============================================================ */

/* ============================================================
   1.  ADMIN JOB DETAIL — logs viewer
   ============================================================ */
function AdminJobDetail({ jobId, onBack }) {
  const job = ADMIN.jobs.find(j => j.id === jobId) || ADMIN.jobs[3]; // default to failed one
  const logs = [
    { t: '14:02:18.412', lvl: 'info',  msg: 'Job dispatched · queue depth: 12 · worker: voice-prod-3' },
    { t: '14:02:18.518', lvl: 'info',  msg: `Resolving project ${job.project} · user ${job.user}` },
    { t: '14:02:19.044', lvl: 'info',  msg: `Selected model: ${job.model} (default for stage:voice)` },
    { t: '14:02:19.812', lvl: 'info',  msg: 'Loading voice clone artifact · /artifacts/voice_clone/cv1.bin · 24 MB' },
    { t: '14:02:24.118', lvl: 'info',  msg: 'TTS streaming started · expected duration: 11:42 (702s)' },
    { t: '14:02:51.402', lvl: 'info',  msg: 'Chunk 1/12 complete · 58s synthesized · 1.31x realtime' },
    { t: '14:03:18.890', lvl: 'info',  msg: 'Chunk 2/12 complete · 116s synthesized' },
    { t: '14:03:32.114', lvl: 'warn',  msg: 'Provider returned 429 — backing off 2.0s' },
    { t: '14:03:34.118', lvl: 'info',  msg: 'Retry attempt 1/3 — chunk 3' },
    { t: '14:03:38.802', lvl: 'warn',  msg: 'Provider returned 429 — backing off 4.0s' },
    { t: '14:03:42.814', lvl: 'info',  msg: 'Retry attempt 2/3 — chunk 3' },
    { t: '14:03:46.219', lvl: 'error', msg: 'TTS_RATE_LIMIT · provider rejected after 3 retries' },
    { t: '14:03:46.318', lvl: 'error', msg: 'Job failed · marking for retry · billing-back: 4 credits' },
    { t: '14:03:46.388', lvl: 'info',  msg: 'Notification queued: review_needed → mihir@aicreators.cloud' },
  ];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span className="t-small" style={{ cursor: 'pointer' }} onClick={onBack}>Jobs</span>
            <I.ChevRight size={12} stroke="var(--fg-faint)"/>
            <span className="t-mono t-small" style={{ color: 'var(--fg-default)' }}>{job.id}</span>
          </div>
          <div style={{ flex: 1 }}/>
          <JobStatusBadge status={job.status}/>
          {job.status === 'failed' && <Btn kind="primary" icon={I.Refresh}>Retry</Btn>}
          {job.status === 'running' && <Btn kind="danger" icon={I.Close}>Cancel</Btn>}
          <Btn kind="ghost" icon={I.Credit}>Credit back</Btn>
        </div>
        <div className="t-h3">{job.project}</div>
        <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
          <span className="t-small">{job.userName}</span>
          <span style={{ color: 'var(--fg-faint)' }}>·</span>
          <span className="t-small">stage: <strong style={{ color: 'var(--fg-default)' }}>{STAGE_BY_ID[job.stage]?.label || job.stage}</strong></span>
          <span style={{ color: 'var(--fg-faint)' }}>·</span>
          <span className="t-mono t-small">{job.model}</span>
          {job.gpu && job.gpu !== '—' && <>
            <span style={{ color: 'var(--fg-faint)' }}>·</span>
            <span className="t-mono t-small">GPU {job.gpu}</span>
          </>}
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', display: 'grid', gridTemplateColumns: '1fr 340px' }}>
        {/* Logs panel */}
        <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', borderRight: '1px solid var(--border-hairline)' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10, background: 'var(--surface-subtle)' }}>
            <I.Activity size={14} stroke="var(--fg-default)"/>
            <span className="t-h5">Logs</span>
            <span className="chip">{logs.length} lines</span>
            <div style={{ flex: 1 }}/>
            <Tabs value="all" onChange={()=>{}} items={[
              { id: 'all',   label: 'All' },
              { id: 'warn',  label: 'Warn' },
              { id: 'error', label: 'Error' },
            ]}/>
            <Btn kind="ghost" size="sm" icon={I.Download}>Export</Btn>
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0', background: '#0B0C16' }}>
            {logs.map((l, i) => (
              <div key={i} style={{
                padding: '4px 18px',
                font: '500 12px/1.6 var(--font-mono)',
                color: l.lvl === 'error' ? '#F87171' : l.lvl === 'warn' ? '#FBBF24' : '#E5E7F2',
                display: 'flex', gap: 12,
              }}>
                <span style={{ color: '#7E839E', flexShrink: 0 }}>{l.t}</span>
                <span style={{
                  flexShrink: 0, padding: '0 6px', borderRadius: 3, height: 18, display: 'inline-flex', alignItems: 'center',
                  background: l.lvl === 'error' ? 'rgba(248,113,113,0.16)' : l.lvl === 'warn' ? 'rgba(251,191,36,0.16)' : 'rgba(255,255,255,0.04)',
                  color: l.lvl === 'error' ? '#F87171' : l.lvl === 'warn' ? '#FBBF24' : '#9097B5',
                  font: '700 9px/1 var(--font-sans)', letterSpacing: '0.06em', textTransform: 'uppercase',
                }}>{l.lvl}</span>
                <span style={{ whiteSpace: 'pre-wrap' }}>{l.msg}</span>
              </div>
            ))}
            <div style={{ padding: '8px 18px', font: '500 12px/1 var(--font-mono)', color: '#7E839E', display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#7E839E' }} className="sparkle-ping"/>
              <span>Streaming live · WS connected</span>
            </div>
          </div>
        </div>

        {/* Side panel */}
        <div style={{ overflowY: 'auto', padding: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 14 }}>Metadata</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <KV4 k="Job ID"     v={<span className="t-mono">{job.id}</span>}/>
              <KV4 k="Status"     v={<JobStatusBadge status={job.status} size="sm"/>}/>
              <KV4 k="Started"    v={job.startedAt}/>
              <KV4 k="Elapsed"    v={job.elapsed}/>
              <KV4 k="Credits"    v={`${job.credits}`}/>
              <KV4 k="Retries"    v={`${job.retries}`}/>
              {job.errorCode && <KV4 k="Error"      v={<span className="t-mono" style={{ color: 'var(--danger-fg)' }}>{job.errorCode}</span>}/>}
            </div>
          </div>

          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 14 }}>Input artifacts</div>
            <ArtifactRow icon={I.Edit}   name="script_v2.md"          size="11 KB"/>
            <ArtifactRow icon={I.Mic}    name="voice_clone_cv1.bin"   size="24 MB"/>
            <ArtifactRow icon={I.Image}  name="music_bed.wav"          size="6.8 MB"/>
          </div>

          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 14 }}>Recent runs of this job</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <RunRow ts="14:03:46" status="failed" elapsed="00:42"/>
              <RunRow ts="14:01:18" status="failed" elapsed="00:38"/>
              <RunRow ts="13:58:02" status="failed" elapsed="00:34"/>
            </div>
          </div>

          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 10 }}>Quick actions</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <Btn kind="secondary" size="sm" icon={I.Refresh}>Retry with same model</Btn>
              <Btn kind="secondary" size="sm" icon={I.Robot}>Retry with fallback model</Btn>
              <Btn kind="ghost" size="sm" icon={I.User}>Email user</Btn>
              <Btn kind="ghost" size="sm" icon={I.Ticket}>Open ticket</Btn>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function KV4({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span className="t-small">{k}</span>
      <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{v}</span>
    </div>
  );
}

function ArtifactRow({ icon: Ico, name, size }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderTop: '1px solid var(--border-hairline)' }}>
      <Ico size={14} stroke="var(--fg-default)"/>
      <span className="t-mono" style={{ font: '500 12px/1 var(--font-mono)', color: 'var(--fg-default)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
      <span className="t-tiny">{size}</span>
      <button className="btn btn--ghost btn--icon btn--sm" style={{ width: 24, height: 24 }}><I.Download size={11}/></button>
    </div>
  );
}

function RunRow({ ts, status, elapsed }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 0' }}>
      <span className="t-mono t-small">{ts}</span>
      <JobStatusBadge status={status} size="sm"/>
      <span className="t-mono t-small" style={{ marginLeft: 'auto' }}>{elapsed}</span>
    </div>
  );
}

/* ============================================================
   2.  ADMIN TICKET THREAD
   ============================================================ */
function AdminTicketThread({ ticketId, onBack }) {
  const ticket = ADMIN.tickets.find(t => t.id === ticketId) || ADMIN.tickets[0];
  const msgs = [
    { from: 'user', who: 'Hossam K.',     ts: '12 min ago', body: "Hi — every time I try to publish to YouTube, it fails with a 403. The OAuth scope says 'youtube.upload' is granted. Help?" },
    { from: 'agent', who: 'Mihir V', ts: '8 min ago', internal: true, body: "Internal note: looks like his refresh token expired Apr 22 — last successful refresh. Channel ch_005 (Aztec Daily). Going to re-trigger OAuth flow." },
    { from: 'agent', who: 'Mihir V', ts: '7 min ago', body: "Hey Hossam — sorry about that! Your YouTube OAuth refresh token expired about 3 weeks ago. I just emailed you a one-click re-auth link — give it a try and the next publish should work." },
  ];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '20px 28px 16px', borderBottom: '1px solid var(--border-hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <button className="btn btn--ghost btn--icon" onClick={onBack}><I.ChevLeft size={18}/></button>
          <span className="t-small" onClick={onBack} style={{ cursor: 'pointer' }}>Support tickets</span>
          <I.ChevRight size={12} stroke="var(--fg-faint)"/>
          <span className="t-mono t-small">{ticket.id}</span>
          <div style={{ flex: 1 }}/>
          <Btn kind="ghost" size="sm" icon={I.User}>Open as user</Btn>
          <select defaultValue={ticket.priority} style={{ width: 120, height: 36, fontSize: 13 }}>
            <option value="high">High priority</option><option value="medium">Medium</option><option value="low">Low</option>
          </select>
          <select defaultValue={ticket.status} style={{ width: 120, height: 36, fontSize: 13 }}>
            <option value="open">Open</option><option value="waiting">Waiting</option><option value="resolved">Resolved</option><option value="closed">Closed</option>
          </select>
        </div>
        <div className="t-h3">{ticket.subject}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 6 }}>
          <span className="t-small">From <strong style={{ color: 'var(--fg-default)' }}>{ticket.user}</strong></span>
          <span style={{ color: 'var(--fg-faint)' }}>·</span>
          <span className="t-small">Opened {ticket.age}</span>
          <span style={{ color: 'var(--fg-faint)' }}>·</span>
          <span className="chip">YouTube · OAuth</span>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', display: 'grid', gridTemplateColumns: '1fr 320px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ flex: 1, overflowY: 'auto', padding: '24px 32px' }}>
            <div style={{ maxWidth: 760, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 14 }}>
              {msgs.map((m, i) => {
                const isAgent = m.from === 'agent';
                return (
                  <div key={i} style={{ display: 'flex', gap: 12, flexDirection: isAgent ? 'row-reverse' : 'row' }}>
                    <Avatar name={m.who} size={36} color={isAgent ? 'var(--magic-grad)' : 'var(--brand)'}/>
                    <div style={{ maxWidth: '78%' }}>
                      <div style={{ display: 'flex', gap: 8, marginBottom: 4, flexDirection: isAgent ? 'row-reverse' : 'row' }}>
                        <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{m.who}</span>
                        <span className="t-small">{m.ts}</span>
                        {m.internal && <span className="chip chip--warning">internal</span>}
                      </div>
                      <div style={{
                        padding: '12px 14px',
                        borderRadius: isAgent ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                        background: m.internal ? 'var(--warning-bg)' : isAgent ? 'var(--brand)' : 'var(--bg-surface)',
                        border: m.internal ? '1px solid var(--warning-bd)' : isAgent ? 0 : '1px solid var(--border-hairline)',
                        color: m.internal ? 'var(--warning-fg)' : isAgent ? 'var(--fg-on-brand)' : 'var(--fg-default)',
                        font: '500 14px/1.55 var(--font-sans)',
                        textWrap: 'pretty',
                      }}>{m.body}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div style={{ padding: 16, borderTop: '1px solid var(--border-hairline)', background: 'var(--surface-subtle)' }}>
            <div style={{ maxWidth: 760, margin: '0 auto' }}>
              <div style={{ display: 'flex', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
                <span className="t-tiny">Canned replies:</span>
                {['OAuth re-auth', 'Refund flow', 'Voice clone unsupported', 'Plan downgrade', 'Bug report received'].map(c => (
                  <span key={c} className="chip" style={{ height: 22, fontSize: 11, cursor: 'pointer' }}>{c}</span>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <textarea rows={2} placeholder="Reply… (markdown supported)" style={{ flex: 1 }}/>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <Btn kind="ghost" size="sm">Internal note</Btn>
                  <Btn kind="primary" size="sm" icon={I.Send}>Reply</Btn>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Context rail */}
        <div style={{ overflowY: 'auto', padding: 18, borderLeft: '1px solid var(--border-hairline)', display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 10 }}>Customer</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Avatar name={ticket.user} size={40}/>
              <div>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{ticket.user}</div>
                <div className="t-small">u_006 · Studio Pro</div>
              </div>
            </div>
            <div className="divider" style={{ margin: '14px 0' }}/>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <KV4 k="Joined"        v="Dec 2024"/>
              <KV4 k="Lifetime spend" v="$890"/>
              <KV4 k="Open tickets"  v="2"/>
              <KV4 k="Last seen"     v="14 min ago"/>
            </div>
            <Btn kind="ghost" size="sm" icon={I.Eye} style={{ width: '100%', marginTop: 12 }}>Open user</Btn>
          </div>

          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 10 }}>Linked job</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--danger-bg)', color: 'var(--danger)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <I.Pipeline size={14}/>
              </span>
              <div style={{ minWidth: 0 }}>
                <div className="t-mono" style={{ font: '600 12px/1.2 var(--font-mono)', color: 'var(--fg-strong)' }}>j_8424</div>
                <div className="t-small" style={{ marginTop: 4 }}>Voice stage · failed · TTS_RATE_LIMIT</div>
              </div>
            </div>
            <Btn kind="ghost" size="sm" style={{ width: '100%', marginTop: 10 }}>Open job</Btn>
          </div>

          <div className="card">
            <div className="t-tiny" style={{ marginBottom: 10 }}>Activity</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                'Ticket opened · 12 min ago',
                'Assigned to Mihir V · 11 min ago',
                'Internal note added · 8 min ago',
                'Reply sent · 7 min ago',
              ].map((a, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
                  <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0, marginTop: 6 }}/>
                  <span className="t-small">{a}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   3.  ADMIN COHORTS / RETENTION
   ============================================================ */
function AdminCohorts() {
  // Cohort retention heatmap: rows = signup month, cols = N months after
  const months = ['Sep 24','Oct 24','Nov 24','Dec 24','Jan 25','Feb 25','Mar 25','Apr 25','May 25'];
  // Each row has retention % at month 0..N
  const data = [
    [100, 78, 64, 58, 52, 49, 47, 45, 44],
    [100, 80, 67, 60, 55, 52, 50, 48, null],
    [100, 82, 70, 64, 58, 55, 53, null, null],
    [100, 85, 72, 67, 61, 58, null, null, null],
    [100, 86, 75, 69, 64, null, null, null, null],
    [100, 88, 78, 71, null, null, null, null, null],
    [100, 88, 80, null, null, null, null, null, null],
    [100, 90, null, null, null, null, null, null, null],
    [100, null, null, null, null, null, null, null, null],
  ];
  const cohortSize = ['184','212','244','268','312','356','402','488','536'];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Cohorts & retention</div>
            <div className="t-small" style={{ marginTop: 4 }}>How many users from each signup month are still active N months later</div>
          </div>
          <Tabs value="signup" onChange={()=>{}} items={[
            { id: 'signup',   label: 'By signup month' },
            { id: 'plan',     label: 'By plan' },
            { id: 'cohort',   label: 'By acquisition channel' },
          ]}/>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          <AdminStat label="M1 retention"  value="87.2%" delta="+2.4pp" trend="up" icon={I.User}/>
          <AdminStat label="M3 retention"  value="71.4%" delta="+4.1pp" trend="up" icon={I.User}/>
          <AdminStat label="M6 retention"  value="56.8%" delta="+1.8pp" trend="up" icon={I.User}/>
          <AdminStat label="LTV (12mo)"     value="$844"  delta="+12%"   trend="up" icon={I.Credit}/>
        </div>

        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
            <span className="t-h5">Retention heatmap</span>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
              <thead>
                <tr style={{ background: 'var(--surface-subtle)' }}>
                  <th style={{ padding: '10px 14px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase' }}>Signup month</th>
                  <th style={{ padding: '10px 14px', textAlign: 'right', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase' }}>Size</th>
                  {months.map((_, i) => (
                    <th key={i} style={{ padding: '10px 0', textAlign: 'center', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase' }}>M{i}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map((row, i) => (
                  <tr key={i} style={{ borderTop: '1px solid var(--border-hairline)' }}>
                    <td style={{ padding: '8px 14px', font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{months[i]}</td>
                    <td style={{ padding: '8px 14px', textAlign: 'right' }} className="t-mono t-small">{cohortSize[i]}</td>
                    {row.map((v, j) => (
                      <td key={j} style={{ padding: 4, textAlign: 'center' }}>
                        {v == null ? <span style={{ color: 'var(--fg-faint)' }}>—</span> : (
                          <span style={{
                            display: 'inline-block', width: 56, padding: '6px 0', borderRadius: 4,
                            background: `rgba(6, 78, 59, ${0.04 + (v / 100) * 0.72})`,
                            font: '600 12px/1 var(--font-sans)',
                            color: v > 50 ? 'white' : 'var(--fg-strong)',
                          }}>{v}%</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   4.  ADMIN FEATURE FLAGS
   ============================================================ */
function AdminFlags() {
  const flags = [
    { key: 'beta_imagine_5',        label: 'Imagine v5 (beta)',                 desc: 'New T2I model with better identity locks',     rollout: 12,  targeting: 'paid only', enabled: true,  exp: { winner: 'B', uplift: '+6.4% CTR' } },
    { key: 'multi_platform_publish', label: 'Multi-platform publishing',         desc: 'Cross-post to Instagram, TikTok, X simultaneously', rollout: 100, targeting: 'all users', enabled: true },
    { key: 'voice_clone_hindi',      label: 'Voice clone · Hindi',               desc: 'Hindi-language voice cloning model',           rollout: 38,  targeting: 'IN region', enabled: true },
    { key: 'autopilot_v3',           label: 'Autopilot v3 (always-on review)',  desc: 'New default: pause for review at confidence < 80', rollout: 4, targeting: '5% sample', enabled: true,  exp: { winner: 'control', uplift: 'no signal yet' } },
    { key: 'lipsync_realtime',       label: 'Real-time lip sync',                desc: 'Sub-second lip sync rendering',                rollout: 0,    targeting: 'internal',  enabled: false },
    { key: 'creator_marketplace',    label: 'Creator marketplace',               desc: 'Buy/sell voices, avatars, visual styles',      rollout: 0,    targeting: 'closed',    enabled: false },
    { key: 'discord_bot',            label: 'Discord bot publishing',            desc: 'Auto-post announcements to Discord on publish', rollout: 100, targeting: 'all users', enabled: true },
    { key: 'web3_provenance',        label: 'Provenance signatures (C2PA)',     desc: 'Embed AI-generated provenance metadata',       rollout: 100, targeting: 'all users', enabled: true },
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Feature flags & experiments</div>
            <div className="t-small" style={{ marginTop: 4 }}>Roll out features gradually · run A/B experiments · target by plan / region / cohort</div>
          </div>
          <Btn kind="primary" icon={I.Plus}>New flag</Btn>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {flags.map(f => (
            <div key={f.key} className="card" style={{ display: 'grid', gridTemplateColumns: '8px 1fr auto', gap: 14, alignItems: 'center' }}>
              <HealthDot status={f.enabled ? 'ok' : 'down'}/>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{f.label}</span>
                  <span className="t-mono" style={{ font: '500 11px/1 var(--font-mono)', color: 'var(--fg-muted)', padding: '3px 6px', background: 'var(--surface-hover)', borderRadius: 4, border: '1px solid var(--border-hairline)' }}>{f.key}</span>
                  {f.exp && <span className="chip chip--magic"><I.Sparkles size={11}/> Experiment</span>}
                </div>
                <div className="t-small" style={{ marginTop: 6 }}>{f.desc}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 10 }}>
                  <div style={{ width: 200 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span className="t-tiny">Rollout</span>
                      <span style={{ font: '600 12px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{f.rollout}%</span>
                    </div>
                    <ProgressBar value={f.rollout} size="sm"/>
                  </div>
                  <span className="chip" style={{ height: 24, fontSize: 11 }}>{f.targeting}</span>
                  {f.exp && (
                    <span className="chip chip--success" style={{ height: 24, fontSize: 11 }}>
                      Winner: {f.exp.winner} · {f.exp.uplift}
                    </span>
                  )}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Switch on={f.enabled} onChange={()=>{}}/>
                <button className="btn btn--ghost btn--icon btn--sm"><I.Edit size={12}/></button>
                <button className="btn btn--ghost btn--icon btn--sm"><I.More size={12}/></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  AdminJobDetail, AdminTicketThread, AdminCohorts, AdminFlags,
});
