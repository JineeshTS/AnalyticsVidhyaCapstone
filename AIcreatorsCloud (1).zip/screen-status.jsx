/* ============================================================
   AIcreators.cloud · Public Status Page
   ============================================================
   PURPOSE
     Public-facing system status. Marketing-grade page that
     embeds incident history + per-service uptime. Lives at
     status.aicreators.cloud.

   BACKEND
     GET /public/status            – cached snapshot
     GET /public/status/incidents  – last 60 days
     GET /public/status/uptime?days=90
     POST /public/status/subscribe {email, channels[]}

   This is intentionally a STANDALONE entry — no app shell, no
   user auth. Anyone can load it.
   ============================================================ */

const STATUS_SERVICES = [
  { svc: 'Web app',                  ok: true,  uptime: 99.98 },
  { svc: 'API',                      ok: true,  uptime: 99.96 },
  { svc: 'Pipeline · Script (LLM)',  ok: true,  uptime: 99.92 },
  { svc: 'Pipeline · Keyframes',     ok: 'warn',uptime: 99.62, note: 'Slight queue lag — 12 min p95' },
  { svc: 'Pipeline · Image-to-video',ok: true,  uptime: 99.88 },
  { svc: 'Pipeline · Voice / TTS',   ok: true,  uptime: 99.94 },
  { svc: 'Pipeline · Voice cloning', ok: true,  uptime: 99.90 },
  { svc: 'Pipeline · Lip sync',      ok: true,  uptime: 99.86 },
  { svc: 'Pipeline · Render',        ok: true,  uptime: 99.94 },
  { svc: 'YouTube publisher',        ok: true,  uptime: 99.84 },
  { svc: 'Instagram publisher',      ok: true,  uptime: 99.78 },
  { svc: 'TikTok publisher',         ok: true,  uptime: 99.82 },
  { svc: 'Auth & sessions',          ok: true,  uptime: 100.0 },
];

const STATUS_INCIDENTS = [
  { date: 'May 16, 2025', t: '11:42 → 13:08', severity: 'minor', title: 'Keyframes queue lag', body: 'GPU node A100-W4 hit an NCCL timeout. We rolled traffic to other regions; resolved in 1h 26m.' },
  { date: 'May 04, 2025', t: '02:14 → 02:38', severity: 'minor', title: 'YouTube API timeouts',  body: 'Upstream YouTube Data API had elevated latency. We added retries with backoff; no failed uploads.' },
  { date: 'Apr 22, 2025', t: '18:00 → 18:42', severity: 'major', title: 'Instagram publisher down', body: 'Meta rotated OAuth scopes without warning. We restored within 42 min by adding the new scope.' },
];

// 90-day uptime grid mock: 90 cells per service
function makeUptime(seed) {
  const arr = Array.from({ length: 90 }, (_, i) => {
    const r = Math.abs(Math.sin((seed + i) * 9.7));
    if (r > 0.985) return 'down';
    if (r > 0.96)  return 'degraded';
    return 'ok';
  });
  return arr;
}

function StatusApp() {
  const allOk = STATUS_SERVICES.every(s => s.ok === true);

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg-app)' }}>
      <SparkleField count={12} intensity={0.25}/>

      {/* Top nav */}
      <header style={{ padding: '20px 32px', display: 'flex', alignItems: 'center', borderBottom: '1px solid var(--border-hairline)', position: 'relative', zIndex: 2 }}>
        <a href="AIcreators Cloud.html" style={{ textDecoration: 'none', display: 'inline-flex' }}>
          <LogoLockup markSize={32} wordSize={17}/>
        </a>
        <span style={{ marginLeft: 10, padding: '4px 10px', borderRadius: 999, background: 'var(--surface-hover)', font: '600 11px/1 var(--font-sans)', color: 'var(--fg-muted)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>Status</span>
        <div style={{ flex: 1 }}/>
        <a href="AIcreators Cloud.html" className="t-small" style={{ color: 'var(--brand)', marginRight: 16 }}>Back to studio</a>
        <Btn kind="ghost" size="sm" icon={I.Bell}>Subscribe to updates</Btn>
      </header>

      <div style={{ flex: 1, padding: '40px 32px', maxWidth: 1080, margin: '0 auto', width: '100%', position: 'relative', zIndex: 1 }}>

        {/* Hero banner */}
        <div className="card" style={{
          padding: 28, marginBottom: 28,
          background: allOk ? 'var(--success-bg)' : 'var(--warning-bg)',
          border: `1px solid ${allOk ? 'var(--success-bd)' : 'var(--warning-bd)'}`,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <span style={{
              width: 56, height: 56, borderRadius: 16,
              background: allOk ? 'var(--success)' : 'var(--warning)',
              color: 'white',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: `0 6px 18px ${allOk ? 'rgba(16,185,129,0.4)' : 'rgba(251,191,36,0.4)'}`,
            }}>
              {allOk ? <I.Check size={28}/> : <I.Warn size={28}/>}
            </span>
            <div style={{ flex: 1 }}>
              <div className="t-h2" style={{ fontSize: 26, marginBottom: 4 }}>
                {allOk ? 'All systems operational' : 'Minor issue · keyframes queue'}
              </div>
              <div className="t-small">Last updated 14 seconds ago · auto-refreshing every 30s</div>
            </div>
          </div>
        </div>

        {/* Services */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 14 }}>
          <span className="t-h4">Service status</span>
          <span className="t-small">90-day uptime per service</span>
        </div>

        <div className="card" style={{ padding: 0 }}>
          {STATUS_SERVICES.map((s, i) => {
            const days = makeUptime(i + 1);
            return (
              <div key={s.svc} style={{
                padding: '14px 20px',
                borderBottom: i < STATUS_SERVICES.length - 1 ? '1px solid var(--border-hairline)' : 0,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                  <HealthDot status={s.ok === true ? 'ok' : 'warn'}/>
                  <span style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)', flex: 1 }}>{s.svc}</span>
                  <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{s.uptime}% uptime</span>
                </div>
                <div style={{ display: 'flex', gap: 2, height: 28 }}>
                  {days.map((d, j) => (
                    <div key={j} title={`Day ${j + 1}: ${d}`} style={{
                      flex: 1,
                      background: d === 'ok' ? 'var(--success)' : d === 'degraded' ? 'var(--warning)' : 'var(--danger)',
                      borderRadius: 2,
                      opacity: 0.85,
                    }}/>
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
                  <span className="t-tiny">90 days ago</span>
                  <span className="t-tiny">Today</span>
                </div>
                {s.note && <div className="t-small" style={{ marginTop: 8, color: 'var(--warning-fg)' }}>{s.note}</div>}
              </div>
            );
          })}
        </div>

        {/* Incidents */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 36, marginBottom: 14 }}>
          <span className="t-h4">Past incidents</span>
          <span className="t-small">Last 60 days</span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {STATUS_INCIDENTS.map((inc, i) => (
            <div key={i} className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                {inc.severity === 'major' && <span className="chip chip--danger">Major incident</span>}
                {inc.severity === 'minor' && <span className="chip chip--warning">Minor incident</span>}
                <span className="t-small">{inc.date} · {inc.t}</span>
              </div>
              <div className="t-h5" style={{ marginBottom: 6 }}>{inc.title}</div>
              <div className="t-body" style={{ color: 'var(--fg-secondary)', textWrap: 'pretty' }}>{inc.body}</div>
            </div>
          ))}
        </div>

        {/* Subscribe */}
        <div className="card" style={{ marginTop: 36, padding: 24, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)' }}>
          <div className="t-h4" style={{ marginBottom: 6 }}>Get notified about incidents</div>
          <div className="t-small" style={{ marginBottom: 16 }}>Pick how — email, Slack, RSS, webhook. We only ping you when it matters.</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input placeholder="you@studio.com" style={{ flex: 1, background: 'var(--bg-surface)' }}/>
            <Btn kind="primary" icon={I.Bell}>Subscribe</Btn>
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
            <Btn kind="ghost" size="sm" icon={I.Message}>Slack</Btn>
            <Btn kind="ghost" size="sm" icon={I.Globe}>RSS</Btn>
            <Btn kind="ghost" size="sm" icon={I.Code}>Webhook</Btn>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer style={{ padding: '20px 32px', borderTop: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 16, position: 'relative', zIndex: 1 }}>
        <span className="t-small">© 2026 AIcreators.cloud</span>
        <div style={{ flex: 1 }}/>
        <a href="AIcreators Cloud.html" className="t-small">Studio</a>
        <a href="#" className="t-small">API docs</a>
        <a href="#" className="t-small">Terms</a>
        <a href="#" className="t-small">Privacy</a>
      </footer>
    </div>
  );
}

/* HealthDot helper (local if not imported) */
if (typeof window.HealthDot === 'undefined') {
  window.HealthDot = function HealthDot({ status }) {
    const color = { ok: 'var(--success)', warn: 'var(--warning)', down: 'var(--danger)' }[status] || 'var(--fg-muted)';
    return <span style={{ width: 8, height: 8, borderRadius: '50%', background: color, boxShadow: `0 0 6px ${color}` }}/>;
  };
}

ReactDOM.createRoot(document.getElementById('root')).render(<StatusApp/>);
