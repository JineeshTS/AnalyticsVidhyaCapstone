/* ============================================================
   AIcreators.cloud · Admin — Developer & Comms
   ============================================================

   SCREENS in this file
     AdminAPIKeys      – issue & revoke API keys per user / org
     AdminWebhooks     – outgoing webhook endpoints
     AdminEmailTemplates – transactional email templates
     AdminRefunds      – refund request queue
     AdminAuthLog      – sign-in attempts + suspicious activity

   BACKEND
     GET    /admin/api-keys?user_id=
     POST   /admin/api-keys                 {user_id, label, scopes[]}
     DELETE /admin/api-keys/{id}
     GET    /admin/webhooks
     POST   /admin/webhooks                 {url, events[], secret}
     PATCH  /admin/webhooks/{id}            {enabled?}
     POST   /admin/webhooks/{id}/test
     GET    /admin/email-templates
     PATCH  /admin/email-templates/{key}    {subject_md, body_md, enabled}
     POST   /admin/email-templates/{key}/test  {to}
     GET    /admin/refunds?status=
     POST   /admin/refunds/{id}/approve     {amount?, reason}
     POST   /admin/refunds/{id}/reject      {reason}
     GET    /admin/auth-log?user_id=&cursor=
   ============================================================ */

const ADMIN_API_KEYS = [
  { id: 'k_001', label: 'Production · Priya Studio',    user: 'u_002', userName: 'Priya Shah',     prefix: 'aic_live_8a4Bk2…',  scopes: ['videos:write','channels:read','analytics:read'], lastUsed: '4 min ago',  createdAt: '2024-12-01' },
  { id: 'k_002', label: 'Webhook receiver · Mythic',     user: 'u_001', userName: 'Mihir Vaishnav', prefix: 'aic_live_QzKx9R…',  scopes: ['webhooks:receive'], lastUsed: '1 h ago',   createdAt: '2025-02-14' },
  { id: 'k_003', label: 'Zapier integration',            user: 'u_010', userName: 'Carlos Ruiz',    prefix: 'aic_live_p3MnY7…',  scopes: ['videos:read','topics:write'], lastUsed: '12 h ago', createdAt: '2025-03-22' },
  { id: 'k_004', label: 'CI / GitHub Actions',           user: 'u_002', userName: 'Priya Shah',     prefix: 'aic_test_z82Fjs…',  scopes: ['*'], lastUsed: 'never',     createdAt: '2025-05-01' },
];

const ADMIN_WEBHOOKS = [
  { id: 'wh_001', url: 'https://api.priya-studio.co/aic-events', events: ['video.published','job.failed'], status: 'ok',    deliveries: 1284, fails: 12 },
  { id: 'wh_002', url: 'https://hook.zapier.com/hooks/...3jKx9',   events: ['topic.queued','video.published'], status: 'ok', deliveries: 412,  fails: 4 },
  { id: 'wh_003', url: 'https://aztec-daily.io/webhooks/aic',      events: ['video.published'], status: 'failing', deliveries: 88,   fails: 22, note: '5 consecutive 502s' },
];

const ADMIN_EMAIL_TEMPLATES = [
  { key: 'welcome',            label: 'Welcome (post sign-up)', subject: 'Welcome to AIcreators 👋', updated: 'May 02', sent30d: '2,184' },
  { key: 'verify_email',       label: 'Verify your email',       subject: 'Verify your AIcreators email', updated: 'Apr 18', sent30d: '2,184' },
  { key: 'magic_link',         label: 'Magic sign-in link',       subject: 'Your sign-in link', updated: 'Apr 18', sent30d: '5,440' },
  { key: 'reset_password',     label: 'Password reset',           subject: 'Reset your password', updated: 'Apr 18', sent30d: '128' },
  { key: 'review_needed',      label: 'A video needs your review', subject: '{{project_title}} is ready to review', updated: 'May 04', sent30d: '948' },
  { key: 'video_published',    label: 'Video published',          subject: 'Your video is live on YouTube', updated: 'May 04', sent30d: '6,420' },
  { key: 'plan_renewal',       label: 'Plan renews soon',         subject: 'Your Studio Pro renews in 7 days', updated: 'Mar 12', sent30d: '912' },
  { key: 'low_credits',        label: 'Low credits warning',      subject: 'You\'re running low on credits', updated: 'Mar 12', sent30d: '218' },
  { key: 'weekly_digest',      label: 'Weekly performance digest', subject: 'Your channels last week', updated: 'May 10', sent30d: '8,840' },
  { key: 'oauth_disconnected', label: 'YouTube disconnected',     subject: 'Re-connect your YouTube account', updated: 'Apr 22', sent30d: '14' },
];

const ADMIN_REFUNDS = [
  { id: 'r_001', user: 'u_004', userName: 'Lila Becker',    plan: 'Starter',   amount: '$29',   reason: 'Pipeline failed twice, video never shipped',     filed: '2 h ago',  status: 'pending' },
  { id: 'r_002', user: 'u_007', userName: 'Sofia Costa',    plan: 'Starter',   amount: '$29',   reason: 'Charged after I cancelled',                       filed: '8 h ago',  status: 'pending' },
  { id: 'r_003', user: 'u_005', userName: 'Akira Watanabe', plan: 'Studio Pro',amount: '$89',   reason: 'Voice clone language unsupported',                filed: '1 day',    status: 'approved', resolvedBy: 'Mihir V' },
  { id: 'r_004', user: 'u_006', userName: 'Hossam K.',       plan: 'Studio Pro', amount: '$45 (partial)', reason: 'Half a month — already used credits', filed: '2 days', status: 'approved', resolvedBy: 'Priya R' },
];

function AdminAPIKeys() {
  const [openIssue, setOpenIssue] = React.useState(false);
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">API keys</div>
            <div className="t-small" style={{ marginTop: 4 }}>Per-user developer keys. Customer-issued via Settings → API; you can also issue / revoke here.</div>
          </div>
          <Btn kind="primary" icon={I.Plus} onClick={() => setOpenIssue(true)}>Issue key</Btn>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          <AdminStat label="Active keys"        value={String(ADMIN_API_KEYS.length)} icon={I.Key}/>
          <AdminStat label="API calls (24h)"    value="42.8k"   delta="+12%" trend="up" icon={I.Code}/>
          <AdminStat label="Error rate (24h)"   value="0.18%"   delta="-0.04%" trend="down" icon={I.Help}/>
          <AdminStat label="Top consumer"        value="Priya Shah" sub="38.4% of all calls" icon={I.User}/>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Label','User','Key prefix','Scopes','Last used','Created',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ADMIN_API_KEYS.map(k => (
                <tr key={k.id} style={{ borderBottom: '1px solid var(--border-hairline)' }}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{k.label}</div>
                    <div className="t-mono t-small">{k.id}</div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{k.userName}</div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span className="t-mono" style={{ font: '500 12px/1 var(--font-mono)', color: 'var(--fg-default)', padding: '4px 8px', background: 'var(--surface-hover)', borderRadius: 6, border: '1px solid var(--border-hairline)' }}>{k.prefix}</span>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', maxWidth: 280 }}>
                      {k.scopes.map(s => <span key={s} className="chip" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>{s}</span>)}
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{k.lastUsed}</td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{k.createdAt}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button className="btn btn--ghost btn--icon btn--sm" title="Copy"><I.Copy size={12}/></button>
                    <button className="btn btn--ghost btn--icon btn--sm" title="Revoke"><I.Trash size={12}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Webhooks */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 28, marginBottom: 12 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h4">Outgoing webhooks</div>
            <div className="t-small" style={{ marginTop: 4 }}>Endpoints customers have registered to receive events</div>
          </div>
          <Btn kind="secondary" icon={I.Plus}>Add webhook</Btn>
        </div>

        <div className="card" style={{ padding: 0 }}>
          {ADMIN_WEBHOOKS.map((w, i) => (
            <div key={w.id} style={{
              padding: '14px 18px',
              borderBottom: i < ADMIN_WEBHOOKS.length - 1 ? '1px solid var(--border-hairline)' : 0,
              display: 'grid', gridTemplateColumns: '8px 1fr auto auto', gap: 14, alignItems: 'center',
            }}>
              <HealthDot status={w.status === 'ok' ? 'ok' : 'warn'}/>
              <div style={{ minWidth: 0 }}>
                <div className="t-mono" style={{ font: '600 13px/1.2 var(--font-mono)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{w.url}</div>
                <div style={{ display: 'flex', gap: 4, marginTop: 6, flexWrap: 'wrap' }}>
                  {w.events.map(e => <span key={e} className="chip" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>{e}</span>)}
                </div>
                {w.note && <div className="t-small" style={{ marginTop: 4, color: 'var(--warning-fg)' }}>{w.note}</div>}
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="t-tiny">Deliveries</div>
                <div className="t-mono" style={{ font: '600 13px/1 var(--font-mono)', color: 'var(--fg-strong)', marginTop: 4 }}>{w.deliveries.toLocaleString()}</div>
                <div className="t-small" style={{ marginTop: 4, color: w.fails > 20 ? 'var(--warning-fg)' : 'var(--fg-muted)' }}>{w.fails} failed</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <Btn kind="ghost" size="sm">Replay</Btn>
                <Btn kind="ghost" size="sm" icon={I.Lightning}>Test</Btn>
                <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {openIssue && (
        <Modal open={true} onClose={() => setOpenIssue(false)} width={480}>
          <div style={{ padding: 24 }}>
            <div className="t-h4" style={{ marginBottom: 18 }}>Issue an API key</div>
            <label className="label">User</label>
            <select><option>Priya Shah · u_002</option><option>Mihir Vaishnav · u_001</option></select>
            <label className="label" style={{ marginTop: 14 }}>Label</label>
            <input placeholder="What is this key for?"/>
            <label className="label" style={{ marginTop: 14 }}>Scopes</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {['videos:read','videos:write','channels:read','channels:write','topics:read','topics:write','analytics:read','webhooks:receive'].map(s => (
                <label key={s} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: 'var(--surface-subtle)', borderRadius: 8, cursor: 'pointer' }}>
                  <input type="checkbox" style={{ width: 14, height: 14, accentColor: 'var(--brand)' }}/>
                  <span className="t-mono t-small" style={{ color: 'var(--fg-default)' }}>{s}</span>
                </label>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 22 }}>
              <Btn kind="ghost" onClick={() => setOpenIssue(false)}>Cancel</Btn>
              <Btn kind="primary" icon={I.Key}>Issue key</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function AdminEmailTemplates() {
  const [open, setOpen] = React.useState(null);
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Email templates</div>
            <div className="t-small" style={{ marginTop: 4 }}>Transactional email. Edit subject + body in Markdown. Variables: {'{{user_name}}, {{project_title}}, {{channel_name}}, …'}</div>
          </div>
          <Btn kind="secondary" icon={I.Mail}>Send test</Btn>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--surface-subtle)' }}>
                {['Template','Subject preview','Sent (30d)','Updated',''].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', font: '700 11px/1 var(--font-sans)', letterSpacing: '0.06em', color: 'var(--fg-faint)', textTransform: 'uppercase', borderBottom: '1px solid var(--border-hairline)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ADMIN_EMAIL_TEMPLATES.map(t => (
                <tr key={t.key} onClick={() => setOpen(t)} style={{ borderBottom: '1px solid var(--border-hairline)', cursor: 'pointer' }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--brand-soft-bg)', color: 'var(--brand-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <I.Mail size={16}/>
                      </span>
                      <div>
                        <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{t.label}</div>
                        <div className="t-mono t-small">{t.key}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ font: '500 13px/1.3 var(--font-sans)', color: 'var(--fg-default)' }}>{t.subject}</span>
                  </td>
                  <td style={{ padding: '12px 16px' }} className="t-mono t-small">{t.sent30d}</td>
                  <td style={{ padding: '12px 16px' }} className="t-small">{t.updated}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button onClick={e=>e.stopPropagation()} className="btn btn--ghost btn--icon btn--sm" title="Edit"><I.Edit size={12}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {open && (
        <Modal open={true} onClose={() => setOpen(null)} width={720}>
          <div style={{ padding: '20px 24px 24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
              <I.Mail size={20} stroke="var(--brand)"/>
              <span className="t-h4">{open.label}</span>
              <span className="t-mono t-small">{open.key}</span>
              <div style={{ flex: 1 }}/>
              <button className="btn btn--ghost btn--icon btn--sm" onClick={() => setOpen(null)}><I.Close size={14}/></button>
            </div>
            <label className="label">Subject</label>
            <input defaultValue={open.subject}/>
            <label className="label" style={{ marginTop: 14 }}>Body (Markdown · Liquid variables)</label>
            <textarea rows={10} defaultValue={`Hi {{user_name}},\n\nYour video **{{project_title}}** is ready to review on {{channel_name}}.\n\nClick here to approve or re-roll any stage:\n{{review_url}}\n\n— The AIcreators studio team`}/>

            <div style={{ marginTop: 14, padding: 12, borderRadius: 10, background: 'var(--info-bg)', border: '1px solid var(--info-bd)' }}>
              <div className="t-tiny" style={{ marginBottom: 6 }}>Available variables</div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {['{{user_name}}','{{user_email}}','{{project_title}}','{{channel_name}}','{{review_url}}','{{credits_remaining}}','{{plan_name}}'].map(v => (
                  <span key={v} className="t-mono" style={{ font: '500 11px/1 var(--font-mono)', color: 'var(--info-fg)', padding: '4px 8px', background: 'var(--bg-surface)', borderRadius: 6 }}>{v}</span>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 22 }}>
              <Btn kind="ghost" onClick={() => setOpen(null)}>Cancel</Btn>
              <Btn kind="secondary" icon={I.Send}>Send test</Btn>
              <Btn kind="primary" icon={I.Check}>Save</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function AdminRefunds() {
  const pending  = ADMIN_REFUNDS.filter(r => r.status === 'pending');
  const resolved = ADMIN_REFUNDS.filter(r => r.status !== 'pending');
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1560, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1 }}>
            <div className="t-h3">Refunds</div>
            <div className="t-small" style={{ marginTop: 4 }}>{pending.length} pending · {resolved.length} resolved this month</div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
          <AdminStat label="Pending requests" value={String(pending.length)} icon={I.Hourglass}/>
          <AdminStat label="Approved (30d)"   value="$184" delta="-22%" trend="down" icon={I.Check}/>
          <AdminStat label="Rejected (30d)"   value="$58"  delta="+12%" trend="up" icon={I.Close}/>
          <AdminStat label="Avg time to resolve" value="9 h" delta="-3h" trend="down" icon={I.Clock}/>
        </div>

        <div className="t-h5" style={{ marginBottom: 10 }}>Pending</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 28 }}>
          {pending.map(r => (
            <div key={r.id} className="card" style={{ display: 'grid', gridTemplateColumns: '40px 1fr auto auto', gap: 16, alignItems: 'center' }}>
              <Avatar name={r.userName} size={40}/>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ font: '600 14px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{r.userName}</span>
                  <span className="chip">{r.plan}</span>
                  <span className="chip chip--warning">{r.amount}</span>
                </div>
                <div className="t-small" style={{ marginTop: 6, textWrap: 'pretty' }}>"{r.reason}"</div>
                <div className="t-small" style={{ marginTop: 4, color: 'var(--fg-faint)' }}>Filed {r.filed} · {r.id}</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <Btn kind="primary" size="sm" icon={I.Check}>Approve</Btn>
                <Btn kind="danger" size="sm" icon={I.Close}>Reject</Btn>
              </div>
              <button className="btn btn--ghost btn--icon btn--sm"><I.More size={14}/></button>
            </div>
          ))}
        </div>

        <div className="t-h5" style={{ marginBottom: 10 }}>Resolved · this month</div>
        <div className="card" style={{ padding: 0 }}>
          {resolved.map((r, i) => (
            <div key={r.id} style={{
              padding: '12px 18px',
              borderBottom: i < resolved.length - 1 ? '1px solid var(--border-hairline)' : 0,
              display: 'grid', gridTemplateColumns: '32px 1fr 100px 80px 140px', gap: 14, alignItems: 'center',
            }}>
              <Avatar name={r.userName} size={32}/>
              <div>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{r.userName}</div>
                <div className="t-small" style={{ marginTop: 4 }}>"{r.reason}"</div>
              </div>
              <span style={{ font: '600 13px/1 var(--font-sans)', color: 'var(--fg-strong)' }}>{r.amount}</span>
              {r.status === 'approved' && <span className="chip chip--success"><I.Check size={10}/> Approved</span>}
              {r.status === 'rejected' && <span className="chip chip--danger"><I.Close size={10}/> Rejected</span>}
              <span className="t-small">by {r.resolvedBy} · {r.filed}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.AdminAPIKeys = AdminAPIKeys;
window.AdminEmailTemplates = AdminEmailTemplates;
window.AdminRefunds = AdminRefunds;
