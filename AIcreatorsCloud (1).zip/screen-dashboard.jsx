/* ============================================================
   AIcreators.cloud — Production Line (Dashboard)
   The centerpiece: every video flowing through 8 stages.
   ============================================================ */

function StageBadge({ stage, state, size = 'md' }) {
  const palette = {
    todo:    { bg: 'var(--surface-hover)', bd:'var(--border-default)',   fg:'var(--fg-faint)' },
    queued:  { bg: 'var(--surface-hover)', bd:'var(--border-default)',   fg:'var(--fg-muted)' },
    running: { bg:'var(--accent-tint-3)',  bd:'var(--accent-border)',  fg:'var(--accent-fg)' },
    review:  { bg:'var(--warning-bg)',  bd:'var(--warning-bd)',   fg:'var(--warning)' },
    done:    { bg:'var(--success-bg)',  bd:'var(--success-bd)',   fg:'var(--success)' },
  }[state] || { bg: 'var(--surface-hover)', bd:'var(--border-default)', fg:'var(--fg-muted)' };
  const Ico = I[stage.icon];
  const h = size === 'sm' ? 26 : 32;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      height: h, padding: '0 10px',
      background: palette.bg, border: `1px solid ${palette.bd}`, color: palette.fg,
      borderRadius: 999, font: '600 12px/1 var(--font-sans)', letterSpacing: '-0.01em',
    }}>
      <Ico size={size === 'sm' ? 12 : 14}/>
      {stage.label}
    </span>
  );
}

/* The horizontal mini-pipeline visualization for a single project */
function ProjectPipeline({ project, onStageClick, compact = false }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      gap: 0, width: '100%', position: 'relative',
    }}>
      {PIPELINE_STAGES.map((stage, idx) => {
        const state = project.stageStates[stage.id] || 'todo';
        const nextState = idx < PIPELINE_STAGES.length - 1
          ? (project.stageStates[PIPELINE_STAGES[idx + 1].id] || 'todo')
          : null;
        const connectorActive = state === 'done' || (state === 'running' && nextState !== 'todo');
        return (
          <React.Fragment key={stage.id}>
            <div
              onClick={() => onStageClick && onStageClick(project, stage)}
              title={`${stage.label} · ${state}`}
              className={state === 'running' ? 'process-pulse' : ''}
              style={{
                position: 'relative', flexShrink: 0, cursor: 'pointer',
                width: compact ? 28 : 34, height: compact ? 28 : 34, borderRadius: 10,
                background:
                  state === 'done'    ? 'linear-gradient(135deg, var(--success-bd), var(--success-bg))' :
                  state === 'running' ? 'linear-gradient(135deg, var(--accent-border), rgba(34,211,238,0.20))' :
                  state === 'review'  ? 'var(--warning-bg)' :
                                        'var(--surface-subtle)',
                border: `1px solid ${
                  state === 'done'    ? 'var(--success-bd)' :
                  state === 'running' ? 'var(--accent-border)' :
                  state === 'review'  ? 'var(--warning-bd)' :
                                        'var(--border-default)'
                }`,
                color:
                  state === 'done'    ? 'var(--success)' :
                  state === 'running' ? 'var(--accent-fg)' :
                  state === 'review'  ? 'var(--warning)' :
                                        'var(--fg-faint)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                transition: 'transform 160ms var(--ease-out)',
                zIndex: 2,
              }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-1px) scale(1.05)'}
              onMouseLeave={e => e.currentTarget.style.transform = ''}
            >
              {state === 'done'
                ? <I.Check size={compact ? 14 : 16}/>
                : React.createElement(I[stage.icon], { size: compact ? 14 : 16 })}
            </div>

            {idx < PIPELINE_STAGES.length - 1 && (
              <div style={{
                flex: 1, height: 2,
                background: connectorActive
                  ? 'linear-gradient(90deg, var(--success-bd), var(--accent-border))'
                  : 'var(--border-hairline)',
                margin: '0 -2px',
                position: 'relative', zIndex: 1,
              }}/>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

/* The stat tile up top */
function StatTile({ label, value, sub, gradient, icon: Ico }) {
  return (
    <div className="card" style={{ padding: 16, minHeight: 96, position: 'relative', overflow: 'hidden' }}>
      {gradient && <div style={{ position: 'absolute', inset: 0, background: gradient, opacity: 0.18, pointerEvents: 'none' }}/>}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10,
          background: 'var(--surface-hover)',
          border: '1px solid var(--border-hairline)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--accent-fg)',
        }}>
          {Ico && <Ico size={18}/>}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="t-tiny">{label}</div>
          <div style={{ font: '700 24px/1.1 var(--font-display)', color: 'var(--fg-strong)', letterSpacing: '-0.02em', marginTop: 6 }}>{value}</div>
          {sub && <div className="t-small" style={{ marginTop: 4 }}>{sub}</div>}
        </div>
      </div>
    </div>
  );
}

function ChannelHeader({ ch }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap: 8 }}>
      <span style={{
        width: 22, height: 22, borderRadius: '50%',
        background: ch.color, color:'white',
        display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontSize: 11, fontWeight: 700,
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.18)',
      }}>{ch.emoji || ch.name[0]}</span>
      <span style={{ font:'600 13px/1 var(--font-sans)', color:'var(--fg-default)' }}>{ch.name}</span>
    </span>
  );
}

function ProjectRow({ project, onOpen, onStageClick }) {
  const ch = MOCK.channels.find(c => c.id === project.channelId);
  const currentStage = STAGE_BY_ID[project.stage];
  const [hover, setHover] = React.useState(false);

  const stateColor = {
    running: 'var(--accent-fg)',
    review:  'var(--warning)',
    queued:  'var(--fg-muted)',
    done:    'var(--success)',
  }[project.stageState] || 'var(--fg-muted)';

  return (
    <div
      onClick={() => onOpen(project)}
      onMouseEnter={()=>setHover(true)}
      onMouseLeave={()=>setHover(false)}
      style={{
        display: 'grid', gridTemplateColumns: '340px 1fr 220px', gap: 20, alignItems: 'center',
        padding: '14px 16px',
        background: hover ? 'rgba(255,255,255,0.025)' : 'transparent',
        borderBottom: '1px solid var(--border-hairline)',
        cursor: 'pointer',
        transition: 'background 120ms var(--ease-out)',
      }}>
      {/* Left: project info */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
        <div style={{
          width: 64, height: 40, borderRadius: 8,
          background: project.thumb,
          border: '1px solid var(--border-hairline)',
          flexShrink: 0, position: 'relative', overflow: 'hidden',
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.18), transparent 50%)',
          }}/>
          <span style={{
            position: 'absolute', bottom: 3, right: 4,
            font: '700 10px/1 var(--font-sans)', color: 'white', textShadow: '0 1px 2px rgba(0,0,0,0.6)',
            padding: '2px 5px', borderRadius: 4, background: 'rgba(0,0,0,0.45)',
          }}>{project.duration}</span>
        </div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ font: '600 14px/1.3 var(--font-sans)', color: 'var(--fg-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{project.title}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
            <ChannelHeader ch={ch}/>
            <span style={{ color: 'var(--fg-faint)', fontSize: 10 }}>•</span>
            <span className="t-small">{project.format}</span>
          </div>
        </div>
      </div>

      {/* Middle: pipeline */}
      <div onClick={e => e.stopPropagation()} style={{ padding: '0 12px' }}>
        <ProjectPipeline project={project} onStageClick={(p, s) => onStageClick(p, s)} compact/>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
          <span className="t-small" style={{ color: stateColor }}>
            {project.stageState === 'review' ? '⚠︎ Awaiting your review' :
             project.stageState === 'running' ? `${currentStage.label} in progress…` :
             project.stageState === 'queued' ? 'Queued for autopilot' :
             project.stageState === 'done' ? 'Published' :
             currentStage.label}
          </span>
          <span className="t-small" style={{ color: 'var(--fg-faint)', whiteSpace: 'nowrap' }}>{project.eta}</span>
        </div>
      </div>

      {/* Right: actions / schedule */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, justifyContent: 'flex-end' }}>
        <div style={{ textAlign: 'right' }}>
          <div className="t-tiny" style={{ color:'var(--fg-faint)' }}>{project.autopilot ? 'Autopilot' : 'Manual'}</div>
          <div style={{ font: '600 12px/1.3 var(--font-sans)', color: 'var(--fg-default)', marginTop: 4 }}>{project.publishAt}</div>
        </div>
        <button onClick={e=>{ e.stopPropagation(); onOpen(project); }} className="btn btn--ghost btn--icon">
          <I.ChevRight size={18}/>
        </button>
      </div>
    </div>
  );
}

function DashboardScreen({ onOpenProject, onNavigate }) {
  const [filter, setFilter] = React.useState('all');
  const filtered = MOCK.projects.filter(p => {
    if (filter === 'autopilot') return p.autopilot;
    if (filter === 'review') return p.stageState === 'review';
    if (filter === 'today') return /Today|Tomorrow/.test(p.publishAt);
    return true;
  });
  const inReview = MOCK.projects.filter(p => p.stageState === 'review').length;

  return (
    <div style={{ flex: 1, overflowY: 'auto', position: 'relative' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto', position: 'relative', zIndex: 1 }}>

        {/* Hero stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
          <StatTile label="In production" value="6" sub="3 on autopilot · 1 needs review" icon={I.Pipeline} gradient="radial-gradient(50% 100% at 50% 0%, rgba(124,58,237,0.40), transparent)"/>
          <StatTile label="Publishing today" value="2" sub="Auto-queued · 6:00 PM" icon={I.Clock} gradient="radial-gradient(50% 100% at 50% 0%, var(--accent-tint-3), transparent)"/>
          <StatTile label="Last 30d views" value="2.4M" sub="+18.2% vs prior 30d" icon={I.TrendUp} gradient="radial-gradient(50% 100% at 50% 0%, var(--success-bd), transparent)"/>
          <StatTile label="Credits remaining" value="2,840" sub="of 5,000 · resets in 12d" icon={I.Spark} gradient="radial-gradient(50% 100% at 50% 0%, rgba(236,72,153,0.30), transparent)"/>
        </div>

        {/* Pipeline stage legend / Production Line headline */}
        <div className="card" style={{ padding: 0, marginBottom: 20, overflow: 'hidden' }}>

          {/* Top bar */}
          <div style={{ padding: '20px 20px 16px', display: 'flex', alignItems: 'center', gap: 16, position: 'relative' }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <I.Pipeline size={20} stroke="var(--accent)"/>
                <span className="t-h4">The Production Line</span>
                {inReview > 0 && <span className="chip chip--warning">{inReview} needs review</span>}
              </div>
              <div className="t-small" style={{ marginTop: 6 }}>
                Every video flows left → right. <span style={{ color:'var(--accent-fg)' }}>Autopilot</span> moves them automatically. Click any stage to drop in and review.
              </div>
            </div>
            <Tabs
              value={filter}
              onChange={setFilter}
              items={[
                { id: 'all',       label: 'All',         icon: I.Layers },
                { id: 'autopilot', label: 'Autopilot',   icon: I.Robot },
                { id: 'review',    label: 'Needs review', icon: I.Eye },
                { id: 'today',     label: 'Today',       icon: I.Clock },
              ]}
            />
            <Btn kind="magic" icon={I.Plus} onClick={()=>onNavigate('topics')}>New Video</Btn>
          </div>

          {/* Stage header rail */}
          <div style={{
            display: 'grid', gridTemplateColumns: '340px 1fr 220px', gap: 20,
            padding: '12px 16px',
            borderTop: '1px solid var(--border-hairline)',
            borderBottom: '1px solid var(--border-hairline)',
            background: 'rgba(255,255,255,0.015)',
          }}>
            <div className="t-tiny">Project · Channel</div>
            <div onClick={e=>e.stopPropagation()} style={{ padding: '0 12px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: `repeat(${PIPELINE_STAGES.length}, 1fr)`, gap: 0 }}>
                {PIPELINE_STAGES.map((s, i) => (
                  <div key={s.id} style={{ textAlign: 'center', position: 'relative' }}>
                    <div className="t-tiny" style={{ color: 'var(--fg-muted)' }}>{String(i+1).padStart(2,'0')}</div>
                    <div style={{ font: '600 11px/1.2 var(--font-sans)', color: 'var(--fg-default)', marginTop: 4 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="t-tiny" style={{ textAlign: 'right' }}>Schedule</div>
          </div>

          {/* Project rows */}
          <div>
            {filtered.length === 0 ? (
              <div style={{ padding: 60, textAlign: 'center' }}>
                <div className="t-small">No projects match this filter.</div>
              </div>
            ) : filtered.map(p => (
              <ProjectRow
                key={p.id}
                project={p}
                onOpen={onOpenProject}
                onStageClick={(proj, stage) => { onOpenProject(proj, stage.id); }}
              />
            ))}
          </div>
        </div>

        {/* Below: two-column "next up" + "live" */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
          {/* Recently published */}
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-hairline)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <I.Youtube size={18} stroke="var(--fg-default)"/>
                <span className="t-h5">Recently published</span>
              </div>
              <Btn kind="ghost" size="sm" iconRight={I.ArrowRight} onClick={()=>onNavigate('library')}>Library</Btn>
            </div>
            <div>
              {MOCK.publishedRecent.map((v, i) => {
                const ch = MOCK.channels.find(c=>c.id===v.channelId);
                return (
                  <div key={v.id} onClick={() => onNavigate('video', v.id)} style={{
                    display: 'grid', gridTemplateColumns: '64px 1fr auto', gap: 12, alignItems: 'center',
                    padding: '12px 20px',
                    borderBottom: i < MOCK.publishedRecent.length - 1 ? '1px solid var(--border-hairline)' : 0,
                    cursor: 'pointer',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                    <div style={{
                      width: 64, height: 40, borderRadius: 8,
                      background: v.thumb, border: '1px solid var(--border-hairline)',
                    }}/>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ font: '600 13px/1.3 var(--font-sans)', color: 'var(--fg-strong)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{v.title}</div>
                      <div style={{ display: 'flex', gap: 12, marginTop: 4 }}>
                        <ChannelHeader ch={ch}/>
                        <span className="t-small">{v.published}</span>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 18, textAlign: 'right' }}>
                      <div><div className="t-tiny">Views</div><div style={{ font:'600 13px/1.2 var(--font-sans)', color:'var(--fg-strong)', marginTop: 4 }}>{v.views}</div></div>
                      <div><div className="t-tiny">CTR</div><div style={{ font:'600 13px/1.2 var(--font-sans)', color:'var(--fg-strong)', marginTop: 4 }}>{v.ctr}</div></div>
                      <div><div className="t-tiny">AVD</div><div style={{ font:'600 13px/1.2 var(--font-sans)', color:'var(--fg-strong)', marginTop: 4 }}>{v.avd}</div></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Topic ideas queue */}
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-hairline)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <I.Spark size={18} stroke="var(--accent)"/>
                <span className="t-h5">Idea queue</span>
                <span className="chip chip--brand">AI suggested</span>
              </div>
              <Btn kind="ghost" size="sm" iconRight={I.ArrowRight} onClick={()=>onNavigate('topics')}>All</Btn>
            </div>
            <div style={{ padding: '8px 0' }}>
              {MOCK.topicIdeas.slice(0, 5).map((t, i) => {
                const ch = MOCK.channels.find(c=>c.id===t.channelId);
                return (
                  <div key={t.id}
                       onClick={() => onNavigate('topic', t.id)}
                       style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '10px 20px', cursor: 'pointer',
                  }}
                       onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-hover)'}
                       onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                    <span style={{
                      width: 36, height: 36, borderRadius: 10,
                      background: 'var(--accent-tint-1)',
                      border: '1px solid var(--brand-soft-bd)',
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      color: 'var(--accent-fg)', font: '700 13px/1 var(--font-sans)', flexShrink: 0,
                    }}>{t.score}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ font: '500 13px/1.3 var(--font-sans)', color: 'var(--fg-default)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{t.title}</div>
                      <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                        <ChannelHeader ch={ch}/>
                        <span className="t-small">{t.est}</span>
                      </div>
                    </div>
                    <button className="btn btn--ghost btn--icon" title="Generate"><I.Spark size={16}/></button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

window.DashboardScreen = DashboardScreen;
window.ProjectPipeline = ProjectPipeline;
window.StageBadge = StageBadge;
window.ChannelHeader = ChannelHeader;
window.StatTile = StatTile;
