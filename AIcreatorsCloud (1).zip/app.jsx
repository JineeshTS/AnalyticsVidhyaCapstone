/* ============================================================
   AIcreators.cloud — App shell + router
   Routes:
     /onboarding | /dashboard | /channels | /channel/:id
     /topics | /library | /analytics | /project/:id/:stage
     /settings | /billing | /integrations | /mobile
   ============================================================ */

const { useState, useEffect } = React;

function TopBarActions({ onNavigate, route, onNotifs, onSearch }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <button onClick={onSearch} style={{
        height: 36, padding: '0 12px',
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-input)',
        borderRadius: 12, cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 10,
        width: 280, font: '500 13px/1 var(--font-sans)', color: 'var(--fg-faint)',
      }}>
        <I.Search size={14} stroke="var(--fg-muted)"/>
        <span style={{ flex: 1, textAlign: 'left' }}>Search…</span>
        <span style={{ padding: '2px 6px', borderRadius: 4, background: 'var(--surface-hover)', border: '1px solid var(--border-hairline)', font: '600 10px/1 var(--font-mono)', color: 'var(--fg-muted)' }}>⌘ K</span>
      </button>
      <button className="btn btn--ghost btn--icon" title="Notifications" onClick={onNotifs} style={{ position: 'relative' }}>
        <I.Bell size={18}/>
        <span style={{ position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: '50%', background: 'var(--magenta-400, var(--danger))', boxShadow: '0 0 6px currentColor' }}/>
      </button>
      <button className="btn btn--ghost btn--icon" title="Mobile preview" onClick={() => onNavigate('mobile')}>
        <I.GIF size={18}/>
      </button>
      <Btn kind="magic" size="sm" icon={I.Plus} onClick={() => onNavigate('topics')}>New video</Btn>
    </div>
  );
}

function App() {
  // route is { name, params }
  const [route, setRoute] = useState(() => {
    const hash = (window.location.hash || '').replace(/^#/, '');
    if (hash) {
      const parts = hash.split('/');
      return { name: parts[0] || 'onboarding', params: parts.slice(1) };
    }
    return { name: 'onboarding', params: [] };
  });

  // open onboarding by default, but allow direct nav
  const go = (name, ...params) => {
    setRoute({ name, params });
    window.location.hash = [name, ...params].join('/');
  };

  // Track project context
  const [activeProject, setActiveProject] = useState(null);
  const [activeStage, setActiveStage] = useState(null);
  const [activeChannel, setActiveChannel] = useState(null);
  const [activeTopic, setActiveTopic] = useState(null);
  const [activeVideo, setActiveVideo] = useState(null);
  const [activeTicket, setActiveTicket] = useState(null);

  // Overlays
  const [notifsOpen, setNotifsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [previewProject, setPreviewProject] = useState(null);
  // Global ⌘K shortcut
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      } else if (e.key === 'Escape') {
        setSearchOpen(false);
        setNotifsOpen(false);
      }
    };
    window.addEventListener('keydown', onKey);
    // Expose preview opener globally so deep components can call it
    window.openPreview = (p) => setPreviewProject(p);
    return () => {
      window.removeEventListener('keydown', onKey);
      delete window.openPreview;
    };
  }, []);

  const openProject = (p, stage) => {
    setActiveProject(p);
    setActiveStage(stage || p.stage);
    go('project', p.id, stage || p.stage);
  };
  const openChannel = (ch) => {
    setActiveChannel(ch);
    go('channel', ch.id);
  };
  const openTopic = (t) => {
    setActiveTopic(t);
    go('topic', t.id);
  };
  const openVideo = (v) => { setActiveVideo(v); go('video', v.id); };
  const openTicket = (t) => { setActiveTicket(t); go('ticket', t.id); };

  // Resolve from route on first load
  useEffect(() => {
    if (route.name === 'project' && route.params[0] && !activeProject) {
      const p = MOCK.projects.find(x => x.id === route.params[0]);
      if (p) { setActiveProject(p); setActiveStage(route.params[1] || p.stage); }
    }
    if (route.name === 'channel' && route.params[0] && !activeChannel) {
      const c = MOCK.channels.find(x => x.id === route.params[0]);
      if (c) setActiveChannel(c);
    }
    if (route.name === 'topic' && route.params[0] && !activeTopic) {
      const t = MOCK.topicIdeas.find(x => x.id === route.params[0]);
      if (t) setActiveTopic(t);
    }
  }, [route.name]);

  // Onboarding takes the whole screen
  if (route.name === 'onboarding') {
    return <OnboardingScreen onDone={() => go('dashboard')}/>;
  }

  // Mobile preview takes the whole screen
  if (route.name === 'mobile') {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', flexDirection: 'column', gap: 24 }}>
        <SparkleField count={20} intensity={0.4}/>
        <div style={{ position: 'absolute', top: 24, left: 24, zIndex: 2 }}>
          <button className="btn btn--secondary" onClick={() => go('dashboard')}>
            <I.ChevLeft size={16}/> Back to desktop
          </button>
        </div>
        <div style={{ textAlign: 'center', zIndex: 1, position: 'relative' }}>
          <span className="chip chip--magic"><I.GIF size={12}/> PWA mobile preview</span>
          <div className="t-h3" style={{ marginTop: 12 }}>AIcreators on the go</div>
          <div className="t-small" style={{ marginTop: 6, maxWidth: 460 }}>Same studio. Same autopilot. Approve, review, and publish from anywhere.</div>
        </div>
        <MobilePreview/>
      </div>
    );
  }

  // Standard app shell
  return (
    <div style={{ height: '100%', display: 'flex', position: 'relative', zIndex: 1 }}>
      <Sidebar
        active={
          route.name === 'project' ? 'dashboard' :
          route.name === 'channel' ? 'channels' :
          route.name === 'billing' ? 'billing' :
          route.name === 'integrations' ? 'integrations' :
          route.name
        }
        onNavigate={(id) => go(id)}
        user={MOCK.user}
      />
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' }}>
        {route.name === 'dashboard' && (
          <>
            <Header
              title="Studio"
              subtitle="Your videos · today's autopilot · live channels"
              actions={<TopBarActions onNavigate={go} route={route}/>}
            />
            <DashboardScreen onOpenProject={openProject} onNavigate={go}/>
          </>
        )}
        {route.name === 'channels' && (
          <>
            <Header title="Channels" subtitle="Each one runs its own brand, schedule, autopilot" actions={<TopBarActions onNavigate={go} route={route}/>}/>
            <ChannelsScreen onOpenChannel={openChannel}/>
          </>
        )}
        {route.name === 'channel' && activeChannel && (
          <ChannelIdentityScreen channel={activeChannel} onBack={() => go('channels')}/>
        )}
        {route.name === 'topics' && (
          <>
            <Header title="Topics & Calendar" subtitle="Idea queue · publishing rhythm · trends" actions={<TopBarActions onNavigate={go} route={route}/>}/>
            <TopicsScreen onOpenProject={openProject}/>
          </>
        )}
        {route.name === 'library' && (
          <>
            <Header title="Library" subtitle="Everything you've made" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <LibraryScreen onOpenProject={openVideo}/>
          </>
        )}
        {route.name === 'analytics' && (
          <>
            <Header title="Analytics" subtitle="Across all channels · last 30d" actions={<TopBarActions onNavigate={go} route={route}/>}/>
            <AnalyticsScreen/>
          </>
        )}
        {route.name === 'voices' && (
          <>
            <Header title="Voice Library" subtitle="Clone your voice · studio voices · per-channel defaults" actions={<TopBarActions onNavigate={go} route={route}/>}/>
            <VoiceLibraryScreen/>
          </>
        )}
        {route.name === 'avatars' && (
          <>
            <Header title="Avatars & Lip Sync" subtitle="Upload your face · sync to any voiceover" actions={<TopBarActions onNavigate={go} route={route}/>}/>
            <AvatarsScreen/>
          </>
        )}
        {route.name === 'styles' && (
          <>
            <Header title="Visual Styles" subtitle="The look that drives every keyframe + motion clip" actions={<TopBarActions onNavigate={go} route={route}/>}/>
            <StylesLibraryScreen/>
          </>
        )}
        {route.name === 'integrations' && (
          <>
            <Header title="Integrations" subtitle="Connect destinations · workflow tools · API" actions={<TopBarActions onNavigate={go} route={route}/>}/>
            <IntegrationsScreen/>
          </>
        )}
        {route.name === 'project' && activeProject && (
          <ProjectScreen
            project={activeProject}
            initialStage={activeStage}
            onBack={() => go('dashboard')}
            onAutopilot={() => {}}
          />
        )}
        {route.name === 'topic' && activeTopic && (
          <TopicDetailScreen
            topic={activeTopic}
            onBack={() => go('topics')}
            onStart={() => { openProject(MOCK.projects[5]); /* mock: start a new project */ }}
          />
        )}
        {route.name === 'video' && (
          <VideoDetailScreen video={activeVideo || MOCK.publishedRecent[0]} onBack={() => go('library')}/>
        )}
        {route.name === 'channel-analytics' && (
          <ChannelAnalyticsScreen channelId={route.params[0]} onBack={() => go('analytics')}/>
        )}
        {route.name === 'ab' && (
          <ABResultsScreen video={activeVideo || MOCK.publishedRecent[0]} onBack={() => go('library')}/>
        )}
        {route.name === 'ticket' && (
          <>
            <Header title="Ticket" subtitle="" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <TicketThreadScreen ticketId={activeTicket?.id || route.params[0]} onBack={() => go('help')}/>
          </>
        )}
        {route.name === 'notif-prefs' && (
          <>
            <Header title="Notification preferences" subtitle="In-app, email, push, Slack" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <NotificationPrefsScreen/>
          </>
        )}
        {route.name === 'refer' && (
          <>
            <Header title="Refer & Earn" subtitle="Bring a friend, both get a month free" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <ReferEarnScreen/>
          </>
        )}
        {route.name === 'security' && (
          <>
            <Header title="Security" subtitle="Password · 2FA · passkeys · sessions" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <SecurityScreen/>
          </>
        )}
        {route.name === 'api-keys' && (
          <>
            <Header title="API keys" subtitle="Build on top of AIcreators" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <UserAPIKeysScreen/>
          </>
        )}
        {route.name === 'invoices' && (
          <>
            <Header title="Invoices" subtitle="Receipts and billing history" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <InvoicesScreen/>
          </>
        )}
        {(route.name === 'settings' || route.name === 'billing') && (
          <>
            <Header title="Settings" subtitle="Tune the autopilot, manage your subscription" actions={<TopBarActions onNavigate={go} route={route} onNotifs={() => setNotifsOpen(true)} onSearch={() => setSearchOpen(true)}/>}/>
            <SettingsScreen section={route.name} onInviteTeam={() => setTeamInviteOpen(true)}/>
          </>
        )}
      </main>

      {/* Global overlays */}
      <ToastHost/>
      <NotificationsPanel open={notifsOpen} onClose={() => setNotifsOpen(false)}/>
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} onNavigate={go}/>
      <VideoPreviewModal open={!!previewProject} project={previewProject} onClose={() => setPreviewProject(null)}/>
      <TourLauncher/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
