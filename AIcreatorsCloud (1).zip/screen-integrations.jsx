/* ============================================================
   AIcreators.cloud — Integrations & Publishing Destinations
   ============================================================

   PURPOSE
   -------
   The central hub where users connect ALL the places they want
   their videos to go (YouTube, Instagram, TikTok, X, etc.) plus
   workflow tools (Drive, Notion, Slack, Zapier, Webhooks).

   Every video can publish to multiple destinations at once.
   We auto-reformat per platform:
     - aspect ratio (16:9 ↔ 9:16 ↔ 1:1)
     - duration limits (Shorts 60s, Reels 90s, TikTok 10m, etc.)
     - caption length + hashtag rules
     - thumbnail / cover-frame per platform

   SCREENS in this file
     IntegrationsScreen          – grid of all destinations + workflow
     ConnectDestinationModal     – OAuth handshake + scope chooser
     DestinationAccountList      – many accounts can be connected per platform

   BACKED BY
     GET    /integrations
     GET    /integrations/{platform}                   – connected accounts
     POST   /integrations/{platform}/connect           – OAuth start URL
     GET    /integrations/{platform}/callback          – server-side
     DELETE /integrations/{platform}/accounts/{id}
     PATCH  /integrations/{platform}/accounts/{id}     – per-account defaults
     GET    /integrations/workflow                     – Drive/Notion/Slack/Zapier

   DATA MODEL — IntegrationAccount
     id, user_id, platform (youtube|instagram|tiktok|x|linkedin|facebook|threads|pinterest|reddit|snapchat),
     external_id (platform-specific id),
     handle, display_name, avatar_url,
     followers,
     oauth_access_token (encrypted),
     oauth_refresh_token (encrypted),
     oauth_expires_at,
     scopes[],
     status (ok | refresh_failing | revoked | rate_limited),
     default_visibility (public|unlisted|private|followers),
     default_hashtags_csv,
     auto_post (bool),
     created_at

   DATA MODEL — DistributionTarget (per Project)
     project_id, integration_account_id, platform,
     status (pending | scheduled | publishing | published | failed | skipped),
     reformat_aspect, reformat_duration_seconds,
     platform_title, platform_description, platform_hashtags,
     platform_cover_url,
     scheduled_at, published_at,
     external_post_id, external_url, error_code
   ============================================================ */

const PUBLISHING_DESTINATIONS = [
  {
    id: 'youtube', name: 'YouTube',
    color: '#FF0000', bgTint: 'rgba(255,0,0,0.10)',
    blurb: 'Shorts (≤60s · 9:16) · long-form (≤12h · 16:9) · scheduled publishing · live stream draft',
    surfaces: ['Shorts','Long-form','Community posts'],
    scopes: ['Upload videos','Read analytics','Manage thumbnails'],
    perks: ['Title up to 100 chars','Description up to 5,000','15 hashtags','Auto-A/B thumbnails'],
    icon: 'Youtube',
  },
  {
    id: 'instagram', name: 'Instagram',
    color: '#E1306C', bgTint: 'rgba(225,48,108,0.10)',
    blurb: 'Reels (≤90s · 9:16) · Posts (1:1 or 4:5) · Stories (15s)',
    surfaces: ['Reels','Posts','Stories'],
    scopes: ['Publish content','Read insights','Manage stories'],
    perks: ['Caption up to 2,200','30 hashtags','Cover frame picker','Auto-collab tags'],
    icon: 'Image',
  },
  {
    id: 'tiktok', name: 'TikTok',
    color: '#000000', bgTint: 'rgba(0,0,0,0.06)',
    blurb: 'Videos (3s–10m · 9:16) · scheduled · branded content disclosure',
    surfaces: ['Video','Stitches','Duets'],
    scopes: ['Post video','Read stats','Brand toggle'],
    perks: ['Caption up to 2,200','Trending sounds suggester','Branded-content compliance'],
    icon: 'Film',
  },
  {
    id: 'x', name: 'X (Twitter)',
    color: '#0F1419', bgTint: 'rgba(15,20,25,0.06)',
    blurb: 'Video posts (≤2m20s · 16:9 or 9:16) · threads · scheduled',
    surfaces: ['Posts','Threads'],
    scopes: ['Read & write posts','Upload media'],
    perks: ['280-char post + 4-tweet thread breakdown','Auto-#hashtag from script'],
    icon: 'Send',
  },
  {
    id: 'linkedin', name: 'LinkedIn',
    color: '#0A66C2', bgTint: 'rgba(10,102,194,0.10)',
    blurb: 'Posts with video (≤10m · 16:9 / 1:1) · company pages · newsletters',
    surfaces: ['Personal posts','Company posts','Articles'],
    scopes: ['Share posts','Manage company pages'],
    perks: ['3,000-char post','Professional caption auto-rewrite'],
    icon: 'Users',
  },
  {
    id: 'facebook', name: 'Facebook',
    color: '#1877F2', bgTint: 'rgba(24,119,242,0.10)',
    blurb: 'Reels (≤90s · 9:16) · Page posts · Stories · Groups',
    surfaces: ['Reels','Page posts','Stories','Groups'],
    scopes: ['Publish to pages','Manage groups','Insights'],
    perks: ['Multi-page broadcast','Auto crosspost to Instagram'],
    icon: 'Globe',
  },
  {
    id: 'threads', name: 'Threads',
    color: '#000000', bgTint: 'rgba(0,0,0,0.04)',
    blurb: 'Posts with video (≤5m · 9:16 or 1:1) · multi-thread breakdowns',
    surfaces: ['Posts','Threads'],
    scopes: ['Publish posts'],
    perks: ['500-char post','Auto-chain longer captions'],
    icon: 'Message',
  },
  {
    id: 'pinterest', name: 'Pinterest',
    color: '#E60023', bgTint: 'rgba(230,0,35,0.10)',
    blurb: 'Idea Pins (≤60s · 9:16) · Video Pins (≤15m · 1:1 / 2:3)',
    surfaces: ['Idea Pins','Video Pins'],
    scopes: ['Create pins','Read board stats'],
    perks: ['SEO-tuned descriptions','Auto-board routing by tag'],
    icon: 'Pin',
  },
  {
    id: 'reddit', name: 'Reddit',
    color: '#FF4500', bgTint: 'rgba(255,69,0,0.10)',
    blurb: 'Video posts to chosen subreddits · per-sub rules enforcement',
    surfaces: ['Subreddit posts'],
    scopes: ['Submit posts','Read inbox'],
    perks: ['Per-subreddit title rules','Auto-flair'],
    icon: 'Megaphone',
  },
  {
    id: 'snapchat', name: 'Snapchat Spotlight',
    color: '#FFFC00', bgTint: 'rgba(255,252,0,0.20)',
    blurb: 'Spotlight (≤60s · 9:16) · public Stories',
    surfaces: ['Spotlight','Public Stories'],
    scopes: ['Publish content'],
    perks: ['Auto sticker / caption overlay'],
    icon: 'Spark',
  },
];

const WORKFLOW_INTEGRATIONS = [
  { id: 'drive',    name: 'Google Drive',  color: '#4285F4', icon: 'Folder',    blurb: 'Sync raw drafts, scripts, and final renders' },
  { id: 'notion',   name: 'Notion',        color: '#000000', icon: 'Pin',       blurb: 'Send weekly analytics digests + project briefs' },
  { id: 'slack',    name: 'Slack',         color: '#4A154B', icon: 'Bell',      blurb: 'Notify channels on publish / failures / review' },
  { id: 'discord',  name: 'Discord',       color: '#5865F2', icon: 'Message',   blurb: 'Per-server bot · announce new videos' },
  { id: 'zapier',   name: 'Zapier',        color: '#FF4A00', icon: 'Lightning', blurb: 'Wire AIcreators to 6,000+ apps' },
  { id: 'make',     name: 'Make',          color: '#6D00CC', icon: 'Lightning', blurb: 'Visual automations' },
  { id: 'webhooks', name: 'Webhooks',      color: '#22D3EE', icon: 'Globe',     blurb: 'POST events to your endpoint (signed)' },
  { id: 'api',      name: 'API & API keys', color: '#10B981', icon: 'Code',     blurb: 'Build on top of AIcreators · REST + WS' },
];

// Mock "connected accounts" state — for demo
const CONNECTED_ACCOUNTS = {
  youtube:   [
    { id: 'yt_001', handle: '@mythictales',  display: 'Mythic Tales',  followers: '127K', status: 'ok', autopost: true },
    { id: 'yt_002', handle: '@snackscience', display: 'Snackable Science', followers: '38K', status: 'ok', autopost: true },
    { id: 'yt_003', handle: '@noirreels',    display: 'Noir Reels',    followers: '64K', status: 'ok', autopost: true },
    { id: 'yt_004', handle: '@tinytoon',     display: 'Tiny Toon Theatre', followers: '8.6K', status: 'ok', autopost: false },
  ],
  instagram: [
    { id: 'ig_001', handle: '@mythictales.ig',  display: 'Mythic Tales',  followers: '24K', status: 'ok', autopost: true },
    { id: 'ig_002', handle: '@snackscience.ig', display: 'Snackable Sci', followers: '12K', status: 'ok', autopost: true },
  ],
  tiktok:    [
    { id: 'tk_001', handle: '@snackscience',   display: 'Snackable Science', followers: '88K', status: 'ok', autopost: true },
  ],
  x:         [
    { id: 'x_001',  handle: '@mihir_creates',  display: 'Mihir V', followers: '4.2K', status: 'ok', autopost: false },
  ],
  linkedin:  [],
  facebook:  [
    { id: 'fb_001', handle: 'Mythic Tales Page', display: 'Mythic Tales', followers: '11K', status: 'refresh', autopost: false, note: 'OAuth token expiring' },
  ],
  threads:   [],
  pinterest: [],
  reddit:    [],
  snapchat:  [],
};

function IntegrationsScreen() {
  const [openConnect, setOpenConnect] = React.useState(null);

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div style={{ padding: '24px 28px 40px', maxWidth: 1480, margin: '0 auto' }}>

        {/* Hero */}
        <div className="card" style={{ padding: 22, marginBottom: 20, background: 'var(--magic-tint)', border: '1px solid var(--accent-border-soft)', position: 'relative', overflow: 'hidden' }}>
          <SparkleField count={8} intensity={0.35}/>
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 22 }}>
            <span style={{
              width: 64, height: 64, borderRadius: 18,
              background: 'var(--magic-grad)',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              color: 'white', flexShrink: 0,
            }}><I.Megaphone size={28}/></span>
            <div style={{ flex: 1 }}>
              <div className="t-h3" style={{ marginBottom: 6 }}>Make one video. Post it everywhere.</div>
              <div className="t-small" style={{ maxWidth: 720 }}>
                Connect your social accounts and AIcreators auto-reformats each video per platform — aspect ratio, length, captions, hashtags, cover frame. One pipeline, every audience.
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
              <div style={{ display: 'flex', gap: -6 }}>
                {PUBLISHING_DESTINATIONS.slice(0, 7).map((d, i) => (
                  <span key={d.id} style={{
                    width: 34, height: 34, borderRadius: '50%',
                    background: d.bgTint, border: '2px solid var(--bg-surface)',
                    color: d.color, marginLeft: i === 0 ? 0 : -10,
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', zIndex: 10 - i,
                  }}>{React.createElement(I[d.icon], { size: 16 })}</span>
                ))}
              </div>
              <span className="t-small">10 publishing destinations</span>
            </div>
          </div>
        </div>

        {/* Publishing destinations */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <I.Send size={16} stroke="var(--fg-default)"/>
          <span className="t-h5">Publishing destinations</span>
          <span className="t-small" style={{ marginLeft: 4 }}>where your videos go</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 32 }}>
          {PUBLISHING_DESTINATIONS.map(d => {
            const accounts = CONNECTED_ACCOUNTS[d.id] || [];
            const connected = accounts.length > 0;
            return (
              <div key={d.id} className="card card--hover" style={{
                padding: 0, overflow: 'hidden',
                borderColor: connected ? 'var(--brand-soft-bd)' : 'var(--border-hairline)',
              }}>
                {/* Header band in platform color */}
                <div style={{
                  padding: '14px 16px',
                  background: d.bgTint,
                  borderBottom: '1px solid var(--border-hairline)',
                  display: 'flex', alignItems: 'center', gap: 12,
                }}>
                  <span style={{
                    width: 40, height: 40, borderRadius: 10,
                    background: d.color, color: 'white',
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                    boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.20), 0 2px 6px rgba(0,0,0,0.10)',
                  }}>
                    {React.createElement(I[d.icon], { size: 20 })}
                  </span>
                  <div style={{ flex: 1 }}>
                    <div style={{ font: '700 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{d.name}</div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 4, flexWrap: 'wrap' }}>
                      {d.surfaces.map(s => <span key={s} className="chip" style={{ height: 20, fontSize: 10, padding: '0 6px' }}>{s}</span>)}
                    </div>
                  </div>
                  {connected && <span className="chip chip--success" style={{ height: 22, fontSize: 11 }}><I.Check size={10}/> {accounts.length}</span>}
                </div>

                {/* Body */}
                <div style={{ padding: 16 }}>
                  <div className="t-small" style={{ marginBottom: 12, minHeight: 36 }}>{d.blurb}</div>

                  {connected ? (
                    <>
                      <div className="t-tiny" style={{ marginBottom: 8 }}>Connected accounts</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 12 }}>
                        {accounts.slice(0, 2).map(a => (
                          <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <span style={{ width: 6, height: 6, borderRadius: '50%', background: a.status === 'ok' ? 'var(--success)' : 'var(--warning)' }}/>
                            <span style={{ font: '500 12px/1 var(--font-sans)', color: 'var(--fg-default)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.handle}</span>
                            <span className="t-small">{a.followers}</span>
                          </div>
                        ))}
                        {accounts.length > 2 && (
                          <div className="t-small">+ {accounts.length - 2} more</div>
                        )}
                      </div>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <Btn kind="ghost" size="sm" icon={I.Plus} onClick={() => setOpenConnect(d)}>Add account</Btn>
                        <Btn kind="ghost" size="sm" icon={I.Settings}>Manage</Btn>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="t-tiny" style={{ marginBottom: 6 }}>What we'll do</div>
                      <ul style={{ margin: 0, padding: '0 0 0 18px', font: '500 12px/1.6 var(--font-sans)', color: 'var(--fg-secondary)', marginBottom: 14 }}>
                        {d.perks.slice(0, 2).map(p => <li key={p}>{p}</li>)}
                      </ul>
                      <Btn kind="primary" size="sm" icon={I.Plus} onClick={() => setOpenConnect(d)}>Connect {d.name}</Btn>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Workflow integrations */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <I.Lightning size={16} stroke="var(--fg-default)"/>
          <span className="t-h5">Workflow integrations</span>
          <span className="t-small" style={{ marginLeft: 4 }}>everything else</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {WORKFLOW_INTEGRATIONS.map(w => (
            <div key={w.id} className="card card--hover" style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{
                width: 44, height: 44, borderRadius: 12,
                background: `${w.color}1A`, border: `1px solid ${w.color}44`,
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: w.color, flexShrink: 0,
              }}>
                {React.createElement(I[w.icon], { size: 20 })}
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: '600 14px/1.2 var(--font-sans)', color: 'var(--fg-strong)' }}>{w.name}</div>
                <div className="t-small" style={{ marginTop: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{w.blurb}</div>
              </div>
              <Btn kind="ghost" size="sm">Connect</Btn>
            </div>
          ))}
        </div>

        {/* Multi-post explainer */}
        <div className="card" style={{ marginTop: 24, padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <I.Spark size={16} stroke="var(--accent-fg)"/>
            <span className="t-h5">One video. Auto-reformatted for every platform.</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 1, background: 'var(--border-hairline)' }}>
            {[
              { p: 'YouTube',  ar: '16:9',  len: '≤ 12 min',  cap: '5,000 ch', col: '#FF0000' },
              { p: 'Shorts',   ar: '9:16',  len: '≤ 60 s',    cap: '5,000 ch', col: '#FF0000' },
              { p: 'Instagram',ar: '9:16',  len: '≤ 90 s',    cap: '2,200 ch · 30 #', col: '#E1306C' },
              { p: 'TikTok',   ar: '9:16',  len: '≤ 10 min',  cap: '2,200 ch · # auto', col: '#000000' },
              { p: 'X',        ar: '16:9',  len: '≤ 2:20',    cap: '280 ch (thread)', col: '#0F1419' },
            ].map((m, i) => (
              <div key={i} style={{ padding: 16, background: 'var(--bg-surface)' }}>
                <span style={{ width: 28, height: 28, borderRadius: 8, background: `${m.col}1A`, border: `1px solid ${m.col}44`, color: m.col, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', font: '700 11px/1 var(--font-sans)' }}>{m.p[0]}</span>
                <div style={{ font: '600 13px/1.2 var(--font-sans)', color: 'var(--fg-strong)', marginTop: 10 }}>{m.p}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginTop: 8 }}>
                  <KVRow k="Aspect" v={m.ar}/>
                  <KVRow k="Length" v={m.len}/>
                  <KVRow k="Caption" v={m.cap}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {openConnect && <ConnectDestinationModal d={openConnect} onClose={() => setOpenConnect(null)}/>}
    </div>
  );
}

function KVRow({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
      <span className="t-tiny">{k}</span>
      <span style={{ font: '500 11px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{v}</span>
    </div>
  );
}

function ConnectDestinationModal({ d, onClose }) {
  return (
    <Modal open={true} onClose={onClose} width={520}>
      <div style={{ padding: 26 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <span style={{
            width: 44, height: 44, borderRadius: 12,
            background: d.color, color: 'white',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.20)',
          }}>{React.createElement(I[d.icon], { size: 22 })}</span>
          <div style={{ flex: 1 }}>
            <div className="t-h4">Connect {d.name}</div>
            <div className="t-small" style={{ marginTop: 2 }}>OAuth · you can disconnect any time</div>
          </div>
          <button className="btn btn--ghost btn--icon btn--sm" onClick={onClose}><I.Close size={14}/></button>
        </div>

        <div className="t-tiny" style={{ marginBottom: 8 }}>We'll ask for these permissions</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 18 }}>
          {d.scopes.map(s => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: 'var(--surface-subtle)', borderRadius: 8 }}>
              <I.Check size={14} stroke="var(--success)"/>
              <span style={{ font: '500 13px/1 var(--font-sans)', color: 'var(--fg-default)' }}>{s}</span>
            </div>
          ))}
        </div>

        <div className="t-tiny" style={{ marginBottom: 8 }}>What we won't do</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 22 }}>
          {['Read your DMs','Post without your approval','Share your data with third parties'].map(s => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: 'var(--surface-subtle)', borderRadius: 8 }}>
              <I.Close size={14} stroke="var(--fg-faint)"/>
              <span style={{ font: '500 13px/1 var(--font-sans)', color: 'var(--fg-muted)' }}>{s}</span>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Btn kind="ghost" onClick={onClose}>Cancel</Btn>
          <button className="btn btn--primary" style={{ background: d.color, borderColor: d.color }}>
            {React.createElement(I[d.icon], { size: 16 })}
            Sign in with {d.name}
          </button>
        </div>
      </div>
    </Modal>
  );
}

window.IntegrationsScreen = IntegrationsScreen;
window.PUBLISHING_DESTINATIONS = PUBLISHING_DESTINATIONS;
window.CONNECTED_ACCOUNTS = CONNECTED_ACCOUNTS;
